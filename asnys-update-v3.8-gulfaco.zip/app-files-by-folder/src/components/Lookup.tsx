import { useState } from 'react';
import { q, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { useAction, useLoad } from './ui';

/** A drop-down of standard choices plus the company's own (contract types, sectors), with "+ Add new…" at the end. */
export function LookupSelect({ list, base, value, onChange, label, id, emptyLabel = '—' }: {
  list: 'contract_type' | 'sector'; base: [string, string][]; value: string; onChange: (v: string) => void; label: string; id: string; emptyLabel?: string;
}) {
  const { cid, can } = useSession();
  const act = useAction();
  const [adding, setAdding] = useState<string | null>(null);
  const { data, reload } = useLoad(() => q<any[]>(supabase.from('lookup_values').select('code,label').eq('company_id', cid).eq('list', list).order('label') as any).catch(() => [] as any[]), [cid, list]);
  const own = (data || []).map(x => [x.code, x.label] as [string, string]).filter(([c]) => !base.some(b => b[0] === c));
  const all = [...base, ...own];
  const canAdd = can('accountant', 'sales', 'project_manager');
  const save = () => act.run(async () => {
    const lab = (adding || '').trim();
    if (lab.length < 2) throw new Error('Type the new name.');
    const code = lab.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 40) || 'other';
    if (!all.some(x => x[0] === code)) await q(supabase.from('lookup_values').insert({ company_id: cid, list, code, label: lab }) as any);
    reload(); onChange(code); setAdding(null);
  }, 'Added to the list');
  if (adding !== null) return <div className="field"><label htmlFor={id + '-new'}>{label}: new</label>
    <div style={{ display: 'flex', gap: 6 }}><input id={id + '-new'} autoFocus value={adding} onChange={e => setAdding(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); save(); } }} placeholder="e.g. Framework agreement" />
      <button className="btn small primary" type="button" disabled={act.busy} onClick={save}>Add</button><button className="btn small ghost" type="button" onClick={() => setAdding(null)}>Cancel</button></div></div>;
  return <div className="field"><label htmlFor={id}>{label}</label>
    <select id={id} value={value || ''} onChange={e => e.target.value === '__add' ? setAdding('') : onChange(e.target.value)}>
      <option value="">{emptyLabel}</option>
      {all.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      {value && !all.some(x => x[0] === value) && <option value={value}>{value}</option>}
      {canAdd && <option value="__add">+ Add new…</option>}
    </select></div>;
}

/** The label of a code from the standard list or the company's own list. */
export function useLookupLabel(list: 'contract_type' | 'sector', base: [string, string][]) {
  const { cid } = useSession();
  const { data } = useLoad(() => q<any[]>(supabase.from('lookup_values').select('code,label').eq('company_id', cid).eq('list', list) as any).catch(() => [] as any[]), [cid, list]);
  return (code?: string | null) => code ? base.find(x => x[0] === code)?.[1] || (data || []).find(x => x.code === code)?.label || code : '';
}
