import { useState } from 'react';
import { q, rpc, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { cedis, money, today } from '../lib/format';
import { downloadCsv } from '../lib/download';
import { readSheet, toIsoDate, toNum } from '../lib/sheet';
import { Empty, Field, PageHead, Panel, useAction } from '../components/ui';

type Kind = 'customers' | 'suppliers' | 'products' | 'employees' | 'accounts' | 'opening_tb' | 'open_invoices' | 'open_bills';
/** aliases: other headings accepted, e.g. the column names in QuickBooks Online exports. */
type Col = { key: string; label: string; required?: boolean; kind?: 'num' | 'date' | 'bool'; example: string; aliases?: string[] };
const SPECS: Record<Kind, { title: string; who: string; cols: Col[]; note: string }> = {
  customers: { title: 'Customers', who: 'accountant or sales', note: 'Opening balance = what the customer owed on the opening date. It becomes an open item you can collect against, age and put on a statement.',
    cols: [{ key: 'name', label: 'Name', required: true, example: 'Kumasi Mart Ltd', aliases: ['Customer', 'Customer full name', 'Display name', 'Company name', 'Company'] }, { key: 'phone', label: 'Phone', example: '0244123456', aliases: ['Phone numbers', 'Main phone', 'Mobile'] }, { key: 'email', label: 'Email', example: 'accounts@kumasimart.com' },
      { key: 'tin', label: 'TIN', example: 'C0012345678', aliases: ['Tax ID', 'Business ID No', 'Tax registration number', 'Resale no', 'Tax resale no'] }, { key: 'city', label: 'Town', example: 'Kumasi', aliases: ['Billing city', 'Bill city'] }, { key: 'address', label: 'Address', example: 'AK-039-5028', aliases: ['Billing address', 'Bill address', 'Full billing address'] },
      { key: 'contact_name', label: 'Contact person', example: 'Kofi Mensah', aliases: ['Full name', 'Contact', 'Contact name'] },
      { key: 'opening_balance', label: 'Opening balance', kind: 'num', example: '1500' }, { key: 'reference', label: 'Old invoice no.', example: 'INV-OLD-77' }, { key: 'due_date', label: 'Due date', kind: 'date', example: '2026-12-15' }] },
  suppliers: { title: 'Suppliers', who: 'accountant', note: 'Opening balance = what you owed the supplier on the opening date.',
    cols: [{ key: 'name', label: 'Name', required: true, example: 'Tema Wholesale', aliases: ['Vendor', 'Supplier', 'Display name', 'Company name', 'Company'] }, { key: 'phone', label: 'Phone', example: '0302123456', aliases: ['Phone numbers', 'Main phone', 'Mobile'] }, { key: 'email', label: 'Email', example: '' },
      { key: 'tin', label: 'TIN', example: '', aliases: ['Tax ID', 'Business ID No', 'Tax registration number'] }, { key: 'city', label: 'Town', example: 'Tema', aliases: ['Billing city'] }, { key: 'address', label: 'Address', example: '', aliases: ['Billing address', 'Full billing address', 'Address'] },
      { key: 'contact_name', label: 'Contact person', example: '', aliases: ['Full name', 'Contact', 'Contact name'] },
      { key: 'opening_balance', label: 'Opening balance', kind: 'num', example: '800' }, { key: 'reference', label: 'Their invoice no.', example: 'SUP-991' }, { key: 'due_date', label: 'Due date', kind: 'date', example: '' }] },
  products: { title: 'Items and opening stock', who: 'accountant or sales', note: 'Opening quantity and unit cost post the stock value to the books on the opening date.',
    cols: [{ key: 'sku', label: 'SKU', example: 'RIC-25' }, { key: 'name', label: 'Name', required: true, example: 'Rice 25 kg', aliases: ['Product/Service Name', 'Product/Service', 'Product', 'Item name'] }, { key: 'unit', label: 'Unit', example: 'bag' },
      { key: 'price', label: 'Selling price', kind: 'num', example: '520', aliases: ['Sales price', 'Sales Price / Rate', 'Rate', 'Price'] }, { key: 'taxable', label: 'VAT applies (yes/no)', kind: 'bool', example: 'yes', aliases: ['Taxable'] }, { key: 'reorder_level', label: 'Reorder level', kind: 'num', example: '20', aliases: ['Reorder point'] },
      { key: 'category', label: 'Category', example: 'Food' }, { key: 'barcode', label: 'Barcode', example: '' }, { key: 'item_type', label: 'Type (stock/non_stock/service)', example: 'stock', aliases: ['Type', 'Item type'] }, { key: 'reorder_qty', label: 'Reorder quantity', kind: 'num', example: '50' },
      { key: 'opening_qty', label: 'Opening quantity', kind: 'num', example: '100', aliases: ['Qty on hand', 'Quantity on hand', 'QOH'] }, { key: 'opening_cost', label: 'Opening unit cost', kind: 'num', example: '410', aliases: ['Purchase cost', 'Cost'] }] },
  employees: { title: 'Employees', who: 'HR', note: 'Branch and cost centre use the short codes set under Settings. Pay method is bank, momo or cash.',
    cols: [{ key: 'full_name', label: 'Full name', required: true, example: 'Ama Owusu' }, { key: 'staff_no', label: 'Staff no.', example: 'E001' }, { key: 'job_title', label: 'Job title', example: 'Accountant' },
      { key: 'department', label: 'Department', example: 'Finance' }, { key: 'hire_date', label: 'Hire date', kind: 'date', example: '2024-03-01' }, { key: 'basic_salary', label: 'Basic salary', kind: 'num', required: true, example: '4500' },
      { key: 'allowances', label: 'Allowances', kind: 'num', example: '600' }, { key: 'ghana_card', label: 'Ghana Card', example: 'GHA-000000000-0' }, { key: 'ssnit_no', label: 'SSNIT no.', example: 'C123456789012' },
      { key: 'tin', label: 'TIN', example: '' }, { key: 'pay_method', label: 'Pay method', example: 'bank' }, { key: 'bank_name', label: 'Bank', example: 'GCB Bank' }, { key: 'bank_branch', label: 'Bank branch', example: 'Adum' },
      { key: 'bank_account', label: 'Account no.', example: '1021130000001' }, { key: 'momo_number', label: 'MoMo number', example: '' }, { key: 'phone', label: 'Phone', example: '0244000000' },
      { key: 'email', label: 'Email', example: '' }, { key: 'branch', label: 'Branch code', example: 'KSI' }, { key: 'cost_centre', label: 'Cost centre code', example: 'OPS' }, { key: 'is_junior', label: 'Junior staff (yes/no)', kind: 'bool', example: 'no' }] },
  opening_tb: { title: 'Opening trial balance', who: 'accountant', note: 'All accounts except receivables, payables and stock (those come from the customer, supplier and product imports). Any difference goes to 3050 Opening balance equity.',
    cols: [{ key: 'code', label: 'Account code', example: '1100', aliases: ['Account #', 'Account number', 'Number', 'Account'] }, { key: 'name', label: 'Account name (for reference)', example: 'Bank account', aliases: ['Account name'] },
      { key: 'debit', label: 'Debit', kind: 'num', example: '25000' }, { key: 'credit', label: 'Credit', kind: 'num', example: '' }] },
  accounts: { title: 'Chart of accounts', who: 'accountant', note: 'Adds accounts you used in QuickBooks that Asnys does not have yet (matched by number, then by name). QuickBooks account types are understood (Bank, Expenses, Other Current Liabilities…). Import this before the trial balance.',
    cols: [{ key: 'code', label: 'Account number', example: '6450', aliases: ['Account #', 'Number', 'Code', 'Account code'] }, { key: 'name', label: 'Account name', required: true, example: 'Site security', aliases: ['Account', 'Name', 'Full name'] },
      { key: 'type', label: 'Type', required: true, example: 'Expenses', aliases: ['Account type'] }, { key: 'detail', label: 'Detail type', example: '' }] },
  open_invoices: { title: 'Unpaid customer invoices', who: 'accountant', note: 'From QuickBooks: Reports → A/R Aging Detail (or Open Invoices) → Export to Excel. Each unpaid invoice becomes an opening receivable with its own number and due date, so you can collect against it. New customer names are created.',
    cols: [{ key: 'party', label: 'Customer', required: true, example: 'Volta River Authority', aliases: ['Name', 'Customer full name', 'Customer name'] }, { key: 'ref', label: 'Invoice no.', example: '1043', aliases: ['Num', 'No', 'No.', 'Number', 'Invoice number'] },
      { key: 'date', label: 'Date', kind: 'date', example: '2026-09-30', aliases: ['Transaction date', 'Invoice date'] }, { key: 'due', label: 'Due date', kind: 'date', example: '2026-10-30' },
      { key: 'amount', label: 'Open balance', kind: 'num', required: true, example: '12500', aliases: ['Open amount', 'Balance', 'Amount due', 'Balance due'] }, { key: 'txn', label: 'Transaction type', example: 'Invoice', aliases: ['Type'] }] },
  open_bills: { title: 'Unpaid supplier bills', who: 'accountant', note: 'From QuickBooks: Reports → A/P Aging Detail (or Unpaid Bills) → Export to Excel. Each unpaid bill becomes an opening payable. New supplier names are created.',
    cols: [{ key: 'party', label: 'Supplier', required: true, example: 'Tema Steel', aliases: ['Vendor', 'Name', 'Vendor name'] }, { key: 'ref', label: 'Bill no.', example: 'TS-881', aliases: ['Num', 'No', 'No.', 'Number', 'Ref no'] },
      { key: 'date', label: 'Date', kind: 'date', example: '2026-09-30', aliases: ['Transaction date', 'Bill date'] }, { key: 'due', label: 'Due date', kind: 'date', example: '2026-10-30' },
      { key: 'amount', label: 'Open balance', kind: 'num', required: true, example: '8000', aliases: ['Open amount', 'Balance', 'Amount due', 'Balance due'] }, { key: 'txn', label: 'Transaction type', example: 'Bill', aliases: ['Type'] }] },
};
/** QuickBooks account types → Asnys account types. */
function qbType(t: string): string {
  const x = String(t || '').toLowerCase();
  if (/^(asset|liability|equity|income|expense)$/.test(x)) return x;
  if (/receivable|bank|current asset|fixed asset|other asset|inventory|cash/.test(x)) return 'asset';
  if (/payable|credit card|liabilit|loan/.test(x)) return 'liability';
  if (/equity|capital|retained/.test(x)) return 'equity';
  if (/income|revenue|sales/.test(x)) return 'income';
  if (/expense|cost of goods|cogs|cost of sales/.test(x)) return 'expense';
  return '';
}
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');
const yes = (v: string) => /^(y|yes|true|1|x)$/i.test(String(v || '').trim());

export function ImportPage() {
  const { cid, can } = useSession();
  const act = useAction();
  const [kind, setKind] = useState<Kind>('customers');
  const [rows, setRows] = useState<any[] | null>(null);
  const [fileName, setFileName] = useState('');
  const [openDate, setOpenDate] = useState(() => { const d = new Date(); d.setUTCDate(0); return d.toISOString().slice(0, 10); });
  const [progress, setProgress] = useState('');
  const [done, setDone] = useState<string | null>(null);
  const spec = SPECS[kind];
  const allowed = kind === 'employees' ? can('hr') : ['opening_tb', 'suppliers', 'accounts', 'open_invoices', 'open_bills'].includes(kind) ? can('accountant') : can('accountant', 'sales');

  const load = (file: File) => act.run(async () => {
    setDone(null); setFileName(file.name);
    const grid = await readSheet(file);
    if (grid.length < 2) throw new Error('The file has no data rows under the header.');
    // QuickBooks Online exports start with a few title lines (company, report name, dates): find the real heading row.
    const names = (c: Col) => [c.label, c.key, ...(c.aliases || [])].map(norm);
    const score = (row: any[]) => { const h = row.map(x => norm(String(x ?? ''))); return spec.cols.filter(c => names(c).some(n => h.includes(n))).length; };
    let hr = 0; for (let i = 1; i < Math.min(grid.length, 15); i++) if (score(grid[i]) > score(grid[hr])) hr = i;
    const header = grid[hr].map(x => norm(String(x ?? '')));
    const used = new Set<number>();
    const idx = spec.cols.map(c => { for (const n of names(c)) { const j = header.findIndex((h, k) => h === n && !used.has(k)); if (j >= 0) { used.add(j); return j; } } return -1; });
    if (kind === 'opening_tb' && idx[0] < 0 && idx[2] >= 0) idx[0] = 0;   // QuickBooks trial balance: the account is the unnamed first column
    const missing = spec.cols.filter((c, i) => c.required && idx[i] < 0);
    if (missing.length) throw new Error(`Missing column${missing.length > 1 ? 's' : ''}: ${missing.map(m => m.label).join(', ')}. Download the template to see the headings.`);
    let ctx: any = {};
    if (kind === 'employees') {
      ctx.branches = await q<any[]>(supabase.from('branches').select('id,code').eq('company_id', cid) as any);
      ctx.centres = await q<any[]>(supabase.from('cost_centres').select('id,code').eq('company_id', cid) as any);
    }
    if (['customers', 'suppliers'].includes(kind)) ctx.existing = new Set((await fetchNames(kind as any, cid)).map(n => n.toLowerCase()));
    if (kind === 'products') ctx.existing = new Set((await q<any[]>(supabase.from('products').select('sku').eq('company_id', cid) as any)).map(p => String(p.sku).toLowerCase()));
    const seen = new Set<string>();
    if (kind === 'opening_tb' || kind === 'accounts') ctx.accounts = await q<any[]>(supabase.from('accounts').select('id,code,name,system_key,type').eq('company_id', cid) as any);
    const isTotal = (r: any[]) => { const first = r.map(x => String(x ?? '').trim()).find(Boolean) || ''; return !first || /^total\b|^total for /i.test(first); };
    const out = grid.slice(hr + 1).map((r, n) => ({ r, n: n + hr + 2 })).filter(x => !isTotal(x.r)).map(({ r, n }) => {
      const v: any = { _row: n, _errors: [] as string[] };
      spec.cols.forEach((c, i) => {
        const raw = idx[i] >= 0 ? String(r[idx[i]] ?? '').trim() : '';
        if (c.kind === 'num') { const x = toNum(raw); if (Number.isNaN(x)) v._errors.push(`${c.label} is not a number`); v[c.key] = x; }
        else if (c.kind === 'date') { const d = toIsoDate(raw); if (raw && !d) v._errors.push(`${c.label} is not a date`); v[c.key] = d; }
        else if (c.kind === 'bool') v[c.key] = raw ? yes(raw) : null;
        else v[c.key] = raw;
        if (c.required && (v[c.key] === '' || v[c.key] === null)) v._errors.push(`${c.label} is required`);
      });
      if (kind === 'products') {
        if (!v.sku) v.sku = String(v.name || '').toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
        const t = String(v.item_type || '').toLowerCase();
        v.item_type = /non.?inv|non.?stock/.test(t) ? 'non_stock' : /serv/.test(t) ? 'service' : /bundle/.test(t) ? 'non_stock' : 'stock';
      }
      const key = String(v.name || v.sku || v.full_name || v.code || '').toLowerCase();
      if (['customers', 'suppliers', 'products'].includes(kind)) {
        const k = kind === 'products' ? String(v.sku).toLowerCase() : key;
        if (ctx.existing.has(k)) v._skip = 'Already exists';
        if (seen.has(k)) v._errors.push('Duplicate in this file'); seen.add(k);
      }
      if (v.opening_balance != null && v.opening_balance < 0) v._errors.push('Opening balance cannot be negative');
      if (kind === 'products' && (v.opening_qty || 0) > 0 && !(v.opening_cost > 0)) v._errors.push('Opening unit cost is needed with an opening quantity');
      if (kind === 'employees') {
        if (v.branch) { v.branch_id = ctx.branches.find((b: any) => b.code.toLowerCase() === v.branch.toLowerCase())?.id; if (!v.branch_id) v._errors.push(`Branch ${v.branch} not found`); }
        if (v.cost_centre) { v.cost_centre_id = ctx.centres.find((b: any) => b.code.toLowerCase() === v.cost_centre.toLowerCase())?.id; if (!v.cost_centre_id) v._errors.push(`Cost centre ${v.cost_centre} not found`); }
        if (v.pay_method && !['bank', 'momo', 'cash'].includes(v.pay_method.toLowerCase())) v._errors.push('Pay method must be bank, momo or cash');
      }
      if (kind === 'accounts') {
        const m = String(v.name).match(/^(\d{3,6})\s+(.+)$/); if (!v.code && m) { v.code = m[1]; v.name = m[2]; }
        v.name = String(v.name).split(':').pop()!.trim();
        v.type = qbType(v.type);
        if (!v.type) v._errors.push('Type not recognised');
        const hit = ctx.accounts.find((x: any) => (v.code && x.code === v.code) || x.name.toLowerCase() === v.name.toLowerCase());
        if (hit) v._skip = `Already in Asnys as ${hit.code} ${hit.name}`;
        if (seen.has(v.name.toLowerCase())) v._errors.push('Duplicate in this file'); seen.add(v.name.toLowerCase());
      }
      if (kind === 'open_invoices' || kind === 'open_bills') {
        if (v.txn && !/invoice|bill|opening|journal/i.test(v.txn)) v._skip = `${v.txn} (not ${kind === 'open_invoices' ? 'an invoice' : 'a bill'})`;
        if (!(v.amount > 0)) v._skip = v._skip || 'Nothing open';
      }
      if (kind === 'opening_tb') {
        const raw = String(v.code || '').trim(); const m = raw.match(/^(\d{3,6})\b\s*(.*)$/);
        const nm = (m ? m[2] : raw).split(':').pop()!.trim().toLowerCase();
        const a = ctx.accounts.find((x: any) => x.code === raw) || (m && ctx.accounts.find((x: any) => x.code === m[1])) || ctx.accounts.find((x: any) => x.name.toLowerCase() === nm);
        if (!a) v._errors.push(`Account "${raw}" not found — import the chart of accounts first, or rename it`);
        else { v.account_id = a.id; v.account_name = a.name; if (['ar', 'ap', 'inventory', 'opening'].includes(a.system_key)) v._skip = `${a.name} comes from the unpaid invoices/bills or product import`; }
        if (!(v.debit > 0) && !(v.credit > 0)) v._skip = 'No amount';
      }
      return v;
    });
    setRows(out);
  });

  const good = (rows || []).filter(r => !r._errors.length && !r._skip);
  const bad = (rows || []).filter(r => r._errors.length);
  const tbDr = kind === 'opening_tb' ? good.reduce((s, r) => s + (r.debit || 0), 0) : 0, tbCr = kind === 'opening_tb' ? good.reduce((s, r) => s + (r.credit || 0), 0) : 0;

  const run = () => act.run(async () => {
    if (bad.length) throw new Error(`Fix the ${bad.length} row${bad.length === 1 ? '' : 's'} with problems first (or remove them from the file).`);
    if (!can('accountant') && good.some(r => (r.opening_balance || 0) > 0)) throw new Error('Only an accountant can bring in opening balances. Remove the Opening balance column or ask an accountant to import.');
    let n = 0;
    const step = (label: string) => setProgress(`${label} ${++n} of ${good.length}…`);
    if (kind === 'opening_tb') {
      await rpc('post_opening_balances', { cid, p_date: openDate, p_lines: good.map(r => ({ account_id: r.account_id, debit: r.debit || 0, credit: r.credit || 0 })) });
      setDone(`Opening trial balance posted at ${openDate}${tbDr !== tbCr ? `; the difference of ${cedis(Math.abs(tbDr - tbCr))} went to 3050 Opening balance equity` : ''}.`);
    } else if (kind === 'customers' || kind === 'suppliers') {
      for (let i = 0; i < good.length; i += 200) {
        const batch = good.slice(i, i + 200);
        const ins = await q<any[]>(supabase.from(kind).insert(batch.map(r => ({ company_id: cid, name: r.name, phone: r.phone || null, email: r.email || null, tin: r.tin || null, city: r.city || null, address: r.address || null, contact_name: r.contact_name || null }))).select('id,name') as any);
        for (const r of batch) {
          step('Saving');
          if (r.opening_balance > 0) {
            const id = ins.find(x => x.name === r.name)?.id;
            await rpc(kind === 'customers' ? 'opening_receivable' : 'opening_payable', { [kind === 'customers' ? 'p_customer' : 'p_supplier']: id, p_date: openDate, p_amount: r.opening_balance, p_ref: r.reference || null, p_due: r.due_date || null });
          }
        }
      }
      setDone(`${good.length} ${kind} imported${good.some(r => r.opening_balance > 0) ? `, with opening balances totalling ${cedis(good.reduce((s, r) => s + (r.opening_balance || 0), 0))}` : ''}.`);
    } else if (kind === 'accounts') {
      const have = new Set((await q<any[]>(supabase.from('accounts').select('code').eq('company_id', cid) as any)).map(x => x.code));
      const base: Record<string, number> = { asset: 1800, liability: 2800, equity: 3800, income: 4800, expense: 6800 };
      for (const r of good) {
        let code = r.code && !have.has(r.code) ? r.code : '';
        if (!code) { let c = base[r.type]; while (have.has(String(c))) c++; code = String(c); }
        have.add(code); step('Adding');
        await q(supabase.from('accounts').insert({ company_id: cid, code, name: r.name, type: r.type }) as any);
      }
      setDone(`${good.length} accounts added to the chart of accounts.`);
    } else if (kind === 'open_invoices' || kind === 'open_bills') {
      const table = kind === 'open_invoices' ? 'customers' : 'suppliers';
      const list = await q<any[]>(supabase.from(table).select('id,name').eq('company_id', cid) as any);
      const byName = new Map(list.map(x => [x.name.toLowerCase(), x.id]));
      for (const r of good) {
        step('Saving');
        let id = byName.get(r.party.toLowerCase());
        if (!id) { id = (await q<any>(supabase.from(table).insert({ company_id: cid, name: r.party }).select('id').single() as any)).id; byName.set(r.party.toLowerCase(), id); }
        await rpc(kind === 'open_invoices' ? 'opening_receivable' : 'opening_payable', { [kind === 'open_invoices' ? 'p_customer' : 'p_supplier']: id, p_date: r.date && r.date <= openDate ? r.date : openDate,
          p_amount: r.amount, p_ref: r.ref ? `QB ${r.ref}` : null, p_due: r.due || null });
      }
      setDone(`${good.length} unpaid ${kind === 'open_invoices' ? 'invoices' : 'bills'} brought in, totalling ${cedis(good.reduce((x, r) => x + r.amount, 0))}.`);
    } else if (kind === 'products') {
      for (let i = 0; i < good.length; i += 200) {
        const batch = good.slice(i, i + 200);
        const ins = await q<any[]>(supabase.from('products').insert(batch.map(r => ({ company_id: cid, sku: r.sku, name: r.name, unit: r.unit || 'each', price: r.price || 0, taxable: r.taxable ?? true, reorder_level: r.reorder_level || 0, reorder_qty: r.reorder_qty || 0, category: r.category || null, barcode: r.barcode || null, item_type: ['non_stock', 'service'].includes(String(r.item_type || '').toLowerCase().replace(/[- ]/g, '_')) ? String(r.item_type).toLowerCase().replace(/[- ]/g, '_') : 'stock' }))).select('id,sku') as any);
        for (const r of batch) {
          step('Saving');
          if ((r.opening_qty || 0) > 0) await rpc('adjust_stock', { p_product: ins.find(x => x.sku === r.sku)?.id, p_qty: r.opening_qty, p_unit_cost: r.opening_cost, p_date: openDate, p_kind: 'opening', p_note: 'Opening stock (import)' });
        }
      }
      setDone(`${good.length} products imported${good.some(r => r.opening_qty > 0) ? `, opening stock worth ${cedis(good.reduce((s, r) => s + (r.opening_qty || 0) * (r.opening_cost || 0), 0))} posted` : ''}.`);
    } else {
      for (let i = 0; i < good.length; i += 200) {
        await q(supabase.from('employees').insert(good.slice(i, i + 200).map(r => ({ company_id: cid, full_name: r.full_name, staff_no: r.staff_no || null, job_title: r.job_title || null, department: r.department || null,
          hire_date: r.hire_date, basic_salary: r.basic_salary || 0, allowances: r.allowances || 0, ghana_card: r.ghana_card || null, ssnit_no: r.ssnit_no || null, tin: r.tin || null,
          pay_method: (r.pay_method || 'bank').toLowerCase(), bank_name: r.bank_name || null, bank_branch: r.bank_branch || null, bank_account: r.bank_account || null, momo_number: r.momo_number || null,
          phone: r.phone || null, email: r.email || null, branch_id: r.branch_id || null, cost_centre_id: r.cost_centre_id || null, is_junior: !!r.is_junior }))) as any);
        n += Math.min(200, good.length - i); setProgress(`Saving ${n} of ${good.length}…`);
      }
      setDone(`${good.length} employees imported.`);
    }
    setProgress(''); setRows(null);
  }, 'Import finished');

  return <>
    <PageHead title="Import from a spreadsheet" sub="Bring customers, suppliers, products, staff and opening balances across from your old system or Excel in one go." />
    <div className="actions">{(Object.keys(SPECS) as Kind[]).map(k => <button key={k} type="button" className={'btn small' + (kind === k ? ' primary' : '')} onClick={() => { setKind(k); setRows(null); setDone(null); }}>{SPECS[k].title}</button>)}</div>
    <Panel title={spec.title} pad>
      <ol style={{ margin: '0 0 12px', paddingLeft: 20, display: 'grid', gap: 4 }}>
        <li>Download the template and fill one row per {kind === 'opening_tb' ? 'account' : kind === 'employees' ? 'person' : kind.replace(/s$/, '')}. Keep the headings.</li>
        <li>Save it as Excel (.xlsx) or CSV and choose it below. Nothing is saved until you press Import.</li>
      </ol>
      <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>{spec.note} Needs the {spec.who} role.</p>
      <div className="filters">
        <button className="btn" type="button" style={{ alignSelf: 'end' }} onClick={() => downloadCsv(`asnys-template-${kind}`, spec.cols.map(c => c.label), [spec.cols.map(c => c.example)])}>Download template</button>
        {['customers', 'suppliers', 'products', 'opening_tb', 'open_invoices', 'open_bills'].includes(kind) && <Field label="Opening balance date" id="im-date" type="date" value={openDate} onChange={setOpenDate} />}
        <div className="field"><label htmlFor="im-file">Spreadsheet (.xlsx or .csv)</label>
          <input id="im-file" type="file" accept=".xlsx,.csv,text/csv" disabled={!allowed} onChange={e => { const f = e.target.files?.[0]; if (f) load(f); e.target.value = ''; }} /></div>
      </div>
      {!allowed && <p style={{ color: 'var(--bad)', margin: 0 }}>Your role cannot import {spec.title.toLowerCase()}.</p>}
      {done && <div className="note" role="status" style={{ marginTop: 12 }}>{done}</div>}
    </Panel>
    {rows && <Panel title={`${fileName}: ${good.length} ready, ${bad.length} with problems${rows.filter(r => r._skip).length ? `, ${rows.filter(r => r._skip).length} skipped` : ''}`}
      actions={<button className="btn primary" type="button" disabled={act.busy || !good.length || bad.length > 0} onClick={run}>{progress || `Import ${good.length}`}</button>}>
      {kind === 'opening_tb' && <div className="body">Debits {cedis(tbDr)} · Credits {cedis(tbCr)}{tbDr !== tbCr && <> · difference {cedis(Math.abs(tbDr - tbCr))} will go to 3050 Opening balance equity</>}</div>}
      {rows.length ? <div className="scroll"><table>
        <thead><tr><th>Row</th>{spec.cols.slice(0, 6).map(c => <th key={c.key}>{c.label}</th>)}<th>Check</th></tr></thead>
        <tbody>{[...bad, ...rows.filter(r => !r._errors.length)].slice(0, 200).map(r => <tr key={r._row} style={r._skip ? { opacity: .5 } : undefined}>
          <td className="num">{r._row}</td>{spec.cols.slice(0, 6).map(c => <td key={c.key} className={c.kind === 'num' ? 'num' : ''}>{c.kind === 'num' ? (r[c.key] != null && !Number.isNaN(r[c.key]) ? money(r[c.key]) : '') : c.kind === 'bool' ? (r[c.key] == null ? '' : r[c.key] ? 'Yes' : 'No') : r[c.key]}</td>)}
          <td>{r._errors.length ? <span style={{ color: 'var(--bad)', fontSize: 13 }}>{r._errors.join('; ')}</span> : r._skip ? <span className="muted" style={{ fontSize: 13 }}>{r._skip}, skipped</span> : <span className="pill good">OK</span>}</td></tr>)}</tbody>
      </table></div> : <Empty>No rows.</Empty>}
      {rows.length > 200 && <div className="body muted" style={{ fontSize: 13 }}>Showing the first 200 rows (problems first). All {rows.length} are checked.</div>}
    </Panel>}
  </>;
}

async function fetchNames(table: 'customers' | 'suppliers', cid: string) {
  const out: string[] = [];
  for (let a = 0; a < 100000; a += 1000) {
    const r = await q<any[]>(supabase.from(table).select('name').eq('company_id', cid).range(a, a + 999) as any);
    out.push(...r.map(x => x.name)); if (r.length < 1000) break;
  }
  return out;
}
