import { useState } from 'react';
import { q, rpc, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { ConfirmButton, Empty, Field, FormModal, Panel, useAction, useLoad } from '../components/ui';

/** Shrinks a picked image to at most 600×240 and returns a PNG data URL (keeps transparency). */
export function shrinkImage(file: File, maxW = 600, maxH = 240): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!/^image\/(png|jpe?g|webp|gif|svg\+xml)$/.test(file.type)) return reject(new Error('Choose a PNG, JPG, WebP or SVG image.'));
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, maxW / img.width, maxH / img.height);
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
      c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src);
      resolve(c.toDataURL('image/png'));
    };
    img.onerror = () => reject(new Error('That image could not be read.'));
    img.src = URL.createObjectURL(file);
  });
}

export function LogoPanel() {
  const { cid, company, reload, can } = useSession();
  const act = useAction();
  if (!can()) return null;
  const logo = (company as any)?.logo_data as string | null;
  const save = (v: string | null) => act.run(async () => { await q(supabase.from('companies').update({ logo_data: v }).eq('id', cid) as any); await reload(); }, v ? 'Logo saved' : 'Logo removed');
  return <Panel title="Company logo" pad>
    <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>Printed at the top of invoices, quotes, purchase orders, payslips, statements and reports, and shown on the screen versions. A wide logo with a transparent background looks best.</p>
    <div className="filters" style={{ alignItems: 'center' }}>
      <div style={{ width: 200, height: 80, border: '1px dashed var(--line)', borderRadius: 8, display: 'grid', placeItems: 'center', background: '#fff' }}>
        {logo ? <img src={logo} alt="Company logo" style={{ maxWidth: 190, maxHeight: 70, objectFit: 'contain' }} /> : <span className="muted">No logo</span>}</div>
      <label className="btn primary" style={{ cursor: 'pointer' }}>{logo ? 'Change logo' : 'Upload logo'}
        <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" style={{ display: 'none' }}
          onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f) act.run(async () => { const d = await shrinkImage(f); if (d.length > 390000) throw new Error('That logo is too detailed. Use a smaller PNG.'); await q(supabase.from('companies').update({ logo_data: d }).eq('id', cid) as any); await reload(); }, 'Logo saved'); }} /></label>
      {logo && <button className="btn ghost" type="button" disabled={act.busy} onClick={() => save(null)}>Remove</button>}
    </div>
  </Panel>;
}

export function InvoicingRulesPanel() {
  const { cid, can } = useSession();
  const act = useAction();
  const { data, reload } = useLoad(() => q<any>(supabase.from('companies').select('strict_invoices,wht_default_rate').eq('id', cid).single() as any), [cid]);
  const [rate, setRate] = useState<string | null>(null);
  if (!can('accountant') || !data) return null;
  const upd = (patch: any, msg: string) => act.run(async () => { await q(supabase.from('companies').update(patch).eq('id', cid) as any); reload(); }, msg);
  return <Panel title="Invoice rules" pad>
    <label className="check"><input type="checkbox" checked={!!data.strict_invoices} onChange={e => upd({ strict_invoices: e.target.checked }, 'Saved')} />
      <span><b>Strict invoices</b> — an invoice can only be posted when the customer has a TIN, the invoice has a reference, and it is tied to a quotation, contract, project or the customer's PO number.</span></label>
    <div className="filters" style={{ marginTop: 12 }}>
      <Field label="Default withholding tax rate for WHT-agent customers (%)" id="ir-wht" type="number" step="0.5" min="0" max="30" value={rate ?? String(data.wht_default_rate)} onChange={setRate} />
      <button className="btn" type="button" style={{ marginBottom: 2 }} disabled={rate === null || act.busy} onClick={() => upd({ wht_default_rate: Number(rate) }, 'Default WHT rate saved')}>Save rate</button>
    </div>
    <p className="muted" style={{ fontSize: 13, marginBottom: 0 }}>Ghana rates: 7.5% for services and works contracts, 3% for goods, 5% for works by resident persons in some cases. Set each customer's own rate on the customer record if it differs.</p>
  </Panel>;
}

const NAMES: Record<string, string> = {
  INV: 'Sales invoices', QUO: 'Quotations', SO: 'Sales orders', CN: 'Credit notes', BILL: 'Supplier bills', PO: 'Purchase orders', GRN: 'Goods received',
  ADR: 'Procurement requests (ADR)', SR: 'Service requests (SR)', MRO: 'Material requests (MRO)', PR: 'Purchase requests (old)', SRQ: 'Stock requests (old)',
  JE: 'Journal entries', ADV: 'Cash advances', ARQ: 'Asset requests', AST: 'Assets', ATR: 'Asset transfers', TRF: 'Stock transfers', TR: 'Transfers',
  CASE: 'Support cases', CNT: 'Contracts', CON: 'Contract variations', TND: 'Tenders', PRJ: 'Projects', JOB: 'Jobs', PCR: 'Petty cash requests', PCV: 'Petty cash vouchers',
  RA: 'Requests', CB: 'Bonds & guarantees', OB: 'Obligations', OBB: 'Obligations', HSI: 'HSE inspections', INC: 'Incidents', CAPA: 'Corrective actions', PTW: 'Permits to work',
  TRN: 'Training', TRP: 'Trips', VRQ: 'Vehicle requests', WB: 'Waybills',
};

export function NumberingPanel() {
  const { cid, company, reload, can } = useSession();
  const act = useAction();
  const [code, setCode] = useState<string>((company as any)?.doc_prefix || '');
  const [edit, setEdit] = useState<Record<string, { prefix: string; next: string }>>({});
  const { data, reload: again } = useLoad(() => rpc<any[]>('number_settings', { cid }).catch(() => null), [cid]);
  if (!can('accountant')) return null;
  const saveCode = () => act.run(async () => { await rpc('set_numbering', { cid, p_code: code }); await reload(); again(); }, code ? `Numbers now start with ${code.toUpperCase()}-` : 'Company code removed');
  const saveRow = (k: string) => act.run(async () => {
    const e = edit[k]; await rpc('set_numbering', { cid, p_code: code, p_key: k, p_prefix: e.prefix || null, p_next: e.next ? Number(e.next) : null });
    setEdit(x => { const y = { ...x }; delete y[k]; return y; }); again();
  }, 'Numbering saved');
  return <Panel title="Document numbering">
    <div className="body">
      <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>Every number gets the company code in front, e.g. <b className="num">GUF-INV-00001</b>. You can also change each document's letters and the next number (for example to continue from QuickBooks). Numbers already issued do not change.</p>
      <div className="filters">
        <Field label="Company code (up to 6 letters or digits)" id="nb-code" value={code} onChange={v => setCode(v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))} placeholder="GUF" />
        <button className="btn primary" type="button" style={{ marginBottom: 2 }} disabled={act.busy} onClick={saveCode}>Save code</button>
      </div>
    </div>
    {data === null ? <Empty>Run the v3.4 database update to set numbering here.</Empty> : data && data.length ? <div className="scroll"><table>
      <thead><tr><th>Document</th><th>Letters</th><th className="r">Next number</th><th>Next will be</th><th></th></tr></thead>
      <tbody>{data.map(r => { const e = edit[r.key]; return <tr key={r.key}>
        <td>{NAMES[r.key] || r.key}</td>
        <td><input aria-label={`Letters for ${r.key}`} value={e ? e.prefix : r.prefix} style={{ width: 90 }} onChange={ev => setEdit({ ...edit, [r.key]: { prefix: ev.target.value.toUpperCase().replace(/[^A-Z0-9/-]/g, '').slice(0, 12), next: e?.next ?? String(r.next_value) } })} /></td>
        <td className="r"><input aria-label={`Next number for ${r.key}`} type="number" min="1" step="1" value={e ? e.next : r.next_value} style={{ width: 100, textAlign: 'right' }} onChange={ev => setEdit({ ...edit, [r.key]: { prefix: e?.prefix ?? r.prefix, next: ev.target.value } })} /></td>
        <td className="num">{e ? `${code ? code + '-' : ''}${e.prefix || r.prefix}-${String(e.next || r.next_value).padStart(5, '0')}` : r.example}</td>
        <td className="r">{e && <button className="btn small primary" type="button" disabled={act.busy} onClick={() => saveRow(r.key)}>Save</button>}</td></tr>; })}</tbody>
    </table></div> : <Empty>Numbers appear here once the first document of each kind is created.</Empty>}
  </Panel>;
}

/** One line for a bank account, as printed on invoices. */
export const bankLine = (b: any) => b ? [b.bank_name, b.branch, b.account_name && 'A/C name ' + b.account_name, 'A/C ' + b.account_no + (b.currency && b.currency !== 'GHS' ? ` (${b.currency})` : ''), b.swift && 'SWIFT ' + b.swift].filter(Boolean).join(', ') : '';

export function BanksPanel() {
  const { cid, can } = useSession();
  const act = useAction();
  const [edit, setEdit] = useState<any | null>(null);
  const { data, reload } = useLoad(() => q<any[]>(supabase.from('company_banks').select('*').eq('company_id', cid).order('sort').order('created_at') as any).catch(() => null), [cid]);
  if (!can('accountant') || data === null) return null;
  const save = () => act.run(async () => {
    const row = { bank_name: edit.bank_name.trim(), branch: edit.branch || null, account_name: edit.account_name || null, account_no: edit.account_no.trim(), swift: edit.swift || null,
      currency: (edit.currency || 'GHS').toUpperCase(), is_default: !!edit.is_default, active: edit.active !== false };
    if (row.is_default) await q(supabase.from('company_banks').update({ is_default: false }).eq('company_id', cid).neq('id', edit.id || '00000000-0000-0000-0000-000000000000') as any);
    if (edit.id) await q(supabase.from('company_banks').update(row).eq('id', edit.id) as any);
    else await q(supabase.from('company_banks').insert({ ...row, company_id: cid, sort: (data || []).length }) as any);
    setEdit(null); reload();
  }, 'Bank account saved');
  return <Panel title="Bank accounts for invoices" actions={<button className="btn small primary" type="button" onClick={() => setEdit({ bank_name: '', branch: '', account_name: '', account_no: '', swift: '', currency: 'GHS', is_default: !(data || []).length, active: true })}>Add bank account</button>}>
    {data && data.length ? <div className="scroll"><table>
      <thead><tr><th>Bank</th><th>Account</th><th>Currency</th><th></th><th></th></tr></thead>
      <tbody>{data.map(b => <tr key={b.id} style={b.active ? undefined : { opacity: .55 }}><td>{b.bank_name}{b.branch && <span className="muted"> · {b.branch}</span>}</td>
        <td className="num">{b.account_no}{b.account_name && <><br /><span className="muted">{b.account_name}</span></>}{b.swift && <span className="muted"> · SWIFT {b.swift}</span>}</td>
        <td className="num">{b.currency}</td><td>{b.is_default && <span className="pill good">Default</span>}{!b.active && <span className="pill">Not used</span>}</td>
        <td className="r"><button className="btn small ghost" type="button" onClick={() => setEdit({ ...b, branch: b.branch || '', account_name: b.account_name || '', swift: b.swift || '' })}>Edit</button></td></tr>)}</tbody>
    </table></div> : <Empty>No bank accounts yet: invoices print the "Bank details" text from Company details. Add your accounts here to choose one on each invoice (e.g. a USD account for USD invoices).</Empty>}
    {edit && <FormModal title={edit.id ? 'Edit bank account' : 'Add bank account'} busy={act.busy} onClose={() => setEdit(null)} onSave={save}
      danger={edit.id && <ConfirmButton className="btn danger" label="Delete" confirm="Delete this bank account? Invoices that used it keep printing nothing for it." onConfirm={() => act.run(async () => { await q(supabase.from('company_banks').delete().eq('id', edit.id) as any); setEdit(null); reload(); })} />}>
      <div className="grid-form">
        <Field label="Bank" id="bk-bank" value={edit.bank_name} onChange={v => setEdit({ ...edit, bank_name: v })} placeholder="e.g. Stanbic Bank Ghana" required />
        <Field label="Branch" id="bk-branch" value={edit.branch} onChange={v => setEdit({ ...edit, branch: v })} placeholder="e.g. Airport City" />
        <Field label="Account name" id="bk-name" value={edit.account_name} onChange={v => setEdit({ ...edit, account_name: v })} placeholder="Gulfaco Limited" />
        <Field label="Account number" id="bk-no" value={edit.account_no} onChange={v => setEdit({ ...edit, account_no: v })} required />
        <Field label="SWIFT / BIC (for foreign payments)" id="bk-swift" value={edit.swift} onChange={v => setEdit({ ...edit, swift: v.toUpperCase() })} />
        <Field label="Currency" id="bk-ccy" value={edit.currency} onChange={v => setEdit({ ...edit, currency: v.toUpperCase().slice(0, 3) })} placeholder="GHS" required />
      </div>
      <label className="check"><input type="checkbox" checked={!!edit.is_default} onChange={e => setEdit({ ...edit, is_default: e.target.checked })} /> Default account</label>
      <label className="check"><input type="checkbox" checked={edit.active !== false} onChange={e => setEdit({ ...edit, active: e.target.checked })} /> In use</label>
    </FormModal>}
  </Panel>;
}
