import { useState } from 'react';
import { q, rpc, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { longDate, today } from '../lib/format';
import { uploadDocFile } from '../components/ProjectDocs';
import { openAttachment } from '../components/ProjectPurchases';
import { ConfirmButton, Empty, Field, FormModal, PageHead, Panel, Select, useAction, useLoad } from '../components/ui';
import { DimensionsPanel } from './AdminPanels';

export const SUPPLIER_TYPES: [string, string][] = [['vendor', 'Vendor (goods and services)'], ['subcontractor', 'Subcontractor (works on site)'], ['both', 'Both']];
export const NETWORKS: [string, string][] = [['', '—'], ['mtn', 'MTN MoMo'], ['telecel', 'Telecel Cash (Vodafone)'], ['airteltigo', 'AirtelTigo Money'], ['other', 'Other']];
export const DOC_TYPES: [string, string][] = [['business_registration', 'Business registration certificate'], ['incorporation', 'Certificate of incorporation'], ['vat_certificate', 'VAT certificate'],
  ['tax_clearance', 'Tax clearance certificate'], ['iso_certificate', 'ISO certificate'], ['hse_policy', 'HSE policy'], ['quality_policy', 'Quality policy'], ['tax_exemption', 'Tax exemption'],
  ['bog_fx', 'BoG exemption letter'], ['ssnit', 'SSNIT clearance'], ['insurance', 'Insurance'], ['other', 'Other (say what)']];
export const ONB: Record<string, [string, string]> = { pending: ['Onboarding pending', 'warn'], approved: ['Approved supplier', 'good'], rejected: ['Rejected', 'bad'], suspended: ['Suspended', 'bad'] };
/** The documents every supplier page lists, in this order; "Others" can be added as many times as needed. */
export const CHECKLIST = ['business_registration', 'incorporation', 'vat_certificate', 'iso_certificate', 'hse_policy', 'quality_policy', 'bog_fx', 'tax_exemption'];
const docName = (d: any) => d.doc_type === 'other' ? d.doc_label || 'Other' : DOC_TYPES.find(x => x[0] === d.doc_type)?.[1] || d.doc_type;

/** The supplier fields beyond name, TIN and address: type, Ghana Card, what they supply, bank and MoMo. */
export function SupplierFields({ edit, setEdit }: { edit: any; setEdit: (x: any) => void }) {
  const set = (k: string) => (v: any) => setEdit({ ...edit, [k]: v });
  return <>
    <div className="grid-form">
      <Select label="Supplier type" id="sf-type" value={edit.supplier_type || 'vendor'} onChange={set('supplier_type')} options={SUPPLIER_TYPES} />
      <Field label="Ghana Card (owner or director)" id="sf-gc" value={edit.ghana_card || ''} onChange={set('ghana_card')} placeholder="GHA-000000000-0" />
      <Field label="Payment terms (days)" id="sf-terms" type="number" min="0" value={edit.payment_terms_days ?? 30} onChange={set('payment_terms_days')} />
    </div>
    <Field label="Products and services they supply" id="sf-ps" type="textarea" value={edit.products_services || ''} onChange={set('products_services')} placeholder="e.g. Siemens LV switchgear, cable trays; electrical installation; crane hire" />
    <div className="label" style={{ marginTop: 6 }}>Bank</div>
    <div className="grid-form">
      <Field label="Bank name" id="sf-bank" value={edit.bank_name || ''} onChange={set('bank_name')} />
      <Field label="Branch" id="sf-branch" value={edit.bank_branch || ''} onChange={set('bank_branch')} />
      <Field label="Account name" id="sf-acname" value={edit.bank_account_name || ''} onChange={set('bank_account_name')} />
      <Field label="Account number" id="sf-acno" value={edit.bank_account || ''} onChange={set('bank_account')} />
      <Field label="SWIFT code" id="sf-swift" value={edit.bank_swift || ''} onChange={v => setEdit({ ...edit, bank_swift: v.toUpperCase() })} />
      <Field label="Bank address" id="sf-baddr" value={edit.bank_address || ''} onChange={set('bank_address')} />
    </div>
    <div className="label" style={{ marginTop: 6 }}>Mobile Money</div>
    <div className="grid-form">
      <Select label="Network" id="sf-net" value={edit.momo_network || ''} onChange={set('momo_network')} options={NETWORKS} />
      <Field label="MoMo number" id="sf-momo" value={edit.momo_number || ''} onChange={set('momo_number')} />
      <Field label="Name on the MoMo account" id="sf-momoname" value={edit.momo_name || ''} onChange={set('momo_name')} />
    </div>
  </>;
}
/** The columns SupplierFields edits, cleaned for saving. */
export const supplierRow = (e: any) => ({
  supplier_type: e.supplier_type || 'vendor', ghana_card: e.ghana_card || null, products_services: e.products_services || null, payment_terms_days: Number(e.payment_terms_days ?? 30) || 0,
  bank_name: e.bank_name || null, bank_branch: e.bank_branch || null, bank_account_name: e.bank_account_name || null, bank_account: e.bank_account || null, bank_swift: e.bank_swift || null,
  bank_address: e.bank_address || null, momo_network: e.momo_network || null, momo_number: e.momo_number || null, momo_name: e.momo_name || null,
});

/** Supplier page: onboarding documents, what is missing, and Finance's approval. */
export function OnboardingPanel({ s, onChange }: { s: any; onChange: () => void }) {
  const { cid, can } = useSession();
  const act = useAction();
  const [up, setUp] = useState<any | null>(null);
  const [decide, setDecide] = useState<any | null>(null);
  const { data, reload } = useLoad(async () => ({
    docs: await q<any[]>(supabase.from('supplier_documents').select('*').eq('supplier_id', s.id).order('created_at', { ascending: false }) as any).catch(() => null),
    reqs: await q<any[]>(supabase.from('onboarding_requirements').select('*').eq('company_id', cid) as any).catch(() => [] as any[]),
  }), [s.id, cid]);
  if (!data || data.docs === null) return null;
  const types = s.supplier_type === 'both' ? ['vendor', 'subcontractor'] : [s.supplier_type || 'vendor'];
  const req = new Set(data.reqs.filter(r => r.required && types.includes(r.supplier_type)).map(r => r.doc_type));
  const valid = (t: string) => data.docs!.some(d => d.doc_type === t && d.status !== 'rejected' && (!d.expires_on || d.expires_on >= today()));
  const missing = [...req].filter(t => !valid(t));
  const fin = can('accountant');
  const st = ONB[s.onboarding_status] || [s.onboarding_status, ''];
  const done = () => { reload(); onChange(); };
  return <Panel title={<div className="actions"><h2>Onboarding</h2><span className={'pill ' + st[1]}>{st[0]}</span></div>}
    actions={<>{can('accountant', 'store', 'project_manager') && <button className="btn small" type="button" onClick={() => setUp({ doc_type: missing[0] || 'business_registration', doc_label: '', ref_no: '', issued_on: '', expires_on: '', file: null })}>Upload document</button>}
      {fin && s.onboarding_status !== 'approved' && <button className="btn small primary" type="button" onClick={() => setDecide({ status: 'approved', note: '', override: missing.length > 0 })}>Approve</button>}
      {fin && s.onboarding_status === 'approved' && <button className="btn small ghost" type="button" onClick={() => setDecide({ status: 'suspended', note: '' })}>Suspend</button>}
      {fin && s.onboarding_status === 'pending' && <button className="btn small ghost" type="button" onClick={() => setDecide({ status: 'rejected', note: '' })}>Reject</button>}</>}>
    <div className="body" style={{ fontSize: 13 }}>
      {missing.length ? <><b style={{ color: 'var(--bad)' }}>Still needed:</b> {missing.map(t => DOC_TYPES.find(x => x[0] === t)?.[1] || t).join(', ')}.</> : <span className="pill good">All required documents are in</span>}
      {s.onboarding_note && <div className="muted" style={{ marginTop: 4 }}>Note: {s.onboarding_note}{s.onboarded_at ? ` (${longDate(s.onboarded_at.slice(0, 10))})` : ''}</div>}
    </div>
    <div className="scroll"><table>
      <thead><tr><th>Document</th><th>Attached</th><th>Reference</th><th>Expires</th><th>Status</th><th></th></tr></thead>
      <tbody>{[...CHECKLIST.map(t => ({ t, d: data.docs!.find(x => x.doc_type === t) })), ...data.docs.filter(x => x.doc_type === 'other' || !CHECKLIST.includes(x.doc_type)).map(d => ({ t: d.doc_type, d })),
        { t: 'other', d: null as any }].map(({ t, d }, i) => {
        const isOtherSlot = t === 'other' && !d;
        const name = d ? docName(d) : isOtherSlot ? (data.docs!.some(x => x.doc_type === 'other') ? 'Another document' : 'Others (any other document)') : DOC_TYPES.find(x => x[0] === t)?.[1] || t;
        return <tr key={d?.id || t + i}>
          <td>{name}{req.has(t) && <span className="pill warn" style={{ marginLeft: 6 }}>required</span>}</td>
          <td>{d?.storage_path ? <button className="btn ghost small" style={{ padding: 0 }} type="button" onClick={() => act.run(() => openAttachment(d))}>📎 {d.name || 'Open'}</button> : <span className="muted">—</span>}</td>
          <td>{d?.ref_no}</td>
          <td className="num" style={{ color: d?.expires_on && d.expires_on < today() ? 'var(--bad)' : undefined }}>{d?.expires_on || ''}</td>
          <td>{d ? <span className={'pill ' + (d.status === 'verified' ? 'good' : d.status === 'rejected' ? 'bad' : 'warn')}>{d.status}</span> : <span className="muted">not attached</span>}</td>
          <td className="r"><span className="actions" style={{ justifyContent: 'flex-end' }}>
            {can('accountant', 'store', 'project_manager') && <button className={'btn small' + (d ? ' ghost' : ' primary')} type="button" onClick={() => setUp({ doc_type: t, doc_label: d?.doc_label || '', ref_no: '', issued_on: '', expires_on: '', file: null })}>{d ? 'Replace' : 'Attach'}</button>}
            {fin && d && d.status !== 'verified' && <button className="btn small ghost" type="button" onClick={() => act.run(async () => { await q(supabase.from('supplier_documents').update({ status: 'verified', verified_at: new Date().toISOString() }).eq('id', d.id) as any); done(); }, 'Verified')}>Verify</button>}
            {fin && d && d.status !== 'rejected' && <button className="btn small ghost" type="button" onClick={() => act.run(async () => { await q(supabase.from('supplier_documents').update({ status: 'rejected' }).eq('id', d.id) as any); done(); }, 'Marked rejected')}>Reject</button>}
            {fin && d && <ConfirmButton className="btn small ghost" label="Remove" confirm="Remove this document?" onConfirm={() => act.run(async () => { await q(supabase.from('supplier_documents').delete().eq('id', d.id) as any); done(); })} />}
          </span></td></tr>; })}</tbody></table></div>
    {up && <FormModal title="Upload onboarding document" busy={act.busy} onClose={() => setUp(null)} onSave={() => act.run(async () => {
      let f: any = {};
      if (up.file) { const u = await uploadDocFile(cid, 'suppliers', up.file); f = { name: u.name, storage_path: u.path }; }
      if (up.doc_type === 'other' && !up.doc_label.trim()) throw new Error('Say what the document is.');
      await q(supabase.from('supplier_documents').insert({ company_id: cid, supplier_id: s.id, doc_type: up.doc_type, doc_label: up.doc_label || null, ref_no: up.ref_no || null,
        issued_on: up.issued_on || null, expires_on: up.expires_on || null, ...f }) as any);
      setUp(null); done(); }, 'Document added')}>
      <div className="grid-form">
        <Select label="Document" id="od-type" value={up.doc_type} onChange={v => setUp({ ...up, doc_type: v })} options={DOC_TYPES} />
        {up.doc_type === 'other' && <Field label="What it is" id="od-label" value={up.doc_label} onChange={v => setUp({ ...up, doc_label: v })} required />}
        <Field label="Certificate / reference no." id="od-ref" value={up.ref_no} onChange={v => setUp({ ...up, ref_no: v })} />
        <Field label="Issued on" id="od-iss" type="date" value={up.issued_on} onChange={v => setUp({ ...up, issued_on: v })} />
        <Field label="Expires on" id="od-exp" type="date" value={up.expires_on} onChange={v => setUp({ ...up, expires_on: v })} />
      </div>
      <div className="field"><label htmlFor="od-file">File (PDF or photo)</label><input id="od-file" type="file" accept=".pdf,image/*,.doc,.docx" onChange={e => setUp({ ...up, file: e.target.files?.[0] || null })} /></div>
      <p className="muted" style={{ margin: 0, fontSize: 13 }}>Finance and the storekeeper are reminded 30 days before it expires.</p>
    </FormModal>}
    {decide && <FormModal title={({ approved: 'Approve supplier', rejected: 'Reject supplier', suspended: 'Suspend supplier' } as any)[decide.status]} busy={act.busy} onClose={() => setDecide(null)}
      onSave={() => act.run(async () => { await rpc('decide_supplier', { p_supplier: s.id, p_status: decide.status, p_note: decide.note || null, p_override: !!decide.override }); setDecide(null); done(); }, 'Saved')}>
      {decide.status === 'approved' && missing.length > 0 && <p style={{ margin: 0, color: 'var(--bad)' }}>Missing: {missing.map(t => DOC_TYPES.find(x => x[0] === t)?.[1] || t).join(', ')}. You can approve anyway with a reason.</p>}
      <Field label={decide.status === 'approved' ? (missing.length ? 'Reason for approving without every document' : 'Note (optional)') : 'Reason'} id="od-note" type="textarea" value={decide.note} onChange={v => setDecide({ ...decide, note: v })} required={decide.status !== 'approved' || missing.length > 0} />
    </FormModal>}
  </Panel>;
}

/** Settings: which documents vendors and subcontractors must give. */
export function OnboardingRequirementsPanel() {
  const { cid, can } = useSession();
  const act = useAction();
  const { data, reload } = useLoad(() => q<any[]>(supabase.from('onboarding_requirements').select('*').eq('company_id', cid) as any).catch(() => null), [cid]);
  if (!can('accountant') || !data) return null;
  const is = (t: string, d: string) => data.some(r => r.supplier_type === t && r.doc_type === d && r.required);
  const toggle = (t: string, d: string, on: boolean) => act.run(async () => {
    await q(supabase.from('onboarding_requirements').upsert({ company_id: cid, supplier_type: t, doc_type: d, required: on }) as any); reload();
  });
  return <Panel title="Supplier onboarding: required documents">
    <div className="scroll"><table>
      <thead><tr><th>Document</th><th style={{ textAlign: 'center' }}>Vendors</th><th style={{ textAlign: 'center' }}>Subcontractors</th></tr></thead>
      <tbody>{DOC_TYPES.filter(d => d[0] !== 'other').map(([d, l]) => <tr key={d}><td>{l}</td>
        {['vendor', 'subcontractor'].map(t => <td key={t} style={{ textAlign: 'center' }}><input type="checkbox" aria-label={`${l} required for ${t}s`} checked={is(t, d)} disabled={act.busy} onChange={e => toggle(t, d, e.target.checked)} /></td>)}</tr>)}</tbody>
    </table></div>
    <div className="body muted" style={{ fontSize: 13 }}>A new supplier is "Onboarding pending" until Finance approves it on the supplier's page. Ticked documents must be uploaded (and not expired) first; Finance can approve without one only by giving a reason. Purchase orders to suppliers that are not approved show a warning.</div>
  </Panel>;
}

export function CostCentresPage() {
  return <>
    <PageHead title="Branches and cost centres" sub="Create the cost centres (and branches) that invoices, bills, expenses, payroll and projects are charged to. Reports can then be run per cost centre." />
    <DimensionsPanel />
  </>;
}
export function OnboardingRulesPage() {
  return <>
    <PageHead title="Supplier onboarding rules" sub="Which documents vendors and subcontractors must give before Finance approves them." />
    <OnboardingRequirementsPanel />
  </>;
}

/** On the "Add supplier" form: attach the onboarding documents straight away. "Others" repeats: filling one adds another. */
export type DocPick = { type: string; label: string; file: File | null };
export function SupplierDocPicker({ picks, setPicks }: { picks: DocPick[]; setPicks: (p: DocPick[]) => void }) {
  const set = (i: number, patch: Partial<DocPick>) => {
    let next = picks.map((p, j) => j === i ? { ...p, ...patch } : p);
    const others = next.filter(p => p.type === 'other');
    if (others.length && (others[others.length - 1].file || others[others.length - 1].label)) next = [...next, { type: 'other', label: '', file: null }];
    setPicks(next);
  };
  return <>
    <div className="label" style={{ marginTop: 6 }}>Documents to attach</div>
    <div style={{ display: 'grid', gap: 6 }}>{picks.map((p, i) => <div key={i} style={{ display: 'grid', gridTemplateColumns: 'minmax(160px, 1fr) 2fr', gap: 8, alignItems: 'center' }}>
      {p.type === 'other' ? <input aria-label="Other document: what it is" value={p.label} onChange={e => set(i, { label: e.target.value })} placeholder="Others: what is it?" />
        : <span style={{ fontSize: 14 }}>{DOC_TYPES.find(d => d[0] === p.type)?.[1]}</span>}
      <input type="file" aria-label={`Attach ${p.type}`} accept=".pdf,image/*,.doc,.docx" onChange={e => set(i, { file: e.target.files?.[0] || null })} />
    </div>)}</div>
    <p className="muted" style={{ margin: 0, fontSize: 12 }}>You can also attach them later on the supplier's page, with reference numbers and expiry dates.</p>
  </>;
}
export const initialPicks = (): DocPick[] => [...['business_registration', 'vat_certificate', 'iso_certificate', 'hse_policy', 'quality_policy', 'bog_fx'].map(t => ({ type: t, label: '', file: null })), { type: 'other', label: '', file: null }];
export async function uploadSupplierPicks(cid: string, supplierId: string, picks: DocPick[]) {
  for (const p of picks.filter(x => x.file)) {
    const u = await uploadDocFile(cid, 'suppliers', p.file!);
    await q(supabase.from('supplier_documents').insert({ company_id: cid, supplier_id: supplierId, doc_type: p.type, doc_label: p.type === 'other' ? p.label || p.file!.name : null, name: u.name, storage_path: u.path }) as any);
  }
}
