-- Asnys ERP: new installation, part3 of 3.
-- Contains 0010_asnys_v2_4.sql, 0011_asnys_v2_5.sql, 0012_asnys_v2_6.sql, 0013_asnys_v2_7.sql, 0014_asnys_v2_8.sql, 0015_asnys_v2_8_1.sql, 0016_asnys_v2_9.sql, 0017_asnys_v3_0.sql. Run part 1, then part 2, then part 3, once each, in a new Supabase project.


-- ======================================================================
-- 0010_asnys_v2_4.sql
-- ======================================================================
-- =====================================================================
-- Asnys ERP v2.4 — contract payment terms and payment schedules
--   Each contract (project) sets its own terms: credit days, advance, retention and its release, billing basis,
--   valuation day and how far ahead to remind. Asnys builds the payment schedule (when to invoice, when the
--   client must pay), gives project invoices their due date from the contract, and prompts Finance and the
--   project manager before each date and when one is missed.
-- Run after 0009.
-- =====================================================================

-- ---------------------------------------------------------------- 1. Terms on the contract
alter table public.projects add column if not exists contract_date date;
alter table public.projects add column if not exists payment_terms_days int check (payment_terms_days between 0 and 365);
alter table public.projects add column if not exists advance_pct numeric(5,2) not null default 0 check (advance_pct between 0 and 100);
alter table public.projects add column if not exists retention_pct numeric(5,2) not null default 0 check (retention_pct between 0 and 50);
alter table public.projects add column if not exists retention_release_days int not null default 365 check (retention_release_days between 0 and 1825);
alter table public.projects add column if not exists billing_basis text not null default 'milestones' check (billing_basis in ('milestones','monthly','on_completion'));
alter table public.projects add column if not exists valuation_day int check (valuation_day between 1 and 28);
alter table public.projects add column if not exists reminder_days int not null default 7 check (reminder_days between 0 and 60);
alter table public.projects add column if not exists payment_terms_notes text;

alter table public.tenders add column if not exists payment_terms_days int check (payment_terms_days between 0 and 365);
alter table public.tenders add column if not exists advance_pct numeric(5,2) not null default 0 check (advance_pct between 0 and 100);
alter table public.tenders add column if not exists retention_pct numeric(5,2) not null default 0 check (retention_pct between 0 and 50);
alter table public.tenders add column if not exists payment_terms_notes text;

-- Projects registered from an award take the award's terms.
create or replace function public.project_terms_from_tender() returns trigger
language plpgsql security definer set search_path = public as $$
declare t tenders;
begin
  if new.tender_id is not null then
    select * into t from tenders where id = new.tender_id;
    new.payment_terms_days := coalesce(new.payment_terms_days, t.payment_terms_days);
    new.advance_pct := case when coalesce(new.advance_pct, 0) = 0 then coalesce(t.advance_pct, 0) else new.advance_pct end;
    new.retention_pct := case when coalesce(new.retention_pct, 0) = 0 then coalesce(t.retention_pct, 0) else new.retention_pct end;
    new.payment_terms_notes := coalesce(new.payment_terms_notes, t.payment_terms_notes);
    new.contract_date := coalesce(new.contract_date, t.contract_signed_on);
  end if;
  return new;
end $$;
create trigger projects_terms_from_tender before insert on public.projects for each row execute function public.project_terms_from_tender();

-- ---------------------------------------------------------------- 2. Payment schedule
create table public.project_payment_schedule (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  project_id uuid not null references public.projects(id) on delete cascade,
  seq int not null default 0,
  kind text not null check (kind in ('advance','milestone','valuation','completion','retention','other')),
  description text not null,
  amount numeric(14,2) not null check (amount >= 0),   -- project currency, excluding VAT
  invoice_on date not null,                            -- when Finance should raise the invoice
  due_on date,                                         -- when the client should pay (invoice date + credit days)
  milestone_id uuid references public.project_milestones(id) on delete set null,
  invoice_id uuid references public.invoices(id) on delete set null,
  notes text,
  created_at timestamptz not null default now()
);
create index on public.project_payment_schedule (project_id, invoice_on);

create or replace function public.payment_schedule_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare pr projects;
begin
  select * into pr from projects where id = new.project_id;
  new.company_id := pr.company_id;
  if new.due_on is null or (tg_op = 'UPDATE' and new.invoice_on is distinct from old.invoice_on and old.due_on = old.invoice_on + coalesce(pr.payment_terms_days, 30)) then
    new.due_on := new.invoice_on + coalesce(pr.payment_terms_days, 30);
  end if;
  if tg_op = 'UPDATE' and old.invoice_id is not null and (new.amount, new.kind) is distinct from (old.amount, old.kind) then
    raise exception 'This payment has been invoiced; change the invoice or add an adjustment line instead';
  end if;
  return new;
end $$;
create trigger project_payment_schedule_defaults before insert or update on public.project_payment_schedule for each row execute function public.payment_schedule_defaults();
create trigger project_payment_schedule_closed before insert on public.project_payment_schedule for each row execute function public.closed_project_guard();

-- Build the schedule from the contract terms. Lines already invoiced are kept; the rest are rebuilt.
create or replace function public.generate_payment_schedule(p_project uuid) returns int
language plpgsql security definer set search_path = public as $$
declare pr projects; v_start date; v_end date; v_cv numeric; v_adv numeric; v_ret numeric; v_rest numeric; n int := 0; m record; v_months int; d date; i int; v_each numeric;
begin
  select * into pr from projects where id = p_project for update;
  if not found then raise exception 'Project not found'; end if;
  if not (can_manage_project(p_project) or has_role(pr.company_id, array['owner','admin','accountant','sales'])) then raise exception 'Only Finance, Business Development or the project manager can set the payment schedule'; end if;
  if coalesce(pr.contract_value, 0) <= 0 then raise exception 'Enter the contract value first'; end if;
  v_start := coalesce(pr.contract_date, pr.actual_start, pr.start_date, current_date);
  v_end := coalesce(pr.end_date, v_start + 90);
  v_cv := pr.contract_value;
  v_adv := round(v_cv * pr.advance_pct / 100, 2);
  v_ret := round(v_cv * pr.retention_pct / 100, 2);
  delete from project_payment_schedule where project_id = p_project and invoice_id is null;
  -- what is already invoiced counts against the contract
  v_rest := v_cv - v_adv - v_ret - coalesce((select sum(amount) from project_payment_schedule where project_id = p_project and kind not in ('advance','retention')), 0);
  if v_adv > 0 and not exists (select 1 from project_payment_schedule where project_id = p_project and kind = 'advance') then
    insert into project_payment_schedule (project_id, seq, kind, description, amount, invoice_on)
    values (p_project, 1, 'advance', 'Advance payment ' || trim(to_char(pr.advance_pct, 'FM990.##')) || '% on signing', v_adv, v_start);
    n := n + 1;
  end if;
  if pr.billing_basis = 'milestones' then
    for m in select * from project_milestones where project_id = p_project and status <> 'invoiced' and id not in (select milestone_id from project_payment_schedule where milestone_id is not null) order by sort, due_date loop
      insert into project_payment_schedule (project_id, seq, kind, description, amount, invoice_on, milestone_id)
      values (p_project, 10 + n, 'milestone', m.name, m.amount, coalesce(m.due_date, v_end), m.id);
      n := n + 1;
    end loop;
  elsif pr.billing_basis = 'monthly' then
    v_months := greatest(1, (date_part('year', age(v_end, v_start)) * 12 + date_part('month', age(v_end, v_start)))::int + 1);
    v_each := round(greatest(v_rest, 0) / v_months, 2);
    for i in 1..v_months loop
      d := (date_trunc('month', v_start) + make_interval(months => i - 1))::date + coalesce(pr.valuation_day, 25) - 1;
      insert into project_payment_schedule (project_id, seq, kind, description, amount, invoice_on)
      values (p_project, 10 + i, 'valuation', 'Valuation ' || i || ' (' || to_char(d, 'Mon YYYY') || ')',
              case when i = v_months then greatest(v_rest, 0) - v_each * (v_months - 1) else v_each end, d);
      n := n + 1;
    end loop;
  else
    if v_rest > 0 then
      insert into project_payment_schedule (project_id, seq, kind, description, amount, invoice_on)
      values (p_project, 50, 'completion', 'On completion', v_rest, v_end);
      n := n + 1;
    end if;
  end if;
  if v_ret > 0 and not exists (select 1 from project_payment_schedule where project_id = p_project and kind = 'retention') then
    insert into project_payment_schedule (project_id, seq, kind, description, amount, invoice_on)
    values (p_project, 90, 'retention', 'Release of retention ' || trim(to_char(pr.retention_pct, 'FM990.##')) || '% after the defects period', v_ret, v_end + pr.retention_release_days);
    n := n + 1;
  end if;
  return n;
end $$;

-- Raise the invoice for a scheduled payment. Milestones go through the usual milestone billing.
create or replace function public.invoice_schedule_item(p_id uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare s project_payment_schedule; pr projects; v_rate numeric; v_inv uuid;
begin
  select * into s from project_payment_schedule where id = p_id for update;
  if not found then raise exception 'Scheduled payment not found'; end if;
  select * into pr from projects where id = s.project_id;
  if not (has_role(pr.company_id, array['owner','admin','accountant','sales']) or can_manage_project(pr.id)) then raise exception 'Your role cannot invoice this project'; end if;
  if s.invoice_id is not null then raise exception 'Already invoiced'; end if;
  if s.milestone_id is not null then
    v_inv := invoice_milestone(s.milestone_id);
  else
    if pr.customer_id is null then raise exception 'Set a client on this project before invoicing'; end if;
    v_rate := case when pr.currency = 'GHS' then 1 else (select rate from currencies where company_id = pr.company_id and code = pr.currency) end;
    if v_rate is null then raise exception 'Add % under Settings → Foreign currencies first', pr.currency; end if;
    insert into invoices (company_id, customer_id, project_id, invoice_date, currency, exchange_rate, branch_id, cost_centre_id, notes)
    values (pr.company_id, pr.customer_id, pr.id, current_date, pr.currency, v_rate, pr.branch_id, pr.cost_centre_id,
            'Project ' || coalesce(pr.number, '') || ' ' || pr.name || coalesce(' · contract ' || pr.contract_ref, '') ||
            '. Payment terms: ' || coalesce(pr.payment_terms_days, 30) || ' days.') returning id into v_inv;
    insert into invoice_lines (invoice_id, company_id, description, qty, unit_price, taxable, sort)
    values (v_inv, pr.company_id, s.description, 1, s.amount, true, 0);
  end if;
  update project_payment_schedule set invoice_id = v_inv where id = p_id;
  return v_inv;
end $$;

-- Invoicing a milestone from the Billing tab ticks it off the schedule too.
create or replace function public.milestone_to_schedule() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.invoice_id is not null and old.invoice_id is distinct from new.invoice_id then
    update project_payment_schedule set invoice_id = new.invoice_id where milestone_id = new.id and invoice_id is null;
  end if;
  return null;
end $$;
create trigger project_milestones_to_schedule after update on public.project_milestones for each row execute function public.milestone_to_schedule();

-- ---------------------------------------------------------------- 3. Project invoices take their due date from the contract
alter table public.invoices add column if not exists due_from_terms boolean not null default false;
create or replace function public.invoice_due_from_contract() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_days int;
begin
  if new.status <> 'draft' or new.project_id is null then return new; end if;
  select payment_terms_days into v_days from projects where id = new.project_id;
  if v_days is null then return new; end if;
  if tg_op = 'INSERT' then
    if new.due_date is null then new.due_date := new.invoice_date + v_days; new.due_from_terms := true; end if;
  elsif new.due_from_terms and (new.invoice_date is distinct from old.invoice_date or new.project_id is distinct from old.project_id)
        and new.due_date is not distinct from old.due_date then
    new.due_date := new.invoice_date + v_days;
  elsif new.due_date is distinct from old.due_date then
    new.due_from_terms := false;
  elsif new.due_date is null then
    new.due_date := new.invoice_date + v_days; new.due_from_terms := true;
  end if;
  return new;
end $$;
create trigger invoices_due_from_contract before insert or update on public.invoices for each row execute function public.invoice_due_from_contract();

-- ---------------------------------------------------------------- 4. What is coming: invoices to raise and payments to collect
create or replace function public.payment_calendar(cid uuid, p_days int default 30, p_project uuid default null)
returns table (kind text, project_id uuid, project text, customer text, manager_id uuid, ref_id uuid, description text, amount numeric, amount_ghs numeric,
               action_date date, days_left int, status text, invoice_id uuid, invoice_number text)
language sql stable security definer set search_path = public as $$
  with fx as (select p.id, case when p.currency = 'GHS' then 1 else coalesce((select rate from currencies x where x.company_id = p.company_id and x.code = p.currency), 1) end r from projects p where p.company_id = cid)
  -- scheduled payments not yet invoiced: Finance raises the invoice
  select 'to_invoice', p.id, coalesce(p.number || ' ', '') || p.name, c.name, p.manager_id, s.id, s.description, s.amount, round(s.amount * fx.r, 2),
         s.invoice_on, s.invoice_on - current_date,
         case when s.invoice_on < current_date then 'late' when s.invoice_on <= current_date + p.reminder_days then 'due_soon' else 'scheduled' end, null::uuid, null::text
    from project_payment_schedule s join projects p on p.id = s.project_id join fx on fx.id = p.id left join customers c on c.id = p.customer_id
   where p.company_id = cid and s.invoice_id is null and p.status not in ('cancelled') and (p_project is null or p.id = p_project)
     and s.invoice_on <= current_date + p_days and is_member(cid)
  union all
  -- invoices raised and not yet paid: Finance collects, the project manager knows
  select 'to_collect', p.id, coalesce(p.number || ' ', '') || p.name, c.name, p.manager_id, i.id, coalesce(s.description, 'Invoice ' || i.number),
         i.total - i.amount_paid - i.amount_credited, round((i.total - i.amount_paid - i.amount_credited) * i.exchange_rate, 2),
         i.due_date, i.due_date - current_date,
         case when i.due_date < current_date then 'overdue' when i.due_date <= current_date + p.reminder_days then 'due_soon' else 'not_due' end, i.id, i.number
    from invoices i join projects p on p.id = i.project_id left join customers c on c.id = i.customer_id
    left join lateral (select description from project_payment_schedule x where x.invoice_id = i.id limit 1) s on true
   where i.company_id = cid and i.status = 'posted' and i.total - i.amount_paid - i.amount_credited > 0.005 and (p_project is null or p.id = p_project)
     and i.due_date <= current_date + p_days and is_member(cid)
  order by 10;
$$;

-- Schedule with live status for one project.
create or replace function public.project_payment_status(p_project uuid)
returns table (id uuid, seq int, kind text, description text, amount numeric, invoice_on date, due_on date, milestone_id uuid, invoice_id uuid, invoice_number text,
               invoice_due date, billed numeric, paid numeric, outstanding numeric, status text)
language sql stable security definer set search_path = public as $$
  select s.id, s.seq, s.kind, s.description, s.amount, s.invoice_on, coalesce(i.due_date, s.due_on), s.milestone_id, s.invoice_id, i.number, i.due_date,
         i.total, i.amount_paid + i.amount_credited, i.total - i.amount_paid - i.amount_credited,
         case when s.invoice_id is null then case when s.invoice_on < current_date then 'invoice_late' else 'to_invoice' end
              when i.status = 'draft' then 'draft_invoice'
              when i.status = 'paid' or i.total - i.amount_paid - i.amount_credited <= 0.005 then 'paid'
              when i.due_date < current_date then 'overdue' else 'awaiting_payment' end
    from project_payment_schedule s left join invoices i on i.id = s.invoice_id
   where s.project_id = p_project and exists (select 1 from projects p where p.id = p_project and is_member(p.company_id))
   order by s.invoice_on, s.seq;
$$;


-- Reminders come from the system, so they reach the person who happened to trigger them too.
drop function public.notify(uuid, text[], uuid[], text, text, text, text);
create or replace function public.notify(cid uuid, p_roles text[], p_users uuid[], p_kind text, p_title text, p_body text default null, p_path text default null, p_include_self boolean default false)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into notifications (company_id, user_id, kind, title, body, path)
  select distinct cid, u, p_kind, p_title, p_body, p_path from (
    select m.user_id u from memberships m where m.company_id = cid and (m.role = any(p_roles) or m.role in ('owner','admin'))
    union select unnest(coalesce(p_users, '{}'::uuid[]))) x
  where u is not null and (p_include_self or u is distinct from auth.uid());
  get diagnostics n = row_count;
  return n;
end $$;

-- ---------------------------------------------------------------- 5. Prompts to Finance and the project manager
create table public.payment_reminders (
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  sent_at timestamptz not null default now(),
  primary key (company_id, key)
);
alter table public.payment_reminders enable row level security;

-- Sends each prompt once: "invoice to raise" when within the contract's reminder days and again when late;
-- "payment due" before the client's due date and again when overdue. Safe to run as often as you like
-- (the app runs it when Finance or a project manager opens the dashboard; it can also run daily, see SETUP).
create or replace function public.run_payment_reminders(cid uuid) returns int
language plpgsql security definer set search_path = public as $$
declare r record; v_key text; n int := 0; v_ins int;
begin
  if auth.uid() is not null and not is_member(cid) then raise exception 'Not a member of this company'; end if;
  for r in select * from payment_calendar(cid, 60) where status in ('due_soon','late','overdue') loop
    v_key := r.kind || ':' || r.ref_id || ':' || case when r.status in ('late','overdue') then 'late' else 'soon' end;
    insert into payment_reminders (company_id, key) values (cid, v_key) on conflict do nothing;
    get diagnostics v_ins = row_count;
    continue when v_ins = 0;
    if r.kind = 'to_invoice' then
      perform notify(cid, array['accountant'], array[r.manager_id], 'payment.invoice_due',
        case when r.status = 'late' then 'Invoice not raised: ' else 'Invoice to raise: ' end || r.description || ' · ' || r.project,
        'GH₵ ' || to_char(r.amount_ghs, 'FM999,999,999,990.00') || case when r.status = 'late' then ' was due to be invoiced on ' else ' to be invoiced on ' end ||
        to_char(r.action_date, 'DD Mon YYYY') || ' under the contract terms.', '/projects/' || r.project_id, true);
    else
      perform notify(cid, array['accountant'], array[r.manager_id], 'payment.client_due',
        case when r.status = 'overdue' then 'Client payment overdue: ' else 'Client payment due: ' end || coalesce(r.invoice_number, '') || ' · ' || r.project,
        coalesce(r.customer, '') || ' owes GH₵ ' || to_char(r.amount_ghs, 'FM999,999,999,990.00') || case when r.status = 'overdue' then ', due on ' else ', due on ' end ||
        to_char(r.action_date, 'DD Mon YYYY') || case when r.status = 'overdue' then ' (' || (current_date - r.action_date) || ' days late). Follow up and log it.' else '.' end,
        '/invoices/' || r.ref_id, true);
    end if;
    n := n + 1;
  end loop;
  return n;
end $$;

-- For a scheduled job (Supabase pg_cron): reminders for every company.
create or replace function public.run_all_payment_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop n := n + run_payment_reminders(c.id); end loop;
  return n;
end $$;

-- ---------------------------------------------------------------- 6. Security and audit
alter table public.project_payment_schedule enable row level security;
create policy "members read schedule" on public.project_payment_schedule for select using (is_member(company_id));
create policy "finance and pm write schedule" on public.project_payment_schedule for all
  using (can_manage_project(project_id) or has_role(company_id, array['owner','admin','accountant','sales']))
  with check (can_manage_project(project_id) or has_role((select company_id from projects where id = project_id), array['owner','admin','accountant','sales']));
create trigger project_payment_schedule_audit after insert or update or delete on public.project_payment_schedule for each row execute function public.audit_row();

-- Terms on a registered project are set by Finance, Business Development or the project manager (not other staff).
create or replace function public.project_terms_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (new.payment_terms_days, new.advance_pct, new.retention_pct, new.retention_release_days, new.billing_basis, new.valuation_day, new.reminder_days, new.contract_date)
     is distinct from (old.payment_terms_days, old.advance_pct, old.retention_pct, old.retention_release_days, old.billing_basis, old.valuation_day, old.reminder_days, old.contract_date)
     and auth.uid() is not null and not (can_manage_project(new.id) or has_role(new.company_id, array['owner','admin','accountant','sales'])) then
    raise exception 'Only Finance, Business Development or the project manager can change the contract''s payment terms';
  end if;
  return new;
end $$;
create trigger projects_terms_guard before update on public.projects for each row execute function public.project_terms_guard();

-- Function permissions
revoke execute on all functions in schema public from public, anon;
grant execute on all functions in schema public to authenticated;
revoke execute on function public.post_journal(uuid,date,text,jsonb,text,uuid) from authenticated;
revoke execute on function public.seed_accounts(uuid) from authenticated;
revoke execute on function public.seed_accounts_v11(uuid) from authenticated;
revoke execute on function public.seed_accounts_v12(uuid) from authenticated;
revoke execute on function public.seed_accounts_v13(uuid) from authenticated;
revoke execute on function public.seed_accounts_v14(uuid) from authenticated;
revoke execute on function public.seed_accounts_v20(uuid) from authenticated;
revoke execute on function public.seed_accounts_v21(uuid) from authenticated;
revoke execute on function public.seed_leave_types(uuid) from authenticated;
revoke execute on function public.seed_asset_categories(uuid) from authenticated;
revoke execute on function public.seed_cycle_responsibilities(uuid) from authenticated;
revoke execute on function public.next_number(uuid,text,text) from authenticated;
revoke execute on function public.notify(uuid,text[],uuid[],text,text,text,text,boolean) from authenticated;
revoke execute on function public.run_all_payment_reminders() from authenticated;
revoke execute on function public.project_cost_items(uuid) from authenticated;
revoke execute on function public.project_cost_totals(uuid) from authenticated;
revoke execute on function public.finalize_expense(uuid) from authenticated;
revoke execute on function public.doc_dims(text,uuid) from authenticated;
revoke execute on function public.wh(uuid) from authenticated;
revoke execute on function public.transit_wh(uuid) from authenticated;
revoke execute on function public.ledger_checks_v20(uuid) from authenticated;
revoke execute on function public.unposted_documents_v20(uuid) from authenticated;
revoke execute on function public.project_close_check_v21(uuid) from authenticated;
revoke execute on function public.project_close_check_v22(uuid) from authenticated;
revoke execute on function public.create_project_from_template_v13(uuid, text, uuid, date, uuid) from authenticated;
grant execute on function public.public_help(uuid) to anon;
grant execute on function public.submit_case_public(uuid,text,text,text,text,text) to anon;
grant execute on function public.case_status_public(text,text) to anon;
grant execute on function public.reply_case_public(text,text,text,int) to anon;


-- ======================================================================
-- 0011_asnys_v2_5.sql
-- ======================================================================
-- Asnys ERP v2.5: invite staff by email.
-- HR or an admin enters a work email and role (or invites employees in bulk). The invite-member edge function
-- emails a link; the person sets a password and is added to the company with that role, linked to their
-- employee record. Run after 0001 to 0010.

-- ---------------------------------------------------------------- 1. Invitations
create table public.member_invites (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  email text not null,
  role text not null default 'staff' check (role in ('admin','accountant','sales','hr','project_manager','store','staff')),
  employee_id uuid references public.employees(id) on delete set null,
  invited_by uuid default auth.uid(),
  invited_at timestamptz not null default now(),
  last_sent_at timestamptz,
  send_count int not null default 0,
  send_method text,                     -- 'invite' (new account) or 'magic_link' (already has a login)
  status text not null default 'pending' check (status in ('pending','sent','accepted','revoked','failed')),
  error text,
  user_id uuid,
  accepted_at timestamptz,
  unique (company_id, email)
);
create index member_invites_email on public.member_invites (lower(email));

-- Who may invite whom: owners and admins any role but owner; HR only staff.
create or replace function public.can_invite(cid uuid, p_role text) returns boolean
language sql stable security definer set search_path = public as $$
  select has_role(cid, array['owner','admin']) or (p_role = 'staff' and has_role(cid, array['hr']))
$$;

-- p_list: [{"email": "...", "role": "staff", "employee_id": "..."}]. Returns one row per address with what happened.
create or replace function public.create_invites(cid uuid, p_list jsonb)
returns table (id uuid, email text, result text) language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare x jsonb; v_email text; v_role text; v_emp uuid; v_user uuid; v_id uuid;
begin
  perform require_member(cid, array['owner','admin','hr']);
  if jsonb_typeof(p_list) is distinct from 'array' or jsonb_array_length(p_list) = 0 then raise exception 'Add at least one email address'; end if;
  if jsonb_array_length(p_list) > 200 then raise exception 'Invite at most 200 people at a time'; end if;
  for x in select * from jsonb_array_elements(p_list) loop
    v_email := lower(trim(coalesce(x->>'email', '')));
    v_role := coalesce(nullif(x->>'role', ''), 'staff');
    v_emp := nullif(x->>'employee_id', '')::uuid;
    if v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
      id := null; email := v_email; result := 'invalid email'; return next; continue;
    end if;
    if v_role = 'owner' or v_role not in ('admin','accountant','sales','hr','project_manager','store','staff') then raise exception 'Choose a valid role for %', v_email; end if;
    if not can_invite(cid, v_role) then raise exception 'HR can invite staff only; ask an admin to give % the % role', v_email, v_role; end if;
    if v_emp is not null and not exists (select 1 from employees e where e.id = v_emp and e.company_id = cid) then raise exception 'Employee not found'; end if;
    select m.user_id into v_user from memberships m where m.company_id = cid and lower(m.email) = v_email;
    if v_user is not null then
      if v_emp is not null then update employees set user_id = v_user where employees.id = v_emp and user_id is null; end if;
      id := null; email := v_email; result := 'already a member'; return next; continue;
    end if;
    insert into member_invites as mi (company_id, email, role, employee_id, invited_by)
    values (cid, v_email, v_role, v_emp, auth.uid())
    on conflict (company_id, email) do update set role = excluded.role, employee_id = coalesce(excluded.employee_id, mi.employee_id),
      invited_by = excluded.invited_by, invited_at = now(), status = 'pending', error = null, user_id = null, accepted_at = null
    returning mi.id into v_id;
    id := v_id; email := v_email; result := 'invited'; return next;
  end loop;
end $$;

-- What the edge function needs to send the emails; checks the caller may send each one.
create or replace function public.invites_to_send(cid uuid, p_ids uuid[])
returns table (id uuid, email text, role text, company_name text, has_login boolean)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform require_member(cid, array['owner','admin','hr']);
  return query
    select i.id, i.email, i.role, c.name, exists (select 1 from auth.users u where lower(u.email) = i.email)
      from member_invites i join companies c on c.id = i.company_id
     where i.company_id = cid and i.id = any(p_ids) and i.status in ('pending','sent','failed') and can_invite(cid, i.role);
end $$;

create or replace function public.mark_invite_sent(p_id uuid, p_ok boolean, p_error text default null, p_method text default null)
returns void language plpgsql security definer set search_path = public as $$
declare i member_invites;
begin
  select * into i from member_invites where id = p_id;
  if not found then raise exception 'Invitation not found'; end if;
  perform require_member(i.company_id, array['owner','admin','hr']);
  if not can_invite(i.company_id, i.role) then raise exception 'You cannot send this invitation'; end if;
  if i.status in ('accepted','revoked') then return; end if;
  update member_invites set status = case when p_ok then 'sent' else 'failed' end, error = case when p_ok then null else left(p_error, 500) end,
         last_sent_at = case when p_ok then now() else last_sent_at end, send_count = send_count + case when p_ok then 1 else 0 end,
         send_method = coalesce(p_method, send_method)
   where id = p_id;
end $$;

create or replace function public.revoke_invite(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare i member_invites;
begin
  select * into i from member_invites where id = p_id;
  if not found then raise exception 'Invitation not found'; end if;
  perform require_member(i.company_id, array['owner','admin','hr']);
  if not can_invite(i.company_id, i.role) then raise exception 'You cannot revoke this invitation'; end if;
  if i.status = 'accepted' then raise exception 'Already accepted; remove them from the team instead'; end if;
  update member_invites set status = 'revoked' where id = p_id;
end $$;

-- Called by the app after every sign-in. Only a confirmed email address can claim an invitation, so nobody
-- can sign up with a colleague's address and take their place.
create or replace function public.claim_my_invites()
returns int language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_email text; v_confirmed timestamptz; r member_invites; n int := 0; v_emp uuid;
begin
  if v_uid is null then return 0; end if;
  select lower(u.email), u.email_confirmed_at into v_email, v_confirmed from auth.users u where u.id = v_uid;
  if v_email is null or v_confirmed is null then return 0; end if;
  for r in select * from member_invites where lower(email) = v_email and status in ('pending','sent','failed') loop
    insert into memberships (company_id, user_id, email, role) values (r.company_id, v_uid, v_email, r.role)
    on conflict (company_id, user_id) do nothing;            -- never changes the role of someone already in
    v_emp := r.employee_id;
    if v_emp is null then
      select e.id into v_emp from employees e where e.company_id = r.company_id and e.user_id is null and lower(e.email) = v_email limit 1;
    end if;
    if v_emp is not null then update employees set user_id = v_uid where id = v_emp and company_id = r.company_id and user_id is null; end if;
    update member_invites set status = 'accepted', accepted_at = now(), user_id = v_uid where id = r.id;
    perform notify(r.company_id, array[]::text[], array[r.invited_by], 'invite_accepted', v_email || ' joined as ' || replace(r.role, '_', ' '), null, '/settings', true);
    n := n + 1;
  end loop;
  return n;
end $$;

-- Team list with sign-in status, plus open invitations.
create or replace function public.team_access(cid uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','hr']);
  return jsonb_build_object(
    'members', coalesce((select jsonb_agg(jsonb_build_object('user_id', m.user_id, 'email', coalesce(m.email, u.email), 'role', m.role,
                 'last_sign_in_at', u.last_sign_in_at, 'joined_at', m.created_at,
                 'employee', (select e.full_name from employees e where e.company_id = cid and e.user_id = m.user_id limit 1))
               order by m.role = 'owner' desc, coalesce(m.email, u.email))
               from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid), '[]'),
    'invites', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'email', i.email, 'role', i.role, 'status', i.status, 'error', i.error,
                 'invited_at', i.invited_at, 'last_sent_at', i.last_sent_at, 'send_count', i.send_count, 'employee_id', i.employee_id,
                 'employee', (select e.full_name from employees e where e.id = i.employee_id),
                 'invited_by', (select m.email from memberships m where m.company_id = cid and m.user_id = i.invited_by))
               order by i.invited_at desc)
               from member_invites i where i.company_id = cid and i.status <> 'accepted'), '[]'));
end $$;

-- Employee list status: Not invited / Invited / Has access.
create or replace function public.employee_access(cid uuid)
returns table (employee_id uuid, access text, email text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform require_member(cid, array['owner','admin','hr']);
  return query
    select e.id,
      case when e.user_id is not null and exists (select 1 from memberships m where m.company_id = cid and m.user_id = e.user_id) then 'active'
           when i.status in ('pending','sent') then 'invited'
           when i.status = 'failed' then 'failed'
           else 'none' end,
      coalesce(i.email, lower(e.email))
    from employees e
    left join lateral (select * from member_invites mi where mi.company_id = cid and mi.status <> 'revoked'
                         and (mi.employee_id = e.id or (e.email is not null and mi.email = lower(trim(e.email))))
                       order by mi.invited_at desc limit 1) i on true
   where e.company_id = cid;
end $$;

-- The old link message pointed at a sign-up step that invitations now replace.
create or replace function public.link_employee_user(p_employee uuid, p_email text)
returns void language plpgsql security definer set search_path = public as $$
declare e employees; v_user uuid;
begin
  select * into e from employees where id = p_employee;
  if not found then raise exception 'Employee not found'; end if;
  perform require_member(e.company_id, array['owner','admin','hr']);
  if coalesce(trim(p_email),'') = '' then update employees set user_id = null where id = p_employee; return; end if;
  select id into v_user from auth.users where lower(email) = lower(trim(p_email));
  if v_user is null then raise exception 'No one has signed in with % yet. Press "Invite to Asnys" to email them an invitation.', p_email; end if;
  update employees set user_id = v_user where id = p_employee;
end $$;

alter table public.member_invites enable row level security;
create policy "admins and hr read invites" on public.member_invites for select using (has_role(company_id, array['owner','admin','hr']));
create trigger member_invites_audit after insert or update or delete on public.member_invites for each row execute function public.audit_row();

-- Function permissions
revoke execute on all functions in schema public from public, anon;
grant execute on all functions in schema public to authenticated;
revoke execute on function public.post_journal(uuid,date,text,jsonb,text,uuid) from authenticated;
revoke execute on function public.seed_accounts(uuid) from authenticated;
revoke execute on function public.seed_accounts_v11(uuid) from authenticated;
revoke execute on function public.seed_accounts_v12(uuid) from authenticated;
revoke execute on function public.seed_accounts_v13(uuid) from authenticated;
revoke execute on function public.seed_accounts_v14(uuid) from authenticated;
revoke execute on function public.seed_accounts_v20(uuid) from authenticated;
revoke execute on function public.seed_accounts_v21(uuid) from authenticated;
revoke execute on function public.seed_leave_types(uuid) from authenticated;
revoke execute on function public.seed_asset_categories(uuid) from authenticated;
revoke execute on function public.seed_cycle_responsibilities(uuid) from authenticated;
revoke execute on function public.next_number(uuid,text,text) from authenticated;
revoke execute on function public.notify(uuid,text[],uuid[],text,text,text,text,boolean) from authenticated;
revoke execute on function public.run_all_payment_reminders() from authenticated;
revoke execute on function public.project_cost_items(uuid) from authenticated;
revoke execute on function public.project_cost_totals(uuid) from authenticated;
revoke execute on function public.finalize_expense(uuid) from authenticated;
revoke execute on function public.doc_dims(text,uuid) from authenticated;
revoke execute on function public.wh(uuid) from authenticated;
revoke execute on function public.transit_wh(uuid) from authenticated;
revoke execute on function public.ledger_checks_v20(uuid) from authenticated;
revoke execute on function public.unposted_documents_v20(uuid) from authenticated;
revoke execute on function public.project_close_check_v21(uuid) from authenticated;
revoke execute on function public.project_close_check_v22(uuid) from authenticated;
revoke execute on function public.create_project_from_template_v13(uuid, text, uuid, date, uuid) from authenticated;
grant execute on function public.public_help(uuid) to anon;
grant execute on function public.submit_case_public(uuid,text,text,text,text,text) to anon;
grant execute on function public.case_status_public(text,text) to anon;
grant execute on function public.reply_case_public(text,text,text,int) to anon;


-- ======================================================================
-- 0012_asnys_v2_6.sql
-- ======================================================================
-- Asnys ERP v2.6: contract management, and asset check-out, audits, requests and reminders. Run after 0001 to 0011.
-- A register of every contract the company signs (with clients, suppliers, subcontractors, service and leases),
-- its variations, the bonds and guarantees behind it, key dates and obligations, and the signed files.

-- ---------------------------------------------------------------- 1. Contracts
create table public.contracts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  title text not null,
  kind text not null default 'client' check (kind in ('client','supplier','subcontract','service','lease','other')),
  customer_id uuid references public.customers(id) on delete set null,
  supplier_id uuid references public.suppliers(id) on delete set null,
  counterparty text,                                  -- name when not a customer or supplier record
  their_ref text,                                     -- the other party's contract, PO or LPO number
  project_id uuid references public.projects(id) on delete set null,
  tender_id uuid references public.tenders(id) on delete set null,
  value numeric(14,2) not null default 0 check (value >= 0),
  currency text not null default 'GHS',
  signed_on date,
  start_date date,
  end_date date,
  status text not null default 'draft' check (status in ('draft','active','on_hold','terminated','closed')),
  payment_terms_days int check (payment_terms_days between 0 and 365),
  advance_pct numeric(5,2) check (advance_pct between 0 and 100),
  retention_pct numeric(5,2) check (retention_pct between 0 and 100),
  notice_days int not null default 30 check (notice_days between 0 and 365),   -- remind this long before the end date
  auto_renew boolean not null default false,
  renewal_months int check (renewal_months between 1 and 120),
  owner_id uuid default auth.uid(),                   -- who manages the contract
  description text,
  termination_note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  check (end_date is null or start_date is null or end_date >= start_date)
);
create index contracts_company on public.contracts (company_id, status);
create unique index contracts_tender on public.contracts (tender_id) where tender_id is not null;

create table public.contract_variations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  contract_id uuid not null references public.contracts(id) on delete cascade,
  number text,
  title text not null,
  description text,
  value_change numeric(14,2) not null default 0,      -- + adds to the contract, - omits work
  days_extension int not null default 0 check (days_extension >= 0),
  status text not null default 'proposed' check (status in ('proposed','approved','rejected')),
  requested_on date not null default current_date,
  decided_on date,
  decided_by uuid,
  decision_note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create table public.contract_securities (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  contract_id uuid not null references public.contracts(id) on delete cascade,
  kind text not null check (kind in ('bid_bond','performance_bond','advance_payment_guarantee','retention_bond','insurance','warranty','other')),
  direction text not null default 'given' check (direction in ('given','received')),   -- given by us, or received from the other party
  issuer text,                                        -- bank or insurer
  reference text,
  amount numeric(14,2) check (amount >= 0),
  issued_on date,
  expires_on date,
  status text not null default 'active' check (status in ('active','released','claimed','expired')),
  notes text,
  created_at timestamptz not null default now()
);

create table public.contract_obligations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  contract_id uuid not null references public.contracts(id) on delete cascade,
  title text not null,                                -- e.g. Submit monthly HSE report, Renew insurance, Final account
  due_date date not null,
  responsible_id uuid,                                -- a user
  status text not null default 'open' check (status in ('open','done','waived')),
  done_on date,
  notes text,
  created_at timestamptz not null default now()
);

create table public.contract_files (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  contract_id uuid not null references public.contracts(id) on delete cascade,
  kind text not null default 'signed_contract' check (kind in ('signed_contract','variation','security','correspondence','other')),
  name text not null,
  storage_path text not null,                         -- project-docs bucket, <company>/contracts/<contract>/...
  size_bytes bigint,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

-- Who works with contracts: owners, admins, Finance, Business Development and project managers; anyone named as its owner.
create or replace function public.can_see_contract(c contracts) returns boolean
language sql stable security definer set search_path = public as $$
  select has_role(c.company_id, array['owner','admin','accountant','sales','project_manager']) or c.owner_id = auth.uid()
$$;
create or replace function public.can_edit_contract(c contracts) returns boolean
language sql stable security definer set search_path = public as $$
  select has_role(c.company_id, array['owner','admin','accountant','sales'])
      or c.owner_id = auth.uid()
      or (c.project_id is not null and can_manage_project(c.project_id))
$$;

create or replace function public.contract_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.number is null or new.number = '' then new.number := next_number(new.company_id, 'CON', 'CON-'); end if;
  if new.counterparty is null then
    new.counterparty := coalesce((select name from customers where id = new.customer_id), (select name from suppliers where id = new.supplier_id));
  end if;
  if new.project_id is not null and not exists (select 1 from projects where id = new.project_id and company_id = new.company_id) then raise exception 'Project not found'; end if;
  if tg_op = 'UPDATE' and new.status in ('terminated','closed') and old.status not in ('terminated','closed') and new.termination_note is null and new.status = 'terminated' then
    raise exception 'Say why the contract was terminated';
  end if;
  return new;
end $$;
create trigger contracts_defaults before insert or update on public.contracts for each row execute function public.contract_defaults();

create or replace function public.child_company() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select company_id into new.company_id from contracts where id = new.contract_id;
  if new.company_id is null then raise exception 'Contract not found'; end if;
  return new;
end $$;
create trigger contract_variations_company before insert on public.contract_variations for each row execute function public.child_company();
create trigger contract_securities_company before insert on public.contract_securities for each row execute function public.child_company();
create trigger contract_obligations_company before insert on public.contract_obligations for each row execute function public.child_company();
create trigger contract_files_company before insert on public.contract_files for each row execute function public.child_company();

create or replace function public.variation_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare c contracts;
begin
  select * into c from contracts where id = new.contract_id;
  if tg_op = 'INSERT' then
    new.number := 'VO-' || lpad((select count(*) + 1 from contract_variations where contract_id = new.contract_id)::text, 2, '0');
    new.status := 'proposed'; new.decided_on := null; new.decided_by := null;
    perform notify(c.company_id, array['accountant'], array[c.owner_id], 'variation_proposed',
      'Variation ' || new.number || ' proposed on ' || c.number, new.title || ' (' || to_char(new.value_change, 'FM999,999,999,990.00') || ')', '/contracts/' || c.id);
  elsif (new.status, new.value_change, new.days_extension) is distinct from (old.status, old.value_change, old.days_extension)
        and coalesce(current_setting('sika.contracts', true), '') <> 'on' then
    if old.status <> 'proposed' then raise exception 'This variation has been decided; propose a new one instead'; end if;
    if new.status <> old.status then raise exception 'Use Approve or Reject'; end if;
  end if;
  return new;
end $$;
create trigger contract_variations_defaults before insert or update on public.contract_variations for each row execute function public.variation_defaults();

-- Finance, owners and admins decide variations. An approved time extension moves the contract's end date.
create or replace function public.decide_variation(p_id uuid, p_approve boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v contract_variations; c contracts;
begin
  select * into v from contract_variations where id = p_id;
  if not found then raise exception 'Variation not found'; end if;
  select * into c from contracts where id = v.contract_id;
  perform require_member(c.company_id, array['owner','admin','accountant']);
  if v.status <> 'proposed' then raise exception 'Already %', v.status; end if;
  perform set_config('sika.contracts', 'on', true);
  update contract_variations set status = case when p_approve then 'approved' else 'rejected' end, decided_on = current_date, decided_by = auth.uid(), decision_note = p_note where id = p_id;
  if p_approve and v.days_extension > 0 and c.end_date is not null then
    update contracts set end_date = end_date + v.days_extension where id = c.id;
  end if;
  perform set_config('sika.contracts', 'off', true);
  perform notify(c.company_id, array[]::text[], array[c.owner_id, v.created_by], 'variation_decided',
    v.number || ' on ' || c.number || ' ' || case when p_approve then 'approved' else 'rejected' end, p_note, '/contracts/' || c.id, true);
end $$;

-- ---------------------------------------------------------------- 2. Awarded tenders become client contracts
create or replace function public.contract_from_tender(p_tender uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders; v uuid; pj uuid;
begin
  select * into t from tenders where id = p_tender;
  if not found then raise exception 'Tender not found'; end if;
  if t.status <> 'awarded' then raise exception 'Only an awarded tender becomes a contract'; end if;
  select id into v from contracts where tender_id = p_tender;
  if v is not null then return v; end if;
  pj := coalesce(t.project_id, (select id from projects where tender_id = t.id limit 1));
  insert into contracts (company_id, title, kind, customer_id, counterparty, their_ref, project_id, tender_id, value, currency, signed_on, start_date, status,
                         payment_terms_days, advance_pct, retention_pct, owner_id, description)
  values (t.company_id, t.title, 'client', t.customer_id, t.client_name, t.contract_ref, pj, t.id, coalesce(t.awarded_value, 0), t.currency, t.contract_signed_on,
          coalesce((select start_date from projects where id = pj), t.contract_signed_on), 'active',
          (to_jsonb(t)->>'payment_terms_days')::int, (to_jsonb(t)->>'advance_pct')::numeric, (to_jsonb(t)->>'retention_pct')::numeric,
          coalesce(t.bd_owner_id, auth.uid()), 'Awarded on ' || t.number || coalesce(' (' || replace(t.award_type, '_', ' ') || ')', ''))
  returning id into v;
  return v;
end $$;

create or replace function public.tender_award_contract() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'awarded' and old.status is distinct from 'awarded' then perform contract_from_tender(new.id); end if;
  if new.project_id is not null and new.project_id is distinct from old.project_id then
    update contracts set project_id = new.project_id where tender_id = new.id and project_id is null;
  end if;
  return new;
end $$;
create trigger tenders_award_contract after update on public.tenders for each row execute function public.tender_award_contract();

-- Projects created from a tender pick up the contract.
create or replace function public.project_links_contract() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.tender_id is not null then update contracts set project_id = new.id where tender_id = new.tender_id and project_id is null; end if;
  return new;
end $$;
create trigger projects_link_contract after insert on public.projects for each row execute function public.project_links_contract();

-- Awards made before this release.
insert into contracts (company_id, title, kind, customer_id, counterparty, their_ref, project_id, tender_id, value, currency, signed_on, start_date, status, owner_id, created_by, description)
select t.company_id, t.title, 'client', t.customer_id, t.client_name, t.contract_ref, coalesce(t.project_id, (select id from projects p where p.tender_id = t.id limit 1)), t.id,
       coalesce(t.awarded_value, 0), t.currency, t.contract_signed_on, t.contract_signed_on, 'active', t.bd_owner_id, t.bd_owner_id, 'Awarded on ' || t.number
  from tenders t where t.status = 'awarded' and not exists (select 1 from contracts c where c.tender_id = t.id);

-- ---------------------------------------------------------------- 3. Register with live figures
create or replace function public.contract_register(cid uuid)
returns table (id uuid, number text, title text, kind text, counterparty text, their_ref text, project_id uuid, project text, status text, display_status text,
               currency text, value numeric, variations numeric, revised_value numeric, pending_variations int, billed numeric, paid numeric, remaining numeric,
               signed_on date, start_date date, end_date date, days_left int, owner_id uuid, owner_email text,
               securities_active int, securities_expiring int, obligations_open int, obligations_overdue int, auto_renew boolean)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform require_member(cid, array['owner','admin','accountant','sales','project_manager','hr','store','staff']);
  return query
  with v as (select contract_id, sum(value_change) filter (where status = 'approved') appr, count(*) filter (where status = 'proposed') pend
               from contract_variations where company_id = cid group by contract_id),
       inv as (select c.id cid2, sum(i.total) billed, sum(i.amount_paid) paid
                 from contracts c join invoices i on i.company_id = c.company_id and i.status <> 'draft'
                  and ((c.project_id is not null and i.project_id = c.project_id) or (c.project_id is null and c.customer_id is not null and i.customer_id = c.customer_id
                        and i.invoice_date >= coalesce(c.start_date, c.signed_on, '1900-01-01')))
                where c.company_id = cid and c.kind = 'client' group by c.id),
       bil as (select c.id cid2, sum(b.total) billed, sum(b.amount_paid) paid
                 from contracts c join bills b on b.company_id = c.company_id and b.status <> 'draft' and b.supplier_id = c.supplier_id
                  and (c.project_id is null or exists (select 1 from bill_lines l where l.bill_id = b.id and l.project_id = c.project_id))
                  and b.bill_date >= coalesce(c.start_date, c.signed_on, '1900-01-01')
                where c.company_id = cid and c.kind <> 'client' and c.supplier_id is not null group by c.id),
       s as (select contract_id, count(*) filter (where status = 'active') act,
                    count(*) filter (where status = 'active' and expires_on <= current_date + 30) soon
               from contract_securities where company_id = cid group by contract_id),
       o as (select contract_id, count(*) filter (where status = 'open') op, count(*) filter (where status = 'open' and due_date < current_date) late
               from contract_obligations where company_id = cid group by contract_id)
  select c.id, c.number, c.title, c.kind, c.counterparty, c.their_ref, c.project_id, coalesce(p.number || ' ', '') || p.name, c.status,
         case when c.status = 'active' and c.end_date < current_date then 'expired'
              when c.status = 'active' and c.end_date <= current_date + c.notice_days then 'ending_soon' else c.status end,
         c.currency, c.value, coalesce(v.appr, 0), c.value + coalesce(v.appr, 0), coalesce(v.pend, 0)::int,
         coalesce(inv.billed, bil.billed, 0), coalesce(inv.paid, bil.paid, 0), c.value + coalesce(v.appr, 0) - coalesce(inv.billed, bil.billed, 0),
         c.signed_on, c.start_date, c.end_date, (c.end_date - current_date)::int, c.owner_id,
         (select m.email from memberships m where m.company_id = cid and m.user_id = c.owner_id),
         coalesce(s.act, 0)::int, coalesce(s.soon, 0)::int, coalesce(o.op, 0)::int, coalesce(o.late, 0)::int, c.auto_renew
    from contracts c
    left join projects p on p.id = c.project_id
    left join v on v.contract_id = c.id left join inv on inv.cid2 = c.id left join bil on bil.cid2 = c.id
    left join s on s.contract_id = c.id left join o on o.contract_id = c.id
   where c.company_id = cid and can_see_contract(c)
   order by (c.status = 'active') desc, c.end_date nulls last, c.number;
end $$;

-- Everything needing attention, newest risk first.
create or replace function public.contract_alerts(cid uuid, p_days int default 30)
returns table (kind text, contract_id uuid, contract text, title text, due date, days_left int)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform require_member(cid, array['owner','admin','accountant','sales','project_manager','hr','store','staff']);
  return query
  select * from (
    select 'contract_end'::text, c.id, c.number, c.title || ' ends' || case when c.auto_renew then ' (renews automatically)' else '' end, c.end_date, (c.end_date - current_date)::int
      from contracts c where c.company_id = cid and c.status = 'active' and c.end_date is not null and c.end_date <= current_date + greatest(c.notice_days, p_days) and can_see_contract(c)
    union all
    select 'security_expiry', c.id, c.number, initcap(replace(s.kind, '_', ' ')) || coalesce(' ' || s.reference, '') || coalesce(' from ' || s.issuer, '') || ' expires', s.expires_on, (s.expires_on - current_date)::int
      from contract_securities s join contracts c on c.id = s.contract_id
     where s.company_id = cid and s.status = 'active' and s.expires_on is not null and s.expires_on <= current_date + p_days and can_see_contract(c)
    union all
    select 'obligation', c.id, c.number, o.title, o.due_date, (o.due_date - current_date)::int
      from contract_obligations o join contracts c on c.id = o.contract_id
     where o.company_id = cid and o.status = 'open' and o.due_date <= current_date + least(p_days, 14) and can_see_contract(c)
    union all
    select 'variation', c.id, c.number, v.number || ' awaiting decision: ' || v.title, v.requested_on, (v.requested_on - current_date)::int
      from contract_variations v join contracts c on c.id = v.contract_id
     where v.company_id = cid and v.status = 'proposed' and can_see_contract(c)
  ) x order by 6, 5;
end $$;

-- ---------------------------------------------------------------- 4. Reminders (contracts and assets), sent once each
create or replace function public.run_contract_reminders_internal(cid uuid) returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; k text;
begin
  for r in select c.*, (c.end_date - current_date) dl from contracts c
            where c.company_id = cid and c.status = 'active' and c.end_date is not null and c.end_date <= current_date + c.notice_days loop
    k := 'con-end:' || r.id || ':' || r.end_date || ':' || case when r.dl < 0 then 'late' else 'soon' end;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array['accountant'], array[r.owner_id], 'contract_ending',
        r.number || ' ' || r.title || case when r.dl < 0 then ' ended on ' else ' ends on ' end || to_char(r.end_date, 'DD Mon YYYY'),
        case when r.auto_renew then 'It renews automatically unless notice is given.' else 'Renew, extend or close it.' end, '/contracts/' || r.id, true);
      n := n + 1;
    end if;
  end loop;
  for r in select s.*, c.number cn, c.owner_id from contract_securities s join contracts c on c.id = s.contract_id
            where s.company_id = cid and s.status = 'active' and s.expires_on is not null and s.expires_on <= current_date + 30 loop
    k := 'con-sec:' || r.id || ':' || r.expires_on || ':' || case when r.expires_on < current_date then 'late' else 'soon' end;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array['accountant'], array[r.owner_id], 'security_expiring',
        initcap(replace(r.kind, '_', ' ')) || ' on ' || r.cn || case when r.expires_on < current_date then ' expired on ' else ' expires on ' end || to_char(r.expires_on, 'DD Mon YYYY'),
        coalesce(r.issuer || ' ', '') || coalesce(r.reference, ''), '/contracts/' || r.contract_id, true);
      n := n + 1;
    end if;
  end loop;
  for r in select o.*, c.number cn, c.owner_id from contract_obligations o join contracts c on c.id = o.contract_id
            where o.company_id = cid and o.status = 'open' and o.due_date <= current_date + 7 loop
    k := 'con-obl:' || r.id || ':' || r.due_date || ':' || case when r.due_date < current_date then 'late' else 'soon' end;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array[]::text[], array[r.owner_id, r.responsible_id], 'obligation_due',
        r.title || ' (' || r.cn || ')' || case when r.due_date < current_date then ' was due ' else ' is due ' end || to_char(r.due_date, 'DD Mon YYYY'), null, '/contracts/' || r.contract_id, true);
      n := n + 1;
    end if;
  end loop;
  -- Assets: maintenance coming due and warranties ending
  for r in select a.id, a.tag, a.name, a.custodian_id, m.next_due from assets a
             join lateral (select next_due from asset_maintenance x where x.asset_id = a.id order by service_date desc limit 1) m on true
            where a.company_id = cid and a.status = 'active' and m.next_due is not null and m.next_due <= current_date + 7 loop
    k := 'ast-mnt:' || r.id || ':' || r.next_due;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array['accountant'], array[(select user_id from employees where id = r.custodian_id)], 'maintenance_due',
        'Maintenance due on ' || r.tag || ' ' || r.name || ': ' || to_char(r.next_due, 'DD Mon YYYY'), null, '/assets/' || r.id, true);
      n := n + 1;
    end if;
  end loop;
  for r in select a.* from assets a where a.company_id = cid and a.status = 'active' and a.warranty_until between current_date and current_date + 30 loop
    k := 'ast-war:' || r.id || ':' || r.warranty_until;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array['accountant','store'], null, 'warranty_ending', 'Warranty on ' || r.tag || ' ' || r.name || ' ends ' || to_char(r.warranty_until, 'DD Mon YYYY'), null, '/assets/' || r.id, true);
      n := n + 1;
    end if;
  end loop;
  for r in select a.* from assets a where a.company_id = cid and a.status = 'active' and a.state <> 'archived' and a.next_audit is not null and a.next_audit <= current_date + 7 loop
    k := 'ast-aud:' || r.id || ':' || r.next_audit;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array['store'], null, 'audit_due', 'Audit due on ' || r.tag || ' ' || r.name || ': ' || to_char(r.next_audit, 'DD Mon YYYY'), coalesce('At ' || r.location, null), '/assets/' || r.id, true);
      n := n + 1;
    end if;
  end loop;
  for r in select a.*, (select user_id from employees where id = a.custodian_id) uid from assets a
            where a.company_id = cid and a.state = 'deployed' and a.expected_return is not null and a.expected_return < current_date loop
    k := 'ast-ret:' || r.id || ':' || r.expected_return;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array['store'], array[r.uid], 'asset_overdue', r.tag || ' ' || r.name || ' was due back on ' || to_char(r.expected_return, 'DD Mon YYYY'), null, '/assets/' || r.id, true);
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

create or replace function public.run_contract_reminders(cid uuid) returns int
language plpgsql security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant','sales','project_manager','hr','store','staff']);
  return run_contract_reminders_internal(cid);
end $$;

create or replace function public.run_all_contract_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_contract_reminders_internal(c.id), 0);
    exception when others then null; end;
  end loop;
  return n;
end $$;

-- ---------------------------------------------------------------- 5. Asset maintenance schedule
create or replace function public.asset_maintenance_schedule(cid uuid)
returns table (asset_id uuid, tag text, name text, location text, custodian text, last_service date, last_description text, next_due date, days_left int, total_cost numeric, services int)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform require_member(cid, array['owner','admin','accountant','sales','project_manager','hr','store','staff']);
  return query
  select a.id, a.tag, a.name, a.location, e.full_name, l.service_date, l.description, l.next_due, (l.next_due - current_date)::int,
         coalesce((select sum(cost) from asset_maintenance m where m.asset_id = a.id), 0), (select count(*) from asset_maintenance m where m.asset_id = a.id)::int
    from assets a
    left join employees e on e.id = a.custodian_id
    left join lateral (select * from asset_maintenance x where x.asset_id = a.id order by service_date desc limit 1) l on true
   where a.company_id = cid and a.status = 'active'
   order by l.next_due nulls last, a.tag;
end $$;


-- ---------------------------------------------------------------- 7. Asset operations: status, check out and in, audits, requests
alter table public.assets add column if not exists state text not null default 'ready'
  check (state in ('ready','deployed','pending','repair','broken','lost','archived'));
alter table public.assets add column if not exists requestable boolean not null default false;
alter table public.assets add column if not exists holder_project uuid references public.projects(id) on delete set null;
alter table public.assets add column if not exists expected_return date;
alter table public.assets add column if not exists last_audit date;
alter table public.assets add column if not exists next_audit date;
alter table public.companies add column if not exists asset_audit_months int not null default 12 check (asset_audit_months between 1 and 60);
update public.assets set state = case when status <> 'active' then 'archived' when custodian_id is not null then 'deployed' else 'ready' end;
update public.assets set next_audit = current_date + 90 where status = 'active' and next_audit is null;

alter table public.asset_movements add column if not exists kind text not null default 'move' check (kind in ('move','checkout','checkin','audit','status'));
alter table public.asset_movements add column if not exists project_id uuid references public.projects(id) on delete set null;
alter table public.asset_movements add column if not exists expected_return date;
alter table public.asset_movements add column if not exists state_after text;
alter table public.asset_movements add column if not exists moved_by uuid default auth.uid();

create table public.asset_audits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  asset_id uuid not null references public.assets(id) on delete cascade,
  audited_on date not null default current_date,
  audited_by uuid default auth.uid(),
  location text,
  condition text not null default 'good' check (condition in ('good','fair','poor','broken','missing')),
  note text,
  next_audit date
);

create table public.asset_requests (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  asset_id uuid references public.assets(id) on delete set null,         -- a specific requestable asset, or
  category_id uuid references public.asset_categories(id) on delete set null,  -- any asset of a kind
  description text not null,
  requested_by uuid not null default auth.uid(),
  employee_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  needed_from date not null default current_date,
  needed_until date,
  status text not null default 'pending' check (status in ('pending','approved','fulfilled','rejected','cancelled')),
  decided_by uuid, decided_on date, decision_note text,
  fulfilled_asset_id uuid references public.assets(id) on delete set null,
  created_at timestamptz not null default now()
);

create or replace function public.asset_manager(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$ select has_role(cid, array['owner','admin','accountant','store']) $$;

create or replace function public.asset_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.next_audit is null and new.status = 'active' then
    new.next_audit := current_date + make_interval(months => coalesce((select asset_audit_months from companies where id = new.company_id), 12));
  end if;
  if new.custodian_id is not null and new.state = 'ready' and tg_op = 'INSERT' then new.state := 'deployed'; end if;
  if new.status <> 'active' then new.state := 'archived'; end if;
  return new;
end $$;
create trigger assets_defaults before insert or update of status on public.assets for each row execute function public.asset_defaults();

-- Hand an asset to a person, a project site or a location.
create or replace function public.checkout_asset(p_asset uuid, p_employee uuid default null, p_project uuid default null, p_location text default null,
  p_expected_return date default null, p_note text default null, p_request uuid default null)
returns void language plpgsql security definer set search_path = public as $$
declare a assets;
begin
  select * into a from assets where id = p_asset for update;
  if not found then raise exception 'Asset not found'; end if;
  if not asset_manager(a.company_id) then raise exception 'Only the storekeeper, Finance or an admin can check assets out'; end if;
  if a.status <> 'active' or a.state in ('broken','lost','archived','repair') then raise exception '% is % and cannot be checked out', a.tag, replace(a.state, 'repair', 'out for repair'); end if;
  if a.state = 'deployed' then raise exception '% is already checked out; check it in first', a.tag; end if;
  if p_employee is null and p_project is null and coalesce(trim(p_location), '') = '' then raise exception 'Choose a person, a project or a location'; end if;
  if p_employee is not null and not exists (select 1 from employees where id = p_employee and company_id = a.company_id) then raise exception 'Employee not found'; end if;
  if p_project is not null and not exists (select 1 from projects where id = p_project and company_id = a.company_id) then raise exception 'Project not found'; end if;
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, from_custodian, to_custodian, project_id, expected_return, state_after, note)
  values (a.company_id, a.id, 'checkout', a.location, coalesce(nullif(trim(p_location), ''), (select coalesce(location, name) from projects where id = p_project), a.location),
          a.custodian_id, p_employee, p_project, p_expected_return, 'deployed', p_note);
  update assets set state = 'deployed', custodian_id = p_employee, holder_project = p_project, expected_return = p_expected_return,
         location = coalesce(nullif(trim(p_location), ''), (select coalesce(location, name) from projects where id = p_project), location)
   where id = a.id;
  if p_request is not null then update asset_requests set status = 'fulfilled', fulfilled_asset_id = a.id where id = p_request and company_id = a.company_id; end if;
  perform notify(a.company_id, array[]::text[], array[(select user_id from employees where id = p_employee),
          (select requested_by from asset_requests where id = p_request)], 'asset_checked_out',
    a.tag || ' ' || a.name || ' checked out to you' , case when p_expected_return is not null then 'Please return it by ' || to_char(p_expected_return, 'DD Mon YYYY') end, '/assets/' || a.id);
end $$;

create or replace function public.checkin_asset(p_asset uuid, p_state text default 'ready', p_location text default null, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare a assets;
begin
  select * into a from assets where id = p_asset for update;
  if not found then raise exception 'Asset not found'; end if;
  if not asset_manager(a.company_id) then raise exception 'Only the storekeeper, Finance or an admin can check assets in'; end if;
  if a.state <> 'deployed' then raise exception '% is not checked out', a.tag; end if;
  if p_state not in ('ready','pending','repair','broken','lost') then raise exception 'Choose the condition it came back in'; end if;
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, from_custodian, to_custodian, project_id, state_after, note)
  values (a.company_id, a.id, 'checkin', a.location, coalesce(nullif(trim(p_location), ''), a.location), a.custodian_id, null, a.holder_project, p_state, p_note);
  update assets set state = p_state, custodian_id = null, holder_project = null, expected_return = null, location = coalesce(nullif(trim(p_location), ''), location) where id = a.id;
end $$;

create or replace function public.set_asset_state(p_asset uuid, p_state text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare a assets;
begin
  select * into a from assets where id = p_asset for update;
  if not found then raise exception 'Asset not found'; end if;
  if not asset_manager(a.company_id) then raise exception 'Only the storekeeper, Finance or an admin can change an asset''s status'; end if;
  if p_state not in ('ready','pending','repair','broken','lost','archived') then raise exception 'Choose a status'; end if;
  if a.state = 'deployed' and p_state not in ('lost') then raise exception 'Check % in first', a.tag; end if;
  if a.status <> 'active' and p_state <> 'archived' then raise exception '% has been disposed of', a.tag; end if;
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, from_custodian, to_custodian, state_after, note)
  values (a.company_id, a.id, 'status', a.location, a.location, a.custodian_id, case when p_state = 'lost' then null else a.custodian_id end, p_state, p_note);
  update assets set state = p_state, custodian_id = case when p_state = 'lost' then null else custodian_id end,
         holder_project = case when p_state = 'lost' then null else holder_project end where id = a.id;
end $$;

-- Confirm an asset is where it should be and in what condition; sets the next audit date.
create or replace function public.audit_asset(p_asset uuid, p_condition text default 'good', p_location text default null, p_note text default null, p_next date default null)
returns date language plpgsql security definer set search_path = public as $$
declare a assets; v_next date;
begin
  select * into a from assets where id = p_asset for update;
  if not found then raise exception 'Asset not found'; end if;
  if not asset_manager(a.company_id) then raise exception 'Only the storekeeper, Finance or an admin can audit assets'; end if;
  if a.status <> 'active' then raise exception '% has been disposed of', a.tag; end if;
  v_next := coalesce(p_next, current_date + make_interval(months => coalesce((select asset_audit_months from companies where id = a.company_id), 12)));
  insert into asset_audits (company_id, asset_id, location, condition, note, next_audit) values (a.company_id, a.id, coalesce(nullif(trim(p_location), ''), a.location), p_condition, p_note, v_next);
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, from_custodian, to_custodian, state_after, note)
  values (a.company_id, a.id, 'audit', a.location, coalesce(nullif(trim(p_location), ''), a.location), a.custodian_id, a.custodian_id,
          case p_condition when 'broken' then 'broken' when 'missing' then 'lost' else a.state end, 'Audit: ' || p_condition || coalesce(' · ' || p_note, ''));
  update assets set last_audit = current_date, next_audit = v_next, location = coalesce(nullif(trim(p_location), ''), location),
         state = case p_condition when 'broken' then 'broken' when 'missing' then 'lost' else state end,
         custodian_id = case when p_condition = 'missing' then null else custodian_id end
   where id = a.id;
  return v_next;
end $$;

-- Staff ask for equipment; the storekeeper approves and checks it out.
create or replace function public.request_asset(cid uuid, p_description text, p_asset uuid default null, p_category uuid default null, p_project uuid default null,
  p_from date default null, p_until date default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v uuid; v_emp uuid; n text;
begin
  perform require_member(cid, array['owner','admin','accountant','sales','project_manager','hr','store','staff']);
  if coalesce(trim(p_description), '') = '' and p_asset is null then raise exception 'Say what you need'; end if;
  if p_asset is not null and not exists (select 1 from assets where id = p_asset and company_id = cid and requestable and status = 'active') then raise exception 'That asset cannot be requested'; end if;
  if p_until is not null and p_until < coalesce(p_from, current_date) then raise exception 'The return date is before the start date'; end if;
  select id into v_emp from employees where company_id = cid and user_id = auth.uid() limit 1;
  n := next_number(cid, 'ARQ', 'ARQ-');
  insert into asset_requests (company_id, number, asset_id, category_id, description, employee_id, project_id, needed_from, needed_until)
  values (cid, n, p_asset, p_category, coalesce(nullif(trim(p_description), ''), (select tag || ' ' || name from assets where id = p_asset)), v_emp, p_project,
          coalesce(p_from, current_date), p_until)
  returning id into v;
  perform notify(cid, array['store'], null, 'asset_requested', n || ': ' || coalesce(nullif(trim(p_description), ''), 'asset requested'),
    (select email from memberships where company_id = cid and user_id = auth.uid()), '/assets/requests');
  return v;
end $$;

create or replace function public.decide_asset_request(p_id uuid, p_approve boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r asset_requests;
begin
  select * into r from asset_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if r.requested_by = auth.uid() and not p_approve and not asset_manager(r.company_id) then
    if r.status not in ('pending','approved') then raise exception 'Already %', r.status; end if;
    update asset_requests set status = 'cancelled' where id = p_id; return;       -- the requester withdraws it
  end if;
  if not asset_manager(r.company_id) then raise exception 'Only the storekeeper, Finance or an admin can decide asset requests'; end if;
  if r.status <> 'pending' then raise exception 'Already %', r.status; end if;
  update asset_requests set status = case when p_approve then 'approved' else 'rejected' end, decided_by = auth.uid(), decided_on = current_date, decision_note = p_note where id = p_id;
  perform notify(r.company_id, array[]::text[], array[r.requested_by], 'asset_request_decided',
    r.number || ' ' || case when p_approve then 'approved' else 'declined' end, p_note, '/assets/requests', true);
end $$;

alter table public.asset_audits enable row level security;
create policy "members read audits" on public.asset_audits for select using (is_member(company_id));
alter table public.asset_requests enable row level security;
create policy "requests read" on public.asset_requests for select using (requested_by = auth.uid() or asset_manager(company_id) or has_role(company_id, array['project_manager','hr']));
create trigger asset_audits_audit after insert or update or delete on public.asset_audits for each row execute function public.audit_row();
create trigger asset_requests_audit after insert or update or delete on public.asset_requests for each row execute function public.audit_row();

-- ---------------------------------------------------------------- 6. Security
alter table public.contracts enable row level security;
create policy "contracts read" on public.contracts for select using (can_see_contract(contracts));
create policy "contracts add" on public.contracts for insert with check (has_role(company_id, array['owner','admin','accountant','sales','project_manager']));
create policy "contracts change" on public.contracts for update using (can_edit_contract(contracts)) with check (can_edit_contract(contracts));
create policy "contracts delete drafts" on public.contracts for delete using (status = 'draft' and has_role(company_id, array['owner','admin','accountant']));
do $$ declare t text; begin
  foreach t in array array['contract_variations','contract_securities','contract_obligations','contract_files'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "read with contract" on public.%I for select using (exists (select 1 from contracts c where c.id = contract_id and can_see_contract(c)))', t);
    execute format('create policy "write with contract" on public.%I for all using (exists (select 1 from contracts c where c.id = contract_id and can_edit_contract(c))) with check (exists (select 1 from contracts c where c.id = contract_id and can_edit_contract(c)))', t);
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
  end loop;
end $$;
create trigger contracts_audit after insert or update or delete on public.contracts for each row execute function public.audit_row();

-- Function permissions
revoke execute on all functions in schema public from public, anon;
grant execute on all functions in schema public to authenticated;
revoke execute on function public.post_journal(uuid,date,text,jsonb,text,uuid) from authenticated;
revoke execute on function public.seed_accounts(uuid) from authenticated;
revoke execute on function public.seed_accounts_v11(uuid) from authenticated;
revoke execute on function public.seed_accounts_v12(uuid) from authenticated;
revoke execute on function public.seed_accounts_v13(uuid) from authenticated;
revoke execute on function public.seed_accounts_v14(uuid) from authenticated;
revoke execute on function public.seed_accounts_v20(uuid) from authenticated;
revoke execute on function public.seed_accounts_v21(uuid) from authenticated;
revoke execute on function public.seed_leave_types(uuid) from authenticated;
revoke execute on function public.seed_asset_categories(uuid) from authenticated;
revoke execute on function public.seed_cycle_responsibilities(uuid) from authenticated;
revoke execute on function public.next_number(uuid,text,text) from authenticated;
revoke execute on function public.notify(uuid,text[],uuid[],text,text,text,text,boolean) from authenticated;
revoke execute on function public.run_all_payment_reminders() from authenticated;
revoke execute on function public.run_all_contract_reminders() from authenticated;
revoke execute on function public.run_contract_reminders_internal(uuid) from authenticated;
revoke execute on function public.child_company() from authenticated;
revoke execute on function public.project_cost_items(uuid) from authenticated;
revoke execute on function public.project_cost_totals(uuid) from authenticated;
revoke execute on function public.finalize_expense(uuid) from authenticated;
revoke execute on function public.doc_dims(text,uuid) from authenticated;
revoke execute on function public.wh(uuid) from authenticated;
revoke execute on function public.transit_wh(uuid) from authenticated;
revoke execute on function public.ledger_checks_v20(uuid) from authenticated;
revoke execute on function public.unposted_documents_v20(uuid) from authenticated;
revoke execute on function public.project_close_check_v21(uuid) from authenticated;
revoke execute on function public.project_close_check_v22(uuid) from authenticated;
revoke execute on function public.create_project_from_template_v13(uuid, text, uuid, date, uuid) from authenticated;
grant execute on function public.public_help(uuid) to anon;
grant execute on function public.submit_case_public(uuid,text,text,text,text,text) to anon;
grant execute on function public.case_status_public(text,text) to anon;
grant execute on function public.reply_case_public(text,text,text,int) to anon;


-- ======================================================================
-- 0013_asnys_v2_7.sql
-- ======================================================================
-- Asnys ERP v2.7: spend requests, staff cash advances (imprest) and petty cash floats. Run after 0001 to 0012.
-- Spending that has no project or sales order goes through a request, an approval chain and a budget check
-- before Finance turns it into a purchase order, a supplier bill, a payment or a cash advance.
-- Advances must be retired with receipts; petty cash floats are counted and replenished only when reconciled.

-- ---------------------------------------------------------------- 1. Accounts and settings
create or replace function public.seed_accounts_v27(cid uuid)
returns void language sql security definer set search_path = public as $$
  insert into accounts (company_id, code, name, type, system_key) values
  (cid,'1260','Staff cash advances (imprest)','asset','staff_advances'),
  (cid,'6960','Cash shortages','expense','cash_short'),
  (cid,'4960','Cash overages','income','cash_over')
  on conflict do nothing;
$$;
select public.seed_accounts_v27(id) from public.companies;

alter table public.companies add column if not exists advance_retire_days int not null default 7 check (advance_retire_days between 1 and 90);
alter table public.companies add column if not exists max_open_advances int not null default 1 check (max_open_advances between 1 and 10);
alter table public.companies add column if not exists advance_recover_after_days int not null default 30 check (advance_recover_after_days between 1 and 365);

create or replace function public.create_company(p_name text, p_tin text default null, p_city text default null,
  p_phone text default null, p_email text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v uuid; v_email text;
begin
  if auth.uid() is null then raise exception 'Please sign in'; end if;
  if coalesce(trim(p_name),'') = '' then raise exception 'Company name is required'; end if;
  select email into v_email from auth.users where id = auth.uid();
  insert into companies (name, tin, city, phone, email) values (trim(p_name), p_tin, p_city, p_phone, coalesce(p_email, v_email))
  returning id into v;
  insert into memberships (company_id, user_id, email, role) values (v, auth.uid(), v_email, 'owner');
  perform seed_accounts(v);
  perform seed_accounts_v11(v);
  perform seed_accounts_v12(v);
  perform seed_accounts_v13(v);
  perform seed_accounts_v14(v);
  perform seed_accounts_v20(v);
  perform seed_accounts_v21(v);
  perform seed_accounts_v27(v);
  perform seed_leave_types(v);
  perform seed_asset_categories(v);
  perform wh(v);
  perform seed_cycle_responsibilities(v);
  return v;
end $$;

create or replace function public.is_finance(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$ select has_role(cid, array['owner','admin','accountant']) $$;

-- A cash, MoMo or bank account of this company to pay from.
create or replace function public.paying_account(cid uuid, p_account uuid) returns uuid
language plpgsql stable security definer set search_path = public as $$
declare a accounts;
begin
  if p_account is null then return acct(cid, 'bank'); end if;
  select * into a from accounts where id = p_account and company_id = cid;
  if not found or not a.is_bank then raise exception 'Choose a cash, MoMo or bank account to pay from'; end if;
  return a.id;
end $$;

-- ---------------------------------------------------------------- 2. Spend requests
create table public.spend_requests (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  kind text not null default 'purchase' check (kind in ('purchase','payment','cash_advance')),
  title text not null,
  justification text,
  amount numeric(14,2) not null check (amount > 0),         -- GHS
  account_id uuid references public.accounts(id),           -- what it will be spent on (expense account)
  branch_id uuid references public.branches(id) on delete set null,
  cost_centre_id uuid references public.cost_centres(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  supplier_id uuid references public.suppliers(id) on delete set null,
  payee text,
  employee_id uuid references public.employees(id) on delete set null,   -- who receives a cash advance
  needed_by date,
  status text not null default 'draft' check (status in ('draft','submitted','approved','rejected','cancelled','done')),
  requested_by uuid not null default auth.uid(),
  submitted_at timestamptz, approved_at timestamptz,
  outcome text check (outcome in ('purchase_order','bill','payment','advance')),
  outcome_id uuid, outcome_ref text,
  created_at timestamptz not null default now()
);
create index spend_requests_company on public.spend_requests (company_id, status);

create or replace function public.spend_request_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.number := next_number(new.company_id, 'SRQ', 'SRQ-');
    new.status := 'draft'; new.requested_by := coalesce(auth.uid(), new.requested_by);
    new.outcome := null; new.outcome_id := null; new.submitted_at := null; new.approved_at := null;
  elsif coalesce(current_setting('sika.spend', true), '') <> 'on' then
    if old.status <> 'draft' then raise exception '% has been submitted and can no longer be changed. Cancel it and raise a new one.', old.number; end if;
    if new.status <> old.status or new.outcome is distinct from old.outcome or new.requested_by <> old.requested_by then raise exception 'Use Submit or Cancel'; end if;
  end if;
  if new.account_id is not null and not exists (select 1 from accounts where id = new.account_id and company_id = new.company_id) then raise exception 'Account not found'; end if;
  if new.kind = 'cash_advance' and new.employee_id is null then
    select id into new.employee_id from employees where company_id = new.company_id and user_id = new.requested_by limit 1;
  end if;
  return new;
end $$;
create trigger spend_requests_guard before insert or update on public.spend_requests for each row execute function public.spend_request_guard();
create trigger spend_requests_spend_gate before insert on public.spend_requests for each row execute function public.project_spend_gate();

-- Budget for the account this year, spent so far, committed by open requests, and what is left.
create or replace function public.spend_budget(cid uuid, p_account uuid, p_date date default current_date)
returns table (budget numeric, actual numeric, committed numeric, remaining numeric)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare y int := extract(year from coalesce(p_date, current_date));
begin
  perform require_member(cid);
  return query
  select b.v, a.v, c.v, b.v - a.v - c.v from
    (select coalesce(sum(amount), 0) v from budgets where company_id = cid and account_id = p_account and year = y) b,
    (select coalesce(sum(l.debit - l.credit), 0) v from journal_lines l join journal_entries e on e.id = l.entry_id
      where l.company_id = cid and l.account_id = p_account and extract(year from e.entry_date) = y) a,
    (select coalesce(sum(amount), 0) v from spend_requests where company_id = cid and account_id = p_account and status in ('submitted','approved')
      and extract(year from coalesce(needed_by, created_at::date)) = y) c;
end $$;

-- Who has an advance that blocks another one.
create or replace function public.advance_block_reason(p_employee uuid) returns text
language plpgsql stable security definer set search_path = public as $$
declare e employees; n int; od text;
begin
  if p_employee is null then return null; end if;
  select * into e from employees where id = p_employee;
  select number into od from cash_advances where employee_id = p_employee and status = 'open' and due_on < current_date order by due_on limit 1;
  if od is not null then return e.full_name || ' has advance ' || od || ' overdue for retirement. Retire it before asking for another.'; end if;
  select count(*) into n from cash_advances where employee_id = p_employee and status in ('open','submitted');
  if n >= (select max_open_advances from companies where id = e.company_id) then
    return e.full_name || ' already has ' || n || ' advance(s) not yet retired.';
  end if;
  return null;
end $$;

create or replace function public.submit_spend_request(p_id uuid) returns int
language plpgsql security definer set search_path = public as $$
declare r spend_requests; n int; why text;
begin
  select * into r from spend_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if r.requested_by <> auth.uid() and not is_finance(r.company_id) then raise exception 'Only the person who raised it can submit it'; end if;
  if r.status <> 'draft' then raise exception '% is already %', r.number, r.status; end if;
  if coalesce(trim(r.justification), '') = '' then raise exception 'Say why the money is needed'; end if;
  if r.kind in ('purchase','payment') and r.account_id is null then raise exception 'Choose what it will be charged to (the expense account)'; end if;
  if r.kind = 'cash_advance' then
    if r.employee_id is null then raise exception 'Choose who receives the advance (they need an employee record)'; end if;
    why := advance_block_reason(r.employee_id);
    if why is not null then raise exception '%', why; end if;
  end if;
  perform set_config('sika.spend', 'on', true);
  update spend_requests set status = 'submitted', submitted_at = now() where id = p_id;
  perform set_config('sika.spend', 'off', true);
  n := start_approval('spend_request', p_id);
  if n = 0 then          -- no chain set up: Finance approves every request
    insert into approval_steps (company_id, doc_type, doc_id, step_no, label, approver_role, amount)
    values (r.company_id, 'spend_request', p_id, 1, 'Finance', 'accountant', r.amount);
    n := 1;
  end if;
  perform notify(r.company_id, (select array_agg(coalesce(approver_role, 'owner')) from approval_steps where doc_type = 'spend_request' and doc_id = p_id and step_no = (select min(step_no) from approval_steps where doc_type = 'spend_request' and doc_id = p_id)),
    (select array_agg(approver_user) from approval_steps where doc_type = 'spend_request' and doc_id = p_id and approver_user is not null),
    'spend_request', r.number || ' needs approval: ' || r.title, 'GH₵ ' || to_char(r.amount, 'FM999,999,999,990.00'), '/requests/' || r.id);
  return n;
end $$;

create or replace function public.cancel_spend_request(p_id uuid, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare r spend_requests;
begin
  select * into r from spend_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if r.requested_by <> auth.uid() and not is_finance(r.company_id) then raise exception 'Only the person who raised it or Finance can cancel it'; end if;
  if r.status not in ('draft','submitted','approved') then raise exception '% is already %', r.number, r.status; end if;
  perform set_config('sika.spend', 'on', true);
  update spend_requests set status = 'cancelled', justification = justification || coalesce(E'\nCancelled: ' || p_note, '') where id = p_id;
  update approval_steps set status = 'skipped' where doc_type = 'spend_request' and doc_id = p_id and status = 'pending';
  perform set_config('sika.spend', 'off', true);
end $$;

-- Requests join the approval chains (Settings → Approval rules, type "Spend request").
alter table public.approval_rules drop constraint if exists approval_rules_doc_type_check;
alter table public.approval_rules add constraint approval_rules_doc_type_check
  check (doc_type in ('bill','payroll','purchase_request','expense_claim','purchase_order','spend_request'));

alter function public.doc_info(text, uuid) rename to doc_info_v26;
create or replace function public.doc_info(p_type text, p_id uuid, out company_id uuid, out amount numeric, out label text, out path text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
begin
  if p_type = 'spend_request' then
    select r.company_id, r.amount,
           r.number || ' · ' || case r.kind when 'cash_advance' then 'Cash advance' when 'payment' then 'Payment' else 'Purchase' end || ' · ' || r.title
             || coalesce(' · ' || (select email from memberships m where m.company_id = r.company_id and m.user_id = r.requested_by), ''),
           '/requests/' || r.id
      into company_id, amount, label, path from spend_requests r where r.id = p_id;
  else
    select d.company_id, d.amount, d.label, d.path into company_id, amount, label, path from doc_info_v26(p_type, p_id) d;
  end if;
end $$;

alter function public.decide_approval(uuid, boolean, text) rename to decide_approval_v26;
create or replace function public.decide_approval(p_step uuid, p_approve boolean, p_note text default null)
returns text language plpgsql security definer set search_path = public as $$
declare s approval_steps; r spend_requests; res text;
begin
  select * into s from approval_steps where id = p_step;
  if found and s.doc_type = 'spend_request' then
    select * into r from spend_requests where id = s.doc_id;
    if r.requested_by = auth.uid() then raise exception 'You cannot approve your own request'; end if;
  end if;
  res := decide_approval_v26(p_step, p_approve, p_note);
  if s.doc_type = 'spend_request' and res in ('approved','rejected') then
    perform set_config('sika.spend', 'on', true);
    update spend_requests set status = res, approved_at = case when res = 'approved' then now() end where id = s.doc_id;
    perform set_config('sika.spend', 'off', true);
    perform notify(r.company_id, case when res = 'approved' then array['accountant'] else array[]::text[] end, array[r.requested_by], 'spend_request_' || res,
      r.number || ' ' || res || ': ' || r.title, case when res = 'rejected' then p_note else 'Finance will now ' ||
        case r.kind when 'cash_advance' then 'pay the advance.' when 'payment' then 'make the payment.' else 'place the order.' end end, '/requests/' || r.id, true);
  elsif s.doc_type = 'spend_request' and res = 'pending' then
    perform notify(r.company_id, (select array_agg(coalesce(approver_role, 'owner')) from approval_steps where doc_type = 'spend_request' and doc_id = r.id and status = 'pending'
                                    and step_no = (select min(step_no) from approval_steps where doc_type = 'spend_request' and doc_id = r.id and status = 'pending')),
      null, 'spend_request', r.number || ' needs your approval: ' || r.title, null, '/requests/' || r.id);
  end if;
  return res;
end $$;

-- Finance acts on an approved request.
create or replace function public.spend_request_ready(p_id uuid) returns spend_requests
language plpgsql security definer set search_path = public as $$
declare r spend_requests;
begin
  select * into r from spend_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if not is_finance(r.company_id) and not (r.kind = 'purchase' and has_role(r.company_id, array['store'])) then raise exception 'Only Finance can act on approved requests'; end if;
  if r.status <> 'approved' then raise exception '% is % and cannot be actioned', r.number, r.status; end if;
  if approval_state('spend_request', r.id) <> 'approved' then raise exception '% has not been fully approved', r.number; end if;
  return r;
end $$;

create or replace function public.spend_request_done(p_id uuid, p_outcome text, p_outcome_id uuid, p_ref text) returns void
language plpgsql security definer set search_path = public as $$
declare r spend_requests;
begin
  perform set_config('sika.spend', 'on', true);
  update spend_requests set status = 'done', outcome = p_outcome, outcome_id = p_outcome_id, outcome_ref = p_ref where id = p_id returning * into r;
  perform set_config('sika.spend', 'off', true);
  perform notify(r.company_id, array[]::text[], array[r.requested_by], 'spend_request_done', r.number || ': ' || replace(p_outcome, '_', ' ') || ' ' || coalesce(p_ref, '') || ' done', null, '/requests/' || r.id, true);
end $$;

create or replace function public.request_to_po(p_id uuid, p_supplier uuid default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare r spend_requests; v uuid; n text;
begin
  r := spend_request_ready(p_id);
  if r.kind <> 'purchase' then raise exception 'Only a purchase request becomes a purchase order'; end if;
  if coalesce(p_supplier, r.supplier_id) is null then raise exception 'Choose the supplier'; end if;
  insert into purchase_orders (company_id, supplier_id, order_date, expected_date, project_id, branch_id, notes)
  values (r.company_id, coalesce(p_supplier, r.supplier_id), current_date, r.needed_by, r.project_id, r.branch_id, 'From ' || r.number || ': ' || r.title)
  returning id, number into v, n;
  insert into po_lines (po_id, company_id, account_id, description, qty, unit_cost, project_id)
  values (v, r.company_id, r.account_id, r.title, 1, r.amount, r.project_id);
  perform spend_request_done(p_id, 'purchase_order', v, coalesce(n, (select number from purchase_orders where id = v)));
  return v;
end $$;

create or replace function public.request_to_bill(p_id uuid, p_supplier uuid default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare r spend_requests; v uuid;
begin
  r := spend_request_ready(p_id);
  if r.kind = 'cash_advance' then raise exception 'A cash advance is paid with Pay advance'; end if;
  if coalesce(p_supplier, r.supplier_id) is null then raise exception 'Choose the supplier'; end if;
  insert into bills (company_id, supplier_id, bill_date, supplier_ref) values (r.company_id, coalesce(p_supplier, r.supplier_id), current_date, r.number) returning id into v;
  insert into bill_lines (bill_id, company_id, account_id, description, qty, unit_cost, taxable, project_id, cost_centre_id)
  values (v, r.company_id, r.account_id, r.title, 1, r.amount, false, r.project_id, r.cost_centre_id);
  perform spend_request_done(p_id, 'bill', v, 'draft bill');
  return v;
end $$;

-- A direct payment (no supplier invoice): Dr the expense, Cr the bank.
create or replace function public.pay_spend_request(p_id uuid, p_from uuid default null, p_date date default current_date, p_reference text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare r spend_requests; v_je uuid; v_from uuid;
begin
  r := spend_request_ready(p_id);
  if r.kind <> 'payment' then raise exception 'Only a payment request is paid directly'; end if;
  if not is_finance(r.company_id) then raise exception 'Only Finance can make payments'; end if;
  v_from := paying_account(r.company_id, p_from);
  v_je := post_journal(r.company_id, coalesce(p_date, current_date), r.number || ' ' || r.title || coalesce(' · ' || coalesce(r.payee, (select name from suppliers where id = r.supplier_id)), '') || coalesce(' · ' || p_reference, ''),
    jsonb_build_array(jl(r.account_id, r.amount, 0) || jsonb_build_object('project_id', r.project_id, 'branch_id', r.branch_id, 'cost_centre_id', r.cost_centre_id),
                      jl(v_from, 0, r.amount)), 'spend_request', r.id);
  perform spend_request_done(p_id, 'payment', v_je, (select entry_no from journal_entries where id = v_je));
  return v_je;
end $$;

-- ---------------------------------------------------------------- 3. Staff cash advances (imprest)
create table public.cash_advances (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  request_id uuid references public.spend_requests(id) on delete set null,
  employee_id uuid not null references public.employees(id),
  purpose text not null,
  amount numeric(14,2) not null check (amount > 0),
  issued_on date not null default current_date,
  paid_from uuid references public.accounts(id),
  due_on date not null,                                    -- retire by
  project_id uuid references public.projects(id) on delete set null,
  branch_id uuid references public.branches(id) on delete set null,
  cost_centre_id uuid references public.cost_centres(id) on delete set null,
  status text not null default 'open' check (status in ('open','submitted','retired','recovered')),
  submitted_at timestamptz,
  returned_note text,                                      -- why Finance sent the retirement back
  spent numeric(14,2), cash_returned numeric(14,2), reimbursed numeric(14,2),
  retired_on date, retired_by uuid,
  loan_id uuid references public.employee_loans(id),
  journal_entry_id uuid references public.journal_entries(id),
  retire_entry_id uuid references public.journal_entries(id),
  created_at timestamptz not null default now()
);
create index cash_advances_employee on public.cash_advances (employee_id, status);

create table public.advance_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  advance_id uuid not null references public.cash_advances(id) on delete cascade,
  line_date date not null default current_date,
  description text not null,
  account_id uuid not null references public.accounts(id),
  amount numeric(14,2) not null check (amount > 0),
  project_id uuid references public.projects(id) on delete set null,
  cost_centre_id uuid references public.cost_centres(id) on delete set null,
  receipt_path text,
  created_at timestamptz not null default now()
);

create or replace function public.advance_holder(a cash_advances) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from employees e where e.id = a.employee_id and e.user_id = auth.uid())
$$;

-- Lines can be changed only by the holder (or Finance) while the advance is open.
create or replace function public.advance_line_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare a cash_advances; r record;
begin
  r := case when tg_op = 'DELETE' then old else new end;
  select * into a from cash_advances where id = r.advance_id;
  if not found then raise exception 'Advance not found'; end if;
  if a.status <> 'open' then raise exception '% has been submitted for retirement; ask Finance to send it back to change it', a.number; end if;
  if not (advance_holder(a) or is_finance(a.company_id)) then raise exception 'Only the person holding the advance or Finance can record what it was spent on'; end if;
  if tg_op <> 'DELETE' then
    new.company_id := a.company_id;
    if not exists (select 1 from accounts where id = new.account_id and company_id = a.company_id and type in ('expense','asset')) then raise exception 'Choose an expense account'; end if;
    new.project_id := coalesce(new.project_id, a.project_id); new.cost_centre_id := coalesce(new.cost_centre_id, a.cost_centre_id);
    return new;
  end if;
  return old;
end $$;
create trigger advance_lines_guard before insert or update or delete on public.advance_lines for each row execute function public.advance_line_guard();
create trigger advance_lines_spend_gate before insert on public.advance_lines for each row execute function public.project_spend_gate();

-- Finance pays an approved cash-advance request: Dr Staff cash advances, Cr bank or cash.
create or replace function public.pay_advance(p_request uuid, p_from uuid default null, p_date date default current_date, p_due date default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare r spend_requests; v uuid; n text; v_from uuid; v_je uuid; why text; v_due date;
begin
  r := spend_request_ready(p_request);
  if r.kind <> 'cash_advance' then raise exception '% is not a cash advance request', r.number; end if;
  if not is_finance(r.company_id) then raise exception 'Only Finance can pay advances'; end if;
  why := advance_block_reason(r.employee_id);
  if why is not null then raise exception '%', why; end if;
  v_from := paying_account(r.company_id, p_from);
  v_due := coalesce(p_due, greatest(coalesce(r.needed_by, p_date), p_date) + (select advance_retire_days from companies where id = r.company_id));
  n := next_number(r.company_id, 'ADV', 'ADV-');
  insert into cash_advances (company_id, number, request_id, employee_id, purpose, amount, issued_on, paid_from, due_on, project_id, branch_id, cost_centre_id)
  values (r.company_id, n, r.id, r.employee_id, r.title, r.amount, coalesce(p_date, current_date), v_from, v_due, r.project_id, r.branch_id, r.cost_centre_id)
  returning id into v;
  v_je := post_journal(r.company_id, coalesce(p_date, current_date), 'Cash advance ' || n || ' to ' || (select full_name from employees where id = r.employee_id) || ': ' || r.title,
    jsonb_build_array(jl(acct(r.company_id, 'staff_advances'), r.amount, 0), jl(v_from, 0, r.amount)), 'cash_advance', v);
  update cash_advances set journal_entry_id = v_je where id = v;
  perform spend_request_done(p_request, 'advance', v, n);
  perform notify(r.company_id, array[]::text[], array[(select user_id from employees where id = r.employee_id)], 'advance_paid',
    'Advance ' || n || ' of GH₵ ' || to_char(r.amount, 'FM999,999,990.00') || ' paid to you', 'Retire it with receipts by ' || to_char(v_due, 'DD Mon YYYY') || '.', '/advances/' || v, true);
  return v;
end $$;

create or replace function public.submit_retirement(p_advance uuid) returns void
language plpgsql security definer set search_path = public as $$
declare a cash_advances; n int; nr int;
begin
  select * into a from cash_advances where id = p_advance for update;
  if not found then raise exception 'Advance not found'; end if;
  if not (advance_holder(a) or is_finance(a.company_id)) then raise exception 'Only the person holding the advance can submit it'; end if;
  if a.status <> 'open' then raise exception '% is already %', a.number, a.status; end if;
  select count(*), count(*) filter (where coalesce(receipt_path, '') = '') into n, nr from advance_lines where advance_id = a.id;
  if nr > 0 then raise exception 'Attach a receipt (a photo is fine) to every line before submitting. % line(s) have none.', nr; end if;
  update cash_advances set status = 'submitted', submitted_at = now(), returned_note = null where id = a.id;
  perform notify(a.company_id, array['accountant'], null, 'retirement_submitted', a.number || ' submitted for retirement',
    (select full_name from employees where id = a.employee_id) || ': ' || n || ' receipt(s)', '/advances/' || a.id);
end $$;

create or replace function public.return_retirement(p_advance uuid, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare a cash_advances;
begin
  select * into a from cash_advances where id = p_advance for update;
  if not found then raise exception 'Advance not found'; end if;
  if not is_finance(a.company_id) then raise exception 'Only Finance can send a retirement back'; end if;
  if a.status <> 'submitted' then raise exception '% is not waiting for checking', a.number; end if;
  if coalesce(trim(p_note), '') = '' then raise exception 'Say what needs fixing'; end if;
  update cash_advances set status = 'open', returned_note = p_note where id = a.id;
  perform notify(a.company_id, array[]::text[], array[(select user_id from employees where id = a.employee_id)], 'retirement_returned', a.number || ' sent back: ' || p_note, null, '/advances/' || a.id, true);
end $$;

-- Finance accepts the receipts: Dr each expense, Dr cash returned (or Cr cash reimbursed), Cr Staff cash advances.
create or replace function public.approve_retirement(p_advance uuid, p_cash uuid default null, p_date date default current_date) returns uuid
language plpgsql security definer set search_path = public as $$
declare a cash_advances; v_spent numeric; v_diff numeric; v_lines jsonb := '[]'::jsonb; l record; v_cash uuid; v_je uuid; who text;
begin
  select * into a from cash_advances where id = p_advance for update;
  if not found then raise exception 'Advance not found'; end if;
  if not is_finance(a.company_id) then raise exception 'Only Finance can approve a retirement'; end if;
  if advance_holder(a) and not has_role(a.company_id, array['owner']) then raise exception 'You cannot approve the retirement of your own advance'; end if;
  if a.status <> 'submitted' then raise exception '% has not been submitted for retirement', a.number; end if;
  select coalesce(sum(amount), 0) into v_spent from advance_lines where advance_id = a.id;
  v_diff := a.amount - v_spent;                 -- > 0: cash to return; < 0: we owe them
  v_cash := case when v_diff <> 0 then paying_account(a.company_id, p_cash) end;
  select full_name into who from employees where id = a.employee_id;
  for l in select * from advance_lines where advance_id = a.id loop
    v_lines := v_lines || jsonb_build_array(jl(l.account_id, l.amount, 0) || jsonb_build_object('project_id', l.project_id, 'cost_centre_id', l.cost_centre_id, 'branch_id', a.branch_id));
  end loop;
  if v_diff > 0 then v_lines := v_lines || jsonb_build_array(jl(v_cash, v_diff, 0)); end if;
  if v_diff < 0 then v_lines := v_lines || jsonb_build_array(jl(v_cash, 0, -v_diff)); end if;
  v_lines := v_lines || jsonb_build_array(jl(acct(a.company_id, 'staff_advances'), 0, a.amount));
  v_je := post_journal(a.company_id, coalesce(p_date, current_date), 'Retirement of ' || a.number || ' (' || who || ')' ||
            case when v_diff > 0 then ': GH₵ ' || to_char(v_diff, 'FM999,999,990.00') || ' returned' when v_diff < 0 then ': GH₵ ' || to_char(-v_diff, 'FM999,999,990.00') || ' reimbursed' else '' end,
            v_lines, 'advance_retirement', a.id);
  update cash_advances set status = 'retired', spent = v_spent, cash_returned = greatest(v_diff, 0), reimbursed = greatest(-v_diff, 0),
         retired_on = coalesce(p_date, current_date), retired_by = auth.uid(), retire_entry_id = v_je where id = a.id;
  perform notify(a.company_id, array[]::text[], array[(select user_id from employees where id = a.employee_id)], 'advance_retired', a.number || ' retired', null, '/advances/' || a.id, true);
  return v_je;
end $$;

-- Not retired long after the due date: move the balance to a staff loan recovered through payroll.
create or replace function public.recover_advance(p_advance uuid, p_installment numeric default null, p_date date default current_date) returns uuid
language plpgsql security definer set search_path = public as $$
declare a cash_advances; v_loan uuid; v_je uuid; v_days int;
begin
  select * into a from cash_advances where id = p_advance for update;
  if not found then raise exception 'Advance not found'; end if;
  if not is_finance(a.company_id) then raise exception 'Only Finance can recover an advance through payroll'; end if;
  if a.status <> 'open' then raise exception '% is %; only an open advance can be recovered', a.number, a.status; end if;
  select advance_recover_after_days into v_days from companies where id = a.company_id;
  if a.due_on + v_days > coalesce(p_date, current_date) then
    raise exception '% can be recovered through payroll from % (% days after it was due)', a.number, to_char(a.due_on + v_days, 'DD Mon YYYY'), v_days;
  end if;
  insert into employee_loans (company_id, employee_id, issue_date, principal, installment, balance, note)
  values (a.company_id, a.employee_id, coalesce(p_date, current_date), a.amount, least(coalesce(p_installment, a.amount), a.amount), a.amount, 'Unretired advance ' || a.number)
  returning id into v_loan;
  v_je := post_journal(a.company_id, coalesce(p_date, current_date), 'Unretired advance ' || a.number || ' moved to staff loan for payroll recovery',
    jsonb_build_array(jl(acct(a.company_id, 'staff_loans'), a.amount, 0), jl(acct(a.company_id, 'staff_advances'), 0, a.amount)), 'cash_advance', a.id);
  update employee_loans set journal_entry_id = v_je where id = v_loan;
  update cash_advances set status = 'recovered', loan_id = v_loan, retired_on = coalesce(p_date, current_date), retired_by = auth.uid(), retire_entry_id = v_je where id = a.id;
  perform notify(a.company_id, array[]::text[], array[(select user_id from employees where id = a.employee_id)], 'advance_recovered',
    a.number || ' will be deducted from your salary', 'GH₵ ' || to_char(least(coalesce(p_installment, a.amount), a.amount), 'FM999,999,990.00') || ' a month until repaid.', '/advances/' || a.id, true);
  return v_loan;
end $$;

-- ---------------------------------------------------------------- 4. Petty cash floats (fixed imprest)
create table public.petty_floats (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  account_id uuid not null references public.accounts(id),
  custodian_id uuid not null,                    -- a user
  float_amount numeric(14,2) not null check (float_amount > 0),
  voucher_limit numeric(14,2) not null check (voucher_limit > 0),
  count_every_days int not null default 30 check (count_every_days between 1 and 92),
  project_id uuid references public.projects(id) on delete set null,
  branch_id uuid references public.branches(id) on delete set null,
  cost_centre_id uuid references public.cost_centres(id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.petty_replenishments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  float_id uuid not null references public.petty_floats(id) on delete cascade,
  number text,
  rep_date date not null,
  vouchers_total numeric(14,2) not null,
  topup numeric(14,2) not null,                  -- restores shortages already written off
  amount numeric(14,2) not null,
  paid_from uuid references public.accounts(id),
  journal_entry_id uuid references public.journal_entries(id),
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create table public.petty_vouchers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  float_id uuid not null references public.petty_floats(id) on delete cascade,
  number text,
  voucher_date date not null default current_date,
  payee text not null,
  description text not null,
  account_id uuid not null references public.accounts(id),
  amount numeric(14,2) not null check (amount > 0),
  project_id uuid references public.projects(id) on delete set null,
  cost_centre_id uuid references public.cost_centres(id) on delete set null,
  receipt_path text,
  status text not null default 'recorded' check (status in ('recorded','approved','rejected')),
  reject_note text,
  replenishment_id uuid references public.petty_replenishments(id) on delete set null,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create table public.petty_counts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  float_id uuid not null references public.petty_floats(id) on delete cascade,
  count_date date not null default current_date,
  counted_by uuid default auth.uid(),
  denominations jsonb not null default '{}',     -- {"200": 3, "50": 4, "0.5": 6, ...}
  counted numeric(14,2) not null,
  expected numeric(14,2) not null,
  difference numeric(14,2) not null,             -- counted - expected; negative is a shortage
  note text,
  status text not null default 'submitted' check (status in ('submitted','approved')),
  treatment text check (treatment in ('expense','custodian','none')),
  approved_by uuid, approved_at timestamptz, approval_note text,
  journal_entry_id uuid references public.journal_entries(id),
  created_at timestamptz not null default now()
);

create or replace function public.float_custodian(f petty_floats) returns boolean
language sql stable security definer set search_path = public as $$ select f.custodian_id = auth.uid() $$;

-- Ledger balance of the float, vouchers not yet replenished, and the cash that should be in the box.
create or replace function public.float_position(p_float uuid)
returns table (ledger numeric, unreplenished numeric, expected_cash numeric, last_count date, last_count_status text, count_due boolean)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare f petty_floats;
begin
  select * into f from petty_floats where id = p_float;
  return query
  select b.v, u.v, b.v - u.v, c.count_date, c.status,
         (c.count_date is null and u.v > 0) or c.count_date < current_date - f.count_every_days
    from (select coalesce(sum(debit - credit), 0) v from journal_lines where account_id = f.account_id) b,
         (select coalesce(sum(amount), 0) v from petty_vouchers where float_id = f.id and replenishment_id is null and status <> 'rejected') u
    left join lateral (select count_date, status from petty_counts where float_id = f.id order by count_date desc, created_at desc limit 1) c on true;
end $$;

create or replace function public.create_petty_float(cid uuid, p_name text, p_custodian uuid, p_amount numeric, p_voucher_limit numeric,
  p_count_days int default 30, p_from uuid default null, p_date date default current_date, p_project uuid default null, p_branch uuid default null, p_cost_centre uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_acct uuid; v_code int; v uuid; v_from uuid;
begin
  if not is_finance(cid) then raise exception 'Only Finance can set up petty cash floats'; end if;
  if coalesce(trim(p_name), '') = '' then raise exception 'Name the float (e.g. Prestea site petty cash)'; end if;
  if not exists (select 1 from memberships where company_id = cid and user_id = p_custodian) then raise exception 'The custodian must be on the team'; end if;
  if p_voucher_limit > p_amount then raise exception 'The limit per voucher cannot be more than the float'; end if;
  v_from := paying_account(cid, p_from);
  select coalesce(max(code::int), 1019) + 1 into v_code from accounts where company_id = cid and code ~ '^10[2-9][0-9]$';
  if v_code > 1099 then raise exception 'No free account codes left for petty cash (1020 to 1099)'; end if;
  insert into accounts (company_id, code, name, type) values (cid, v_code::text, 'Petty cash: ' || trim(p_name), 'asset') returning id into v_acct;
  insert into petty_floats (company_id, name, account_id, custodian_id, float_amount, voucher_limit, count_every_days, project_id, branch_id, cost_centre_id)
  values (cid, trim(p_name), v_acct, p_custodian, p_amount, p_voucher_limit, coalesce(p_count_days, 30), p_project, p_branch, p_cost_centre) returning id into v;
  perform post_journal(cid, coalesce(p_date, current_date), 'Petty cash float set up: ' || trim(p_name), jsonb_build_array(jl(v_acct, p_amount, 0) || jsonb_build_object('branch_id', p_branch), jl(v_from, 0, p_amount)), 'petty_float', v);
  perform notify(cid, array[]::text[], array[p_custodian], 'petty_float', 'You hold the petty cash float ' || trim(p_name), 'GH₵ ' || to_char(p_amount, 'FM999,999,990.00') || '. Record every payout as a voucher with its receipt.', '/petty-cash', true);
  return v;
end $$;

create or replace function public.petty_voucher_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare f petty_floats; p record;
begin
  select * into f from petty_floats where id = coalesce(new.float_id, old.float_id);
  if tg_op = 'DELETE' then
    if old.replenishment_id is not null or old.status <> 'recorded' then raise exception 'This voucher has been replenished and is in the books'; end if;
    if not (float_custodian(f) or is_finance(f.company_id)) then raise exception 'Only the custodian or Finance can remove it'; end if;
    return old;
  end if;
  if coalesce(current_setting('sika.petty', true), '') = 'on' then return new; end if;
  if tg_op = 'UPDATE' then
    if old.replenishment_id is not null or old.status <> 'recorded' then raise exception 'This voucher has been replenished and is in the books'; end if;
    if new.status <> old.status or new.replenishment_id is distinct from old.replenishment_id then raise exception 'Vouchers are approved when the float is replenished'; end if;
  else
    new.number := next_number(f.company_id, 'PCV', 'PCV-'); new.status := 'recorded'; new.replenishment_id := null; new.created_by := auth.uid();
  end if;
  if not f.active then raise exception '% is closed', f.name; end if;
  if not (float_custodian(f) or is_finance(f.company_id)) then raise exception 'Only the custodian of % or Finance can record vouchers', f.name; end if;
  new.company_id := f.company_id;
  if not exists (select 1 from accounts where id = new.account_id and company_id = f.company_id and type in ('expense','asset')) then raise exception 'Choose an expense account'; end if;
  if new.amount > f.voucher_limit then raise exception 'GH₵ % is over the limit of GH₵ % per voucher for %. Use a spend request for bigger payments.', new.amount, f.voucher_limit, f.name; end if;
  select * into p from float_position(f.id);
  if new.amount - (case when tg_op = 'UPDATE' then old.amount else 0 end) > p.expected_cash then
    raise exception 'Only GH₵ % should be left in %. Ask Finance to replenish it.', p.expected_cash, f.name;
  end if;
  new.project_id := coalesce(new.project_id, f.project_id); new.cost_centre_id := coalesce(new.cost_centre_id, f.cost_centre_id);
  return new;
end $$;
create trigger petty_vouchers_guard before insert or update or delete on public.petty_vouchers for each row execute function public.petty_voucher_guard();
create trigger petty_vouchers_spend_gate before insert on public.petty_vouchers for each row execute function public.project_spend_gate();

-- The custodian (or Finance) counts the cash by note and coin.
create or replace function public.count_petty_cash(p_float uuid, p_denominations jsonb, p_note text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare f petty_floats; p record; v_counted numeric := 0; k text; v uuid; n numeric;
begin
  select * into f from petty_floats where id = p_float;
  if not found then raise exception 'Float not found'; end if;
  if not (float_custodian(f) or is_finance(f.company_id)) then raise exception 'Only the custodian or Finance can count %', f.name; end if;
  if exists (select 1 from petty_counts where float_id = f.id and status = 'submitted') then raise exception 'The last count of % is still waiting for Finance', f.name; end if;
  for k in select jsonb_object_keys(coalesce(p_denominations, '{}')) loop
    if k not in ('200','100','50','20','10','5','2','1','0.5','0.2','0.1','0.05','0.01') then raise exception 'Unknown note or coin: %', k; end if;
    n := (p_denominations->>k)::numeric;
    if n < 0 or n <> trunc(n) then raise exception 'Count whole notes and coins'; end if;
    v_counted := v_counted + n * k::numeric;
  end loop;
  select * into p from float_position(f.id);
  insert into petty_counts (company_id, float_id, denominations, counted, expected, difference, note, status, treatment, approved_at)
  values (f.company_id, f.id, coalesce(p_denominations, '{}'), round(v_counted, 2), p.expected_cash, round(v_counted - p.expected_cash, 2), p_note,
          case when round(v_counted - p.expected_cash, 2) = 0 then 'approved' else 'submitted' end,
          case when round(v_counted - p.expected_cash, 2) = 0 then 'none' end, case when round(v_counted - p.expected_cash, 2) = 0 then now() end)
  returning id into v;
  if round(v_counted - p.expected_cash, 2) <> 0 then
    perform notify(f.company_id, array['accountant'], null, 'petty_count_difference',
      f.name || ': cash count is ' || case when v_counted < p.expected_cash then 'short' else 'over' end || ' by GH₵ ' || to_char(abs(v_counted - p.expected_cash), 'FM999,999,990.00'),
      coalesce(p_note, ''), '/petty-cash', true);
  end if;
  return v;
end $$;

-- Finance (not the person who counted) accepts a difference: shortage to expense or charged to the custodian; overage to income.
create or replace function public.approve_petty_count(p_count uuid, p_treatment text default 'expense', p_note text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare c petty_counts; f petty_floats; v_je uuid; d numeric; v_emp uuid; v_loan uuid; other uuid;
begin
  select * into c from petty_counts where id = p_count for update;
  if not found then raise exception 'Count not found'; end if;
  select * into f from petty_floats where id = c.float_id;
  if not is_finance(c.company_id) then raise exception 'Only Finance can approve a cash count difference'; end if;
  if c.counted_by = auth.uid() and not has_role(c.company_id, array['owner']) then raise exception 'Someone other than the person who counted must approve it'; end if;
  if c.status <> 'submitted' then raise exception 'This count is already approved'; end if;
  if coalesce(trim(p_note), '') = '' then raise exception 'Explain the difference'; end if;
  d := c.difference;
  if d < 0 then
    if p_treatment = 'custodian' then
      select id into v_emp from employees where company_id = c.company_id and user_id = f.custodian_id limit 1;
      if v_emp is null then raise exception 'The custodian has no employee record, so the shortage cannot be charged to them'; end if;
      insert into employee_loans (company_id, employee_id, issue_date, principal, installment, balance, note)
      values (c.company_id, v_emp, current_date, -d, -d, -d, 'Petty cash shortage: ' || f.name) returning id into v_loan;
      other := acct(c.company_id, 'staff_loans');
    else
      other := acct(c.company_id, 'cash_short');
    end if;
    v_je := post_journal(c.company_id, c.count_date, 'Petty cash shortage: ' || f.name || ' · ' || p_note,
      jsonb_build_array(jl(other, -d, 0) || jsonb_build_object('branch_id', f.branch_id, 'cost_centre_id', f.cost_centre_id), jl(f.account_id, 0, -d)), 'petty_count', c.id);
    if v_loan is not null then update employee_loans set journal_entry_id = v_je where id = v_loan; end if;
  else
    v_je := post_journal(c.company_id, c.count_date, 'Petty cash overage: ' || f.name || ' · ' || p_note,
      jsonb_build_array(jl(f.account_id, d, 0), jl(acct(c.company_id, 'cash_over'), 0, d)), 'petty_count', c.id);
  end if;
  update petty_counts set status = 'approved', treatment = case when d < 0 then coalesce(p_treatment, 'expense') else 'none' end,
         approved_by = auth.uid(), approved_at = now(), approval_note = p_note, journal_entry_id = v_je where id = c.id;
  return v_je;
end $$;

-- Top the float back up to its full amount: Dr each approved voucher's expense, Dr the float for written-off shortages, Cr the bank.
create or replace function public.replenish_float(p_float uuid, p_from uuid default null, p_date date default current_date, p_reject uuid[] default '{}', p_reject_note text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare f petty_floats; p record; v_from uuid; v_lines jsonb := '[]'::jsonb; v record; v_tot numeric := 0; v_top numeric; v_id uuid; v_je uuid; n text;
begin
  select * into f from petty_floats where id = p_float for update;
  if not found then raise exception 'Float not found'; end if;
  if not is_finance(f.company_id) then raise exception 'Only Finance can replenish petty cash'; end if;
  if f.custodian_id = auth.uid() and not has_role(f.company_id, array['owner']) then raise exception 'The custodian cannot replenish their own float'; end if;
  select * into p from float_position(f.id);
  if p.last_count_status = 'submitted' then raise exception 'The last cash count of % has a difference waiting for approval. Approve it first.', f.name; end if;
  if p.last_count is null then raise exception 'Count the cash in % before replenishing it', f.name; end if;
  if p.last_count < coalesce(p_date, current_date) - least(f.count_every_days, 7) then
    raise exception '% was last counted on %. Count it again (within 7 days) before replenishing.', f.name, to_char(p.last_count, 'DD Mon YYYY');
  end if;
  if exists (select 1 from petty_vouchers where float_id = f.id and replenishment_id is null and status = 'recorded' and created_at > (select max(created_at) from petty_counts where float_id = f.id)) then
    raise exception 'Vouchers were recorded after the last count. Count the cash again first.';
  end if;
  if exists (select 1 from petty_vouchers where float_id = f.id and replenishment_id is null and status = 'recorded' and coalesce(receipt_path, '') = '' and not (id = any(coalesce(p_reject, '{}')))) then
    raise exception 'Some vouchers have no receipt. Reject them or attach the receipts first.';
  end if;
  if coalesce(array_length(p_reject, 1), 0) > 0 and coalesce(trim(p_reject_note), '') = '' then raise exception 'Say why vouchers were rejected'; end if;
  v_from := paying_account(f.company_id, p_from);
  n := next_number(f.company_id, 'PCR', 'PCR-');
  insert into petty_replenishments (company_id, float_id, number, rep_date, vouchers_total, topup, amount, paid_from, note)
  values (f.company_id, f.id, n, coalesce(p_date, current_date), 0, 0, 0, v_from, p_reject_note) returning id into v_id;
  perform set_config('sika.petty', 'on', true);
  update petty_vouchers set status = 'rejected', reject_note = p_reject_note, replenishment_id = v_id
   where float_id = f.id and replenishment_id is null and status = 'recorded' and id = any(coalesce(p_reject, '{}'));
  for v in select * from petty_vouchers where float_id = f.id and replenishment_id is null and status = 'recorded' loop
    v_lines := v_lines || jsonb_build_array(jl(v.account_id, v.amount, 0) || jsonb_build_object('project_id', v.project_id, 'cost_centre_id', v.cost_centre_id, 'branch_id', f.branch_id));
    v_tot := v_tot + v.amount;
  end loop;
  update petty_vouchers set status = 'approved', replenishment_id = v_id where float_id = f.id and replenishment_id is null and status = 'recorded';
  perform set_config('sika.petty', 'off', true);
  v_top := f.float_amount - p.ledger;         -- shortages written off since the last top-up
  if v_top < 0 then v_top := 0; end if;
  if v_tot + v_top = 0 then raise exception 'Nothing to replenish: % is full', f.name; end if;
  if v_top > 0 then v_lines := v_lines || jsonb_build_array(jl(f.account_id, v_top, 0)); end if;
  v_lines := v_lines || jsonb_build_array(jl(v_from, 0, v_tot + v_top));
  v_je := post_journal(f.company_id, coalesce(p_date, current_date), 'Petty cash replenishment ' || n || ': ' || f.name, v_lines, 'petty_replenishment', v_id);
  update petty_replenishments set vouchers_total = v_tot, topup = v_top, amount = v_tot + v_top, journal_entry_id = v_je where id = v_id;
  perform notify(f.company_id, array[]::text[], array[f.custodian_id], 'petty_replenished', f.name || ' replenished with GH₵ ' || to_char(v_tot + v_top, 'FM999,999,990.00'),
    case when coalesce(array_length(p_reject, 1), 0) > 0 then array_length(p_reject, 1) || ' voucher(s) rejected: ' || p_reject_note end, '/petty-cash', true);
  return v_id;
end $$;

-- ---------------------------------------------------------------- 5. Books checks and reminders
alter function public.ledger_checks(uuid) rename to ledger_checks_v26;
create or replace function public.ledger_checks(cid uuid)
returns table (check_name text, ledger numeric, documents numeric, direct numeric, difference numeric, ok boolean, explanation text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare bal numeric; doc numeric;
begin
  return query select * from ledger_checks_v26(cid);
  if not has_role(cid, array['owner','admin','accountant']) then return; end if;
  select coalesce(sum(l.debit - l.credit), 0) into bal from journal_lines l where l.account_id = acct(cid, 'staff_advances');
  select coalesce(sum(amount), 0) into doc from cash_advances where company_id = cid and status in ('open','submitted');
  return query select 'Staff cash advances vs advances not yet retired', bal, doc, 0::numeric, bal - doc, abs(bal - doc) < 0.01,
    'Every advance paid and not yet retired or recovered. A difference means something was posted to 1260 by hand.';
  select coalesce(sum(l.debit - l.credit), 0) into bal from journal_lines l join petty_floats f on f.account_id = l.account_id where f.company_id = cid;
  select coalesce(sum(f.float_amount + coalesce((select sum(c.difference) from petty_counts c where c.float_id = f.id and c.status = 'approved' and c.difference <> 0
            and c.approved_at > coalesce((select max(r.created_at) from petty_replenishments r where r.float_id = f.id), '-infinity')), 0)), 0)
    into doc from petty_floats f where f.company_id = cid;
  return query select 'Petty cash floats vs float amounts', bal, doc, 0::numeric, bal - doc, abs(bal - doc) < 0.01,
    'Each float''s ledger account should equal its float less any shortage written off since its last replenishment.';
end $$;

create or replace function public.cash_control_status(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare me uuid := auth.uid();
begin
  perform require_member(cid);
  return jsonb_build_object(
    'my_requests_open', (select count(*) from spend_requests where company_id = cid and requested_by = me and status in ('draft','submitted','approved')),
    'to_action', case when is_finance(cid) then (select count(*) from spend_requests where company_id = cid and status = 'approved') else 0 end,
    'my_advances_open', (select count(*) from cash_advances a join employees e on e.id = a.employee_id where a.company_id = cid and e.user_id = me and a.status = 'open'),
    'my_advances_overdue', (select count(*) from cash_advances a join employees e on e.id = a.employee_id where a.company_id = cid and e.user_id = me and a.status = 'open' and a.due_on < current_date),
    'advances_overdue', case when is_finance(cid) then (select count(*) from cash_advances where company_id = cid and status = 'open' and due_on < current_date) else 0 end,
    'retirements_to_check', case when is_finance(cid) then (select count(*) from cash_advances where company_id = cid and status = 'submitted') else 0 end,
    'counts_to_approve', case when is_finance(cid) then (select count(*) from petty_counts where company_id = cid and status = 'submitted') else 0 end,
    'floats_count_due', (select count(*) from petty_floats f, float_position(f.id) p where f.company_id = cid and f.active and p.count_due and (is_finance(cid) or f.custodian_id = me)));
end $$;

create or replace function public.run_cash_reminders_internal(cid uuid) returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; k text;
begin
  for r in select a.*, e.user_id uid, e.full_name from cash_advances a join employees e on e.id = a.employee_id
            where a.company_id = cid and a.status = 'open' and a.due_on <= current_date + 2 loop
    k := 'adv:' || r.id || ':' || case when r.due_on < current_date then 'late' else 'soon' end;
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, case when r.due_on < current_date then array['accountant'] else array[]::text[] end, array[r.uid], 'advance_due',
        r.number || ' (' || r.full_name || ') ' || case when r.due_on < current_date then 'was due for retirement on ' else 'is due for retirement on ' end || to_char(r.due_on, 'DD Mon YYYY'),
        'GH₵ ' || to_char(r.amount, 'FM999,999,990.00') || ': ' || r.purpose, '/advances/' || r.id, true);
      n := n + 1;
    end if;
  end loop;
  for r in select f.*, p.last_count from petty_floats f, float_position(f.id) p where f.company_id = cid and f.active and p.count_due loop
    k := 'pcc:' || r.id || ':' || coalesce(r.last_count::text, 'never');
    if not exists (select 1 from payment_reminders where company_id = cid and key = k) then
      insert into payment_reminders (company_id, key) values (cid, k);
      perform notify(cid, array['accountant'], array[r.custodian_id], 'petty_count_due', 'Count the cash in ' || r.name,
        case when r.last_count is null then 'It has not been counted yet.' else 'Last counted ' || to_char(r.last_count, 'DD Mon YYYY') || '.' end, '/petty-cash', true);
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;
create or replace function public.run_cash_reminders(cid uuid) returns int
language plpgsql security definer set search_path = public as $$
begin perform require_member(cid); return run_cash_reminders_internal(cid); end $$;
create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  return n;
end $$;


-- ---------------------------------------------------------------- 7. Purchase orders and requests in other currencies
-- A PO can be in USD, EUR or any currency set up in Settings. Each line keeps the supplier's price (unit_price_fx) and its
-- GHS cost at the order's rate (unit_cost), so stock, goods-received accruals and approval limits stay in GHS.
-- The supplier bill made from the order carries the order's currency at the day's rate. When it is posted, the rate
-- difference on goods already received goes to 4800 Foreign exchange gains and losses, and any price difference to 5150.
alter table public.purchase_orders add column if not exists currency text not null default 'GHS';
alter table public.purchase_orders add column if not exists exchange_rate numeric(14,6) not null default 1 check (exchange_rate > 0);
alter table public.po_lines add column if not exists unit_price_fx numeric(14,4) check (unit_price_fx >= 0);

create or replace function public.po_line_fx() returns trigger
language plpgsql security definer set search_path = public as $$
declare o purchase_orders;
begin
  select * into o from purchase_orders where id = new.po_id;
  if coalesce(o.currency, 'GHS') = 'GHS' then new.unit_price_fx := null; return new; end if;
  if new.unit_price_fx is null then new.unit_price_fx := round(new.unit_cost / o.exchange_rate, 4); end if;
  new.unit_cost := round(new.unit_price_fx * o.exchange_rate, 2);
  return new;
end $$;
create trigger po_lines_fx before insert or update on public.po_lines for each row execute function public.po_line_fx();

create or replace function public.po_currency_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.currency := upper(trim(coalesce(new.currency, 'GHS')));
  if new.currency = 'GHS' then new.exchange_rate := 1; end if;
  if tg_op = 'UPDATE' and (new.currency, new.exchange_rate) is distinct from (old.currency, old.exchange_rate) and old.status <> 'draft' then
    raise exception 'The currency and rate of % are fixed once it is approved', old.number;
  end if;
  return new;
end $$;
create trigger purchase_orders_currency before insert or update on public.purchase_orders for each row execute function public.po_currency_guard();

create or replace function public.po_rate_changed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (new.currency, new.exchange_rate) is distinct from (old.currency, old.exchange_rate) then
    update po_lines set unit_cost = round(unit_price_fx * new.exchange_rate, 2) where po_id = new.id and unit_price_fx is not null;
  end if;
  return new;
end $$;
create trigger purchase_orders_rate_changed after update on public.purchase_orders for each row execute function public.po_rate_changed();

create or replace function public.po_total_fx(p uuid) returns numeric language sql stable as $$
  select coalesce(round(sum(qty * coalesce(unit_price_fx, unit_cost)), 2), 0) from po_lines where po_id = p;
$$;

create or replace function public.bill_from_po(p_po uuid, p_ref text default null, p_date date default current_date, p_all boolean default false)
returns uuid language plpgsql security definer set search_path = public as $$
declare o purchase_orders; v_bill uuid; l record; i int := 0; q numeric; v_rate numeric;
begin
  select * into o from purchase_orders where id = p_po;
  if not found then raise exception 'Purchase order not found'; end if;
  perform require_member(o.company_id, array['owner','admin','accountant']);
  if o.status in ('draft','cancelled') then raise exception 'Approve the order first'; end if;
  v_rate := case when o.currency = 'GHS' then 1 else coalesce((select rate from currencies where company_id = o.company_id and code = o.currency), o.exchange_rate) end;
  insert into bills (company_id, supplier_id, supplier_ref, bill_date, warehouse_id, branch_id, currency, exchange_rate, notes)
  values (o.company_id, o.supplier_id, p_ref, p_date, o.warehouse_id, o.branch_id, o.currency, v_rate,
          'Purchase order ' || o.number || case when o.currency <> 'GHS' then ' (ordered at ' || o.exchange_rate || ')' else '' end) returning id into v_bill;
  for l in select * from po_lines where po_id = p_po order by sort loop
    q := case when p_all then l.qty - l.billed_qty else l.received_qty - l.billed_qty end;
    continue when q <= 0;
    insert into bill_lines (bill_id, company_id, product_id, account_id, description, qty, unit_cost, taxable, sort, project_id, request_id, po_line_id)
    values (v_bill, o.company_id, l.product_id, case when l.product_id is null then coalesce(l.account_id, acct(o.company_id, case when l.project_id is not null then 'project_materials' else 'expense' end)) end,
            l.description, q, coalesce(l.unit_price_fx, l.unit_cost), l.taxable, i, l.project_id, l.request_id, l.id);
    i := i + 1;
  end loop;
  if i = 0 then delete from bills where id = v_bill; raise exception 'Nothing on this order is waiting to be billed. Receive the goods first.'; end if;
  return v_bill;
end $$;

-- Supplier bills: rate differences against the order go to exchange gains and losses.
create or replace function public.post_bill(p_bill uuid)
returns text language plpgsql security definer set search_path = public as $$
declare
  b bills; l record; pr products; pl po_lines; v_lines jsonb := '[]'::jsonb; x numeric; v_dims jsonb;
  v_taxable numeric := 0; v_sub numeric := 0; v_amt numeric; g_amt numeric; g_sum numeric := 0; v_q numeric; v_r numeric; v_grni numeric; v_part numeric; v_fx numeric; po purchase_orders;
  v_vat numeric; v_nhil numeric; v_getf numeric; v_total numeric; v_je uuid; v_no text; v_wh uuid;
  g_vat numeric; g_nhil numeric; g_getf numeric;
begin
  select * into b from bills where id = p_bill for update;
  if not found then raise exception 'Bill not found'; end if;
  perform require_member(b.company_id, array['owner','admin','accountant']);
  if b.status <> 'draft' then raise exception 'This bill is already posted'; end if;
  if not exists (select 1 from bill_lines where bill_id = p_bill) then raise exception 'Add at least one line'; end if;
  if tax_rate('VAT', b.bill_date) is null then raise exception 'No VAT rate is set for %', b.bill_date; end if;
  if exists (select 1 from bill_lines bl join projects pj on pj.id = bl.project_id where bl.bill_id = p_bill and pj.company_id <> b.company_id) then
    raise exception 'A bill line is tagged to another company''s project';
  end if;
  x := b.exchange_rate; v_wh := coalesce(b.warehouse_id, wh(b.company_id));

  perform set_config('sika.posting','on', true);
  perform set_config('sika.po','on', true);
  for l in select * from bill_lines where bill_id = p_bill order by sort loop
    v_amt := round(l.qty * l.unit_cost, 2);
    g_amt := round(v_amt * x, 2);
    v_sub := v_sub + v_amt; g_sum := g_sum + g_amt;
    if l.taxable then v_taxable := v_taxable + v_amt; end if;
    v_dims := jsonb_build_object('project_id', l.project_id, 'cost_centre_id', l.cost_centre_id);
    pr := null;
    if l.product_id is not null then select * into pr from products where id = l.product_id for update; end if;
    v_q := 0;
    if l.po_line_id is not null then
      select * into pl from po_lines where id = l.po_line_id for update;
      v_q := least(l.qty, greatest(pl.received_qty - pl.billed_qty, 0));
      if v_q > 0 then   -- already received: clear the accrual; rate difference to 4800, price difference to 5150
        v_grni := round(v_q * pl.unit_cost, 2);
        v_part := round(g_amt * v_q / l.qty, 2);
        v_fx := 0;
        select * into po from purchase_orders where id = pl.po_id;
        if pl.unit_price_fx is not null and po.currency = b.currency then
          v_fx := round(v_q * l.unit_cost * (x - po.exchange_rate), 2);      -- same foreign price, different rate
        end if;
        v_lines := v_lines || jl(acct(b.company_id,'grni'), v_grni, 0)
                           || (jl(acct(b.company_id,'ppv'), greatest(v_part - v_grni - v_fx, 0), greatest(v_grni + v_fx - v_part, 0)) || v_dims);
        if v_fx <> 0 then v_lines := v_lines || jl(acct(b.company_id,'fx'), greatest(v_fx, 0), greatest(-v_fx, 0)); end if;
      end if;
      update po_lines set billed_qty = billed_qty + l.qty, received_qty = greatest(received_qty, billed_qty + l.qty) where id = pl.id;
    end if;
    v_r := l.qty - v_q;                                  -- not received through a GRN: posts as before
    if v_r > 0 then
      v_part := g_amt - case when v_q > 0 then round(g_amt * v_q / l.qty, 2) else 0 end;
      if pr.id is not null and pr.item_type = 'stock' and l.project_id is null then
        update products set
          cost = round((greatest(stock_qty,0) * cost + v_part) / nullif(greatest(stock_qty,0) + v_r, 0), 4),
          stock_qty = stock_qty + v_r, last_purchase_cost = round(v_part / v_r, 4)
         where id = pr.id;
        insert into stock_moves (company_id, product_id, warehouse_id, move_date, qty, unit_cost, reason, ref_type, ref_id)
        values (b.company_id, pr.id, v_wh, b.bill_date, v_r, round(v_part / v_r, 4), 'Goods received', 'bill', b.id);
        v_lines := v_lines || (jl(acct(b.company_id,'inventory'), v_part, 0) || v_dims);
      else
        v_lines := v_lines || (jl(coalesce(l.account_id, pr.expense_account_id,
                     case when l.project_id is not null then acct(b.company_id,'project_materials') else acct(b.company_id,'expense') end), v_part, 0) || v_dims);
      end if;
    end if;
  end loop;
  perform set_config('sika.posting','off', true);

  v_vat := round(v_taxable * tax_rate('VAT', b.bill_date), 2);
  v_nhil := round(v_taxable * tax_rate('NHIL', b.bill_date), 2);
  v_getf := round(v_taxable * tax_rate('GETFUND', b.bill_date), 2);
  v_total := v_sub + v_vat + v_nhil + v_getf;
  g_vat := round(v_vat * x, 2); g_nhil := round(v_nhil * x, 2); g_getf := round(v_getf * x, 2);
  v_no := next_number(b.company_id, 'BILL', 'BILL-');
  v_lines := v_lines
    || jl(acct(b.company_id,'vat_in'), g_vat, 0)
    || jl(acct(b.company_id,'nhil_in'), g_nhil, 0)
    || jl(acct(b.company_id,'getf_in'), g_getf, 0)
    || jl(acct(b.company_id,'ap'), 0, g_sum + g_vat + g_nhil + g_getf);
  v_je := post_journal(b.company_id, b.bill_date, 'Supplier bill ' || v_no || coalesce(' (' || b.supplier_ref || ')',''), v_lines, 'bill', b.id);
  update bills set status = 'posted', number = v_no, subtotal = v_sub, vat = v_vat, nhil = v_nhil,
         getfund = v_getf, total = v_total, journal_entry_id = v_je, due_date = coalesce(due_date, bill_date + 30)
   where id = p_bill;
  update project_requests set status = 'billed' where bill_id = p_bill and status = 'approved';
  perform set_config('sika.requests','on', true);
  update project_requests set status = 'billed' where id in (select request_id from bill_lines where bill_id = p_bill and request_id is not null) and status = 'ordered';
  perform set_config('sika.requests','off', true);
  update purchase_orders o set status = 'received'
   where o.id in (select pl2.po_id from bill_lines l2 join po_lines pl2 on pl2.id = l2.po_line_id where l2.bill_id = p_bill)
     and o.status in ('approved','sent','partial') and not exists (select 1 from po_lines z where z.po_id = o.id and z.received_qty < z.qty);
  perform set_config('sika.po','off', true);
  return v_no;
end $$;

-- Requests can be in a foreign currency; the GHS equivalent drives budgets and approval limits.
alter table public.spend_requests add column if not exists currency text not null default 'GHS';
alter table public.spend_requests add column if not exists fx_amount numeric(14,2) check (fx_amount > 0);
alter table public.spend_requests add column if not exists exchange_rate numeric(14,6) not null default 1 check (exchange_rate > 0);
create or replace function public.spend_request_fx() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.currency := upper(trim(coalesce(new.currency, 'GHS')));
  if new.currency = 'GHS' then new.exchange_rate := 1; new.fx_amount := null; return new; end if;
  if new.kind = 'cash_advance' then raise exception 'Cash advances are paid in GH₵'; end if;
  if new.fx_amount is null then raise exception 'Enter the amount in %', new.currency; end if;
  if tg_op = 'INSERT' or new.exchange_rate is null then
    new.exchange_rate := coalesce((select rate from currencies where company_id = new.company_id and code = new.currency), new.exchange_rate);
  end if;
  new.amount := round(new.fx_amount * new.exchange_rate, 2);
  return new;
end $$;
create trigger spend_requests_fx before insert or update on public.spend_requests for each row execute function public.spend_request_fx();

create or replace function public.request_to_po(p_id uuid, p_supplier uuid default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare r spend_requests; v uuid; n text;
begin
  r := spend_request_ready(p_id);
  if r.kind <> 'purchase' then raise exception 'Only a purchase request becomes a purchase order'; end if;
  if coalesce(p_supplier, r.supplier_id) is null then raise exception 'Choose the supplier'; end if;
  insert into purchase_orders (company_id, supplier_id, order_date, expected_date, project_id, branch_id, notes, currency, exchange_rate)
  values (r.company_id, coalesce(p_supplier, r.supplier_id), current_date, r.needed_by, r.project_id, r.branch_id, 'From ' || r.number || ': ' || r.title, r.currency, r.exchange_rate)
  returning id, number into v, n;
  insert into po_lines (po_id, company_id, account_id, description, qty, unit_cost, unit_price_fx, project_id)
  values (v, r.company_id, r.account_id, r.title, 1, r.amount, r.fx_amount, r.project_id);
  perform spend_request_done(p_id, 'purchase_order', v, coalesce(n, (select number from purchase_orders where id = v)));
  return v;
end $$;

create or replace function public.request_to_bill(p_id uuid, p_supplier uuid default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare r spend_requests; v uuid;
begin
  r := spend_request_ready(p_id);
  if r.kind = 'cash_advance' then raise exception 'A cash advance is paid with Pay advance'; end if;
  if coalesce(p_supplier, r.supplier_id) is null then raise exception 'Choose the supplier'; end if;
  insert into bills (company_id, supplier_id, bill_date, supplier_ref, currency, exchange_rate) values (r.company_id, coalesce(p_supplier, r.supplier_id), current_date, r.number, r.currency, r.exchange_rate) returning id into v;
  insert into bill_lines (bill_id, company_id, account_id, description, qty, unit_cost, taxable, project_id, cost_centre_id)
  values (v, r.company_id, r.account_id, r.title, 1, coalesce(r.fx_amount, r.amount), false, r.project_id, r.cost_centre_id);
  perform spend_request_done(p_id, 'bill', v, 'draft bill');
  return v;
end $$;

-- ---------------------------------------------------------------- 6. Security
alter table public.spend_requests enable row level security;
create policy "requests read" on public.spend_requests for select using (
  requested_by = auth.uid() or is_finance(company_id)
  or exists (select 1 from approval_steps s where s.doc_type = 'spend_request' and s.doc_id = spend_requests.id
             and (s.approver_user = auth.uid() or (s.approver_role is not null and has_role(s.company_id, array[s.approver_role])) or s.decided_by = auth.uid())));
create policy "requests add" on public.spend_requests for insert with check (is_member(company_id));
create policy "requests edit drafts" on public.spend_requests for update using (requested_by = auth.uid() and status = 'draft') with check (requested_by = auth.uid());
create policy "requests delete drafts" on public.spend_requests for delete using (requested_by = auth.uid() and status = 'draft');

alter table public.cash_advances enable row level security;
create policy "advances read" on public.cash_advances for select using (is_finance(company_id) or advance_holder(cash_advances) or has_role(company_id, array['hr']));
alter table public.advance_lines enable row level security;
create policy "advance lines read" on public.advance_lines for select using (exists (select 1 from cash_advances a where a.id = advance_id and (is_finance(a.company_id) or advance_holder(a))));
create policy "advance lines write" on public.advance_lines for all using (exists (select 1 from cash_advances a where a.id = advance_id and (is_finance(a.company_id) or advance_holder(a))))
  with check (exists (select 1 from cash_advances a where a.id = advance_id and (is_finance(a.company_id) or advance_holder(a))));

alter table public.petty_floats enable row level security;
create policy "floats read" on public.petty_floats for select using (is_finance(company_id) or custodian_id = auth.uid());
create policy "floats edit" on public.petty_floats for update using (is_finance(company_id)) with check (is_finance(company_id));
alter table public.petty_vouchers enable row level security;
create policy "vouchers read" on public.petty_vouchers for select using (exists (select 1 from petty_floats f where f.id = float_id and (is_finance(f.company_id) or f.custodian_id = auth.uid())));
create policy "vouchers write" on public.petty_vouchers for all using (exists (select 1 from petty_floats f where f.id = float_id and (is_finance(f.company_id) or f.custodian_id = auth.uid())))
  with check (exists (select 1 from petty_floats f where f.id = float_id and (is_finance(f.company_id) or f.custodian_id = auth.uid())));
alter table public.petty_counts enable row level security;
create policy "counts read" on public.petty_counts for select using (exists (select 1 from petty_floats f where f.id = float_id and (is_finance(f.company_id) or f.custodian_id = auth.uid())));
alter table public.petty_replenishments enable row level security;
create policy "replenishments read" on public.petty_replenishments for select using (exists (select 1 from petty_floats f where f.id = float_id and (is_finance(f.company_id) or f.custodian_id = auth.uid())));

do $$ declare t text; begin
  foreach t in array array['spend_requests','cash_advances','advance_lines','petty_floats','petty_vouchers','petty_counts','petty_replenishments'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
  end loop;
end $$;

-- Finance can open receipt photos attached to advances and petty cash vouchers.
do $$ begin
  if exists (select 1 from information_schema.schemata where schema_name = 'storage') then
    execute $q$create policy "receipts: imprest finance read" on storage.objects for select to authenticated
      using (bucket_id = 'receipts' and (
        exists (select 1 from public.advance_lines l where l.receipt_path = name and public.is_finance(l.company_id))
        or exists (select 1 from public.petty_vouchers v where v.receipt_path = name and public.is_finance(v.company_id))))$q$;
  end if;
end $$;

-- Function permissions
revoke execute on all functions in schema public from public, anon;
grant execute on all functions in schema public to authenticated;
revoke execute on function public.post_journal(uuid,date,text,jsonb,text,uuid) from authenticated;
revoke execute on function public.seed_accounts(uuid) from authenticated;
revoke execute on function public.seed_accounts_v11(uuid) from authenticated;
revoke execute on function public.seed_accounts_v12(uuid) from authenticated;
revoke execute on function public.seed_accounts_v13(uuid) from authenticated;
revoke execute on function public.seed_accounts_v14(uuid) from authenticated;
revoke execute on function public.seed_accounts_v20(uuid) from authenticated;
revoke execute on function public.seed_accounts_v21(uuid) from authenticated;
revoke execute on function public.seed_accounts_v27(uuid) from authenticated;
revoke execute on function public.doc_info_v26(text,uuid) from authenticated;
revoke execute on function public.decide_approval_v26(uuid,boolean,text) from authenticated;
revoke execute on function public.ledger_checks_v26(uuid) from authenticated;
revoke execute on function public.spend_request_ready(uuid) from authenticated;
revoke execute on function public.spend_request_done(uuid,text,uuid,text) from authenticated;
revoke execute on function public.run_cash_reminders_internal(uuid) from authenticated;
revoke execute on function public.run_all_cash_reminders() from authenticated;
revoke execute on function public.seed_leave_types(uuid) from authenticated;
revoke execute on function public.seed_asset_categories(uuid) from authenticated;
revoke execute on function public.seed_cycle_responsibilities(uuid) from authenticated;
revoke execute on function public.next_number(uuid,text,text) from authenticated;
revoke execute on function public.notify(uuid,text[],uuid[],text,text,text,text,boolean) from authenticated;
revoke execute on function public.run_all_payment_reminders() from authenticated;
revoke execute on function public.run_all_contract_reminders() from authenticated;
revoke execute on function public.run_contract_reminders_internal(uuid) from authenticated;
revoke execute on function public.child_company() from authenticated;
revoke execute on function public.project_cost_items(uuid) from authenticated;
revoke execute on function public.project_cost_totals(uuid) from authenticated;
revoke execute on function public.finalize_expense(uuid) from authenticated;
revoke execute on function public.doc_dims(text,uuid) from authenticated;
revoke execute on function public.wh(uuid) from authenticated;
revoke execute on function public.transit_wh(uuid) from authenticated;
revoke execute on function public.ledger_checks_v20(uuid) from authenticated;
revoke execute on function public.unposted_documents_v20(uuid) from authenticated;
revoke execute on function public.project_close_check_v21(uuid) from authenticated;
revoke execute on function public.project_close_check_v22(uuid) from authenticated;
revoke execute on function public.create_project_from_template_v13(uuid, text, uuid, date, uuid) from authenticated;
grant execute on function public.public_help(uuid) to anon;
grant execute on function public.submit_case_public(uuid,text,text,text,text,text) to anon;
grant execute on function public.case_status_public(text,text) to anon;
grant execute on function public.reply_case_public(text,text,text,int) to anon;


-- ======================================================================
-- 0014_asnys_v2_8.sql
-- ======================================================================
-- Asnys ERP v2.8 — projects on hold until further notice
--   1. A project can be put on hold before it starts as well as while it is in progress.
--   2. The hold records since when, why, and an optional review date (blank = until further notice).
--   3. Resuming returns a project to where it was: Not started if work never began, otherwise In progress.
--   4. While on hold, new time, expense claims, purchase requests, spend requests, cash advances, purchase orders,
--      stock issues and stock requests for the project are refused. Accountants, admins and owners can still book
--      costs that must be paid (security, standby, storage). Returns to store are always allowed.
--   5. The project manager and Finance are reminded when the review date arrives.
-- Run after 0013.

alter table public.projects add column if not exists hold_since date;
alter table public.projects add column if not exists hold_reason text;
alter table public.projects add column if not exists hold_review date;
alter table public.projects add column if not exists hold_reminded date;

-- Projects already on hold: take the date and reason from their last stage change.
update public.projects p set hold_since = l.changed_at::date, hold_reason = l.note
from (select distinct on (project_id) project_id, changed_at, note from public.project_status_log
      where to_status = 'on_hold' order by project_id, changed_at desc) l
where p.id = l.project_id and p.status = 'on_hold' and p.hold_since is null;
update public.projects set hold_since = current_date where status = 'on_hold' and hold_since is null;

drop function if exists public.set_project_status(uuid, text, text, date, boolean);
create or replace function public.set_project_status(p_project uuid, p_action text, p_note text default null, p_date date default current_date,
  p_force boolean default false, p_review date default null)
returns text language plpgsql security definer set search_path = public as $$
declare pr projects; v_to text; v_acct boolean; v_blocks int; v_email text;
begin
  select * into pr from projects where id = p_project for update;
  if not found then raise exception 'Project not found'; end if;
  if pr.is_template then raise exception 'Templates do not have a status'; end if;
  v_acct := has_role(pr.company_id, array['owner','admin','accountant']);
  if not (v_acct or can_manage_project(p_project)) then raise exception 'Only the project''s manager or an accountant can do this'; end if;
  v_to := case p_action
    when 'start' then case when pr.status in ('planned') then 'active' end
    when 'hold' then case when pr.status in ('planned','active') then 'on_hold' end
    when 'resume' then case when pr.status = 'on_hold' then case when pr.actual_start is null then 'planned' else 'active' end end
    when 'hold_review' then case when pr.status = 'on_hold' then 'on_hold' end
    when 'complete' then case when pr.status = 'active' or (pr.status = 'on_hold' and pr.actual_start is not null) then 'done' end
    when 'resume_work' then case when pr.status = 'done' then 'active' end
    when 'close' then case when pr.status = 'done' then 'closed' end
    when 'reopen' then case when pr.status in ('closed','cancelled') then case when pr.status = 'closed' then 'done' else 'planned' end end
    when 'cancel' then case when pr.status in ('planned','active','on_hold') then 'cancelled' end
  end;
  if v_to is null then raise exception 'You cannot % a project that is %', replace(p_action, '_', ' '), replace(pr.status, '_', ' '); end if;
  if p_action in ('hold','cancel','reopen') and coalesce(trim(p_note),'') = '' then raise exception 'Give a reason'; end if;
  if p_action in ('hold','hold_review') and p_review is not null and p_review < current_date then raise exception 'The review date cannot be in the past'; end if;
  if p_action = 'reopen' and not v_acct then raise exception 'Only an accountant, admin or the owner can reopen a closed project'; end if;
  if p_action = 'close' then
    select count(*) into v_blocks from project_close_check(p_project) where severity = 'block';
    if v_blocks > 0 and not (p_force and v_acct and coalesce(trim(p_note),'') <> '') then
      raise exception '% item% must be cleared before closing (see the close-out checklist). An accountant can close anyway with a reason.', v_blocks, case when v_blocks = 1 then '' else 's' end;
    end if;
  end if;
  if p_action = 'cancel' and exists (select 1 from timesheets where project_id = p_project and status = 'approved') and not v_acct then
    raise exception 'Time has been booked to this project. Complete and close it instead, or ask an accountant.';
  end if;
  perform set_config('sika.lifecycle','on', true);
  update projects set status = v_to,
    actual_start = case when v_to = 'active' and p_action <> 'resume' then coalesce(actual_start, p_date) else actual_start end,
    actual_end = case when v_to = 'done' then p_date when p_action = 'resume_work' then null else actual_end end,
    closed_at = case when v_to = 'closed' then now() when p_action = 'reopen' then null else closed_at end,
    closed_by = case when v_to = 'closed' then auth.uid() when p_action = 'reopen' then null else closed_by end,
    close_notes = case when v_to = 'closed' then p_note else close_notes end,
    percent_complete_override = case when v_to = 'done' then 100 when p_action = 'resume_work' then null else percent_complete_override end,
    hold_since = case when p_action = 'hold' then current_date when v_to = 'on_hold' then hold_since end,
    hold_reason = case when p_action = 'hold' then trim(p_note) when v_to = 'on_hold' then hold_reason end,
    hold_review = case when p_action in ('hold','hold_review') then p_review when v_to = 'on_hold' then hold_review end,
    hold_reminded = case when p_action in ('hold','hold_review') then null when v_to = 'on_hold' then hold_reminded end
  where id = p_project;
  perform set_config('sika.lifecycle','off', true);
  select email into v_email from auth.users where id = auth.uid();
  insert into project_status_log (company_id, project_id, from_status, to_status, note, changed_email)
  values (pr.company_id, p_project, pr.status, v_to,
    case when p_force and p_action = 'close' then 'Closed with open items: ' || p_note
         when p_action in ('hold','hold_review') then concat_ws(' · ', nullif(trim(coalesce(p_note,'')), ''),
           case when p_review is null then 'Until further notice' else 'Review on ' || to_char(p_review, 'DD Mon YYYY') end)
         else p_note end, v_email);
  if p_action in ('hold','resume','cancel') then
    perform notify(pr.company_id, array['accountant'], array_remove(array[pr.manager_id], null), 'project_' || p_action,
      coalesce(pr.number || ' ', '') || pr.name || case p_action when 'hold' then ' is on hold' when 'resume' then ' has resumed' else ' was cancelled' end,
      case when p_action = 'hold' then trim(p_note) || case when p_review is null then ' (until further notice)' else ' (review on ' || to_char(p_review, 'DD Mon YYYY') || ')' end else p_note end,
      '/projects/' || p_project, false);
  end if;
  return v_to;
end $$;

-- Closed or cancelled: nothing new. On hold: no new work or spending except by Finance; returns to store always allowed.
create or replace function public.closed_project_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare st text; pid uuid; cid uuid; v_since date;
begin
  pid := new.project_id;
  if pid is null then return new; end if;
  select status, company_id, hold_since into st, cid, v_since from projects where id = pid;
  if st in ('closed','cancelled') then raise exception 'This project is %. Reopen it to book anything to it.', st; end if;
  if st = 'on_hold'
     and tg_table_name in ('timesheets','expense_claims','project_requests','spend_requests','cash_advances','po_lines','stock_issues','stock_requests')
     and not (tg_table_name = 'stock_issues' and coalesce(to_jsonb(new)->>'kind', 'issue') = 'return')
     and not has_role(cid, array['owner','admin','accountant']) then
    raise exception 'This project is on hold%. Resume work on the project first, or ask Finance to book it.',
      case when v_since is not null then ' since ' || to_char(v_since, 'DD Mon YYYY') else '' end;
  end if;
  return new;
end $$;

do $$ declare t text; begin
  foreach t in array array['spend_requests','cash_advances'] loop
    if not exists (select 1 from pg_trigger where tgname = t || '_closed_project') then
      execute format('create trigger %I before insert on public.%I for each row execute function public.closed_project_guard()', t || '_closed_project', t);
    end if;
  end loop;
end $$;

-- Daily: remind the project manager and Finance when a held project reaches its review date (once per review date).
create or replace function public.run_project_hold_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  for r in select * from projects where status = 'on_hold' and hold_review is not null and hold_review <= current_date
             and (hold_reminded is null or hold_reminded < hold_review) loop
    perform notify(r.company_id, array['accountant'], array_remove(array[r.manager_id], null), 'project_hold_review',
      coalesce(r.number || ' ', '') || r.name || ': on-hold review due',
      'On hold since ' || to_char(coalesce(r.hold_since, current_date), 'DD Mon YYYY') || coalesce(': ' || r.hold_reason, '') ||
      '. Resume work, set a new review date, or cancel.', '/projects/' || r.id, true);
    update projects set hold_reminded = current_date where id = r.id;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_project_hold_reminders() from public, anon, authenticated;

-- The daily cash reminder job (asnys-cash-reminders) now also sends the on-hold review reminders, so no new schedule is needed.
create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;


-- ======================================================================
-- 0015_asnys_v2_8_1.sql
-- ======================================================================
-- Asnys ERP v2.8.1 — one link between tenders and projects
-- A tender records the project it became (tenders.project_id) and a project records the tender it came from
-- (projects.tender_id). Two database links between the same tables made Supabase refuse pages that show a tender's
-- project ("more than one relationship was found for 'tenders' and 'projects'"). The project keeps its tender_id, but it
-- is no longer a database link; a trigger clears it when a tender is deleted, which is what the link did. Run after 0014.

alter table public.projects drop constraint if exists projects_tender_id_fkey;

create or replace function public.clear_project_tender() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update projects set tender_id = null where tender_id = old.id;
  return old;
end $$;
drop trigger if exists tenders_clear_project on public.tenders;
create trigger tenders_clear_project after delete on public.tenders for each row execute function public.clear_project_tender();

-- Tell Supabase's API to re-read the links now.
notify pgrst, 'reload schema';


-- ======================================================================
-- 0016_asnys_v2_9.sql
-- ======================================================================
-- Asnys ERP v2.9 — Safety, Compliance & Sustainability
-- Built around the structure of the international management-system standards:
--   ISO 45001 (occupational health and safety): hazard reporting, incidents and investigation, permits to work,
--     inspections, corrective and preventive actions, safety performance (LTIFR, TRIR).
--   ISO 37301 (compliance management): register of compliance obligations (permits, licences, filings, certificates,
--     insurance) with owners, evidence, renewal and reminders; policies that staff must read and acknowledge.
--   ISO 14001 and the GHG Protocol / GRI 302-306: energy, fuel, water and waste records converted to tonnes of CO2e by
--     scope with editable emission factors, for sustainability reporting.
-- HSE officer is a tick on a team member (any role can also be the HSE officer). Owners and admins always count as one.
-- Site safety: toolbox talks with attendance, company / site / visitor inductions with expiry (optional "no induction,
--   no work" rule on timesheets), emergency drills and safety meetings; a Safety tab on every project.
-- Run after 0015.

-- ---------------------------------------------------------------- 1. HSE officers
alter table public.memberships add column if not exists hse boolean not null default false;

create or replace function public.is_hse(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (hse or role in ('owner','admin')));
$$;

create or replace function public.hse_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and hse;
$$;

create or replace function public.set_member_hse(cid uuid, p_user uuid, p_on boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can choose HSE officers'; end if;
  update memberships set hse = p_on where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
end $$;

-- Notify only the people named (the general notify() also copies every owner and admin).
create or replace function public.notify_users(cid uuid, p_users uuid[], p_kind text, p_title text, p_body text default null, p_path text default null, p_include_self boolean default false)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into notifications (company_id, user_id, kind, title, body, path)
  select distinct cid, u, p_kind, p_title, p_body, p_path from unnest(coalesce(p_users, '{}'::uuid[])) u
  where u is not null and exists (select 1 from memberships m where m.company_id = cid and m.user_id = u) and (p_include_self or u is distinct from auth.uid());
  get diagnostics n = row_count;
  return n;
end $$;

-- Anyone in the company who is managing a project (its manager), or an HSE officer.
create or replace function public.hse_or_pm(cid uuid, pid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select is_hse(cid) or (pid is not null and exists (select 1 from projects where id = pid and manager_id = auth.uid()));
$$;

-- ---------------------------------------------------------------- 2. Incidents, near misses and observations
create table public.hse_incidents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  kind text not null default 'near_miss' check (kind in ('observation','near_miss','first_aid','medical_treatment','restricted_work',
    'lost_time','fatality','property_damage','environmental','dangerous_occurrence','vehicle','security','occupational_illness')),
  occurred_at timestamptz not null default now(),
  project_id uuid references public.projects(id) on delete set null,
  location text,
  description text not null,
  immediate_action text,
  persons_involved text,
  injured_employee_id uuid references public.employees(id) on delete set null,
  injured_name text,
  injury_nature text,
  body_part text,
  lost_days int not null default 0 check (lost_days >= 0),
  cost_estimate numeric(14,2),
  potential_severity int check (potential_severity between 1 and 5),
  reportable boolean not null default false,
  authority text,
  authority_ref text,
  reported_to_authority_on date,
  reported_by uuid default auth.uid(),
  reported_email text,
  investigator_id uuid,
  root_cause text,
  contributing_factors text,
  findings text,
  status text not null default 'reported' check (status in ('reported','investigating','action','closed')),
  closed_by uuid, closed_at timestamptz, closure_note text,
  created_at timestamptz not null default now()
);
create index on public.hse_incidents (company_id, occurred_at desc);

create table public.hse_files (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  parent_type text not null check (parent_type in ('incident','inspection','permit','obligation','policy','action','session')),
  parent_id uuid not null,
  name text not null,
  storage_path text not null,
  size_bytes bigint,
  note text,
  valid_until date,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.hse_files (parent_type, parent_id);

create or replace function public.hse_incident_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if not is_member(new.company_id) then raise exception 'You do not have access to this company'; end if;
    new.number := coalesce(new.number, next_number(new.company_id, 'INC', 'INC-'));
    new.status := 'reported';
    new.reported_by := coalesce(new.reported_by, auth.uid());
    new.reported_email := (select email from auth.users where id = new.reported_by);
    new.closed_by := null; new.closed_at := null;
    if new.occurred_at > now() + interval '1 hour' then raise exception 'The incident cannot be in the future'; end if;
  elsif coalesce(current_setting('sika.hse', true), '') <> 'on' then
    if new.status is distinct from old.status or new.closed_by is distinct from old.closed_by then
      raise exception 'Use Start investigation, Actions under way and Close to move an incident along';
    end if;
    if old.status = 'closed' then raise exception 'This incident is closed. An HSE officer can reopen it.'; end if;
    if not (hse_or_pm(old.company_id, old.project_id) or old.investigator_id = auth.uid()
            or (old.status = 'reported' and old.reported_by = auth.uid())) then
      raise exception 'Only the HSE officer, the investigator or the project manager can change this incident';
    end if;
    new.number := old.number; new.reported_by := old.reported_by; new.reported_email := old.reported_email; new.company_id := old.company_id;
  end if;
  return new;
end $$;
create trigger hse_incidents_defaults before insert or update on public.hse_incidents for each row execute function public.hse_incident_defaults();

-- Labels for messages.
create or replace function public.hse_kind_label(k text) returns text language sql immutable as $$
  select case k when 'observation' then 'Safety observation' when 'near_miss' then 'Near miss' when 'first_aid' then 'First-aid injury'
    when 'medical_treatment' then 'Medical treatment injury' when 'restricted_work' then 'Restricted work injury' when 'lost_time' then 'Lost-time injury'
    when 'fatality' then 'Fatality' when 'property_damage' then 'Property damage' when 'environmental' then 'Environmental incident'
    when 'dangerous_occurrence' then 'Dangerous occurrence' when 'vehicle' then 'Vehicle incident' when 'security' then 'Security incident'
    when 'occupational_illness' then 'Occupational illness' else k end;
$$;

-- Recordable (TRIR) and lost-time (LTIFR) classes.
create or replace function public.hse_recordable(k text) returns boolean language sql immutable as $$
  select k in ('medical_treatment','restricted_work','lost_time','fatality','occupational_illness');
$$;
create or replace function public.hse_lti(k text) returns boolean language sql immutable as $$
  select k in ('lost_time','fatality');
$$;

create or replace function public.hse_incident_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_pm uuid; v_serious boolean;
begin
  select manager_id into v_pm from projects where id = new.project_id;
  v_serious := new.kind in ('lost_time','fatality','dangerous_occurrence','environmental') or coalesce(new.potential_severity, 0) >= 4;
  if v_serious then
    perform notify(new.company_id, array[]::text[], array_remove(hse_users(new.company_id) || v_pm, null), 'hse_incident',
      hse_kind_label(new.kind) || ' reported: ' || new.number, left(new.description, 160) || coalesce(' · ' || new.location, ''), '/hse/incidents/' || new.id, false);
  else
    perform notify_users(new.company_id, array_remove(hse_users(new.company_id) || v_pm, null), 'hse_incident',
      hse_kind_label(new.kind) || ' reported: ' || new.number, left(new.description, 160) || coalesce(' · ' || new.location, ''), '/hse/incidents/' || new.id, false);
  end if;
  return null;
end $$;
create trigger hse_incidents_notice after insert on public.hse_incidents for each row execute function public.hse_incident_notice();

-- ---------------------------------------------------------------- 3. Corrective and preventive actions (CAPA)
create table public.hse_actions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  source text not null default 'other' check (source in ('incident','inspection','audit','obligation','risk','observation','management_review','other')),
  source_id uuid,
  project_id uuid references public.projects(id) on delete set null,
  title text not null,
  description text,
  kind text not null default 'corrective' check (kind in ('corrective','preventive','improvement')),
  priority text not null default 'medium' check (priority in ('low','medium','high')),
  owner_id uuid,
  due_date date,
  status text not null default 'open' check (status in ('open','done','verified','cancelled')),
  done_by uuid, done_at timestamptz, done_note text,
  verified_by uuid, verified_at timestamptz, verify_note text,
  reminded_on date,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.hse_actions (company_id, status, due_date);
create index on public.hse_actions (source, source_id);

create or replace function public.hse_action_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if coalesce(current_setting('sika.hse', true), '') <> 'on' and not hse_or_pm(new.company_id, new.project_id) then
      raise exception 'Only an HSE officer or the project manager can raise actions';
    end if;
    new.number := coalesce(new.number, next_number(new.company_id, 'CAPA', 'CAPA-'));
    new.status := 'open'; new.done_by := null; new.verified_by := null;
    new.created_by := coalesce(new.created_by, auth.uid());
  elsif coalesce(current_setting('sika.hse', true), '') <> 'on' then
    if (new.status, new.done_by, new.verified_by) is distinct from (old.status, old.done_by, old.verified_by) then
      raise exception 'Use Mark done, Verify, Reopen or Cancel to change an action';
    end if;
    if old.status in ('verified','cancelled') then raise exception 'This action is closed'; end if;
    if not hse_or_pm(old.company_id, old.project_id) then raise exception 'Only an HSE officer or the project manager can change this action'; end if;
    new.number := old.number; new.company_id := old.company_id; new.source := old.source; new.source_id := old.source_id;
  end if;
  return new;
end $$;
create trigger hse_actions_defaults before insert or update on public.hse_actions for each row execute function public.hse_action_defaults();

create or replace function public.hse_action_notice() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.owner_id is not null and (tg_op = 'INSERT' or new.owner_id is distinct from old.owner_id) then
    perform notify_users(new.company_id, array[new.owner_id], 'hse_action', 'Action for you: ' || new.number,
      new.title || coalesce(' · due ' || to_char(new.due_date, 'DD Mon YYYY'), ''), '/hse/actions', false);
  end if;
  return null;
end $$;
create trigger hse_actions_notice after insert or update on public.hse_actions for each row execute function public.hse_action_notice();

-- Owner (or HSE) marks done; a different person, an HSE officer, verifies it worked.
create or replace function public.hse_action_step(p_id uuid, p_action text, p_note text default null) returns text
language plpgsql security definer set search_path = public as $$
declare a hse_actions; v_to text;
begin
  select * into a from hse_actions where id = p_id for update;
  if not found then raise exception 'Action not found'; end if;
  if not is_member(a.company_id) then raise exception 'You do not have access to this company'; end if;
  if p_action = 'done' then
    if a.status <> 'open' then raise exception 'Only an open action can be marked done'; end if;
    if not (a.owner_id = auth.uid() or hse_or_pm(a.company_id, a.project_id)) then raise exception 'Only the action owner, the project manager or an HSE officer can mark it done'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Say what was done'; end if;
    v_to := 'done';
  elsif p_action = 'verify' then
    if a.status <> 'done' then raise exception 'Mark the action done before verifying it'; end if;
    if not is_hse(a.company_id) then raise exception 'Only an HSE officer can verify that an action worked'; end if;
    if a.done_by = auth.uid() then raise exception 'Someone other than the person who did the work must verify it'; end if;
    v_to := 'verified';
  elsif p_action = 'reopen' then
    if a.status not in ('done') then raise exception 'Only an action marked done can be sent back'; end if;
    if not is_hse(a.company_id) then raise exception 'Only an HSE officer can send an action back'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Say why it is not effective yet'; end if;
    v_to := 'open';
  elsif p_action = 'cancel' then
    if a.status not in ('open','done') then raise exception 'This action is already closed'; end if;
    if not is_hse(a.company_id) then raise exception 'Only an HSE officer can cancel an action'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Give a reason'; end if;
    v_to := 'cancelled';
  else raise exception 'Unknown step %', p_action;
  end if;
  perform set_config('sika.hse', 'on', true);
  update hse_actions set status = v_to,
    done_by = case when p_action = 'done' then auth.uid() when p_action = 'reopen' then null else done_by end,
    done_at = case when p_action = 'done' then now() when p_action = 'reopen' then null else done_at end,
    done_note = case when p_action = 'done' then p_note else done_note end,
    verified_by = case when p_action = 'verify' then auth.uid() else verified_by end,
    verified_at = case when p_action = 'verify' then now() else verified_at end,
    verify_note = case when p_action in ('verify','reopen','cancel') then p_note else verify_note end
  where id = p_id;
  perform set_config('sika.hse', 'off', true);
  if p_action = 'done' then
    perform notify_users(a.company_id, hse_users(a.company_id), 'hse_action_done', a.number || ' done: please verify', a.title, '/hse/actions', false);
  elsif p_action = 'reopen' and a.owner_id is not null then
    perform notify_users(a.company_id, array[a.owner_id], 'hse_action_reopened', a.number || ' sent back', p_note, '/hse/actions', false);
  end if;
  return v_to;
end $$;

-- Incident workflow: investigate → actions → close (root cause recorded, every action verified or cancelled).
create or replace function public.hse_incident_step(p_id uuid, p_action text, p_note text default null, p_investigator uuid default null) returns text
language plpgsql security definer set search_path = public as $$
declare i hse_incidents; v_to text; v_open int;
begin
  select * into i from hse_incidents where id = p_id for update;
  if not found then raise exception 'Incident not found'; end if;
  if not hse_or_pm(i.company_id, i.project_id) then raise exception 'Only an HSE officer or the project manager can do this'; end if;
  if p_action = 'investigate' then
    if i.status <> 'reported' then raise exception 'The investigation has already started'; end if;
    v_to := 'investigating';
  elsif p_action = 'actions' then
    if i.status not in ('reported','investigating') then raise exception 'This incident is already past investigation'; end if;
    if i.kind <> 'observation' and coalesce(trim(i.root_cause), '') = '' then raise exception 'Record the root cause first'; end if;
    v_to := 'action';
  elsif p_action = 'close' then
    if i.status = 'closed' then raise exception 'Already closed'; end if;
    if not is_hse(i.company_id) then raise exception 'Only an HSE officer can close an incident'; end if;
    if i.kind not in ('observation','near_miss') and coalesce(trim(i.root_cause), '') = '' then raise exception 'Record the root cause before closing'; end if;
    select count(*) into v_open from hse_actions where source = 'incident' and source_id = p_id and status in ('open','done');
    if v_open > 0 then raise exception '% action% still open or waiting for verification', v_open, case when v_open = 1 then ' is' else 's are' end; end if;
    if i.reportable and i.authority_ref is null and i.reported_to_authority_on is null then
      raise exception 'This incident is reportable: record when it was reported to the authority and their reference';
    end if;
    v_to := 'closed';
  elsif p_action = 'reopen' then
    if i.status <> 'closed' then raise exception 'Only a closed incident can be reopened'; end if;
    if not is_hse(i.company_id) then raise exception 'Only an HSE officer can reopen an incident'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Give a reason'; end if;
    v_to := 'action';
  else raise exception 'Unknown step %', p_action;
  end if;
  perform set_config('sika.hse', 'on', true);
  update hse_incidents set status = v_to,
    investigator_id = case when p_action = 'investigate' then coalesce(p_investigator, investigator_id, auth.uid()) else investigator_id end,
    closed_by = case when v_to = 'closed' then auth.uid() when p_action = 'reopen' then null else closed_by end,
    closed_at = case when v_to = 'closed' then now() when p_action = 'reopen' then null else closed_at end,
    closure_note = case when v_to = 'closed' or p_action = 'reopen' then p_note else closure_note end
  where id = p_id;
  perform set_config('sika.hse', 'off', true);
  if p_action = 'investigate' and coalesce(p_investigator, auth.uid()) <> auth.uid() then
    perform notify_users(i.company_id, array[p_investigator], 'hse_investigate', 'Investigate ' || i.number, left(i.description, 160), '/hse/incidents/' || p_id, false);
  end if;
  if i.reported_by is not null and v_to = 'closed' then
    perform notify_users(i.company_id, array[i.reported_by], 'hse_closed', i.number || ' closed', coalesce(p_note, 'Thank you for reporting it.'), '/hse/incidents/' || p_id, false);
  end if;
  return v_to;
end $$;

-- ---------------------------------------------------------------- 4. Inspections with checklists
create table public.hse_checklists (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  kind text not null default 'inspection' check (kind in ('inspection','audit','pre_use','toolbox')),
  items jsonb not null default '[]'::jsonb,   -- ["Item to check", ...]
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.hse_inspections (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  checklist_id uuid references public.hse_checklists(id) on delete set null,
  title text not null,
  kind text not null default 'inspection' check (kind in ('inspection','audit','pre_use','toolbox')),
  project_id uuid references public.projects(id) on delete set null,
  location text,
  inspected_on date not null default current_date,
  inspector_id uuid default auth.uid(),
  inspector_email text,
  attendees text,
  results jsonb not null default '[]'::jsonb, -- [{"item":"…","result":"pass|fail|na","note":"…"}]
  score numeric(5,1),
  status text not null default 'draft' check (status in ('draft','completed')),
  notes text,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.hse_inspections (company_id, inspected_on desc);

create or replace function public.hse_inspection_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if not is_member(new.company_id) then raise exception 'You do not have access to this company'; end if;
    new.number := coalesce(new.number, next_number(new.company_id, 'HSI', 'HSI-'));
    new.status := 'draft'; new.score := null; new.completed_at := null;
    new.inspector_id := coalesce(new.inspector_id, auth.uid());
    new.inspector_email := (select email from auth.users where id = new.inspector_id);
    if new.checklist_id is not null and jsonb_array_length(new.results) = 0 then
      select coalesce(jsonb_agg(jsonb_build_object('item', x, 'result', null, 'note', null)), '[]'::jsonb), max(c.kind)
        into new.results, new.kind
        from hse_checklists c, jsonb_array_elements_text(c.items) x where c.id = new.checklist_id;
      new.kind := coalesce(new.kind, 'inspection');
    end if;
  elsif coalesce(current_setting('sika.hse', true), '') <> 'on' then
    if old.status = 'completed' then raise exception 'A completed inspection cannot be changed'; end if;
    if new.status is distinct from old.status then raise exception 'Use Complete to finish the inspection'; end if;
    if not (old.inspector_id = auth.uid() or hse_or_pm(old.company_id, old.project_id)) then raise exception 'Only the inspector, the project manager or an HSE officer can change this inspection'; end if;
    new.number := old.number; new.company_id := old.company_id;
  end if;
  return new;
end $$;
create trigger hse_inspections_defaults before insert or update on public.hse_inspections for each row execute function public.hse_inspection_defaults();

-- Completing scores the checklist and raises a corrective action for every failed item.
create or replace function public.complete_hse_inspection(p_id uuid, p_due date default null) returns int
language plpgsql security definer set search_path = public as $$
declare s hse_inspections; v_pass int; v_fail int; v_blank int; r jsonb; n int := 0; v_owner uuid;
begin
  select * into s from hse_inspections where id = p_id for update;
  if not found then raise exception 'Inspection not found'; end if;
  if s.status = 'completed' then raise exception 'Already completed'; end if;
  if not (s.inspector_id = auth.uid() or hse_or_pm(s.company_id, s.project_id)) then raise exception 'Only the inspector, the project manager or an HSE officer can complete it'; end if;
  select count(*) filter (where e->>'result' = 'pass'), count(*) filter (where e->>'result' = 'fail'), count(*) filter (where coalesce(e->>'result','') = '')
    into v_pass, v_fail, v_blank from jsonb_array_elements(s.results) e;
  if v_blank > 0 then raise exception '% item% not answered. Mark each one pass, fail or not applicable.', v_blank, case when v_blank = 1 then ' is' else 's are' end; end if;
  if v_pass + v_fail = 0 then raise exception 'Mark at least one item as pass or fail'; end if;
  select manager_id into v_owner from projects where id = s.project_id;
  perform set_config('sika.hse', 'on', true);
  update hse_inspections set status = 'completed', completed_at = now(), score = round(100.0 * v_pass / (v_pass + v_fail), 1) where id = p_id;
  for r in select e from jsonb_array_elements(s.results) e where e->>'result' = 'fail' loop
    insert into hse_actions (company_id, source, source_id, project_id, title, description, kind, priority, owner_id, due_date)
    values (s.company_id, 'inspection', p_id, s.project_id, left('Fix: ' || (r->>'item'), 200),
      concat_ws(E'\n', s.number || ' ' || s.title || coalesce(' at ' || s.location, ''), nullif(r->>'note', '')),
      'corrective', 'medium', coalesce(v_owner, s.inspector_id), coalesce(p_due, current_date + 7));
    n := n + 1;
  end loop;
  perform set_config('sika.hse', 'off', true);
  return n;
end $$;

-- ---------------------------------------------------------------- 5. Permits to work
create table public.hse_permits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  kind text not null check (kind in ('hot_work','confined_space','height','electrical','excavation','lifting','general')),
  project_id uuid references public.projects(id) on delete set null,
  location text not null,
  work_description text not null,
  hazards text,
  precautions text,
  isolations text,
  gas_test text,
  ppe text,
  workers text,
  valid_from timestamptz not null,
  valid_to timestamptz not null,
  requested_by uuid default auth.uid(),
  requested_email text,
  issued_by uuid, issued_email text, issued_at timestamptz,
  status text not null default 'requested' check (status in ('requested','approved','suspended','closed','cancelled','rejected')),
  decision_note text,
  closed_by uuid, closed_at timestamptz, close_note text,
  reminded_on date,
  created_at timestamptz not null default now(),
  check (valid_to > valid_from)
);
create index on public.hse_permits (company_id, status, valid_to);

create or replace function public.hse_permit_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if not is_member(new.company_id) then raise exception 'You do not have access to this company'; end if;
    new.number := coalesce(new.number, next_number(new.company_id, 'PTW', 'PTW-'));
    new.status := 'requested'; new.issued_by := null; new.issued_at := null; new.closed_by := null;
    new.requested_by := coalesce(new.requested_by, auth.uid());
    new.requested_email := (select email from auth.users where id = new.requested_by);
    if new.valid_to - new.valid_from > interval '7 days' then raise exception 'A permit can be valid for at most 7 days. Raise a new permit for longer work.'; end if;
  elsif coalesce(current_setting('sika.hse', true), '') <> 'on' then
    if (new.status, new.issued_by, new.closed_by) is distinct from (old.status, old.issued_by, old.closed_by) then
      raise exception 'Use Approve, Reject, Suspend, Resume, Close or Cancel to change a permit';
    end if;
    if old.status <> 'requested' then raise exception 'An approved permit cannot be changed. Cancel it and raise a new one.'; end if;
    if old.requested_by <> auth.uid() and not hse_or_pm(old.company_id, old.project_id) then raise exception 'Only the requester can change this permit'; end if;
    if new.valid_to - new.valid_from > interval '7 days' then raise exception 'A permit can be valid for at most 7 days'; end if;
    new.number := old.number; new.company_id := old.company_id; new.requested_by := old.requested_by; new.requested_email := old.requested_email;
  end if;
  return new;
end $$;
create trigger hse_permits_defaults before insert or update on public.hse_permits for each row execute function public.hse_permit_defaults();

create or replace function public.hse_permit_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_pm uuid;
begin
  select manager_id into v_pm from projects where id = new.project_id;
  perform notify_users(new.company_id, array_remove(hse_users(new.company_id) || v_pm, null), 'hse_permit',
    'Permit to work requested: ' || new.number, replace(new.kind, '_', ' ') || ' at ' || new.location || ' · ' || to_char(new.valid_from, 'DD Mon HH24:MI'),
    '/hse/permits', false);
  return null;
end $$;
create trigger hse_permits_notice after insert on public.hse_permits for each row execute function public.hse_permit_notice();

-- The issuer (HSE officer or the project's manager) must not be the person who asked for the permit.
create or replace function public.hse_permit_step(p_id uuid, p_action text, p_note text default null) returns text
language plpgsql security definer set search_path = public as $$
declare p hse_permits; v_to text; v_email text;
begin
  select * into p from hse_permits where id = p_id for update;
  if not found then raise exception 'Permit not found'; end if;
  if not is_member(p.company_id) then raise exception 'You do not have access to this company'; end if;
  v_to := case p_action
    when 'approve' then case when p.status = 'requested' then 'approved' end
    when 'reject' then case when p.status = 'requested' then 'rejected' end
    when 'suspend' then case when p.status = 'approved' then 'suspended' end
    when 'resume' then case when p.status = 'suspended' then 'approved' end
    when 'close' then case when p.status in ('approved','suspended') then 'closed' end
    when 'cancel' then case when p.status in ('requested','approved','suspended') then 'cancelled' end end;
  if v_to is null then raise exception 'You cannot % a permit that is %', p_action, p.status; end if;
  if p_action in ('approve','reject','suspend','resume') then
    if not hse_or_pm(p.company_id, p.project_id) then raise exception 'Only an HSE officer or the project manager can % a permit', p_action; end if;
    if p_action = 'approve' and p.requested_by = auth.uid() then raise exception 'You cannot approve a permit you asked for. Another authorised person must issue it.'; end if;
    if p_action = 'approve' and p.valid_to < now() then raise exception 'This permit''s time has passed. Change the dates or raise a new one.'; end if;
  elsif p_action = 'close' then
    if not (p.requested_by = auth.uid() or hse_or_pm(p.company_id, p.project_id)) then raise exception 'Only the requester, the project manager or an HSE officer can close it'; end if;
  elsif p_action = 'cancel' then
    if not (p.requested_by = auth.uid() or hse_or_pm(p.company_id, p.project_id)) then raise exception 'Only the requester or the issuer can cancel it'; end if;
  end if;
  if p_action in ('reject','suspend','close','cancel') and coalesce(trim(p_note), '') = '' then
    raise exception '%', case p_action when 'close' then 'Confirm the work is finished and the area left safe' else 'Give a reason' end;
  end if;
  select email into v_email from auth.users where id = auth.uid();
  perform set_config('sika.hse', 'on', true);
  update hse_permits set status = v_to,
    issued_by = case when p_action = 'approve' then auth.uid() else issued_by end,
    issued_email = case when p_action = 'approve' then v_email else issued_email end,
    issued_at = case when p_action = 'approve' then now() else issued_at end,
    decision_note = case when p_action in ('approve','reject','suspend','resume','cancel') then coalesce(p_note, decision_note) else decision_note end,
    closed_by = case when v_to = 'closed' then auth.uid() else closed_by end,
    closed_at = case when v_to = 'closed' then now() else closed_at end,
    close_note = case when v_to = 'closed' then p_note else close_note end
  where id = p_id;
  perform set_config('sika.hse', 'off', true);
  if p.requested_by is not null and p.requested_by <> auth.uid() then
    perform notify_users(p.company_id, array[p.requested_by], 'hse_permit_' || p_action, p.number || ': permit ' || v_to, p_note, '/hse/permits', false);
  end if;
  return v_to;
end $$;

-- ---------------------------------------------------------------- 6. Compliance obligations (ISO 37301)
create table public.compliance_obligations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  title text not null,
  category text not null default 'permit_licence' check (category in ('permit_licence','regulatory_filing','certification','insurance','contract','policy','other')),
  area text not null default 'safety' check (area in ('safety','environment','quality','legal','tax_finance','labour','data_protection','anti_bribery','other')),
  authority text,
  reference text,
  project_id uuid references public.projects(id) on delete set null,
  owner_id uuid,
  issued_on date,
  expires_on date,
  recurrence text not null default 'none' check (recurrence in ('none','monthly','quarterly','semiannual','annual')),
  lead_days int not null default 30 check (lead_days between 0 and 365),
  status text not null default 'active' check (status in ('active','not_compliant','retired')),
  requirement text,
  notes text,
  reminded_for date,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.compliance_obligations (company_id, expires_on);

create or replace function public.compliance_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hse(coalesce(new.company_id, old.company_id)) or has_role(coalesce(new.company_id, old.company_id), array['accountant','hr'])
          or (tg_op <> 'INSERT' and old.owner_id = auth.uid())) then
    raise exception 'Only an HSE or compliance officer, Finance, HR or the obligation''s owner can change the compliance register';
  end if;
  if tg_op = 'UPDATE' then new.company_id := old.company_id; end if;
  return coalesce(new, old);
end $$;
create trigger compliance_obligations_guard before insert or update or delete on public.compliance_obligations for each row execute function public.compliance_guard();

-- Renew: record the new certificate or filing (with its file uploaded separately) and move the dates on.
create or replace function public.renew_obligation(p_id uuid, p_issued date, p_expires date, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare o compliance_obligations;
begin
  select * into o from compliance_obligations where id = p_id for update;
  if not found then raise exception 'Not found'; end if;
  if p_expires is not null and p_issued is not null and p_expires <= p_issued then raise exception 'The new expiry must be after the issue date'; end if;
  update compliance_obligations set issued_on = coalesce(p_issued, issued_on), expires_on = p_expires, status = 'active', reminded_for = null,
    notes = concat_ws(E'\n', notes, to_char(current_date, 'DD Mon YYYY') || ': renewed' || coalesce(' — ' || p_note, '')) where id = p_id;
end $$;

-- Next date for a recurring filing.
create or replace function public.next_due(d date, rec text) returns date language sql immutable as $$
  select case rec when 'monthly' then d + interval '1 month' when 'quarterly' then d + interval '3 months'
    when 'semiannual' then d + interval '6 months' when 'annual' then d + interval '1 year' end::date;
$$;

-- ---------------------------------------------------------------- 7. Policies and acknowledgements
create table public.hse_policies (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  title text not null,
  area text not null default 'safety' check (area in ('safety','environment','quality','legal','tax_finance','labour','data_protection','anti_bribery','other')),
  version text not null default '1',
  effective_on date not null default current_date,
  review_on date,
  summary text,
  storage_path text,
  file_name text,
  requires_ack boolean not null default true,
  active boolean not null default true,
  owner_id uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create table public.hse_policy_acks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  policy_id uuid not null references public.hse_policies(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  email text,
  version text not null,
  acknowledged_at timestamptz not null default now(),
  unique (policy_id, user_id, version)
);
create or replace function public.policy_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hse(coalesce(new.company_id, old.company_id)) or has_role(coalesce(new.company_id, old.company_id), array['hr'])) then
    raise exception 'Only an HSE or compliance officer, HR, an owner or admin can publish policies';
  end if;
  return coalesce(new, old);
end $$;
create trigger hse_policies_guard before insert or update or delete on public.hse_policies for each row execute function public.policy_guard();

create or replace function public.acknowledge_policy(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare p hse_policies;
begin
  select * into p from hse_policies where id = p_id;
  if not found or not p.active then raise exception 'Policy not found'; end if;
  if not is_member(p.company_id) then raise exception 'You do not have access to this company'; end if;
  insert into hse_policy_acks (company_id, policy_id, user_id, email, version)
  values (p.company_id, p_id, auth.uid(), (select email from auth.users where id = auth.uid()), p.version)
  on conflict (policy_id, user_id, version) do nothing;
end $$;

-- ---------------------------------------------------------------- 8. Sustainability: emission factors, records, hours worked
create table public.esg_factors (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  name text not null,
  category text not null check (category in ('fuel','electricity','water','waste','travel','refrigerant','other')),
  scope int check (scope in (1,2,3)),
  unit text not null,
  kg_co2e numeric(14,6) not null default 0 check (kg_co2e >= 0),
  source text,
  waste_route text check (waste_route in ('landfill','recycled','reused','composted','incinerated','hazardous')),
  active boolean not null default true,
  unique (company_id, key)
);
create table public.esg_entries (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  period date not null,                       -- first day of the month
  factor_id uuid not null references public.esg_factors(id),
  quantity numeric(16,3) not null check (quantity >= 0),
  factor_used numeric(14,6),
  kg_co2e numeric(16,3),
  project_id uuid references public.projects(id) on delete set null,
  branch_id uuid,
  source_ref text,
  note text,
  entered_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.esg_entries (company_id, period);
create table public.hse_hours (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  period date not null,
  project_id uuid references public.projects(id) on delete set null,
  hours numeric(12,1) not null check (hours >= 0),
  headcount int,
  note text,
  created_at timestamptz not null default now()
);

create or replace function public.esg_entry_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare f esg_factors;
begin
  if not (is_hse(new.company_id) or has_role(new.company_id, array['accountant','store','project_manager'])) then
    raise exception 'Only an HSE officer, Finance, the storekeeper or a project manager can record sustainability data';
  end if;
  select * into f from esg_factors where id = new.factor_id;
  if f.company_id is distinct from new.company_id then raise exception 'Choose one of your own emission factors'; end if;
  new.period := date_trunc('month', new.period)::date;
  if tg_op = 'INSERT' or new.factor_id is distinct from old.factor_id or new.quantity is distinct from old.quantity then
    new.factor_used := f.kg_co2e;
    new.kg_co2e := round(new.quantity * f.kg_co2e, 3);
  end if;
  return new;
end $$;
create trigger esg_entries_defaults before insert or update on public.esg_entries for each row execute function public.esg_entry_defaults();

create or replace function public.hse_hours_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hse(new.company_id) or has_role(new.company_id, array['hr','project_manager'])) then
    raise exception 'Only an HSE officer, HR or a project manager can record hours worked';
  end if;
  new.period := date_trunc('month', new.period)::date;
  return new;
end $$;
create trigger hse_hours_defaults before insert or update on public.hse_hours for each row execute function public.hse_hours_defaults();

create or replace function public.esg_factor_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(current_setting('sika.seed', true), '') <> 'on' and not (is_hse(coalesce(new.company_id, old.company_id)) or has_role(coalesce(new.company_id, old.company_id), array['accountant'])) then
    raise exception 'Only an HSE officer or Finance can change emission factors';
  end if;
  return coalesce(new, old);
end $$;
create trigger esg_factors_guard before insert or update or delete on public.esg_factors for each row execute function public.esg_factor_guard();

-- Default factors. Fuel: UK DESNZ/DEFRA 2026 conversion factors (the most widely used published set; no Ghana set exists).
-- Grid electricity: IFI harmonised grid emission factors v2.0 (2019), Ghana, combined margin. Replace with the Energy
-- Commission's figure when you have it. Water and waste are tracked as quantities (GRI 303 and 306) with no CO2e by default.
create or replace function public.seed_esg_factors(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform set_config('sika.seed', 'on', true);
  insert into esg_factors (company_id, key, name, category, scope, unit, kg_co2e, source, waste_route) values
    (cid, 'diesel_l', 'Diesel (generators, plant, vehicles)', 'fuel', 1, 'litre', 2.58354, 'UK DESNZ/DEFRA 2026, diesel (average biofuel blend)', null),
    (cid, 'petrol_l', 'Petrol', 'fuel', 1, 'litre', 2.075, 'UK DESNZ/DEFRA 2026, petrol (average biofuel blend)', null),
    (cid, 'lpg_l', 'LPG', 'fuel', 1, 'litre', 1.55713, 'UK DESNZ/DEFRA 2026, LPG', null),
    (cid, 'grid_kwh', 'Grid electricity (ECG / NEDCo)', 'electricity', 2, 'kWh', 0.360, 'IFI harmonised grid emission factors v2.0 (2019), Ghana combined margin', null),
    (cid, 'solar_kwh', 'Own solar generation', 'electricity', null, 'kWh', 0, 'Renewable, zero emissions at the point of use', null),
    (cid, 'water_m3', 'Water used', 'water', null, 'm³', 0, 'Quantity only (GRI 303)', null),
    (cid, 'waste_landfill_kg', 'Waste to landfill', 'waste', null, 'kg', 0, 'Quantity only (GRI 306)', 'landfill'),
    (cid, 'waste_recycled_kg', 'Waste recycled', 'waste', null, 'kg', 0, 'Quantity only (GRI 306)', 'recycled'),
    (cid, 'waste_hazardous_kg', 'Hazardous waste (oil, batteries, chemicals)', 'waste', null, 'kg', 0, 'Quantity only (GRI 306)', 'hazardous')
  on conflict (company_id, key) do nothing;
  insert into hse_checklists (company_id, name, kind, items)
  select cid, x.name, x.kind, x.items::jsonb from (values
    ('Site safety inspection', 'inspection', '["Site access controlled and signage in place","Housekeeping: walkways clear, materials stacked safely","PPE worn correctly (helmet, boots, vest, gloves, eye protection)","Excavations barricaded and shored","Scaffolds tagged and inspected","Ladders in good condition and secured","Edge protection and harnesses for work at height","Electrical cables and distribution boards protected","Fire extinguishers in place, in date and accessible","First-aid kit stocked and first-aider on site","Plant and vehicles with valid inspection, banksman used","Permits to work in place for high-risk work","Toolbox talk held today","Welfare: water, toilets and shade available"]'),
    ('Electrical isolation and LOTO', 'inspection', '["Permit to work issued for the isolation","Circuit identified on drawings and labelled","Isolation point locked and tagged by each worker","Absence of voltage proved with a tested meter","Earthing applied where required","Stored energy (capacitors, springs) released","Insulated tools and arc-rated PPE in use","Barriers and warning signs at the work area","Re-energisation procedure agreed and communicated"]'),
    ('Work at height and scaffolding', 'inspection', '["Scaffold erected by a competent person and tagged","Base plates and sole boards on firm ground","Guardrails, mid-rails and toe boards fitted","Platforms fully boarded","Safe access by ladder or stair","Harness and lanyard inspected and anchored","Rescue plan in place","Tools tethered and exclusion zone below"]'),
    ('Vehicle and plant pre-use check', 'pre_use', '["Tyres and wheels","Brakes and handbrake","Lights, indicators and reverse alarm","Mirrors and windscreen","Seat belt","Fluid leaks (oil, fuel, hydraulic)","Fire extinguisher on board","Operator licence or certificate valid"]'),
    ('Fire safety and emergency', 'inspection', '["Fire exits marked and unobstructed","Extinguishers serviced and in date","Fire alarm tested","Assembly point signposted","Emergency contacts displayed","Flammables stored correctly","Emergency drill held in the last 6 months"]'),
    ('Office HSE walk-through', 'inspection', '["Trip hazards and trailing cables","Workstations set up correctly","Electrical equipment tested (PAT)","First-aid kit and trained first-aider","Fire extinguishers and exits","Kitchen and toilets clean","Air conditioning and lighting adequate"]'),
    ('Toolbox talk record', 'toolbox', '["Topic explained to the team","Hazards of today''s work discussed","Controls and PPE agreed","Questions answered","Attendance recorded"]')
  ) as x(name, kind, items)
  where not exists (select 1 from hse_checklists c where c.company_id = cid);
  perform set_config('sika.seed', 'off', true);
end $$;

do $$ declare c record; begin
  for c in select id from companies loop perform seed_esg_factors(c.id); end loop;
end $$;

create or replace function public.company_seed_hse() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform seed_esg_factors(new.id);
  return null;
end $$;
create trigger companies_seed_hse after insert on public.companies for each row execute function public.company_seed_hse();


-- ---------------------------------------------------------------- 8b. Toolbox talks, inductions, drills and safety meetings
-- Inductions: company induction for every new member of staff, a site induction for each project, and visitors.
-- Each attendee's induction is valid for a set number of months (default 12). A company can turn on
-- "no induction, no work": time cannot then be booked to a project for someone without a valid site induction.
alter table public.companies add column if not exists induction_valid_months int not null default 12 check (induction_valid_months between 1 and 60);
alter table public.companies add column if not exists require_site_induction boolean not null default false;

create table public.hse_sessions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  kind text not null check (kind in ('toolbox','site_induction','company_induction','visitor_induction','emergency_drill','safety_meeting')),
  project_id uuid references public.projects(id) on delete set null,
  held_on date not null default current_date,
  start_time time,
  duration_min int check (duration_min between 1 and 1440),
  topic text not null,
  content text,
  location text,
  presenter_id uuid default auth.uid(),
  presenter_name text,
  outcome text,
  status text not null default 'draft' check (status in ('draft','recorded')),
  recorded_at timestamptz,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.hse_sessions (company_id, held_on desc);
create index on public.hse_sessions (project_id, kind);
create table public.hse_session_attendees (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  session_id uuid not null references public.hse_sessions(id) on delete cascade,
  employee_id uuid references public.employees(id) on delete set null,
  name text not null,
  organisation text,
  attended boolean not null default true,
  valid_until date,
  note text
);
create index on public.hse_session_attendees (session_id);
create index on public.hse_session_attendees (employee_id);

create or replace function public.hse_session_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if not is_member(new.company_id) then raise exception 'You do not have access to this company'; end if;
    if new.kind = 'site_induction' and new.project_id is null then raise exception 'Choose the project this site induction is for'; end if;
    if new.kind in ('site_induction','company_induction') and not (hse_or_pm(new.company_id, new.project_id) or has_role(new.company_id, array['hr'])) then
      raise exception 'Inductions are given by an HSE officer, HR or the project manager';
    end if;
    new.number := coalesce(new.number, next_number(new.company_id, (case new.kind when 'toolbox' then 'TBT' when 'emergency_drill' then 'DRL' when 'safety_meeting' then 'HSM' else 'IND' end),
      case new.kind when 'toolbox' then 'TBT-' when 'emergency_drill' then 'DRL-' when 'safety_meeting' then 'HSM-' else 'IND-' end));
    new.status := 'draft'; new.recorded_at := null;
    new.created_by := coalesce(new.created_by, auth.uid());
  elsif coalesce(current_setting('sika.hse', true), '') <> 'on' then
    if new.status is distinct from old.status then raise exception 'Use Record to finish the attendance list'; end if;
    if old.status = 'recorded' and not is_hse(old.company_id) then raise exception 'A recorded session can only be corrected by an HSE officer'; end if;
    if not (old.created_by = auth.uid() or old.presenter_id = auth.uid() or hse_or_pm(old.company_id, old.project_id)) then raise exception 'Only the presenter, the project manager or an HSE officer can change this'; end if;
    new.number := old.number; new.company_id := old.company_id; new.kind := old.kind;
  end if;
  return new;
end $$;
create trigger hse_sessions_defaults before insert or update on public.hse_sessions for each row execute function public.hse_session_defaults();

create or replace function public.hse_attendee_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare s hse_sessions;
begin
  select * into s from hse_sessions where id = coalesce(new.session_id, old.session_id);
  if coalesce(current_setting('sika.hse', true), '') <> 'on' then
    if s.status = 'recorded' and not is_hse(s.company_id) then raise exception 'This attendance list is recorded. An HSE officer can correct it.'; end if;
    if not (s.created_by = auth.uid() or s.presenter_id = auth.uid() or hse_or_pm(s.company_id, s.project_id)) then raise exception 'Only the presenter, the project manager or an HSE officer can change the attendance list'; end if;
  end if;
  if tg_op <> 'DELETE' then
    new.company_id := s.company_id;
    if new.employee_id is not null and coalesce(trim(new.name), '') = '' then new.name := (select full_name from employees where id = new.employee_id); end if;
  end if;
  return coalesce(new, old);
end $$;
create trigger hse_session_attendees_guard before insert or update or delete on public.hse_session_attendees for each row execute function public.hse_attendee_guard();

-- Record: locks the list and, for inductions, sets how long each attendee's induction is valid.
create or replace function public.record_hse_session(p_id uuid) returns int
language plpgsql security definer set search_path = public as $$
declare s hse_sessions; n int; v_months int;
begin
  select * into s from hse_sessions where id = p_id for update;
  if not found then raise exception 'Not found'; end if;
  if s.status = 'recorded' then raise exception 'Already recorded'; end if;
  if not (s.created_by = auth.uid() or s.presenter_id = auth.uid() or hse_or_pm(s.company_id, s.project_id)) then raise exception 'Only the presenter, the project manager or an HSE officer can record it'; end if;
  select count(*) into n from hse_session_attendees where session_id = p_id and attended;
  if n = 0 then raise exception 'Add the people who attended'; end if;
  select induction_valid_months into v_months from companies where id = s.company_id;
  perform set_config('sika.hse', 'on', true);
  if s.kind in ('site_induction','company_induction','visitor_induction') then
    update hse_session_attendees set valid_until = coalesce(valid_until, (s.held_on + make_interval(months => case when s.kind = 'visitor_induction' then 1 else v_months end))::date)
    where session_id = p_id and attended;
  end if;
  update hse_sessions set status = 'recorded', recorded_at = now() where id = p_id;
  perform set_config('sika.hse', 'off', true);
  return n;
end $$;

-- Is this employee inducted for the project (a valid site induction) — or for the company, when no project is given?
create or replace function public.is_inducted(p_employee uuid, p_project uuid default null, p_on date default current_date) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from hse_session_attendees a join hse_sessions s on s.id = a.session_id
    where a.employee_id = p_employee and a.attended and s.status = 'recorded' and a.valid_until >= p_on
      and ((p_project is not null and s.kind = 'site_induction' and s.project_id = p_project)
        or (p_project is null and s.kind = 'company_induction')));
$$;

-- Induction register: every employee with their company induction and, for each project they are on, their site induction.
create or replace function public.induction_register(cid uuid, p_project uuid default null)
returns table (employee_id uuid, full_name text, project_id uuid, kind text, held_on date, valid_until date, session_id uuid, state text)
language sql stable security definer set search_path = public as $$
  with people as (
    select e.id, e.full_name, null::uuid pid, 'company_induction'::text k from employees e
      where e.company_id = cid and is_member(cid) and p_project is null and coalesce(to_jsonb(e)->>'status', 'active') not in ('left','terminated','inactive')
    union
    select e.id, e.full_name, pa.project_id, 'site_induction' from project_assignments pa join employees e on e.id = pa.employee_id
      join projects p on p.id = pa.project_id
      where pa.company_id = cid and is_member(cid) and (p_project is null or pa.project_id = p_project) and p.status in ('planned','active','on_hold')
  ), last as (
    select distinct on (a.employee_id, s.kind, s.project_id) a.employee_id, s.kind, s.project_id, s.held_on, a.valid_until, s.id sid
    from hse_session_attendees a join hse_sessions s on s.id = a.session_id
    where s.company_id = cid and s.status = 'recorded' and a.attended and s.kind in ('company_induction','site_induction')
    order by a.employee_id, s.kind, s.project_id, a.valid_until desc nulls last
  )
  select pe.id, pe.full_name, pe.pid, pe.k, l.held_on, l.valid_until, l.sid,
    case when l.valid_until is null then 'missing' when l.valid_until < current_date then 'expired' when l.valid_until < current_date + 30 then 'expiring' else 'valid' end
  from people pe left join last l on l.employee_id = pe.id and l.kind = pe.k and l.project_id is not distinct from pe.pid
  order by pe.full_name, pe.pid nulls first;
$$;

-- "No induction, no work": time on a project needs a valid site induction when the company turns this on.
create or replace function public.timesheet_induction_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.employee_id is not null and new.project_id is not null
     and coalesce((select require_site_induction from companies where id = new.company_id), false)
     and not is_inducted(new.employee_id, new.project_id, new.work_date) then
    raise exception '% has no valid site induction for this project. Give the site induction first (HSE → Talks & inductions).',
      coalesce((select full_name from employees where id = new.employee_id), 'This person');
  end if;
  return new;
end $$;
create trigger timesheets_induction before insert on public.timesheets for each row execute function public.timesheet_induction_guard();

create or replace function public.set_induction_rules(cid uuid, p_required boolean, p_months int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not (has_role(cid, array['owner','admin']) or is_hse(cid)) then raise exception 'Only an owner, admin or HSE officer can change induction rules'; end if;
  update companies set require_site_induction = p_required, induction_valid_months = coalesce(p_months, induction_valid_months) where id = cid;
end $$;

-- ---------------------------------------------------------------- 9. Performance figures
-- Hours worked = approved timesheet hours + hours recorded for site labour and subcontractors.
-- LTIFR = lost-time injuries × 1,000,000 / hours. TRIR = recordable injuries × 200,000 / hours.
create or replace function public.hse_stats(cid uuid, p_from date, p_to date, p_project uuid default null)
returns table (hours numeric, incidents int, observations int, near_misses int, first_aid int, recordables int, ltis int, fatalities int,
  lost_days int, ltifr numeric, trir numeric, open_actions int, overdue_actions int, inspections int, avg_score numeric,
  permits_active int, obligations_expired int, obligations_due int, toolbox_talks int, toolbox_attendance int, inductions int, drills int, days_since_lti int)
language plpgsql stable security definer set search_path = public as $$
declare h numeric;
begin
  perform require_member(cid);
  select coalesce((select sum(t.hours) from timesheets t where t.company_id = cid and t.work_date between p_from and p_to
           and coalesce(to_jsonb(t)->>'status', 'approved') = 'approved' and (p_project is null or t.project_id = p_project)), 0)
       + coalesce((select sum(x.hours) from hse_hours x where x.company_id = cid and x.period between date_trunc('month', p_from)::date and p_to
           and (p_project is null or x.project_id = p_project)), 0) into h;
  return query
  with i as (select * from hse_incidents x where x.company_id = cid and x.occurred_at::date between p_from and p_to and (p_project is null or x.project_id = p_project))
  select h,
    (select count(*)::int from i where i.kind <> 'observation'),
    (select count(*)::int from i where i.kind = 'observation'),
    (select count(*)::int from i where i.kind = 'near_miss'),
    (select count(*)::int from i where i.kind = 'first_aid'),
    (select count(*)::int from i where hse_recordable(i.kind)),
    (select count(*)::int from i where hse_lti(i.kind)),
    (select count(*)::int from i where i.kind = 'fatality'),
    (select coalesce(sum(i.lost_days), 0)::int from i),
    case when h > 0 then round((select count(*) from i where hse_lti(i.kind)) * 1000000.0 / h, 2) end,
    case when h > 0 then round((select count(*) from i where hse_recordable(i.kind)) * 200000.0 / h, 2) end,
    (select count(*)::int from hse_actions a where a.company_id = cid and a.status in ('open','done') and (p_project is null or a.project_id = p_project)),
    (select count(*)::int from hse_actions a where a.company_id = cid and a.status = 'open' and a.due_date < current_date and (p_project is null or a.project_id = p_project)),
    (select count(*)::int from hse_inspections s where s.company_id = cid and s.status = 'completed' and s.inspected_on between p_from and p_to and (p_project is null or s.project_id = p_project)),
    (select round(avg(s.score), 1) from hse_inspections s where s.company_id = cid and s.status = 'completed' and s.inspected_on between p_from and p_to and (p_project is null or s.project_id = p_project)),
    (select count(*)::int from hse_permits p where p.company_id = cid and p.status = 'approved' and now() between p.valid_from and p.valid_to and (p_project is null or p.project_id = p_project)),
    (select count(*)::int from compliance_obligations o where o.company_id = cid and o.status <> 'retired' and o.expires_on < current_date),
    (select count(*)::int from compliance_obligations o where o.company_id = cid and o.status <> 'retired' and o.expires_on between current_date and current_date + o.lead_days),
    (select count(*)::int from hse_sessions x where x.company_id = cid and x.kind = 'toolbox' and x.status = 'recorded' and x.held_on between p_from and p_to and (p_project is null or x.project_id = p_project)),
    (select count(*)::int from hse_session_attendees a join hse_sessions x on x.id = a.session_id where x.company_id = cid and x.kind = 'toolbox' and x.status = 'recorded' and a.attended and x.held_on between p_from and p_to and (p_project is null or x.project_id = p_project)),
    (select count(*)::int from hse_session_attendees a join hse_sessions x on x.id = a.session_id where x.company_id = cid and x.kind in ('site_induction','company_induction','visitor_induction') and x.status = 'recorded' and a.attended and x.held_on between p_from and p_to and (p_project is null or x.project_id = p_project)),
    (select count(*)::int from hse_sessions x where x.company_id = cid and x.kind = 'emergency_drill' and x.status = 'recorded' and x.held_on between p_from and p_to and (p_project is null or x.project_id = p_project)),
    (select (current_date - coalesce(max(x.occurred_at)::date,
        coalesce((select min(p.actual_start) from projects p where p.id = p_project), (select c.created_at::date from companies c where c.id = cid))))::int
       from hse_incidents x where x.company_id = cid and hse_lti(x.kind) and (p_project is null or x.project_id = p_project));
end $$;

-- Emissions and resources by category and scope (GHG Protocol; GRI 302, 303, 305, 306).
create or replace function public.esg_summary(cid uuid, p_from date, p_to date, p_project uuid default null)
returns table (category text, scope int, factor_key text, name text, unit text, quantity numeric, t_co2e numeric, waste_route text)
language sql stable security definer set search_path = public as $$
  select f.category, f.scope, f.key, f.name, f.unit, sum(e.quantity), round(sum(e.kg_co2e) / 1000.0, 3), f.waste_route
  from esg_entries e join esg_factors f on f.id = e.factor_id
  where e.company_id = cid and is_member(cid) and e.period between date_trunc('month', p_from)::date and p_to
    and (p_project is null or e.project_id = p_project)
  group by f.category, f.scope, f.key, f.name, f.unit, f.waste_route
  order by f.category, f.scope nulls last, f.name;
$$;

-- ---------------------------------------------------------------- 10. Reminders (daily)
create or replace function public.run_hse_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  -- Actions past their due date: the owner, once a week.
  for r in select * from hse_actions where status = 'open' and due_date < current_date and owner_id is not null
             and (reminded_on is null or reminded_on <= current_date - 7) loop
    perform notify_users(r.company_id, array[r.owner_id], 'hse_action_overdue', r.number || ' is overdue', r.title || ' · was due ' || to_char(r.due_date, 'DD Mon YYYY'), '/hse/actions', true);
    update hse_actions set reminded_on = current_date where id = r.id; n := n + 1;
  end loop;
  -- Obligations: when they enter the reminder window, and again when they lapse.
  for r in select * from compliance_obligations where status <> 'retired' and expires_on is not null
             and expires_on <= current_date + lead_days and (reminded_for is null or (reminded_for < expires_on and current_date > expires_on) or reminded_for < current_date - 30) loop
    perform notify_users(r.company_id, array_remove(hse_users(r.company_id) || r.owner_id, null), 'compliance_due',
      case when r.expires_on < current_date then r.title || ' has expired' else r.title || ' is due ' || to_char(r.expires_on, 'DD Mon YYYY') end,
      coalesce(r.authority || ' · ', '') || coalesce(r.reference, ''), '/hse/obligations', true);
    update compliance_obligations set reminded_for = case when r.expires_on < current_date then current_date else r.expires_on end where id = r.id; n := n + 1;
  end loop;
  -- Permits still open after their end time.
  for r in select * from hse_permits where status in ('approved','suspended') and valid_to < now() and (reminded_on is null or reminded_on < current_date) loop
    perform notify_users(r.company_id, array_remove(array[r.requested_by, r.issued_by], null), 'hse_permit_expired',
      r.number || ' has run out: close it or raise a new permit', r.location, '/hse/permits', true);
    update hse_permits set reminded_on = current_date where id = r.id; n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_hse_reminders() from public, anon, authenticated;

-- Sent by the existing daily job (asnys-cash-reminders), with the cash and on-hold reminders.
create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 11. Security rules
do $$ declare t text; begin
  foreach t in array array['hse_incidents','hse_files','hse_actions','hse_checklists','hse_inspections','hse_permits','compliance_obligations',
                           'hse_policies','hse_policy_acks','esg_factors','esg_entries','hse_hours','hse_sessions','hse_session_attendees'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "members read" on public.%I for select using (is_member(company_id))', t);
  end loop;
end $$;
-- Writes: anyone reports incidents, requests permits, starts inspections and adds files; the triggers above decide the rest.
create policy "members report" on public.hse_incidents for insert with check (is_member(company_id));
create policy "members update" on public.hse_incidents for update using (is_member(company_id));
create policy "hse deletes" on public.hse_incidents for delete using (is_hse(company_id) and status = 'reported');
create policy "members add files" on public.hse_files for insert with check (is_member(company_id));
create policy "hse removes files" on public.hse_files for delete using (is_hse(company_id) or uploaded_by = auth.uid());
create policy "raise actions" on public.hse_actions for insert with check (is_member(company_id));
create policy "edit actions" on public.hse_actions for update using (is_member(company_id));
create policy "hse checklists" on public.hse_checklists for all using (is_hse(company_id)) with check (is_hse(company_id));
create policy "start inspections" on public.hse_inspections for insert with check (is_member(company_id));
create policy "edit inspections" on public.hse_inspections for update using (is_member(company_id));
create policy "delete draft inspections" on public.hse_inspections for delete using (status = 'draft' and (inspector_id = auth.uid() or is_hse(company_id)));
create policy "request permits" on public.hse_permits for insert with check (is_member(company_id));
create policy "edit permits" on public.hse_permits for update using (is_member(company_id));
create policy "register obligations" on public.compliance_obligations for all using (is_member(company_id)) with check (is_member(company_id));
create policy "publish policies" on public.hse_policies for all using (is_member(company_id)) with check (is_member(company_id));
create policy "own acknowledgements" on public.hse_policy_acks for insert with check (user_id = auth.uid() and is_member(company_id));
create policy "edit factors" on public.esg_factors for all using (is_member(company_id)) with check (is_member(company_id));
create policy "record esg" on public.esg_entries for all using (is_member(company_id)) with check (is_member(company_id));
create policy "record sessions" on public.hse_sessions for insert with check (is_member(company_id));
create policy "edit sessions" on public.hse_sessions for update using (is_member(company_id));
create policy "delete draft sessions" on public.hse_sessions for delete using (status = 'draft' and (created_by = auth.uid() or is_hse(company_id)));
create policy "attendance" on public.hse_session_attendees for all using (is_member(company_id)) with check (is_member(company_id));
create policy "record hours" on public.hse_hours for all using (is_member(company_id)) with check (is_member(company_id));

-- Deleting sustainability records and hours: same people who can record them (the insert/update triggers do not run on delete).
create or replace function public.esg_delete_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hse(old.company_id) or has_role(old.company_id, array['accountant'])) then raise exception 'Only an HSE officer or Finance can delete these records'; end if;
  return old;
end $$;
create trigger esg_entries_delete before delete on public.esg_entries for each row execute function public.esg_delete_guard();
create trigger hse_hours_delete before delete on public.hse_hours for each row execute function public.esg_delete_guard();

-- Audit trail for the registers.
do $$ declare t text; begin
  foreach t in array array['hse_incidents','hse_actions','hse_permits','compliance_obligations','hse_policies','esg_factors','esg_entries','hse_sessions'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
  end loop;
end $$;

revoke execute on function public.seed_esg_factors(uuid) from public, anon, authenticated;
revoke execute on function public.hse_users(uuid) from public, anon, authenticated;
revoke execute on function public.notify_users(uuid,uuid[],text,text,text,text,boolean) from public, anon, authenticated;


-- ======================================================================
-- 0017_asnys_v3_0.sql
-- ======================================================================
-- Asnys ERP v3.0 — HR and payroll to the level of dedicated HR suites (PaySpace and similar)
--   1. Pay components: any number of earnings (taxable or not) and deductions per employee, recurring or one-off.
--   2. Salary history with effective dates, bulk increases, and automatic back pay (arrears) for backdated changes.
--   3. Joiners and leavers paid pro rata; off-cycle (interim and final) pay runs, with PAYE worked out on the month's total.
--   4. Employee self-service: own payslips, year-to-date tax summary, profile change requests approved by HR.
--   5. Employment details: manager (org chart), employment type, probation, contract end, next of kin; history of
--      promotions, transfers, salary changes, warnings and awards; employee documents with expiry.
--   6. Onboarding and exit checklists; exits with final pay, leave due, assets and loans to clear, access removed.
--   7. Leave: Ghana public holidays, working days counted without weekends and holidays, monthly accrual, carry-over,
--      approval by the employee's manager or HR.
--   8. Announcements to all staff, a department or a branch.
--   9. HR reports (headcount, joiners and leavers, turnover, payroll cost, leave liability) and the annual PAYE return.
-- Run after 0016.

-- ---------------------------------------------------------------- 0. Accounts and helpers
create or replace function public.seed_accounts_v30(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into accounts (company_id, code, name, type, system_key) values
  (cid, '2260', 'Other payroll deductions payable', 'liability', 'payroll_deductions')
  on conflict do nothing;
$$;
select public.seed_accounts_v30(id) from public.companies;

-- People who may see pay and personal records.
create or replace function public.is_hr(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select has_role(cid, array['owner','admin','hr']);
$$;

-- ---------------------------------------------------------------- 1. Employment details
alter table public.employees add column if not exists manager_id uuid references public.employees(id) on delete set null;
alter table public.employees add column if not exists employment_type text not null default 'permanent'
  check (employment_type in ('permanent','fixed_term','casual','contract','intern','national_service','consultant'));
alter table public.employees add column if not exists grade text;
alter table public.employees add column if not exists probation_end date;
alter table public.employees add column if not exists confirmed_on date;
alter table public.employees add column if not exists contract_end date;
alter table public.employees add column if not exists notice_days int;
alter table public.employees add column if not exists end_date date;
alter table public.employees add column if not exists date_of_birth date;
alter table public.employees add column if not exists gender text check (gender in ('female','male','other'));
alter table public.employees add column if not exists address text;
alter table public.employees add column if not exists next_of_kin_name text;
alter table public.employees add column if not exists next_of_kin_relation text;
alter table public.employees add column if not exists next_of_kin_phone text;
alter table public.employees add column if not exists emergency_phone text;

create table public.employee_events (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  kind text not null check (kind in ('hired','confirmation','promotion','transfer','title_change','salary_change','warning','disciplinary',
    'grievance','award','training','exit','note')),
  effective_date date not null default current_date,
  title text not null,
  details text,
  old_value jsonb,
  new_value jsonb,
  confidential boolean not null default false,
  created_by uuid default auth.uid(),
  created_email text,
  created_at timestamptz not null default now()
);
create index on public.employee_events (employee_id, effective_date desc);

create or replace function public.employee_event_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.company_id := (select company_id from employees where id = new.employee_id);
  if coalesce(current_setting('sika.hr', true), '') <> 'on' and not is_hr(new.company_id) then raise exception 'Only HR can add to an employee''s history'; end if;
  new.created_email := (select email from auth.users where id = auth.uid());
  return new;
end $$;
create trigger employee_events_defaults before insert on public.employee_events for each row execute function public.employee_event_defaults();

-- Changes of title, department, branch, manager or type are written to the history automatically.
create or replace function public.employee_history_log() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_title text; v_kind text;
begin
  if tg_op = 'INSERT' then
    perform set_config('sika.hr', 'on', true);
    insert into employee_events (company_id, employee_id, kind, effective_date, title, new_value)
    values (new.company_id, new.id, 'hired', coalesce(new.hire_date, current_date), 'Joined as ' || coalesce(new.job_title, 'employee'),
      jsonb_build_object('job_title', new.job_title, 'department', new.department, 'basic_salary', new.basic_salary));
    perform set_config('sika.hr', 'off', true);
    return null;
  end if;
  if (new.job_title, new.department, new.branch_id, new.manager_id, new.employment_type, new.grade)
     is not distinct from (old.job_title, old.department, old.branch_id, old.manager_id, old.employment_type, old.grade) then return null; end if;
  v_kind := case when new.branch_id is distinct from old.branch_id or new.department is distinct from old.department then 'transfer'
                 when new.grade is distinct from old.grade or new.job_title is distinct from old.job_title then 'title_change' else 'note' end;
  v_title := concat_ws('; ',
    case when new.job_title is distinct from old.job_title then 'Title: ' || coalesce(old.job_title, '—') || ' → ' || coalesce(new.job_title, '—') end,
    case when new.grade is distinct from old.grade then 'Grade: ' || coalesce(old.grade, '—') || ' → ' || coalesce(new.grade, '—') end,
    case when new.department is distinct from old.department then 'Department: ' || coalesce(old.department, '—') || ' → ' || coalesce(new.department, '—') end,
    case when new.branch_id is distinct from old.branch_id then 'Branch changed' end,
    case when new.manager_id is distinct from old.manager_id then 'Reports to: ' || coalesce((select full_name from employees where id = new.manager_id), 'nobody') end,
    case when new.employment_type is distinct from old.employment_type then 'Type: ' || old.employment_type || ' → ' || new.employment_type end);
  perform set_config('sika.hr', 'on', true);
  insert into employee_events (company_id, employee_id, kind, title, old_value, new_value)
  values (new.company_id, new.id, v_kind, v_title,
    jsonb_build_object('job_title', old.job_title, 'department', old.department, 'grade', old.grade, 'manager_id', old.manager_id),
    jsonb_build_object('job_title', new.job_title, 'department', new.department, 'grade', new.grade, 'manager_id', new.manager_id));
  perform set_config('sika.hr', 'off', true);
  return null;
end $$;
create trigger employees_history after insert or update on public.employees for each row execute function public.employee_history_log();

-- Promotion: title, grade and pay together, with one history line.
create table public.employee_documents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  kind text not null default 'other' check (kind in ('contract','offer_letter','id_card','certificate','cv','medical','warning_letter','appraisal','exit','other')),
  title text not null,
  storage_path text not null,
  file_name text,
  expires_on date,
  visible_to_employee boolean not null default true,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.employee_documents (employee_id);

-- ---------------------------------------------------------------- 2. Pay components and salary history
create table public.pay_components (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  code text not null,
  name text not null,
  kind text not null check (kind in ('earning','deduction')),
  taxable boolean not null default true,       -- earnings only: counts towards PAYE
  account_id uuid references public.accounts(id),  -- deductions only: where the money is owed (default 2260)
  system boolean not null default false,
  active boolean not null default true,
  sort int not null default 100,
  unique (company_id, code)
);
create table public.employee_pay_items (           -- every month from start to end
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  component_id uuid not null references public.pay_components(id),
  amount numeric(14,2) not null check (amount > 0),
  start_period date not null default date_trunc('month', current_date)::date,
  end_period date,
  note text,
  created_at timestamptz not null default now()
);
create table public.payroll_input_items (          -- once, in one month (or in one off-cycle run)
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  period date not null,
  run_id uuid,
  employee_id uuid not null references public.employees(id) on delete cascade,
  component_id uuid not null references public.pay_components(id),
  amount numeric(14,2) not null check (amount > 0),
  note text,
  created_at timestamptz not null default now()
);
create table public.payslip_items (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  payslip_id uuid not null references public.payslips(id) on delete cascade,
  component_id uuid references public.pay_components(id),
  code text not null,
  name text not null,
  kind text not null check (kind in ('earning','deduction')),
  taxable boolean not null default true,
  amount numeric(14,2) not null
);
create index on public.payslip_items (payslip_id);
create table public.salary_changes (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  effective_date date not null,
  basic_salary numeric(14,2) not null check (basic_salary >= 0),
  allowances numeric(14,2) not null default 0 check (allowances >= 0),
  kind text not null default 'increase' check (kind in ('increase','promotion','adjustment','decrease','bulk')),
  reason text,
  arrears_run_id uuid,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.salary_changes (employee_id, effective_date);

alter table public.payslips add column if not exists earnings_other numeric(14,2) not null default 0;
alter table public.payslips add column if not exists nontaxable numeric(14,2) not null default 0;
alter table public.payslips add column if not exists deductions_other numeric(14,2) not null default 0;
alter table public.payslips add column if not exists backpay numeric(14,2) not null default 0;
alter table public.payslips add column if not exists days_paid numeric(5,2);
alter table public.payslips add column if not exists days_in_month int;

alter table public.payroll_runs add column if not exists kind text not null default 'regular' check (kind in ('regular','interim','final'));
alter table public.payroll_runs add column if not exists note text;
alter table public.payroll_runs drop constraint if exists payroll_runs_company_id_period_key;
create unique index if not exists payroll_runs_one_regular on public.payroll_runs (company_id, period) where kind = 'regular';

create or replace function public.seed_pay_components(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into pay_components (company_id, code, name, kind, taxable, system, sort) values
    (cid, 'HOUSING', 'Housing allowance', 'earning', true, false, 10),
    (cid, 'TRANSPORT', 'Transport allowance', 'earning', true, false, 11),
    (cid, 'FUEL', 'Fuel allowance', 'earning', true, false, 12),
    (cid, 'RESPONSIBILITY', 'Responsibility allowance', 'earning', true, false, 13),
    (cid, 'SITE', 'Site / risk allowance', 'earning', true, false, 14),
    (cid, 'ACTING', 'Acting allowance', 'earning', true, false, 15),
    (cid, 'COMMISSION', 'Commission', 'earning', true, false, 20),
    (cid, 'LEAVEPAY', 'Leave pay (days not taken)', 'earning', true, false, 21),
    (cid, 'PRORATA', 'Salary for part month', 'earning', true, false, 22),
    (cid, 'BONUS', 'Bonus', 'earning', true, true, 30),
    (cid, 'BACKPAY', 'Back pay (arrears)', 'earning', true, true, 31),
    (cid, 'REIMBURSE', 'Reimbursement (not taxed)', 'earning', false, false, 40),
    (cid, 'UNION', 'Union dues', 'deduction', false, false, 60),
    (cid, 'WELFARE', 'Staff welfare', 'deduction', false, false, 61),
    (cid, 'CREDITUNION', 'Credit union savings', 'deduction', false, false, 62),
    (cid, 'COURT', 'Court order / garnishee', 'deduction', false, false, 63),
    (cid, 'OTHERDED', 'Other deduction', 'deduction', false, false, 69)
  on conflict (company_id, code) do nothing;
$$;
select public.seed_pay_components(id) from public.companies;

create or replace function public.pay_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare cid uuid; v_period date;
begin
  cid := coalesce(new.company_id, old.company_id);
  if tg_op <> 'DELETE' and tg_table_name in ('payroll_input_items','employee_pay_items') then
    cid := (select company_id from employees where id = new.employee_id);
  end if;
  if coalesce(current_setting('sika.hr', true), '') = 'on' then return coalesce(new, old); end if;
  if not has_role(cid, array['owner','admin','hr','accountant']) then raise exception 'Only HR or Finance can change pay'; end if;
  if tg_table_name = 'payroll_input_items' then
    v_period := coalesce(new.period, old.period);
    if coalesce(new.run_id, old.run_id) is not null then
      if exists (select 1 from payroll_runs where id = coalesce(new.run_id, old.run_id) and status <> 'draft') then raise exception 'That pay run is already posted'; end if;
    elsif exists (select 1 from payroll_runs where company_id = cid and period = date_trunc('month', v_period) and kind = 'regular' and status <> 'draft') then
      raise exception 'Payroll for % is already posted. Add it to next month or to an off-cycle run.', to_char(v_period, 'Mon YYYY');
    end if;
    if tg_op <> 'DELETE' then new.period := date_trunc('month', new.period)::date; end if;
  elsif tg_table_name = 'employee_pay_items' and tg_op <> 'DELETE' then
    new.start_period := date_trunc('month', new.start_period)::date;
    if new.end_period is not null then new.end_period := date_trunc('month', new.end_period)::date; end if;
  end if;
  if tg_op <> 'DELETE' and tg_table_name in ('payroll_input_items','employee_pay_items') then
    new.company_id := (select company_id from employees where id = new.employee_id);
    if (select company_id from pay_components where id = new.component_id) is distinct from new.company_id then raise exception 'Choose one of your own pay components'; end if;
  end if;
  return coalesce(new, old);
end $$;
create trigger pay_components_guard before insert or update or delete on public.pay_components for each row execute function public.pay_guard();
create trigger employee_pay_items_guard before insert or update or delete on public.employee_pay_items for each row execute function public.pay_guard();
create trigger payroll_input_items_guard before insert or update or delete on public.payroll_input_items for each row execute function public.pay_guard();

-- Pay in force on a date: the latest salary change on or before it, otherwise the employee record.
create or replace function public.emp_pay_at(p_employee uuid, p_date date, out basic numeric, out allowances numeric)
language sql stable security definer set search_path = public as $$
  select coalesce(sc.basic_salary, e.basic_salary), coalesce(sc.allowances, e.allowances)
  from employees e left join lateral (select basic_salary, allowances from salary_changes s where s.employee_id = e.id and s.effective_date <= p_date
    order by s.effective_date desc, s.created_at desc limit 1) sc on true
  where e.id = p_employee;
$$;

-- Change pay from a date. Backdated changes are paid as back pay in the next regular payroll.
create or replace function public.change_salary(p_employee uuid, p_effective date, p_basic numeric, p_allowances numeric default null,
  p_reason text default null, p_kind text default 'increase', p_title text default null, p_grade text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare e employees; v uuid; v_allow numeric;
begin
  select * into e from employees where id = p_employee for update;
  if not found then raise exception 'Employee not found'; end if;
  if not is_hr(e.company_id) then raise exception 'Only HR, an owner or admin can change pay'; end if;
  if p_basic is null or p_basic < 0 then raise exception 'Enter the new basic salary'; end if;
  v_allow := coalesce(p_allowances, (emp_pay_at(e.id, p_effective)).allowances, e.allowances);
  insert into salary_changes (company_id, employee_id, effective_date, basic_salary, allowances, kind, reason)
  values (e.company_id, e.id, p_effective, round(p_basic, 2), round(v_allow, 2), p_kind, p_reason) returning id into v;
  if p_effective <= current_date then
    update employees set basic_salary = round(p_basic, 2), allowances = round(v_allow, 2),
      job_title = coalesce(p_title, job_title), grade = coalesce(p_grade, grade) where id = e.id;
  elsif p_title is not null or p_grade is not null then
    update employees set job_title = coalesce(p_title, job_title), grade = coalesce(p_grade, grade) where id = e.id;
  end if;
  perform set_config('sika.hr', 'on', true);
  insert into employee_events (company_id, employee_id, kind, effective_date, title, details, old_value, new_value, confidential)
  values (e.company_id, e.id, case when p_kind = 'promotion' then 'promotion' else 'salary_change' end, p_effective,
    case when p_kind = 'promotion' then 'Promoted' || coalesce(' to ' || p_title, '') else 'Pay changed' end,
    p_reason, jsonb_build_object('basic_salary', e.basic_salary, 'allowances', e.allowances, 'job_title', e.job_title),
    jsonb_build_object('basic_salary', round(p_basic, 2), 'allowances', round(v_allow, 2), 'job_title', coalesce(p_title, e.job_title)), true);
  perform set_config('sika.hr', 'off', true);
  return v;
end $$;

-- Raise many people at once: by a percentage and/or a fixed amount, optionally for one department.
create or replace function public.bulk_salary_change(cid uuid, p_effective date, p_percent numeric, p_amount numeric default 0,
  p_department text default null, p_reason text default null) returns int
language plpgsql security definer set search_path = public as $$
declare e record; n int := 0; cur record;
begin
  if not is_hr(cid) then raise exception 'Only HR, an owner or admin can change pay'; end if;
  if coalesce(p_percent, 0) = 0 and coalesce(p_amount, 0) = 0 then raise exception 'Enter a percentage or an amount'; end if;
  for e in select * from employees where company_id = cid and status = 'active' and (p_department is null or department = p_department) loop
    select * into cur from emp_pay_at(e.id, p_effective);
    perform change_salary(e.id, p_effective, round(cur.basic * (1 + coalesce(p_percent, 0) / 100.0) + coalesce(p_amount, 0), 2), cur.allowances,
      coalesce(p_reason, 'General increase'), 'bulk');
    n := n + 1;
  end loop;
  return n;
end $$;

-- ---------------------------------------------------------------- 3. Payroll calculation (regular and off-cycle runs)
create or replace function public.calc_run(p_run uuid) returns void
language plpgsql security definer set search_path = public as $$
declare
  r payroll_runs; cid uuid; v_period date; v_payday date; v_dim int; e record; pay record;
  v_days numeric; v_f numeric; v_basic numeric; v_allow numeric; v_ot numeric; v_bonus numeric;
  v_earn numeric; v_earn_tax numeric; v_earn_nontax numeric; v_ded numeric; v_back numeric; v_back_basic numeric;
  v_gross numeric; v_emp numeric; v_er numeric; v_t2 numeric; v_t3e numeric; v_t3r numeric; v_ot_tax numeric; v_ot_taxable numeric; v_ot_low numeric;
  v_ytd numeric; v_cap_left numeric; v_b_conc numeric; v_bonus_tax numeric; v_bonus_taxable numeric;
  v_relief_cap numeric; v_t3_relief numeric; v_t3_excess numeric; v_charge numeric; v_paye numeric; v_prior_charge numeric; v_prior_paye numeric;
  v_before numeric; v_loan numeric; v_net numeric; v_slip uuid; it record; v_start date; v_end date;
begin
  select * into r from payroll_runs where id = p_run;
  cid := r.company_id; v_period := r.period;
  v_payday := (v_period + interval '1 month - 1 day')::date;
  v_dim := extract(day from v_payday)::int;
  delete from payslips where run_id = p_run;

  for e in
    select * from employees x where x.company_id = cid and (
      (r.kind = 'regular' and coalesce(x.hire_date, v_period) <= v_payday
         and (x.status = 'active' or (x.end_date is not null and x.end_date >= v_period)) and (x.end_date is null or x.end_date >= v_period))
      or (r.kind <> 'regular' and exists (select 1 from payroll_input_items i where i.run_id = p_run and i.employee_id = x.id)))
    order by x.full_name
  loop
    -- Days paid: joiners and leavers in the month are paid pro rata to calendar days.
    v_start := greatest(v_period, coalesce(e.hire_date, v_period)); v_end := least(v_payday, coalesce(e.end_date, v_payday));
    v_days := case when r.kind = 'regular' then greatest(0, v_end - v_start + 1) else 0 end;
    v_f := case when r.kind = 'regular' then v_days / v_dim else 0 end;
    select * into pay from emp_pay_at(e.id, v_payday);
    v_basic := round(pay.basic * v_f, 2); v_allow := round(pay.allowances * v_f, 2);

    insert into payslips (run_id, company_id, employee_id, basic, allowances, gross, ssnit_employee, chargeable, paye, net, ssnit_employer, tier1, tier2,
      days_paid, days_in_month)
    values (p_run, cid, e.id, v_basic, v_allow, 0, 0, 0, 0, 0, 0, 0, 0, case when r.kind = 'regular' then v_days end, case when r.kind = 'regular' then v_dim end)
    returning id into v_slip;

    -- Recurring items (pro rata) and one-off items.
    if r.kind = 'regular' then
      insert into payslip_items (company_id, payslip_id, component_id, code, name, kind, taxable, amount)
      select cid, v_slip, c.id, c.code, c.name, c.kind, c.taxable, round(sum(p.amount) * case when c.kind = 'earning' then v_f else 1 end, 2)
      from employee_pay_items p join pay_components c on c.id = p.component_id
      where p.employee_id = e.id and p.start_period <= v_period and (p.end_period is null or p.end_period >= v_period) and c.active
      group by c.id, c.code, c.name, c.kind, c.taxable having sum(p.amount) > 0;
      insert into payslip_items (company_id, payslip_id, component_id, code, name, kind, taxable, amount)
      select cid, v_slip, c.id, c.code, c.name, c.kind, c.taxable, sum(i.amount)
      from payroll_input_items i join pay_components c on c.id = i.component_id
      where i.employee_id = e.id and i.period = v_period and i.run_id is null group by c.id, c.code, c.name, c.kind, c.taxable;
    else
      insert into payslip_items (company_id, payslip_id, component_id, code, name, kind, taxable, amount)
      select cid, v_slip, c.id, c.code, c.name, c.kind, c.taxable, sum(i.amount)
      from payroll_input_items i join pay_components c on c.id = i.component_id
      where i.employee_id = e.id and i.run_id = p_run group by c.id, c.code, c.name, c.kind, c.taxable;
    end if;
    delete from payslip_items where payslip_id = v_slip and amount <= 0;

    -- Back pay: the difference between the pay now in force for each month already posted and what was paid.
    v_back := 0; v_back_basic := 0;
    if r.kind = 'regular' and exists (select 1 from salary_changes sc where sc.employee_id = e.id and sc.arrears_run_id is null and sc.effective_date < v_period) then
      select coalesce(sum(greatest(0, round((emp_pay_at(e.id, (pr.period + interval '1 month - 1 day')::date)).basic * coalesce(ps.days_paid, 1) / coalesce(ps.days_in_month, 1), 2) - ps.basic)), 0),
             coalesce(sum(greatest(0, round((emp_pay_at(e.id, (pr.period + interval '1 month - 1 day')::date)).allowances * coalesce(ps.days_paid, 1) / coalesce(ps.days_in_month, 1), 2) - ps.allowances)), 0)
        into v_back_basic, v_back
      from payslips ps join payroll_runs pr on pr.id = ps.run_id
      where ps.employee_id = e.id and pr.kind = 'regular' and pr.status <> 'draft' and pr.period < v_period
        and pr.period >= (select date_trunc('month', min(sc.effective_date)) from salary_changes sc where sc.employee_id = e.id and sc.arrears_run_id is null);
      v_back := v_back + v_back_basic;
      if v_back > 0 then
        insert into payslip_items (company_id, payslip_id, component_id, code, name, kind, taxable, amount)
        select cid, v_slip, c.id, 'BACKPAY', c.name, 'earning', true, v_back from pay_components c where c.company_id = cid and c.code = 'BACKPAY';
      end if;
    end if;

    select coalesce(max(overtime), 0), coalesce(max(bonus), 0) into v_ot, v_bonus
      from payroll_inputs where company_id = cid and period = v_period and employee_id = e.id and r.kind = 'regular';
    v_bonus := v_bonus + coalesce((select sum(amount) from payslip_items where payslip_id = v_slip and code = 'BONUS'), 0);
    select coalesce(sum(amount) filter (where kind = 'earning' and code not in ('BONUS','BACKPAY')), 0),
           coalesce(sum(amount) filter (where kind = 'earning' and taxable and code not in ('BONUS','BACKPAY')), 0),
           coalesce(sum(amount) filter (where kind = 'earning' and not taxable), 0),
           coalesce(sum(amount) filter (where kind = 'deduction'), 0)
      into v_earn, v_earn_tax, v_earn_nontax, v_ded from payslip_items where payslip_id = v_slip;

    v_gross := v_basic + v_allow + v_ot + v_bonus + v_earn + v_back;
    -- SSNIT is on basic salary (including basic arrears).
    v_emp := round((v_basic + v_back_basic) * stat_rate('SSNIT_EMPLOYEE', v_payday), 2);
    v_er := round((v_basic + v_back_basic) * stat_rate('SSNIT_EMPLOYER', v_payday), 2);
    v_t2 := round((v_basic + v_back_basic) * stat_rate('TIER2', v_payday), 2);
    v_t3e := round(v_basic * e.tier3_employee_rate, 2);
    v_t3r := round(v_basic * e.tier3_employer_rate, 2);

    if v_ot > 0 and e.is_junior and (pay.basic + pay.allowances) * 12 <= stat_rate('OVERTIME_INCOME_LIMIT', v_payday) then
      v_ot_low := least(v_ot, 0.5 * pay.basic);
      v_ot_tax := round(v_ot_low * stat_rate('OVERTIME_LOW', v_payday) + (v_ot - v_ot_low) * stat_rate('OVERTIME_HIGH', v_payday), 2);
      v_ot_taxable := 0;
    else v_ot_tax := 0; v_ot_taxable := v_ot; end if;

    select coalesce(sum(s.bonus), 0) into v_ytd from payslips s join payroll_runs pr on pr.id = s.run_id
     where pr.company_id = cid and s.employee_id = e.id and pr.id <> p_run and extract(year from pr.period) = extract(year from v_period);
    v_cap_left := greatest(0, stat_rate('BONUS_CAP', v_payday) * pay.basic * 12 - v_ytd);
    v_b_conc := least(v_bonus, v_cap_left);
    v_bonus_tax := round(v_b_conc * stat_rate('BONUS_RATE', v_payday), 2);
    v_bonus_taxable := v_bonus - v_b_conc;

    v_relief_cap := round(stat_rate('TIER3_RELIEF', v_payday) * (v_basic + v_allow + v_earn_tax), 2);
    v_t3_relief := least(v_t3e, greatest(0, v_relief_cap - v_t3r));
    v_t3_excess := greatest(0, v_t3r - v_relief_cap);

    v_charge := v_basic + v_allow + v_earn_tax + v_back + v_ot_taxable + v_bonus_taxable + v_t3_excess - v_emp - v_t3_relief;
    -- PAYE is on the month's total: other posted runs this month are counted, and the tax already taken is deducted.
    select coalesce(sum(s.chargeable), 0), coalesce(sum(s.paye), 0) into v_prior_charge, v_prior_paye
      from payslips s join payroll_runs pr on pr.id = s.run_id
     where s.employee_id = e.id and pr.company_id = cid and pr.period = v_period and pr.id <> p_run and pr.status <> 'draft';
    v_paye := greatest(0, compute_paye(greatest(0, v_prior_charge + v_charge), v_payday) - v_prior_paye);

    v_before := v_gross - v_emp - v_t3e - v_paye - v_ot_tax - v_bonus_tax - v_ded;
    select coalesce(sum(least(installment, balance)), 0) into v_loan from employee_loans
     where employee_id = e.id and status = 'active' and issue_date <= v_payday and r.kind <> 'interim';
    v_loan := least(greatest(v_before, 0), v_loan);
    v_net := v_before - v_loan;

    update payslips set gross = v_gross, ssnit_employee = v_emp, chargeable = v_charge, paye = v_paye, net = v_net, ssnit_employer = v_er,
      tier1 = v_emp + v_er - v_t2, tier2 = v_t2, overtime = v_ot, bonus = v_bonus, overtime_tax = v_ot_tax, bonus_tax = v_bonus_tax,
      tier3_employee = v_t3e, tier3_employer = v_t3r, loan_deduction = v_loan,
      earnings_other = v_earn, nontaxable = v_earn_nontax, deductions_other = v_ded, backpay = v_back
    where id = v_slip;
  end loop;

  update payroll_runs x set gross = coalesce(s.gross, 0), paye = coalesce(s.tax, 0), ssnit_employee = coalesce(s.emp, 0),
    ssnit_employer = coalesce(s.er, 0), net = coalesce(s.net, 0)
  from (select sum(gross) gross, sum(paye + overtime_tax + bonus_tax) tax, sum(ssnit_employee) emp, sum(ssnit_employer) er, sum(net) net
          from payslips where run_id = p_run) s
  where x.id = p_run;
end $$;
revoke execute on function public.calc_run(uuid) from public, anon, authenticated;

create or replace function public.prepare_payroll(cid uuid, p_period date)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_run uuid; v_period date := date_trunc('month', p_period)::date; v_status text;
begin
  perform require_member(cid, array['owner','admin','hr','accountant']);
  select id, status into v_run, v_status from payroll_runs where company_id = cid and period = v_period and kind = 'regular';
  if v_run is not null and v_status <> 'draft' then raise exception 'Payroll for this month is already posted'; end if;
  if v_run is null then insert into payroll_runs (company_id, period, kind) values (cid, v_period, 'regular') returning id into v_run; end if;
  perform calc_run(v_run);
  return v_run;
end $$;

-- An off-cycle run (bonus, commission, final pay) holds only the items added to it.
create or replace function public.create_offcycle_run(cid uuid, p_period date, p_kind text, p_note text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid;
begin
  perform require_member(cid, array['owner','admin','hr','accountant']);
  if p_kind not in ('interim','final') then raise exception 'Choose interim or final'; end if;
  insert into payroll_runs (company_id, period, kind, note) values (cid, date_trunc('month', p_period)::date, p_kind, p_note) returning id into v;
  return v;
end $$;
create or replace function public.recalc_run(p_run uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r payroll_runs;
begin
  select * into r from payroll_runs where id = p_run;
  if not found then raise exception 'Pay run not found'; end if;
  perform require_member(r.company_id, array['owner','admin','hr','accountant']);
  if r.status <> 'draft' then raise exception 'This pay run is already posted'; end if;
  perform calc_run(p_run);
end $$;

-- Posting: as before, plus other deductions owed to their accounts, back pay settled, off-cycle labels.
create or replace function public.post_payroll(p_run uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  r payroll_runs; v_t1 numeric; v_t2 numeric; v_t3e numeric; v_t3r numeric; v_loans numeric;
  v_je uuid; v_date date; s record; ln record; v_left numeric; v_take numeric; v_lines jsonb := '[]'::jsonb; g record;
begin
  select * into r from payroll_runs where id = p_run for update;
  if not found then raise exception 'Payroll run not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant']);
  if r.status <> 'draft' then raise exception 'This payroll is already posted'; end if;
  if r.gross = 0 then raise exception 'There are no payslips in this run'; end if;
  select sum(tier1), sum(tier2), sum(tier3_employee), sum(tier3_employer), sum(loan_deduction)
    into v_t1, v_t2, v_t3e, v_t3r, v_loans from payslips where run_id = p_run;
  v_date := case when r.kind = 'regular' then (r.period + interval '1 month - 1 day')::date else least(current_date, (r.period + interval '1 month - 1 day')::date) end;
  for g in select e.branch_id, e.cost_centre_id, sum(ps.gross) gross, sum(ps.ssnit_employer) er, sum(ps.tier3_employer) t3
             from payslips ps join employees e on e.id = ps.employee_id where ps.run_id = p_run group by 1, 2 loop
    v_lines := v_lines
      || (jl(acct(r.company_id,'salaries'), g.gross, 0) || jsonb_build_object('branch_id', g.branch_id, 'cost_centre_id', g.cost_centre_id))
      || (jl(acct(r.company_id,'employer_ssnit'), g.er, 0) || jsonb_build_object('branch_id', g.branch_id, 'cost_centre_id', g.cost_centre_id))
      || (jl(acct(r.company_id,'employer_tier3'), g.t3, 0) || jsonb_build_object('branch_id', g.branch_id, 'cost_centre_id', g.cost_centre_id));
  end loop;
  for g in select coalesce(c.account_id, acct(r.company_id, 'payroll_deductions')) acc, sum(i.amount) amt
             from payslip_items i join payslips ps on ps.id = i.payslip_id left join pay_components c on c.id = i.component_id
            where ps.run_id = p_run and i.kind = 'deduction' group by 1 loop
    v_lines := v_lines || jsonb_build_array(jl(g.acc, 0, g.amt));
  end loop;
  v_je := post_journal(r.company_id, v_date, 'Payroll ' || to_char(r.period, 'Mon YYYY') || case r.kind when 'interim' then ' (off-cycle)' when 'final' then ' (final pay)' else '' end,
    v_lines || jsonb_build_array(
      jl(acct(r.company_id,'paye'), 0, r.paye),
      jl(acct(r.company_id,'ssnit1'), 0, v_t1),
      jl(acct(r.company_id,'tier2'), 0, v_t2),
      jl(acct(r.company_id,'tier3'), 0, v_t3e + v_t3r),
      jl(acct(r.company_id,'staff_loans'), 0, v_loans),
      jl(acct(r.company_id,'net_pay'), 0, r.net)),
    'payroll', r.id);

  for s in select * from payslips where run_id = p_run and loan_deduction > 0 loop
    v_left := s.loan_deduction;
    for ln in select * from employee_loans where employee_id = s.employee_id and status = 'active' order by issue_date, created_at for update loop
      exit when v_left <= 0;
      v_take := least(v_left, ln.installment, ln.balance);
      update employee_loans set balance = balance - v_take, status = case when balance - v_take <= 0 then 'settled' else 'active' end where id = ln.id;
      insert into loan_repayments (company_id, loan_id, run_id, repay_date, amount) values (r.company_id, ln.id, p_run, v_date, v_take);
      v_left := v_left - v_take;
    end loop;
  end loop;
  if r.kind = 'regular' then
    update salary_changes sc set arrears_run_id = p_run
     where sc.arrears_run_id is null and sc.effective_date < r.period
       and sc.employee_id in (select employee_id from payslips where run_id = p_run);
  end if;
  update payroll_runs set status = 'posted', journal_entry_id = v_je where id = p_run;
end $$;

-- ---------------------------------------------------------------- 4. Self-service

-- Own payslips (posted runs only), with their items.
create or replace function public.my_payslips(p_year int default null, p_company uuid default null) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('slip', to_jsonb(s) - 'company_id', 'period', r.period, 'kind', r.kind, 'status', r.status,
      'company', jsonb_build_object('id', c.id, 'name', c.name, 'tin', c.tin, 'city', c.city, 'phone', c.phone, 'email', c.email),
      'employee', jsonb_build_object('full_name', e.full_name, 'staff_no', e.staff_no, 'job_title', e.job_title, 'department', e.department,
        'tin', e.tin, 'ssnit_no', e.ssnit_no, 'ghana_card', e.ghana_card, 'bank_name', e.bank_name, 'bank_account', e.bank_account),
      'items', coalesce((select jsonb_agg(jsonb_build_object('code', i.code, 'name', i.name, 'kind', i.kind, 'taxable', i.taxable, 'amount', i.amount) order by i.kind, i.name)
        from payslip_items i where i.payslip_id = s.id), '[]'::jsonb)) order by r.period desc, r.created_at desc), '[]'::jsonb)
  from payslips s join payroll_runs r on r.id = s.run_id join employees e on e.id = s.employee_id join companies c on c.id = r.company_id
  where e.user_id = auth.uid() and r.status in ('posted','paid') and (p_year is null or extract(year from r.period) = p_year) and (p_company is null or r.company_id = p_company);
$$;

-- Payslip items for HR and Finance (and the employee, through my_payslips).
create or replace function public.payslip_items_for_run(p_run uuid) returns setof payslip_items
language sql stable security definer set search_path = public as $$
  select i.* from payslip_items i join payslips s on s.id = i.payslip_id join payroll_runs r on r.id = s.run_id
  where s.run_id = p_run and has_role(r.company_id, array['owner','admin','hr','accountant']);
$$;

create table public.employee_change_requests (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  changes jsonb not null,
  note text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  decided_by uuid, decided_at timestamptz, decision_note text,
  created_at timestamptz not null default now()
);

-- Own record, documents shared with them, history (not confidential lines), manager.
create or replace function public.my_profile(p_company uuid default null) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'employee', to_jsonb(e) - 'basic_salary' - 'allowances' - 'cost_rate' - 'tier3_employee_rate' - 'tier3_employer_rate',
    'pay', jsonb_build_object('basic_salary', e.basic_salary, 'allowances', e.allowances),
    'manager', (select jsonb_build_object('full_name', m.full_name, 'job_title', m.job_title) from employees m where m.id = e.manager_id),
    'documents', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'title', d.title, 'kind', d.kind, 'storage_path', d.storage_path, 'expires_on', d.expires_on) order by d.created_at desc)
      from employee_documents d where d.employee_id = e.id and d.visible_to_employee), '[]'::jsonb),
    'history', coalesce((select jsonb_agg(jsonb_build_object('kind', h.kind, 'effective_date', h.effective_date, 'title', h.title) order by h.effective_date desc)
      from employee_events h where h.employee_id = e.id and not h.confidential), '[]'::jsonb),
    'requests', coalesce((select jsonb_agg(to_jsonb(q) order by q.created_at desc) from employee_change_requests q where q.employee_id = e.id), '[]'::jsonb))
  from employees e where e.user_id = auth.uid() and (p_company is null or e.company_id = p_company) order by e.created_at limit 1;
$$;


-- Staff ask to update their own contact, bank and next-of-kin details; HR approves.
create or replace function public.request_profile_change(p_changes jsonb, p_note text default null, p_company uuid default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare e employees; v uuid; k text; allowed text[] := array['phone','email','address','bank_name','bank_branch','bank_account','momo_number','pay_method',
  'next_of_kin_name','next_of_kin_relation','next_of_kin_phone','emergency_phone','tin','ssnit_no','ghana_card'];
begin
  select * into e from employees where user_id = auth.uid() and (p_company is null or company_id = p_company) order by created_at limit 1;
  if not found then raise exception 'Your login is not linked to an employee record. Ask HR.'; end if;
  for k in select jsonb_object_keys(p_changes) loop
    if not k = any(allowed) then raise exception 'You cannot change % yourself. Ask HR.', k; end if;
  end loop;
  insert into employee_change_requests (company_id, employee_id, changes, note) values (e.company_id, e.id, p_changes, p_note) returning id into v;
  perform notify(e.company_id, array['hr'], null, 'hr_profile_change', e.full_name || ' asked to update their details', null, '/employees', false);
  return v;
end $$;

create or replace function public.decide_profile_change(p_id uuid, p_approve boolean, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare q employee_change_requests; k text; v text;
begin
  select * into q from employee_change_requests where id = p_id for update;
  if not found then raise exception 'Not found'; end if;
  if not is_hr(q.company_id) then raise exception 'Only HR can approve this'; end if;
  if q.status <> 'pending' then raise exception 'Already decided'; end if;
  if p_approve then
    for k, v in select key, value from jsonb_each_text(q.changes) loop
      execute format('update public.employees set %I = $1 where id = $2', k) using nullif(v, ''), q.employee_id;
    end loop;
  end if;
  update employee_change_requests set status = case when p_approve then 'approved' else 'rejected' end, decided_by = auth.uid(), decided_at = now(), decision_note = p_note where id = p_id;
  perform notify_users(q.company_id, array[(select user_id from employees where id = q.employee_id)], 'hr_profile_decided',
    'Your details update was ' || case when p_approve then 'approved' else 'not approved' end, p_note, '/my/profile', false);
end $$;

-- Staff directory for everyone (no pay or personal data): names, titles, departments, managers, work contacts.
create or replace function public.staff_directory(cid uuid) returns table (id uuid, full_name text, job_title text, department text, branch text,
  manager_id uuid, email text, phone text, has_login boolean, location text)
language sql stable security definer set search_path = public as $$
  select e.id, e.full_name, e.job_title, e.department, b.name, e.manager_id, e.email, e.phone, e.user_id is not null, e.location
  from employees e left join branches b on b.id = e.branch_id
  where e.company_id = cid and e.status = 'active' and is_member(cid) order by e.full_name;
$$;

-- ---------------------------------------------------------------- 5. Onboarding and exit
create table public.hr_checklists (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  kind text not null check (kind in ('onboarding','offboarding')),
  name text not null,
  items jsonb not null default '[]'::jsonb,   -- [{"task":"…","owner":"hr|manager|it|finance|store|hse|employee","days":0}]
  active boolean not null default true
);
create table public.employee_tasks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  kind text not null check (kind in ('onboarding','offboarding')),
  task text not null,
  owner text not null default 'hr',
  due_date date,
  status text not null default 'open' check (status in ('open','done','na')),
  done_by uuid, done_at timestamptz, note text,
  sort int not null default 0
);
create index on public.employee_tasks (employee_id, kind);

create or replace function public.seed_hr_checklists(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into hr_checklists (company_id, kind, name, items)
  select cid, x.kind, x.name, x.items::jsonb from (values
    ('onboarding', 'New employee', '[{"task":"Signed offer letter and employment contract on file","owner":"hr","days":-3},{"task":"Ghana Card, SSNIT number, TIN and bank or MoMo details recorded","owner":"hr","days":0},{"task":"Registered with SSNIT and the Tier 2 trustee","owner":"hr","days":7},{"task":"Login created and invitation sent","owner":"it","days":0},{"task":"Email address and phone line set up","owner":"it","days":0},{"task":"Laptop, tools and PPE issued (record in Assets)","owner":"store","days":0},{"task":"Company induction: policies, safety, emergency procedures","owner":"hse","days":1},{"task":"Policies read and acknowledged","owner":"employee","days":5},{"task":"Introduced to the team; job description explained","owner":"manager","days":1},{"task":"Objectives for probation agreed","owner":"manager","days":14},{"task":"Added to payroll from the start date","owner":"finance","days":0}]'),
    ('offboarding', 'Leaving employee', '[{"task":"Resignation or termination letter on file","owner":"hr","days":0},{"task":"Handover of work agreed with the manager","owner":"manager","days":0},{"task":"Laptop, tools, PPE, ID card and keys returned (check Assets)","owner":"store","days":0},{"task":"Cash advances retired and staff loans settled or deducted","owner":"finance","days":0},{"task":"Leave days due worked out and added to final pay","owner":"hr","days":0},{"task":"Final pay calculated and approved","owner":"finance","days":0},{"task":"Exit interview held","owner":"hr","days":0},{"task":"Email and system access removed","owner":"it","days":0},{"task":"Certificate of service issued","owner":"hr","days":7},{"task":"SSNIT and Tier 2 trustee informed","owner":"hr","days":14}]')
  ) as x(kind, name, items)
  where not exists (select 1 from hr_checklists h where h.company_id = cid);
$$;
select public.seed_hr_checklists(id) from public.companies;

create or replace function public.start_hr_checklist(p_employee uuid, p_kind text, p_checklist uuid default null, p_from date default null) returns int
language plpgsql security definer set search_path = public as $$
declare e employees; c hr_checklists; n int := 0; it jsonb; v_base date;
begin
  select * into e from employees where id = p_employee;
  if not is_hr(e.company_id) then raise exception 'Only HR can start a checklist'; end if;
  select * into c from hr_checklists where (id = p_checklist or (p_checklist is null and company_id = e.company_id and kind = p_kind and active)) order by name limit 1;
  if not found then raise exception 'Set up a % checklist first', p_kind; end if;
  v_base := coalesce(p_from, case when p_kind = 'onboarding' then e.hire_date else e.end_date end, current_date);
  for it in select value from jsonb_array_elements(c.items) loop
    n := n + 1;
    insert into employee_tasks (company_id, employee_id, kind, task, owner, due_date, sort)
    values (e.company_id, e.id, c.kind, it->>'task', coalesce(it->>'owner', 'hr'), v_base + coalesce((it->>'days')::int, 0), n);
  end loop;
  return n;
end $$;

create or replace function public.hr_task_step(p_id uuid, p_status text, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare t employee_tasks; v_mgr uuid;
begin
  select * into t from employee_tasks where id = p_id for update;
  select m.user_id into v_mgr from employees e join employees m on m.id = e.manager_id where e.id = t.employee_id;
  if not (is_hr(t.company_id) or (t.owner = 'finance' and has_role(t.company_id, array['accountant'])) or (t.owner = 'store' and has_role(t.company_id, array['store']))
          or (t.owner = 'hse' and is_hse(t.company_id)) or (t.owner = 'manager' and v_mgr = auth.uid())
          or (t.owner = 'employee' and exists (select 1 from employees where id = t.employee_id and user_id = auth.uid()))) then
    raise exception 'This task is for % to complete', t.owner;
  end if;
  if p_status not in ('open','done','na') then raise exception 'Unknown status'; end if;
  update employee_tasks set status = p_status, done_by = case when p_status = 'open' then null else auth.uid() end,
    done_at = case when p_status = 'open' then null else now() end, note = coalesce(p_note, note) where id = p_id;
end $$;

create table public.employee_exits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  reason text not null check (reason in ('resignation','end_of_contract','dismissal','redundancy','retirement','death','mutual','other')),
  notice_date date not null default current_date,
  last_day date not null,
  eligible_rehire boolean,
  interview_notes text,
  leave_days_due numeric(6,2),
  status text not null default 'in_progress' check (status in ('in_progress','completed','cancelled')),
  completed_at timestamptz, completed_by uuid,
  created_at timestamptz not null default now()
);

create or replace function public.start_exit(p_employee uuid, p_reason text, p_notice date, p_last_day date, p_note text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare e employees; v uuid; v_leave numeric;
begin
  select * into e from employees where id = p_employee for update;
  if not is_hr(e.company_id) then raise exception 'Only HR can start an exit'; end if;
  if exists (select 1 from employee_exits where employee_id = p_employee and status = 'in_progress') then raise exception 'An exit is already in progress'; end if;
  if p_last_day < p_notice then raise exception 'The last day cannot be before the notice date'; end if;
  select coalesce(sum(remaining), 0) into v_leave from leave_balances(e.company_id, extract(year from p_last_day)::int) b
   where b.employee_id = e.id and b.leave_code = 'annual';
  insert into employee_exits (company_id, employee_id, reason, notice_date, last_day, leave_days_due, interview_notes)
  values (e.company_id, e.id, p_reason, p_notice, p_last_day, greatest(v_leave, 0), p_note) returning id into v;
  update employees set end_date = p_last_day where id = e.id;
  perform start_hr_checklist(e.id, 'offboarding', null, p_last_day);
  perform set_config('sika.hr', 'on', true);
  insert into employee_events (company_id, employee_id, kind, effective_date, title, details)
  values (e.company_id, e.id, 'exit', p_last_day, 'Leaving: ' || replace(p_reason, '_', ' '), p_note);
  perform set_config('sika.hr', 'off', true);
  perform notify(e.company_id, array['hr','accountant','store'], null, 'hr_exit', e.full_name || ' is leaving on ' || to_char(p_last_day, 'DD Mon YYYY'),
    'Clear assets, advances and loans, and prepare final pay.', '/employees/' || e.id, false);
  return v;
end $$;

-- What must be cleared before someone leaves.
create or replace function public.exit_clearance(p_employee uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'assets', coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'tag', a.tag, 'name', a.name)) from assets a where a.custodian_id = e.id and a.status = 'active'), '[]'::jsonb),
    'loans', coalesce((select sum(balance) from employee_loans where employee_id = e.id and status = 'active'), 0),
    'advances', coalesce((select sum(amount) from cash_advances where employee_id = e.id and status in ('open','submitted')), 0),
    'tasks_open', (select count(*) from employee_tasks where employee_id = e.id and kind = 'offboarding' and status = 'open'),
    'daily_rate', round(e.basic_salary / 22.0, 2))
  from employees e where e.id = p_employee and is_hr(e.company_id);
$$;

create or replace function public.complete_exit(p_exit uuid, p_force boolean default false) returns void
language plpgsql security definer set search_path = public as $$
declare x employee_exits; e employees; v_open int;
begin
  select * into x from employee_exits where id = p_exit for update;
  if not is_hr(x.company_id) then raise exception 'Only HR can complete an exit'; end if;
  if x.status <> 'in_progress' then raise exception 'This exit is not in progress'; end if;
  select count(*) into v_open from employee_tasks where employee_id = x.employee_id and kind = 'offboarding' and status = 'open';
  if v_open > 0 and not p_force then raise exception '% exit task% still open', v_open, case when v_open = 1 then ' is' else 's are' end; end if;
  select * into e from employees where id = x.employee_id for update;
  update employees set status = 'inactive', end_date = x.last_day where id = e.id;
  if e.user_id is not null then delete from memberships where company_id = e.company_id and user_id = e.user_id and role <> 'owner'; end if;
  update employee_exits set status = 'completed', completed_at = now(), completed_by = auth.uid() where id = p_exit;
end $$;

-- ---------------------------------------------------------------- 6. Leave: holidays, working days, accrual, manager approval
create table public.public_holidays (
  company_id uuid not null references public.companies(id) on delete cascade,
  holiday date not null,
  name text not null,
  primary key (company_id, holiday)
);
alter table public.leave_types add column if not exists accrual text not null default 'upfront' check (accrual in ('upfront','monthly'));
alter table public.leave_types add column if not exists carry_over_max numeric(5,1) not null default 0;
alter table public.leave_types add column if not exists counts text not null default 'working' check (counts in ('working','calendar'));
alter table public.leave_requests add column if not exists decided_by uuid;
alter table public.leave_requests add column if not exists decided_at timestamptz;
alter table public.leave_requests add column if not exists decision_note text;
alter table public.leave_requests add column if not exists half_day boolean not null default false;

-- Easter Sunday (Gregorian, anonymous algorithm).
create or replace function public.easter_sunday(y int) returns date language plpgsql immutable as $$
declare a int; b int; c int; d int; e int; f int; g int; h int; i int; k int; l int; m int;
begin
  a := y % 19; b := y / 100; c := y % 100; d := b / 4; e := b % 4; f := (b + 8) / 25; g := (b - f + 1) / 3;
  h := (19 * a + b - d - g + 15) % 30; i := c / 4; k := c % 4; l := (32 + 2 * e + 2 * i - h - k) % 7; m := (a + 11 * h + 22 * l) / 451;
  return make_date(y, (h + l - 7 * m + 114) / 31, ((h + l - 7 * m + 114) % 31) + 1);
end $$;

-- Ghana public holidays under the Public Holidays and Commemorative Days Act as amended in 2025. Eid al-Fitr, Shaqq Day
-- and Eid al-Adha follow the moon and are announced each year: add them when the dates are declared.
create or replace function public.seed_ghana_holidays_internal(cid uuid, y int) returns int
language plpgsql security definer set search_path = public as $$
declare n int; v_dec1 date := make_date(y, 12, 1);
begin
  insert into public_holidays (company_id, holiday, name) values
    (cid, make_date(y, 1, 1), 'New Year''s Day'), (cid, make_date(y, 1, 7), 'Constitution Day'), (cid, make_date(y, 3, 6), 'Independence Day'),
    (cid, easter_sunday(y) - 2, 'Good Friday'), (cid, easter_sunday(y) + 1, 'Easter Monday'), (cid, make_date(y, 5, 1), 'May Day (Workers'' Day)'),
    (cid, make_date(y, 7, 1), 'Republic Day'), (cid, make_date(y, 9, 21), 'Founder''s Day'),
    (cid, v_dec1 + ((5 - extract(dow from v_dec1)::int + 7) % 7), 'Farmers'' Day'),
    (cid, make_date(y, 12, 25), 'Christmas Day'), (cid, make_date(y, 12, 26), 'Boxing Day')
  on conflict do nothing;
  get diagnostics n = row_count;
  return n;
end $$;
revoke execute on function public.seed_ghana_holidays_internal(uuid, int) from public, anon, authenticated;
create or replace function public.seed_ghana_holidays(cid uuid, y int) returns int
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hr(cid) or has_role(cid, array['accountant'])) then raise exception 'Only HR or Finance can set public holidays'; end if;
  return seed_ghana_holidays_internal(cid, y);
end $$;
do $$ declare c record; begin
  for c in select id from companies loop
    perform seed_ghana_holidays_internal(c.id, extract(year from current_date)::int);
    perform seed_ghana_holidays_internal(c.id, extract(year from current_date)::int + 1);
  end loop;
end $$;

create or replace function public.leave_days_between(cid uuid, p_start date, p_end date, p_counts text default 'working') returns numeric
language sql stable security definer set search_path = public as $$
  select count(*)::numeric from generate_series(p_start, p_end, interval '1 day') d
  where is_member(cid) and (p_counts = 'calendar' or (extract(isodow from d) < 6 and not exists (select 1 from public_holidays h where h.company_id = cid and h.holiday = d::date)));
$$;

create or replace function public.leave_request_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_counts text; v_mgr uuid; v_name text;
begin
  if tg_op = 'INSERT' or (new.start_date, new.end_date, new.half_day) is distinct from (old.start_date, old.end_date, old.half_day) then
    select counts into v_counts from leave_types where company_id = new.company_id and code = new.leave_type;
    new.days := case when new.half_day and new.start_date = new.end_date then 0.5 else leave_days_between(new.company_id, new.start_date, new.end_date, coalesce(v_counts, 'working')) end;
    if new.days <= 0 then raise exception 'Those dates are all weekends or public holidays'; end if;
  end if;
  if tg_op = 'INSERT' then
    select m.user_id, e.full_name into v_mgr, v_name from employees e left join employees m on m.id = e.manager_id where e.id = new.employee_id;
    perform notify(new.company_id, array['hr'], array[v_mgr], 'leave_request', v_name || ' asked for ' || new.days || ' day' || case when new.days = 1 then '' else 's' end || ' ' || replace(new.leave_type, '_', ' ') || ' leave',
      to_char(new.start_date, 'DD Mon') || ' to ' || to_char(new.end_date, 'DD Mon YYYY'), '/leave', false);
  end if;
  return new;
end $$;
create trigger leave_requests_defaults before insert or update on public.leave_requests for each row execute function public.leave_request_defaults();

-- HR or the employee's manager decides (never their own request).
create or replace function public.decide_leave(p_id uuid, p_approve boolean, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare q leave_requests; v_mgr uuid; v_self uuid; v_bal numeric;
begin
  select * into q from leave_requests where id = p_id for update;
  if not found then raise exception 'Leave request not found'; end if;
  select m.user_id, e.user_id into v_mgr, v_self from employees e left join employees m on m.id = e.manager_id where e.id = q.employee_id;
  if not (is_hr(q.company_id) or (v_mgr is not null and v_mgr = auth.uid())) then raise exception 'Only HR or the employee''s manager can decide'; end if;
  if v_self = auth.uid() then raise exception 'You cannot approve your own leave'; end if;
  if q.status <> 'pending' then raise exception 'Already decided'; end if;
  if p_approve then
    select remaining into v_bal from leave_balances(q.company_id, extract(year from q.start_date)::int) b where b.employee_id = q.employee_id and b.leave_code = q.leave_type;
    if v_bal is not null and v_bal < q.days and not is_hr(q.company_id) then raise exception 'Only % day(s) left. HR can approve beyond the balance.', v_bal; end if;
  end if;
  update leave_requests set status = case when p_approve then 'approved' else 'rejected' end, decided_by = auth.uid(), decided_at = now(), decision_note = p_note where id = p_id;
  perform notify_users(q.company_id, array[v_self], 'leave_decided', 'Your leave from ' || to_char(q.start_date, 'DD Mon') || ' was ' || case when p_approve then 'approved' else 'not approved' end, p_note, '/leave', false);
end $$;

-- Balances with pro rata for joiners, monthly accrual and carry-over from last year.
drop function if exists public.leave_balances(uuid, int);
create function public.leave_balances(cid uuid, p_year int)
returns table (employee_id uuid, full_name text, leave_code text, leave_name text, entitlement numeric, taken numeric, pending numeric, remaining numeric,
  carried numeric, accrued numeric)
language sql stable security definer set search_path = public as $$
  with base as (
    select e.id eid, e.full_name, t.code, t.name, t.accrual, t.carry_over_max,
      coalesce(en.days, t.days_per_year) full_days,
      -- months employed in the year (whole months from the hire month)
      case when e.hire_date is null or e.hire_date < make_date(p_year, 1, 1) then 12
           when extract(year from e.hire_date) > p_year then 0 else 13 - extract(month from e.hire_date) end::numeric months_in,
      case when p_year < extract(year from current_date) then 12 when p_year > extract(year from current_date) then 0 else extract(month from current_date) end::numeric months_to_date,
      coalesce(enp.days, t.days_per_year) prev_full,
      coalesce((select sum(days) from leave_requests r where r.employee_id = e.id and r.leave_type = t.code and r.status = 'approved' and extract(year from r.start_date) = p_year - 1), 0) prev_taken,
      coalesce((select sum(days) from leave_requests r where r.employee_id = e.id and r.leave_type = t.code and r.status = 'approved' and extract(year from r.start_date) = p_year), 0) taken,
      coalesce((select sum(days) from leave_requests r where r.employee_id = e.id and r.leave_type = t.code and r.status = 'pending' and extract(year from r.start_date) = p_year), 0) pending,
      e.hire_date
    from employees e cross join leave_types t
    left join leave_entitlements en on en.employee_id = e.id and en.leave_code = t.code and en.year = p_year
    left join leave_entitlements enp on enp.employee_id = e.id and enp.leave_code = t.code and enp.year = p_year - 1
    where e.company_id = cid and t.company_id = cid and e.status = 'active' and is_member(cid)
  ), calc as (
    select *, case when full_days is null then null else round(full_days * months_in / 12.0 * 2) / 2 end year_days,
      case when full_days is null or carry_over_max = 0 or (hire_date is not null and extract(year from hire_date) >= p_year) then 0
           else greatest(0, least(carry_over_max, prev_full - prev_taken)) end carried
    from base
  )
  select eid, full_name, code, name,
    case when year_days is null then null else year_days + carried end,
    taken, pending,
    case when year_days is null then null
         when accrual = 'monthly' then round(least(year_days, full_days * greatest(0, months_to_date - (12 - months_in)) / 12.0) * 2) / 2 + carried - taken
         else year_days + carried - taken end,
    carried,
    case when year_days is null then null when accrual = 'monthly' then round(least(year_days, full_days * greatest(0, months_to_date - (12 - months_in)) / 12.0) * 2) / 2 else year_days end
  from calc order by full_name, name;
$$;

-- ---------------------------------------------------------------- 7. Announcements
create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  title text not null,
  body text not null,
  audience text not null default 'all' check (audience in ('all','department','branch')),
  audience_value text,
  pinned boolean not null default false,
  publish_on date not null default current_date,
  expires_on date,
  created_by uuid default auth.uid(),
  created_email text,
  created_at timestamptz not null default now()
);
create table public.announcement_reads (
  announcement_id uuid not null references public.announcements(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  read_at timestamptz not null default now(),
  primary key (announcement_id, user_id)
);

create or replace function public.announcement_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_users uuid[];
begin
  if not is_hr(coalesce(new.company_id, old.company_id)) then raise exception 'Only HR, an owner or admin can post announcements'; end if;
  if tg_op = 'DELETE' then return old; end if;
  if tg_op = 'INSERT' then
    new.created_email := (select email from auth.users where id = auth.uid());
    select coalesce(array_agg(m.user_id), '{}') into v_users from memberships m
     where m.company_id = new.company_id and (new.audience = 'all' or exists (select 1 from employees e left join branches b on b.id = e.branch_id
       where e.user_id = m.user_id and e.company_id = new.company_id and ((new.audience = 'department' and e.department = new.audience_value) or (new.audience = 'branch' and (b.name = new.audience_value or b.code = new.audience_value)))));
    if new.publish_on <= current_date then
      perform notify_users(new.company_id, v_users, 'announcement', new.title, left(new.body, 160), '/', false);
    end if;
  end if;
  return new;
end $$;
create trigger announcements_defaults before insert or update or delete on public.announcements for each row execute function public.announcement_defaults();

create or replace function public.my_announcements(cid uuid) returns table (id uuid, title text, body text, pinned boolean, publish_on date, created_email text, read boolean, audience text, audience_value text)
language sql stable security definer set search_path = public as $$
  select a.id, a.title, a.body, a.pinned, a.publish_on, a.created_email, exists (select 1 from announcement_reads r where r.announcement_id = a.id and r.user_id = auth.uid()), a.audience, a.audience_value
  from announcements a
  where a.company_id = cid and is_member(cid) and a.publish_on <= current_date and (a.expires_on is null or a.expires_on >= current_date)
    and (a.audience = 'all' or is_hr(cid) or exists (select 1 from employees e left join branches b on b.id = e.branch_id where e.user_id = auth.uid() and e.company_id = cid
      and ((a.audience = 'department' and e.department = a.audience_value) or (a.audience = 'branch' and (b.name = a.audience_value or b.code = a.audience_value)))))
  order by a.pinned desc, a.publish_on desc, a.created_at desc limit 50;
$$;

-- ---------------------------------------------------------------- 8. Reports
create or replace function public.hr_report(cid uuid, p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v jsonb; v_start int; v_end int; v_leavers int;
begin
  if not has_role(cid, array['owner','admin','hr','accountant']) then raise exception 'Only HR and Finance can see HR reports'; end if;
  select count(*) into v_start from employees where company_id = cid and coalesce(hire_date, created_at::date) < p_from and (end_date is null or end_date >= p_from);
  select count(*) into v_end from employees where company_id = cid and coalesce(hire_date, created_at::date) <= p_to and (end_date is null or end_date > p_to) and (status = 'active' or end_date > p_to);
  select count(*) into v_leavers from employees where company_id = cid and end_date between p_from and p_to;
  v := jsonb_build_object(
    'headcount_start', v_start, 'headcount_end', v_end, 'leavers', v_leavers,
    'joiners', (select count(*) from employees where company_id = cid and hire_date between p_from and p_to),
    'turnover_pct', case when v_start + v_end > 0 then round(100.0 * v_leavers / ((v_start + v_end) / 2.0), 1) end,
    'by_department', coalesce((select jsonb_agg(jsonb_build_object('name', coalesce(department, 'Not set'), 'n', n, 'basic', basic) order by n desc)
      from (select department, count(*) n, sum(basic_salary) basic from employees where company_id = cid and status = 'active' group by department) x), '[]'::jsonb),
    'by_type', coalesce((select jsonb_agg(jsonb_build_object('name', employment_type, 'n', n)) from (select employment_type, count(*) n from employees where company_id = cid and status = 'active' group by 1) x), '[]'::jsonb),
    'by_gender', coalesce((select jsonb_agg(jsonb_build_object('name', coalesce(gender, 'not recorded'), 'n', n)) from (select gender, count(*) n from employees where company_id = cid and status = 'active' group by 1) x), '[]'::jsonb),
    'payroll_by_month', coalesce((select jsonb_agg(jsonb_build_object('period', period, 'gross', gross, 'employer', er, 'net', net, 'paye', paye, 'people', people) order by period)
      from (select r.period, sum(s.gross) gross, sum(s.ssnit_employer + s.tier3_employer) er, sum(s.net) net, sum(s.paye + s.overtime_tax + s.bonus_tax) paye, count(distinct s.employee_id) people
              from payroll_runs r join payslips s on s.run_id = r.id where r.company_id = cid and r.status <> 'draft' and r.period between date_trunc('month', p_from) and p_to group by r.period) x), '[]'::jsonb),
    'leave_liability', coalesce((select jsonb_build_object('days', sum(greatest(b.remaining, 0)), 'value', round(sum(greatest(b.remaining, 0) * e.basic_salary / 22.0), 2))
      from leave_balances(cid, extract(year from p_to)::int) b join employees e on e.id = b.employee_id where b.leave_code = 'annual'), '{}'::jsonb),
    'probation_ending', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'full_name', full_name, 'date', probation_end) order by probation_end)
      from employees where company_id = cid and status = 'active' and confirmed_on is null and probation_end between current_date - 30 and current_date + 60), '[]'::jsonb),
    'contracts_ending', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'full_name', full_name, 'date', contract_end, 'type', employment_type) order by contract_end)
      from employees where company_id = cid and status = 'active' and contract_end between current_date - 30 and current_date + 90), '[]'::jsonb),
    'documents_expiring', coalesce((select jsonb_agg(jsonb_build_object('employee', e.full_name, 'title', d.title, 'date', d.expires_on) order by d.expires_on)
      from employee_documents d join employees e on e.id = d.employee_id where d.company_id = cid and e.status = 'active' and d.expires_on between current_date - 30 and current_date + 60), '[]'::jsonb),
    'birthdays', coalesce((select jsonb_agg(jsonb_build_object('full_name', full_name, 'day', to_char(date_of_birth, 'DD Mon')) order by to_char(date_of_birth, 'MMDD'))
      from employees where company_id = cid and status = 'active' and date_of_birth is not null and extract(month from date_of_birth) = extract(month from current_date)), '[]'::jsonb));
  return v;
end $$;

-- Annual PAYE return: per employee for the year, from posted pay runs.
create or replace function public.paye_annual(cid uuid, p_year int)
returns table (employee_id uuid, full_name text, tin text, ghana_card text, ssnit_no text, months int, basic numeric, allowances numeric, other_earnings numeric,
  nontaxable numeric, overtime numeric, bonus numeric, gross numeric, ssnit_employee numeric, tier3_employee numeric, chargeable numeric, paye numeric,
  overtime_tax numeric, bonus_tax numeric, total_tax numeric)
language sql stable security definer set search_path = public as $$
  select e.id, e.full_name, e.tin, e.ghana_card, e.ssnit_no, count(distinct r.period)::int, sum(s.basic), sum(s.allowances), sum(s.earnings_other + s.backpay - s.nontaxable),
    sum(s.nontaxable), sum(s.overtime), sum(s.bonus), sum(s.gross), sum(s.ssnit_employee), sum(s.tier3_employee), sum(s.chargeable), sum(s.paye),
    sum(s.overtime_tax), sum(s.bonus_tax), sum(s.paye + s.overtime_tax + s.bonus_tax)
  from payslips s join payroll_runs r on r.id = s.run_id join employees e on e.id = s.employee_id
  where r.company_id = cid and r.status <> 'draft' and extract(year from r.period) = p_year and has_role(cid, array['owner','admin','hr','accountant'])
  group by e.id order by e.full_name;
$$;

-- ---------------------------------------------------------------- 9. Reminders (daily, with the existing job)
create or replace function public.run_hr_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  -- Future-dated pay changes take effect on the employee record on their date.
  update employees e set basic_salary = sc.basic_salary, allowances = sc.allowances
  from (select distinct on (employee_id) employee_id, basic_salary, allowances from salary_changes where effective_date <= current_date
        order by employee_id, effective_date desc, created_at desc) sc
  where e.id = sc.employee_id and (e.basic_salary, e.allowances) is distinct from (sc.basic_salary, sc.allowances);
  for r in select e.*, m.user_id mgr from employees e left join employees m on m.id = e.manager_id
            where e.status = 'active' and e.confirmed_on is null and e.probation_end = current_date + 14 loop
    perform notify(r.company_id, array['hr'], array[r.mgr], 'hr_probation', 'Probation ends in 2 weeks: ' || r.full_name, 'Confirm, extend or end the appointment.', '/employees/' || r.id, true);
    n := n + 1;
  end loop;
  for r in select e.*, m.user_id mgr from employees e left join employees m on m.id = e.manager_id
            where e.status = 'active' and e.contract_end in (current_date + 30, current_date + 7) loop
    perform notify(r.company_id, array['hr'], array[r.mgr], 'hr_contract', 'Contract ends ' || to_char(r.contract_end, 'DD Mon YYYY') || ': ' || r.full_name, 'Renew or start the exit.', '/employees/' || r.id, true);
    n := n + 1;
  end loop;
  for r in select d.*, e.full_name from employee_documents d join employees e on e.id = d.employee_id where e.status = 'active' and d.expires_on = current_date + 30 loop
    perform notify(r.company_id, array['hr'], null, 'hr_document', r.title || ' for ' || r.full_name || ' expires in 30 days', null, '/employees/' || r.employee_id, true);
    n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_hr_reminders() from public, anon, authenticated;

create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 10. New companies and HR policies
create or replace function public.company_seed_hr() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform set_config('sika.hr', 'on', true);
  perform seed_accounts_v30(new.id);
  perform seed_pay_components(new.id);
  perform seed_hr_checklists(new.id);
  perform seed_ghana_holidays_internal(new.id, extract(year from current_date)::int);
  perform seed_ghana_holidays_internal(new.id, extract(year from current_date)::int + 1);
  perform set_config('sika.hr', 'off', true);
  return null;
end $$;
create trigger companies_seed_hr after insert on public.companies for each row execute function public.company_seed_hr();

-- HR and admin policies share the policy register (HSE module); add the two areas.
alter table public.hse_policies drop constraint if exists hse_policies_area_check;
alter table public.hse_policies add constraint hse_policies_area_check
  check (area in ('safety','environment','quality','legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it','other'));

-- ---------------------------------------------------------------- 11. Security rules
do $$ declare t text; begin
  foreach t in array array['employee_events','employee_documents','pay_components','employee_pay_items','payroll_input_items','payslip_items','salary_changes',
                           'employee_change_requests','hr_checklists','employee_tasks','employee_exits','public_holidays','announcements'] loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
end $$;
alter table public.announcement_reads enable row level security;
-- Pay and personal records: owners, admins and HR (Finance reads pay).
create policy "hr reads history" on public.employee_events for select using (is_hr(company_id));
create policy "hr writes history" on public.employee_events for insert with check (is_hr(company_id));
create policy "hr deletes history" on public.employee_events for delete using (is_hr(company_id) and kind in ('note','warning','disciplinary','grievance','award','training'));
create policy "hr documents" on public.employee_documents for all using (is_hr(company_id)) with check (is_hr(company_id));
create policy "pay readers" on public.pay_components for select using (is_member(company_id));
create policy "pay writers" on public.pay_components for all using (has_role(company_id, array['owner','admin','hr','accountant'])) with check (has_role(company_id, array['owner','admin','hr','accountant']));
create policy "pay items" on public.employee_pay_items for all using (has_role(company_id, array['owner','admin','hr','accountant'])) with check (has_role(company_id, array['owner','admin','hr','accountant']));
create policy "input items" on public.payroll_input_items for all using (has_role(company_id, array['owner','admin','hr','accountant'])) with check (has_role(company_id, array['owner','admin','hr','accountant']));
create policy "payslip items" on public.payslip_items for select using (has_role(company_id, array['owner','admin','hr','accountant']));
create policy "salary history" on public.salary_changes for select using (has_role(company_id, array['owner','admin','hr','accountant']));
create policy "change requests hr" on public.employee_change_requests for select using (is_hr(company_id));
create policy "checklists read" on public.hr_checklists for select using (is_member(company_id));
create policy "checklists write" on public.hr_checklists for all using (is_hr(company_id)) with check (is_hr(company_id));
create policy "tasks read" on public.employee_tasks for select using (has_role(company_id, array['owner','admin','hr','accountant','store']) or is_hse(company_id)
  or employee_id in (select my_employee_ids()) or exists (select 1 from employees e join employees m on m.id = e.manager_id where e.id = employee_id and m.user_id = auth.uid()));
create policy "tasks hr" on public.employee_tasks for all using (is_hr(company_id)) with check (is_hr(company_id));
create policy "exits hr" on public.employee_exits for all using (is_hr(company_id)) with check (is_hr(company_id));
create policy "exits finance" on public.employee_exits for select using (has_role(company_id, array['accountant']));
create policy "holidays read" on public.public_holidays for select using (is_member(company_id));
create policy "holidays write" on public.public_holidays for all using (is_hr(company_id) or has_role(company_id, array['accountant'])) with check (is_hr(company_id) or has_role(company_id, array['accountant']));
create policy "announcements hr" on public.announcements for all using (is_hr(company_id)) with check (is_hr(company_id));
create policy "own reads" on public.announcement_reads for all using (user_id = auth.uid()) with check (user_id = auth.uid());
-- Leave: staff see their own requests and their team's; HR sees all; decisions go through decide_leave.
drop policy if exists "members read leave" on public.leave_requests;
create policy "leave visible" on public.leave_requests for select using (is_hr(company_id) or employee_id in (select my_employee_ids())
  or exists (select 1 from employees e join employees m on m.id = e.manager_id where e.id = employee_id and m.user_id = auth.uid())
  or (has_role(company_id, array['project_manager','accountant']) and status = 'approved'));
drop policy if exists "members request leave" on public.leave_requests;
create policy "staff request own leave" on public.leave_requests for insert with check (status = 'pending' and (is_hr(company_id) or employee_id in (select my_employee_ids())));

do $$ declare t text; begin
  foreach t in array array['salary_changes','employee_events','employee_documents','pay_components','employee_pay_items','payroll_input_items','employee_exits','announcements','public_holidays'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
  end loop;
end $$;

revoke execute on function public.seed_accounts_v30(uuid) from public, anon, authenticated;
revoke execute on function public.seed_pay_components(uuid) from public, anon, authenticated;
revoke execute on function public.seed_hr_checklists(uuid) from public, anon, authenticated;

-- ================================================================ 0018_asnys_v3_1.sql
-- Asnys ERP v3.1 — Assets to match the Gulfaco asset system, and Fleet & Logistics
-- Assets
--   1. Locations register (head office, branches, sites, stores, regions) with a manager for each.
--   2. Manufacturer, model and order number on assets.
--   3. Transfers between locations: In transit until the receiving location confirms; reject or recall.
--   4. Requests routed through the site: the site manager approves, or passes it to head office.
--   5. Accessories, components and consumables: quantities per location, check out to people or into an asset,
--      low-stock alerts.
--   6. Software licences: seats, product key, assignment to people or computers, expiry reminders.
--   7. Telegram alerts (optional) for transfers, requests, decisions, low stock and fleet.
-- Fleet & Logistics
--   8. Vehicle file (registration, DVLA roadworthy, insurance, road-use documents with reminders), drivers and licences.
--   9. Trip log with mileage; fuel log with km per litre and unusual consumption flagged; fuel feeds the CO2 figures.
--  10. Service and repairs by mileage or date (job cards, downtime); vehicle requests allocated by the transport officer.
--  11. Waybills for deliveries and collections, own vehicle or hired transport, with signed proof of delivery.
--  12. Fleet reports: cost per vehicle and per km, fuel use, transport by project.
-- Transport officer is a tick on a team member (like HSE officer); owners, admins, Finance and the storekeeper count as one.
-- Run after 0017.

-- ---------------------------------------------------------------- 0. People who manage the fleet
alter table public.memberships add column if not exists transport boolean not null default false;
create or replace function public.is_transport(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (transport or role in ('owner','admin','accountant','store')));
$$;
create or replace function public.transport_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or role = 'store');
$$;
create or replace function public.set_member_transport(cid uuid, p_user uuid, p_on boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can choose transport officers'; end if;
  update memberships set transport = p_on where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
end $$;

-- ---------------------------------------------------------------- 1. Telegram alerts (optional)
-- Needs the pg_net extension (Supabase: Database → Extensions → pg_net). Without it, alerts are skipped quietly.
create table public.company_telegram (
  company_id uuid primary key references public.companies(id) on delete cascade,
  bot_token text,
  chat_id text,
  events text[] not null default '{transfer,request,decision,low_stock,fleet,signup}',
  enabled boolean not null default false,
  updated_at timestamptz not null default now()
);
create or replace function public.send_telegram(cid uuid, p_event text, p_text text) returns void
language plpgsql security definer set search_path = public as $$
declare t company_telegram;
begin
  select * into t from company_telegram where company_id = cid;
  if not found or not t.enabled or t.bot_token is null or t.chat_id is null or not (p_event = any(t.events)) then return; end if;
  if to_regnamespace('net') is null then return; end if;
  begin
    execute 'select net.http_post(url := $1, body := $2, headers := ''{"Content-Type":"application/json"}''::jsonb)'
      using 'https://api.telegram.org/bot' || t.bot_token || '/sendMessage', jsonb_build_object('chat_id', t.chat_id, 'text', left(p_text, 4000));
  exception when others then null;
  end;
end $$;
revoke execute on function public.send_telegram(uuid, text, text) from public, anon, authenticated;
create or replace function public.test_telegram(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can set up Telegram'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  perform send_telegram(cid, (select coalesce(events[1], 'transfer') from company_telegram where company_id = cid), 'Asnys ERP: Telegram alerts are working for ' || (select name from companies where id = cid) || '.');
  return 'sent';
end $$;

-- ---------------------------------------------------------------- 2. Locations
create table public.asset_locations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  kind text not null default 'site' check (kind in ('head_office','branch','site','store','yard','other')),
  region text,
  address text,
  manager_id uuid,
  project_id uuid references public.projects(id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (company_id, name)
);
insert into public.asset_locations (company_id, name, kind)
select id, 'Head office', 'head_office' from public.companies on conflict do nothing;
-- Existing free-text locations become entries.
insert into public.asset_locations (company_id, name, kind)
select distinct company_id, trim(location), 'other' from public.assets where coalesce(trim(location), '') <> '' on conflict do nothing;

alter table public.assets add column if not exists location_id uuid references public.asset_locations(id) on delete set null;
alter table public.assets add column if not exists manufacturer text;
alter table public.assets add column if not exists model text;
alter table public.assets add column if not exists order_number text;
update public.assets a set location_id = l.id from public.asset_locations l where l.company_id = a.company_id and l.name = trim(a.location) and a.location_id is null;
alter table public.assets drop constraint if exists assets_state_check;
alter table public.assets add constraint assets_state_check check (state in ('ready','deployed','pending','repair','broken','lost','archived','transit'));

create or replace function public.location_manager(p_location uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from asset_locations where id = p_location and manager_id = auth.uid());
$$;

create or replace function public.location_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(current_setting('sika.seed', true), '') <> 'on' and not asset_manager(coalesce(new.company_id, old.company_id)) then
    raise exception 'Only the storekeeper, Finance or an admin can change locations';
  end if;
  return coalesce(new, old);
end $$;
create trigger asset_locations_guard before insert or update or delete on public.asset_locations for each row execute function public.location_guard();

-- Keep the free-text location in step with the chosen location.
create or replace function public.asset_location_text() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.location_id is not null and (tg_op = 'INSERT' or new.location_id is distinct from old.location_id) then
    new.location := (select name from asset_locations where id = new.location_id);
  end if;
  return new;
end $$;
create trigger assets_location_text before insert or update of location_id on public.assets for each row execute function public.asset_location_text();

-- ---------------------------------------------------------------- 3. Transfers between locations
create table public.asset_transfers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  asset_id uuid not null references public.assets(id) on delete cascade,
  from_location_id uuid references public.asset_locations(id),
  to_location_id uuid not null references public.asset_locations(id),
  sent_by uuid default auth.uid(), sent_at timestamptz not null default now(),
  note text,
  waybill_id uuid,
  status text not null default 'in_transit' check (status in ('in_transit','received','rejected','recalled')),
  closed_by uuid, closed_at timestamptz, close_note text, condition text
);
create index on public.asset_transfers (company_id, status);

create or replace function public.send_asset_transfer(p_asset uuid, p_to uuid, p_note text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare a assets; v uuid; n text; v_to asset_locations;
begin
  select * into a from assets where id = p_asset for update;
  if not found then raise exception 'Asset not found'; end if;
  if not (asset_manager(a.company_id) or location_manager(a.location_id)) then raise exception 'Only the storekeeper or the manager of the location holding it can send it'; end if;
  if a.state not in ('ready','pending','repair','broken') then raise exception '% is % — check it in first', a.tag, a.state; end if;
  select * into v_to from asset_locations where id = p_to and company_id = a.company_id and active;
  if not found then raise exception 'Choose where it is going'; end if;
  if a.location_id = p_to then raise exception '% is already at %', a.tag, v_to.name; end if;
  n := next_number(a.company_id, 'ATR', 'ATR-');
  insert into asset_transfers (company_id, number, asset_id, from_location_id, to_location_id, note) values (a.company_id, n, a.id, a.location_id, p_to, p_note) returning id into v;
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, note, state_after)
  values (a.company_id, a.id, 'move', a.location, v_to.name || ' (in transit)', concat_ws(' · ', n, p_note), 'transit');
  update assets set state = 'transit' where id = a.id;
  perform notify_users(a.company_id, array_remove(array[v_to.manager_id], null) || transport_users(a.company_id), 'asset_transfer', n || ': ' || a.tag || ' ' || a.name || ' is on its way to ' || v_to.name, p_note, '/assets/transfers', false);
  perform send_telegram(a.company_id, 'transfer', '🚚 ' || n || ': ' || a.tag || ' ' || a.name || ' sent from ' || coalesce(a.location, '—') || ' to ' || v_to.name || coalesce(' — ' || p_note, ''));
  return v;
end $$;

create or replace function public.close_asset_transfer(p_id uuid, p_action text, p_note text default null, p_condition text default 'good') returns void
language plpgsql security definer set search_path = public as $$
declare t asset_transfers; a assets; v_loc uuid; v_state text; v_name text;
begin
  select * into t from asset_transfers where id = p_id for update;
  if not found then raise exception 'Transfer not found'; end if;
  if t.status <> 'in_transit' then raise exception 'This transfer is already %', t.status; end if;
  if p_action = 'receive' then
    if not (asset_manager(t.company_id) or location_manager(t.to_location_id)) then raise exception 'Only the receiving location''s manager or the storekeeper can confirm receipt'; end if;
    v_loc := t.to_location_id; v_state := case when p_condition in ('broken') then 'broken' when p_condition = 'poor' then 'repair' else 'ready' end;
  elsif p_action = 'reject' then
    if not (asset_manager(t.company_id) or location_manager(t.to_location_id)) then raise exception 'Only the receiving location can reject it'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Say why it is rejected'; end if;
    v_loc := t.from_location_id; v_state := 'ready';
  elsif p_action = 'recall' then
    if not (asset_manager(t.company_id) or t.sent_by = auth.uid() or location_manager(t.from_location_id)) then raise exception 'Only the sender can recall it'; end if;
    v_loc := t.from_location_id; v_state := 'ready';
  else raise exception 'Unknown action %', p_action;
  end if;
  select * into a from assets where id = t.asset_id for update;
  select name into v_name from asset_locations where id = v_loc;
  perform set_config('sika.transfer', 'on', true);
  update asset_transfers set status = case p_action when 'receive' then 'received' when 'reject' then 'rejected' else 'recalled' end,
    closed_by = auth.uid(), closed_at = now(), close_note = p_note, condition = case when p_action = 'receive' then p_condition end where id = p_id;
  update assets set state = v_state, location_id = v_loc where id = a.id;
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, note, state_after)
  values (t.company_id, a.id, 'move', 'In transit', v_name, concat_ws(' · ', t.number, initcap(p_action) || case when p_action = 'receive' then 'd' else 'ed' end, p_note), v_state);
  perform set_config('sika.transfer', 'off', true);
  perform notify_users(t.company_id, array[t.sent_by], 'asset_transfer_' || p_action, t.number || ': ' || a.tag || ' ' || case p_action when 'receive' then 'received at ' when 'reject' then 'rejected, coming back to ' else 'recalled to ' end || coalesce(v_name, ''), p_note, '/assets/transfers', false);
  perform send_telegram(t.company_id, 'transfer', case p_action when 'receive' then '✅ ' when 'reject' then '⛔ ' else '↩️ ' end || t.number || ': ' || a.tag || ' ' || a.name || ' ' ||
    case p_action when 'receive' then 'received at ' || v_name || ' (' || p_condition || ')' when 'reject' then 'rejected — ' || p_note else 'recalled' end);
end $$;

-- While in transit, an asset can only be received, rejected or recalled.
create or replace function public.asset_transit_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.state = 'transit' and new.state is distinct from 'transit' and coalesce(current_setting('sika.transfer', true), '') <> 'on' then
    raise exception '% is in transit. Receive, reject or recall the transfer first.', old.tag;
  end if;
  return new;
end $$;
create trigger assets_transit_guard before update of state on public.assets for each row execute function public.asset_transit_guard();

-- ---------------------------------------------------------------- 4. Requests through the site, then head office
alter table public.asset_requests add column if not exists location_id uuid references public.asset_locations(id) on delete set null;
alter table public.asset_requests add column if not exists escalated boolean not null default false;
alter table public.asset_requests add column if not exists escalated_note text;
alter table public.asset_requests add column if not exists quantity int not null default 1 check (quantity > 0);

drop function if exists public.request_asset(uuid, text, uuid, uuid, uuid, date, date);
create or replace function public.request_asset(cid uuid, p_description text, p_asset uuid default null, p_category uuid default null, p_project uuid default null,
  p_from date default null, p_until date default null, p_location uuid default null, p_quantity int default 1)
returns uuid language plpgsql security definer set search_path = public as $$
declare v uuid; v_emp uuid; n text; v_mgr uuid; v_who text;
begin
  perform require_member(cid);
  if coalesce(trim(p_description), '') = '' and p_asset is null then raise exception 'Say what you need'; end if;
  if p_asset is not null and not exists (select 1 from assets where id = p_asset and company_id = cid and requestable and status = 'active') then raise exception 'That asset cannot be requested'; end if;
  if p_until is not null and p_until < coalesce(p_from, current_date) then raise exception 'The return date is before the start date'; end if;
  select id into v_emp from employees where company_id = cid and user_id = auth.uid() limit 1;
  select manager_id into v_mgr from asset_locations where id = p_location and company_id = cid;
  n := next_number(cid, 'ARQ', 'ARQ-');
  insert into asset_requests (company_id, number, asset_id, category_id, description, employee_id, project_id, needed_from, needed_until, location_id, quantity)
  values (cid, n, p_asset, p_category, coalesce(nullif(trim(p_description), ''), (select tag || ' ' || name from assets where id = p_asset)), v_emp, p_project,
          coalesce(p_from, current_date), p_until, p_location, greatest(coalesce(p_quantity, 1), 1))
  returning id into v;
  v_who := (select email from memberships where company_id = cid and user_id = auth.uid());
  if v_mgr is not null and v_mgr <> auth.uid() then
    perform notify_users(cid, array[v_mgr], 'asset_requested', n || ': ' || coalesce(nullif(trim(p_description), ''), 'asset requested'), v_who, '/assets/requests', false);
  else
    perform notify(cid, array['store'], null, 'asset_requested', n || ': ' || coalesce(nullif(trim(p_description), ''), 'asset requested'), v_who, '/assets/requests');
  end if;
  perform send_telegram(cid, 'request', '📝 ' || n || ': ' || coalesce(nullif(trim(p_description), ''), 'asset requested') || ' — ' || coalesce(split_part(v_who, '@', 1), '')
    || coalesce(' · ' || (select name from asset_locations where id = p_location), '') || ' · needed ' || to_char(coalesce(p_from, current_date), 'DD Mon') || coalesce(' to ' || to_char(p_until, 'DD Mon'), ''));
  return v;
end $$;

create or replace function public.decide_asset_request(p_id uuid, p_approve boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r asset_requests;
begin
  select * into r from asset_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if r.requested_by = auth.uid() and not p_approve and not asset_manager(r.company_id) then
    if r.status not in ('pending','approved') then raise exception 'Already %', r.status; end if;
    update asset_requests set status = 'cancelled' where id = p_id; return;
  end if;
  if not (asset_manager(r.company_id) or (not r.escalated and location_manager(r.location_id))) then
    raise exception 'Only the site manager (or, once passed on, head office) can decide this request';
  end if;
  if r.requested_by = auth.uid() then raise exception 'You cannot approve your own request'; end if;
  if r.status <> 'pending' then raise exception 'Already %', r.status; end if;
  update asset_requests set status = case when p_approve then 'approved' else 'rejected' end, decided_by = auth.uid(), decided_on = current_date, decision_note = p_note where id = p_id;
  perform notify_users(r.company_id, array[r.requested_by], 'asset_request_decided', r.number || ' ' || case when p_approve then 'approved' else 'declined' end, p_note, '/assets/requests', true);
  perform send_telegram(r.company_id, 'decision', case when p_approve then '👍 ' else '👎 ' end || r.number || ' ' || case when p_approve then 'approved' else 'declined' end || ': ' || r.description || coalesce(' — ' || p_note, ''));
end $$;

-- The site manager passes a request on to head office (the storekeeper and Finance).
create or replace function public.escalate_asset_request(p_id uuid, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare r asset_requests;
begin
  select * into r from asset_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if not (location_manager(r.location_id) or asset_manager(r.company_id)) then raise exception 'Only the site manager can pass a request on'; end if;
  if r.status <> 'pending' or r.escalated then raise exception 'This request has already been passed on or decided'; end if;
  update asset_requests set escalated = true, escalated_note = p_note where id = p_id;
  perform notify(r.company_id, array['store'], null, 'asset_requested', r.number || ' passed to head office: ' || r.description, p_note, '/assets/requests');
  perform send_telegram(r.company_id, 'request', '⬆️ ' || r.number || ' passed to head office: ' || r.description || coalesce(' — ' || p_note, ''));
end $$;

drop policy if exists "requests read" on public.asset_requests;
create policy "requests read" on public.asset_requests for select using (requested_by = auth.uid() or asset_manager(company_id) or has_role(company_id, array['project_manager','hr']) or location_manager(location_id));

-- ---------------------------------------------------------------- 5. Accessories, components and consumables
create table public.asset_items (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  kind text not null check (kind in ('accessory','component','consumable')),
  name text not null,
  category text,
  manufacturer text,
  model_no text,
  unit text not null default 'each',
  min_qty numeric(12,2) not null default 0,
  unit_cost numeric(14,2),
  requestable boolean not null default false,
  notes text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.asset_item_stock (
  item_id uuid not null references public.asset_items(id) on delete cascade,
  location_id uuid not null references public.asset_locations(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete cascade,
  qty numeric(12,2) not null default 0 check (qty >= 0),
  primary key (item_id, location_id)
);
create table public.asset_item_moves (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  item_id uuid not null references public.asset_items(id) on delete cascade,
  kind text not null check (kind in ('receive','checkout','checkin','consume','transfer','adjust')),
  location_id uuid references public.asset_locations(id),
  to_location_id uuid references public.asset_locations(id),
  qty numeric(12,2) not null,
  employee_id uuid references public.employees(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  unit_cost numeric(14,2),
  note text,
  moved_by uuid default auth.uid(),
  moved_at timestamptz not null default now()
);
create index on public.asset_item_moves (item_id, moved_at desc);
create table public.asset_item_checkouts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  item_id uuid not null references public.asset_items(id) on delete cascade,
  location_id uuid not null references public.asset_locations(id),
  employee_id uuid references public.employees(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  qty numeric(12,2) not null check (qty > 0),
  returned_qty numeric(12,2) not null default 0,
  out_at timestamptz not null default now(),
  expected_return date,
  status text not null default 'out' check (status in ('out','returned')),
  note text
);

create or replace function public.item_total(p_item uuid) returns numeric
language sql stable security definer set search_path = public as $$ select coalesce(sum(qty), 0) from asset_item_stock where item_id = p_item; $$;

create or replace function public.item_stock_change(p_item uuid, p_location uuid, p_delta numeric) returns void
language plpgsql security definer set search_path = public as $$
declare i asset_items; v_have numeric;
begin
  select * into i from asset_items where id = p_item;
  insert into asset_item_stock (item_id, location_id, company_id, qty) values (p_item, p_location, i.company_id, 0) on conflict do nothing;
  select qty into v_have from asset_item_stock where item_id = p_item and location_id = p_location for update;
  if v_have + p_delta < 0 then raise exception 'Only % % of % at %', v_have, i.unit, i.name, (select name from asset_locations where id = p_location); end if;
  update asset_item_stock set qty = qty + p_delta where item_id = p_item and location_id = p_location;
  if p_delta < 0 and i.min_qty > 0 and item_total(p_item) < i.min_qty and item_total(p_item) - p_delta >= i.min_qty then
    perform notify(i.company_id, array['store'], null, 'low_stock', 'Low stock: ' || i.name, item_total(p_item) || ' ' || i.unit || ' left (minimum ' || i.min_qty || ')', '/assets/items', true);
    perform send_telegram(i.company_id, 'low_stock', '⚠️ Low stock: ' || i.name || ' — ' || item_total(p_item) || ' ' || i.unit || ' left (minimum ' || i.min_qty || ')');
  end if;
end $$;
revoke execute on function public.item_stock_change(uuid, uuid, numeric) from public, anon, authenticated;

-- Receive, issue, return, consume, transfer or adjust.
create or replace function public.item_move(p_item uuid, p_kind text, p_location uuid, p_qty numeric, p_to uuid default null, p_employee uuid default null,
  p_asset uuid default null, p_project uuid default null, p_unit_cost numeric default null, p_note text default null, p_checkout uuid default null, p_expected date default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare i asset_items; c asset_item_checkouts; v uuid;
begin
  select * into i from asset_items where id = p_item;
  if not found then raise exception 'Item not found'; end if;
  if not (asset_manager(i.company_id) or location_manager(p_location)) then raise exception 'Only the storekeeper or the location manager can move stock'; end if;
  if p_kind <> 'adjust' and coalesce(p_qty, 0) <= 0 then raise exception 'Enter a quantity'; end if;
  if p_kind = 'receive' then perform item_stock_change(p_item, p_location, p_qty);
    if p_unit_cost is not null then update asset_items set unit_cost = p_unit_cost where id = p_item; end if;
  elsif p_kind = 'consume' then perform item_stock_change(p_item, p_location, -p_qty);
  elsif p_kind = 'checkout' then
    if i.kind = 'consumable' then raise exception 'Consumables are used up, not checked out'; end if;
    if p_employee is null and p_asset is null then raise exception 'Check it out to a person or into an asset'; end if;
    perform item_stock_change(p_item, p_location, -p_qty);
    insert into asset_item_checkouts (company_id, item_id, location_id, employee_id, asset_id, qty, expected_return, note)
    values (i.company_id, p_item, p_location, p_employee, p_asset, p_qty, p_expected, p_note);
  elsif p_kind = 'checkin' then
    select * into c from asset_item_checkouts where id = p_checkout and item_id = p_item for update;
    if not found or c.status <> 'out' then raise exception 'Choose what is being returned'; end if;
    if p_qty > c.qty - c.returned_qty then raise exception 'Only % are out', c.qty - c.returned_qty; end if;
    perform item_stock_change(p_item, p_location, p_qty);
    update asset_item_checkouts set returned_qty = returned_qty + p_qty, status = case when returned_qty + p_qty >= qty then 'returned' else 'out' end where id = c.id;
    p_employee := c.employee_id; p_asset := c.asset_id;
  elsif p_kind = 'transfer' then
    if p_to is null or p_to = p_location then raise exception 'Choose where it is going'; end if;
    perform item_stock_change(p_item, p_location, -p_qty);
    perform item_stock_change(p_item, p_to, p_qty);
  elsif p_kind = 'adjust' then
    if coalesce(trim(p_note), '') = '' then raise exception 'Give a reason for the adjustment'; end if;
    perform item_stock_change(p_item, p_location, p_qty);
  else raise exception 'Unknown movement %', p_kind;
  end if;
  insert into asset_item_moves (company_id, item_id, kind, location_id, to_location_id, qty, employee_id, asset_id, project_id, unit_cost, note)
  values (i.company_id, p_item, p_kind, p_location, p_to, p_qty, p_employee, p_asset, p_project, coalesce(p_unit_cost, i.unit_cost), p_note) returning id into v;
  return v;
end $$;

-- ---------------------------------------------------------------- 6. Software licences
create table public.software_licences (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  manufacturer text,
  product_key text,
  seats int not null default 1 check (seats > 0),
  licensed_to_name text,
  licensed_to_email text,
  purchase_date date,
  cost numeric(14,2),
  expires_on date,
  order_number text,
  supplier_id uuid references public.suppliers(id) on delete set null,
  reassignable boolean not null default true,
  notes text,
  reminded_on date,
  created_at timestamptz not null default now()
);
create table public.licence_seats (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  licence_id uuid not null references public.software_licences(id) on delete cascade,
  employee_id uuid references public.employees(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  assigned_at timestamptz not null default now(),
  released_at timestamptz,
  note text,
  check (employee_id is not null or asset_id is not null)
);
create or replace function public.licence_seat_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare l software_licences; v_used int;
begin
  select * into l from software_licences where id = coalesce(new.licence_id, old.licence_id);
  if not asset_manager(l.company_id) then raise exception 'Only the storekeeper, Finance or an admin can assign licences'; end if;
  if tg_op = 'INSERT' then
    new.company_id := l.company_id;
    select count(*) into v_used from licence_seats where licence_id = l.id and released_at is null;
    if v_used >= l.seats then raise exception 'All % seats of % are in use. Free one first.', l.seats, l.name; end if;
  elsif tg_op = 'UPDATE' and old.released_at is null and new.released_at is not null and not l.reassignable then
    raise exception '% seats cannot be reassigned', l.name;
  end if;
  return coalesce(new, old);
end $$;
create trigger licence_seats_guard before insert or update or delete on public.licence_seats for each row execute function public.licence_seat_guard();

-- ---------------------------------------------------------------- 7. Fleet: vehicles, documents, drivers
create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  asset_id uuid references public.assets(id) on delete set null,
  reg_no text not null,
  make text, model text, year int,
  vehicle_type text not null default 'pickup' check (vehicle_type in ('car','pickup','van','truck','bus','motorbike','plant','crane','trailer','other')),
  fuel_type text not null default 'diesel' check (fuel_type in ('diesel','petrol','lpg','electric','hybrid')),
  chassis_no text, engine_no text, colour text,
  capacity_kg numeric(10,1), seats int,
  odometer numeric(10,0) not null default 0 check (odometer >= 0),
  tank_litres numeric(8,1),
  expected_km_per_l numeric(6,2),
  service_interval_km int,
  service_interval_months int,
  last_service_km numeric(10,0),
  last_service_date date,
  driver_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  location_id uuid references public.asset_locations(id) on delete set null,
  status text not null default 'available' check (status in ('available','in_use','maintenance','off_road','disposed')),
  notes text,
  created_at timestamptz not null default now(),
  unique (company_id, reg_no)
);
create table public.vehicle_documents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  kind text not null check (kind in ('roadworthy','insurance','road_use','registration','permit','tracker','other')),
  reference text,
  provider text,
  issued_on date,
  expires_on date,
  cost numeric(14,2),
  storage_path text,
  reminded_for date,
  created_at timestamptz not null default now()
);
create table public.drivers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  licence_no text,
  licence_class text,
  licence_expiry date,
  defensive_training_on date,
  medical_expiry date,
  active boolean not null default true,
  notes text,
  reminded_for date,
  unique (company_id, employee_id)
);

-- ---------------------------------------------------------------- 8. Trips, fuel, service, requests
create table public.vehicle_requests (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  requested_by uuid not null default auth.uid(),
  employee_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  purpose text not null,
  origin text, destination text,
  from_at timestamptz not null, to_at timestamptz not null,
  passengers int, load_desc text,
  vehicle_type text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled','done')),
  vehicle_id uuid references public.vehicles(id) on delete set null,
  driver_id uuid references public.employees(id) on delete set null,
  decided_by uuid, decided_at timestamptz, decision_note text,
  created_at timestamptz not null default now(),
  check (to_at > from_at)
);
create table public.vehicle_trips (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  driver_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  request_id uuid references public.vehicle_requests(id) on delete set null,
  purpose text not null,
  origin text, destination text,
  start_at timestamptz, end_at timestamptz,
  odometer_start numeric(10,0), odometer_end numeric(10,0),
  distance_km numeric(10,0) generated always as (odometer_end - odometer_start) stored,
  passengers int, load_desc text,
  status text not null default 'planned' check (status in ('planned','in_progress','completed','cancelled')),
  out_of_hours boolean not null default false,
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.vehicle_trips (vehicle_id, start_at desc);
create table public.vehicle_fuel (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  filled_on date not null default current_date,
  litres numeric(10,2) not null check (litres > 0),
  cost numeric(14,2) not null default 0 check (cost >= 0),
  odometer numeric(10,0),
  full_tank boolean not null default true,
  station text,
  paid_by text not null default 'cash' check (paid_by in ('cash','fuel_card','account','advance','petty_cash','other')),
  driver_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  receipt_path text,
  km_per_l numeric(8,2),
  flagged boolean not null default false,
  esg_entry_id uuid,
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.vehicle_fuel (vehicle_id, filled_on desc);
create table public.vehicle_services (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  number text,
  service_date date not null default current_date,
  odometer numeric(10,0),
  kind text not null default 'service' check (kind in ('service','repair','tyres','battery','inspection','accident','bodywork','other')),
  description text not null,
  vendor text,
  cost numeric(14,2) not null default 0 check (cost >= 0),
  parts text,
  downtime_days numeric(6,1),
  next_due_km numeric(10,0),
  next_due_date date,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create or replace function public.fleet_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare cid uuid := coalesce(new.company_id, old.company_id);
begin
  if tg_table_name = 'vehicle_requests' then
    if tg_op = 'INSERT' then
      if not is_member(new.company_id) then raise exception 'You do not have access to this company'; end if;
      new.number := next_number(new.company_id, 'VRQ', 'VRQ-'); new.status := 'pending'; new.requested_by := auth.uid();
      new.employee_id := coalesce(new.employee_id, (select id from employees where company_id = new.company_id and user_id = auth.uid() limit 1));
    elsif coalesce(current_setting('sika.fleet', true), '') <> 'on' and (new.status, new.vehicle_id) is distinct from (old.status, old.vehicle_id) then
      raise exception 'Use Approve, Decline or Cancel';
    end if;
    return new;
  end if;
  if tg_table_name = 'vehicle_trips' and tg_op = 'INSERT' then
    new.number := next_number(new.company_id, 'TRP', 'TRP-');
    if not (is_transport(new.company_id) or exists (select 1 from employees where id = new.driver_id and user_id = auth.uid())) then
      raise exception 'Only the transport officer or the trip''s driver can log a trip';
    end if;
    return new;
  end if;
  if tg_table_name = 'vehicle_services' and tg_op = 'INSERT' then new.number := next_number(new.company_id, 'JOB', 'JOB-'); end if;
  if tg_table_name in ('vehicles','vehicle_documents','drivers','vehicle_services') and coalesce(current_setting('sika.fleet', true), '') <> 'on' and not is_transport(cid) then
    raise exception 'Only the transport officer, storekeeper, Finance or an admin can change fleet records';
  end if;
  return coalesce(new, old);
end $$;
create trigger vehicles_guard before insert or update or delete on public.vehicles for each row execute function public.fleet_defaults();
create trigger vehicle_documents_guard before insert or update or delete on public.vehicle_documents for each row execute function public.fleet_defaults();
create trigger drivers_guard before insert or update or delete on public.drivers for each row execute function public.fleet_defaults();
create trigger vehicle_services_guard before insert or update or delete on public.vehicle_services for each row execute function public.fleet_defaults();
create trigger vehicle_requests_defaults before insert or update on public.vehicle_requests for each row execute function public.fleet_defaults();
create trigger vehicle_trips_defaults before insert on public.vehicle_trips for each row execute function public.fleet_defaults();

-- A service updates the vehicle's last service.
create or replace function public.vehicle_service_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform set_config('sika.fleet', 'on', true);
  update vehicles set last_service_km = case when new.kind = 'service' then coalesce(new.odometer, last_service_km) else last_service_km end,
    last_service_date = case when new.kind = 'service' then new.service_date else last_service_date end,
    odometer = greatest(odometer, coalesce(new.odometer, 0))
  where id = new.vehicle_id;
  perform set_config('sika.fleet', 'off', true);
  return null;
end $$;
create trigger vehicle_services_after after insert on public.vehicle_services for each row execute function public.vehicle_service_after();

create or replace function public.decide_vehicle_request(p_id uuid, p_action text, p_vehicle uuid default null, p_driver uuid default null, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare r vehicle_requests; v vehicles; v_clash text;
begin
  select * into r from vehicle_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if p_action = 'cancel' then
    if not (r.requested_by = auth.uid() or is_transport(r.company_id)) then raise exception 'Only the requester can cancel'; end if;
    if r.status not in ('pending','approved') then raise exception 'Already %', r.status; end if;
  else
    if not is_transport(r.company_id) then raise exception 'Only the transport officer allocates vehicles'; end if;
    if r.status <> 'pending' then raise exception 'Already %', r.status; end if;
    if p_action = 'approve' then
      select * into v from vehicles where id = p_vehicle and company_id = r.company_id;
      if not found then raise exception 'Choose a vehicle'; end if;
      if v.status in ('maintenance','off_road','disposed') then raise exception '% is %', v.reg_no, replace(v.status, '_', ' '); end if;
      select q.number into v_clash from vehicle_requests q where q.vehicle_id = p_vehicle and q.status = 'approved' and q.id <> r.id and tstzrange(q.from_at, q.to_at) && tstzrange(r.from_at, r.to_at) limit 1;
      if v_clash is not null then raise exception '% is already booked then (%)', v.reg_no, v_clash; end if;
    elsif p_action = 'reject' and coalesce(trim(p_note), '') = '' then raise exception 'Give a reason';
    end if;
  end if;
  perform set_config('sika.fleet', 'on', true);
  update vehicle_requests set status = case p_action when 'approve' then 'approved' when 'reject' then 'rejected' else 'cancelled' end,
    vehicle_id = case when p_action = 'approve' then p_vehicle else vehicle_id end, driver_id = case when p_action = 'approve' then coalesce(p_driver, (select driver_id from vehicles where id = p_vehicle)) else driver_id end,
    decided_by = auth.uid(), decided_at = now(), decision_note = p_note where id = p_id;
  perform set_config('sika.fleet', 'off', true);
  if p_action <> 'cancel' then
    perform notify_users(r.company_id, array[r.requested_by, (select user_id from employees where id = coalesce(p_driver, (select driver_id from vehicles where id = p_vehicle)))],
      'vehicle_request', r.number || case when p_action = 'approve' then ': ' || (select reg_no from vehicles where id = p_vehicle) || ' allocated' else ' declined' end, p_note, '/fleet/requests', false);
    perform send_telegram(r.company_id, 'decision', '🚗 ' || r.number || case when p_action = 'approve' then ' — ' || (select reg_no from vehicles where id = p_vehicle) || ' allocated for ' || r.purpose else ' declined: ' || p_note end);
  end if;
end $$;

create or replace function public.vehicle_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform notify_users(new.company_id, transport_users(new.company_id), 'vehicle_request', new.number || ': vehicle needed — ' || new.purpose,
    to_char(new.from_at, 'DD Mon HH24:MI') || ' to ' || to_char(new.to_at, 'DD Mon HH24:MI') || coalesce(' · ' || new.destination, ''), '/fleet/requests', false);
  perform send_telegram(new.company_id, 'request', '🚗 ' || new.number || ': vehicle needed — ' || new.purpose || ' · ' || to_char(new.from_at, 'DD Mon HH24:MI') || coalesce(' to ' || new.destination, ''));
  return null;
end $$;
create trigger vehicle_requests_notice after insert on public.vehicle_requests for each row execute function public.vehicle_request_notice();

-- Start and finish trips: mileage only goes forward; the vehicle is shown in use.
create or replace function public.trip_step(p_trip uuid, p_action text, p_odometer numeric default null, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare t vehicle_trips; v vehicles;
begin
  select * into t from vehicle_trips where id = p_trip for update;
  if not found then raise exception 'Trip not found'; end if;
  if not (is_transport(t.company_id) or exists (select 1 from employees where id = t.driver_id and user_id = auth.uid())) then raise exception 'Only the driver or the transport officer can update this trip'; end if;
  select * into v from vehicles where id = t.vehicle_id for update;
  perform set_config('sika.fleet', 'on', true);
  if p_action = 'start' then
    if t.status <> 'planned' then raise exception 'This trip has already started'; end if;
    if p_odometer is null then raise exception 'Enter the mileage at the start'; end if;
    if p_odometer < v.odometer then raise exception 'The mileage cannot be less than the last reading (% km)', v.odometer; end if;
    if v.status in ('in_use') and exists (select 1 from vehicle_trips where vehicle_id = v.id and status = 'in_progress') then raise exception '% is already on a trip', v.reg_no; end if;
    update vehicle_trips set status = 'in_progress', start_at = coalesce(start_at, now()), odometer_start = p_odometer,
      out_of_hours = extract(isodow from now()) > 5 or extract(hour from now()) not between 6 and 18 where id = t.id;
    update vehicles set status = 'in_use', odometer = p_odometer where id = v.id;
  elsif p_action = 'finish' then
    if t.status <> 'in_progress' then raise exception 'Start the trip first'; end if;
    if p_odometer is null or p_odometer < t.odometer_start then raise exception 'The mileage at the end must be at least % km', t.odometer_start; end if;
    if p_odometer - t.odometer_start > 2000 then raise exception 'That is more than 2,000 km in one trip. Check the reading.'; end if;
    update vehicle_trips set status = 'completed', end_at = now(), odometer_end = p_odometer, note = coalesce(p_note, note) where id = t.id;
    update vehicles set status = 'available', odometer = greatest(odometer, p_odometer) where id = v.id;
    if t.request_id is not null then update vehicle_requests set status = 'done' where id = t.request_id; end if;
  elsif p_action = 'cancel' then
    if t.status = 'completed' then raise exception 'A completed trip cannot be cancelled'; end if;
    update vehicle_trips set status = 'cancelled', note = coalesce(p_note, note) where id = t.id;
    if t.status = 'in_progress' then update vehicles set status = 'available' where id = v.id; end if;
  else raise exception 'Unknown action %', p_action;
  end if;
  perform set_config('sika.fleet', 'off', true);
end $$;

-- Fuel: km per litre between full tanks; low economy is flagged; the litres also go to the sustainability figures.
create or replace function public.vehicle_fuel_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare v vehicles; p vehicle_fuel; v_litres numeric; v_factor uuid; v_esg uuid;
begin
  select * into v from vehicles where id = new.vehicle_id;
  new.company_id := v.company_id;
  if not (is_transport(v.company_id) or v.driver_id in (select my_employee_ids()) or exists (select 1 from vehicle_trips t where t.vehicle_id = v.id and t.status = 'in_progress' and t.driver_id in (select my_employee_ids()))) then
    raise exception 'Only the vehicle''s driver or the transport officer can log fuel';
  end if;
  if new.odometer is not null and new.odometer < (select coalesce(max(odometer), 0) from vehicle_fuel where vehicle_id = v.id and filled_on <= new.filled_on) then
    raise exception 'The mileage is lower than at the previous fill';
  end if;
  new.driver_id := coalesce(new.driver_id, v.driver_id); new.project_id := coalesce(new.project_id, v.project_id);
  if new.full_tank and new.odometer is not null then
    select * into p from vehicle_fuel where vehicle_id = v.id and full_tank and odometer is not null and odometer < new.odometer order by odometer desc limit 1;
    if found then
      select coalesce(sum(litres), 0) into v_litres from vehicle_fuel where vehicle_id = v.id and odometer > p.odometer and odometer < new.odometer;
      new.km_per_l := round((new.odometer - p.odometer) / nullif(v_litres + new.litres, 0), 2);
      new.flagged := v.expected_km_per_l is not null and new.km_per_l < v.expected_km_per_l * 0.8;
    end if;
  end if;
  -- Sustainability (scope 1): diesel or petrol litres.
  select id into v_factor from esg_factors where company_id = v.company_id and key = case v.fuel_type when 'petrol' then 'petrol_l' when 'lpg' then 'lpg_l' else 'diesel_l' end and active;
  if v_factor is not null and v.fuel_type in ('diesel','petrol','lpg') then
    perform set_config('sika.hse', 'on', true);
    insert into esg_entries (company_id, period, factor_id, quantity, factor_used, kg_co2e, project_id, source_ref, note)
    select v.company_id, date_trunc('month', new.filled_on)::date, f.id, new.litres, f.kg_co2e, round(new.litres * f.kg_co2e, 3), new.project_id, 'Fuel log ' || v.reg_no, new.station
    from esg_factors f where f.id = v_factor returning id into v_esg;
    new.esg_entry_id := v_esg;
  end if;
  perform set_config('sika.fleet', 'on', true);
  update vehicles set odometer = greatest(odometer, coalesce(new.odometer, 0)) where id = v.id;
  perform set_config('sika.fleet', 'off', true);
  return new;
end $$;
create trigger vehicle_fuel_defaults before insert on public.vehicle_fuel for each row execute function public.vehicle_fuel_defaults();
create or replace function public.vehicle_fuel_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare v vehicles;
begin
  if new.flagged then
    select * into v from vehicles where id = new.vehicle_id;
    perform notify_users(new.company_id, transport_users(new.company_id), 'fuel_flag', 'Fuel use high: ' || v.reg_no, new.km_per_l || ' km/l against ' || v.expected_km_per_l || ' expected. Check for leaks, misuse or a wrong reading.', '/fleet/fuel', true);
    perform send_telegram(new.company_id, 'fleet', '⛽ Fuel use high on ' || v.reg_no || ': ' || new.km_per_l || ' km/l (expected ' || v.expected_km_per_l || ')');
  end if;
  return null;
end $$;
create trigger vehicle_fuel_notice after insert on public.vehicle_fuel for each row execute function public.vehicle_fuel_notice();

-- Sustainability entries made from the fuel log are allowed without the HSE checks.
create or replace function public.esg_entry_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare f esg_factors;
begin
  if coalesce(current_setting('sika.hse', true), '') <> 'on' and not (is_hse(new.company_id) or has_role(new.company_id, array['accountant','store','project_manager'])) then
    raise exception 'Only an HSE officer, Finance, the storekeeper or a project manager can record sustainability data';
  end if;
  select * into f from esg_factors where id = new.factor_id;
  if f.company_id is distinct from new.company_id then raise exception 'Choose one of your own emission factors'; end if;
  new.period := date_trunc('month', new.period)::date;
  if tg_op = 'INSERT' or new.factor_id is distinct from old.factor_id or new.quantity is distinct from old.quantity then
    new.factor_used := f.kg_co2e;
    new.kg_co2e := round(new.quantity * f.kg_co2e, 3);
  end if;
  return new;
end $$;

-- ---------------------------------------------------------------- 9. Waybills (deliveries and collections, own or hired transport)
create table public.waybills (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  kind text not null default 'delivery' check (kind in ('delivery','collection','transfer','return')),
  transport text not null default 'own' check (transport in ('own','hired','courier')),
  vehicle_id uuid references public.vehicles(id) on delete set null,
  driver_id uuid references public.employees(id) on delete set null,
  transporter_id uuid references public.suppliers(id) on delete set null,
  truck_reg text, driver_name text, driver_phone text,
  project_id uuid references public.projects(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null,
  from_place text not null,
  to_place text not null,
  contact_name text, contact_phone text,
  planned_on date not null default current_date,
  dispatched_at timestamptz, expected_at timestamptz, delivered_at timestamptz,
  status text not null default 'draft' check (status in ('draft','dispatched','delivered','partial','cancelled')),
  received_by_name text,
  pod_path text,
  pod_note text,
  transport_cost numeric(14,2) not null default 0 check (transport_cost >= 0),
  po_id uuid,
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create table public.waybill_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  waybill_id uuid not null references public.waybills(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  description text not null,
  qty numeric(12,2) not null check (qty > 0),
  unit text,
  weight_kg numeric(10,1),
  delivered_qty numeric(12,2),
  note text,
  sort int not null default 0
);
create or replace function public.waybill_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if not (is_transport(new.company_id) or has_role(new.company_id, array['project_manager','sales'])) then raise exception 'Only the transport officer, storekeeper, Finance or a project manager can raise waybills'; end if;
    new.number := next_number(new.company_id, 'WB', 'WB-'); new.status := 'draft';
  elsif coalesce(current_setting('sika.fleet', true), '') <> 'on' then
    if new.status is distinct from old.status then raise exception 'Use Dispatch, Delivered or Cancel'; end if;
    if old.status <> 'draft' and (new.from_place, new.to_place, new.vehicle_id, new.transport_cost) is distinct from (old.from_place, old.to_place, old.vehicle_id, old.transport_cost) and not is_transport(old.company_id) then
      raise exception 'A dispatched waybill can only be changed by the transport officer';
    end if;
    new.number := old.number;
  end if;
  return new;
end $$;
create trigger waybills_defaults before insert or update on public.waybills for each row execute function public.waybill_defaults();
create or replace function public.waybill_line_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare w waybills;
begin
  select * into w from waybills where id = coalesce(new.waybill_id, old.waybill_id);
  if coalesce(current_setting('sika.fleet', true), '') <> 'on' and w.status <> 'draft' then raise exception 'The waybill has been dispatched; its lines are fixed'; end if;
  if tg_op <> 'DELETE' then new.company_id := w.company_id; end if;
  return coalesce(new, old);
end $$;
create trigger waybill_lines_guard before insert or update or delete on public.waybill_lines for each row execute function public.waybill_line_guard();

create or replace function public.waybill_step(p_id uuid, p_action text, p_received_by text default null, p_note text default null, p_lines jsonb default null, p_pod text default null) returns text
language plpgsql security definer set search_path = public as $$
declare w waybills; v_to text; v_short int; l record;
begin
  select * into w from waybills where id = p_id for update;
  if not found then raise exception 'Waybill not found'; end if;
  perform set_config('sika.fleet', 'on', true);
  if p_action = 'dispatch' then
    if not (is_transport(w.company_id) or has_role(w.company_id, array['project_manager'])) then raise exception 'Only the transport officer or project manager can dispatch'; end if;
    if w.status <> 'draft' then raise exception 'Already %', w.status; end if;
    if not exists (select 1 from waybill_lines where waybill_id = p_id) then raise exception 'Add what is being carried'; end if;
    if w.transport = 'own' and w.vehicle_id is null then raise exception 'Choose the vehicle'; end if;
    if w.transport <> 'own' and coalesce(trim(w.truck_reg), '') = '' and w.transporter_id is null then raise exception 'Enter the transporter or truck registration'; end if;
    update waybills set status = 'dispatched', dispatched_at = now() where id = p_id; v_to := 'dispatched';
    perform notify_users(w.company_id, array[(select user_id from employees where id = w.driver_id), (select manager_id from projects where id = w.project_id)], 'waybill', w.number || ' on its way to ' || w.to_place, null, '/fleet/waybills', false);
    perform send_telegram(w.company_id, 'fleet', '📦 ' || w.number || ' dispatched: ' || w.from_place || ' → ' || w.to_place || coalesce(' · ' || (select reg_no from vehicles where id = w.vehicle_id), coalesce(' · ' || w.truck_reg, '')));
  elsif p_action = 'deliver' then
    if w.status <> 'dispatched' then raise exception 'Dispatch it first'; end if;
    if not (is_transport(w.company_id) or has_role(w.company_id, array['project_manager']) or exists (select 1 from employees where id = w.driver_id and user_id = auth.uid())) then raise exception 'Only the driver, the site or the transport officer can confirm delivery'; end if;
    if coalesce(trim(p_received_by), '') = '' then raise exception 'Enter the name of the person who received the goods'; end if;
    if p_lines is not null then
      for l in select (x->>'id')::uuid id, (x->>'delivered_qty')::numeric q from jsonb_array_elements(p_lines) x loop
        update waybill_lines set delivered_qty = l.q where id = l.id and waybill_id = p_id;
      end loop;
    end if;
    update waybill_lines set delivered_qty = coalesce(delivered_qty, qty) where waybill_id = p_id;
    select count(*) into v_short from waybill_lines where waybill_id = p_id and delivered_qty < qty;
    v_to := case when v_short > 0 then 'partial' else 'delivered' end;
    update waybills set status = v_to, delivered_at = now(), received_by_name = p_received_by, pod_note = p_note, pod_path = coalesce(p_pod, pod_path) where id = p_id;
    perform notify_users(w.company_id, transport_users(w.company_id) || array[w.created_by], 'waybill', w.number || ' ' || case when v_short > 0 then 'delivered short (' || v_short || ' line' || case when v_short = 1 then '' else 's' end || ')' else 'delivered' end || ' at ' || w.to_place, 'Received by ' || p_received_by, '/fleet/waybills', false);
    perform send_telegram(w.company_id, 'fleet', case when v_short > 0 then '⚠️ ' else '✅ ' end || w.number || ' ' || v_to || ' at ' || w.to_place || ' — received by ' || p_received_by);
  elsif p_action = 'cancel' then
    if not is_transport(w.company_id) then raise exception 'Only the transport officer can cancel'; end if;
    if w.status in ('delivered','partial') then raise exception 'A delivered waybill cannot be cancelled'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Give a reason'; end if;
    update waybills set status = 'cancelled', note = concat_ws(E'\n', note, 'Cancelled: ' || p_note) where id = p_id; v_to := 'cancelled';
  else raise exception 'Unknown action %', p_action;
  end if;
  perform set_config('sika.fleet', 'off', true);
  return v_to;
end $$;

-- ---------------------------------------------------------------- 10. Reports and reminders
create or replace function public.fleet_report(cid uuid, p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid);
  return jsonb_build_object(
    'vehicles', coalesce((select jsonb_agg(x order by x->>'reg_no') from (
      select jsonb_build_object('id', v.id, 'reg_no', v.reg_no, 'name', concat_ws(' ', v.make, v.model), 'type', v.vehicle_type, 'status', v.status, 'odometer', v.odometer,
        'km', coalesce((select sum(distance_km) from vehicle_trips t where t.vehicle_id = v.id and t.status = 'completed' and t.end_at::date between p_from and p_to), 0),
        'trips', (select count(*) from vehicle_trips t where t.vehicle_id = v.id and t.status = 'completed' and t.end_at::date between p_from and p_to),
        'litres', coalesce((select sum(litres) from vehicle_fuel f where f.vehicle_id = v.id and f.filled_on between p_from and p_to), 0),
        'fuel_cost', coalesce((select sum(cost) from vehicle_fuel f where f.vehicle_id = v.id and f.filled_on between p_from and p_to), 0),
        'service_cost', coalesce((select sum(cost) from vehicle_services s where s.vehicle_id = v.id and s.service_date between p_from and p_to), 0),
        'doc_cost', coalesce((select sum(cost) from vehicle_documents d where d.vehicle_id = v.id and d.issued_on between p_from and p_to), 0),
        'downtime', coalesce((select sum(downtime_days) from vehicle_services s where s.vehicle_id = v.id and s.service_date between p_from and p_to), 0),
        'km_per_l', (select round(avg(km_per_l), 2) from vehicle_fuel f where f.vehicle_id = v.id and f.km_per_l is not null and f.filled_on between p_from and p_to),
        'flags', (select count(*) from vehicle_fuel f where f.vehicle_id = v.id and f.flagged and f.filled_on between p_from and p_to),
        'service_due', case when v.service_interval_km is not null and v.odometer >= coalesce(v.last_service_km, 0) + v.service_interval_km - 500 then true
                            when v.service_interval_months is not null and coalesce(v.last_service_date, v.created_at::date) + make_interval(months => v.service_interval_months) <= current_date + 14 then true else false end) x
      from vehicles v where v.company_id = cid and v.status <> 'disposed') y), '[]'::jsonb),
    'projects', coalesce((select jsonb_agg(x) from (
      select jsonb_build_object('project_id', p.id, 'project', concat_ws(' ', p.number, p.name),
        'km', coalesce((select sum(distance_km) from vehicle_trips t where t.project_id = p.id and t.status = 'completed' and t.end_at::date between p_from and p_to), 0),
        'fuel_cost', coalesce((select sum(cost) from vehicle_fuel f where f.project_id = p.id and f.filled_on between p_from and p_to), 0),
        'waybills', (select count(*) from waybills w where w.project_id = p.id and w.planned_on between p_from and p_to and w.status <> 'cancelled'),
        'transport_cost', coalesce((select sum(transport_cost) from waybills w where w.project_id = p.id and w.planned_on between p_from and p_to and w.status <> 'cancelled'), 0)) x
      from projects p where p.company_id = cid and not p.is_template and (
        exists (select 1 from vehicle_trips t where t.project_id = p.id and t.end_at::date between p_from and p_to) or
        exists (select 1 from vehicle_fuel f where f.project_id = p.id and f.filled_on between p_from and p_to) or
        exists (select 1 from waybills w where w.project_id = p.id and w.planned_on between p_from and p_to))) y), '[]'::jsonb),
    'documents_due', coalesce((select jsonb_agg(jsonb_build_object('reg_no', v.reg_no, 'kind', d.kind, 'expires_on', d.expires_on) order by d.expires_on)
      from vehicle_documents d join vehicles v on v.id = d.vehicle_id where d.company_id = cid and v.status <> 'disposed' and d.expires_on <= current_date + 30
        and not exists (select 1 from vehicle_documents d2 where d2.vehicle_id = d.vehicle_id and d2.kind = d.kind and d2.expires_on > d.expires_on)), '[]'::jsonb),
    'licences_due', coalesce((select jsonb_agg(jsonb_build_object('name', e.full_name, 'licence_expiry', r.licence_expiry) order by r.licence_expiry)
      from drivers r join employees e on e.id = r.employee_id where r.company_id = cid and r.active and r.licence_expiry <= current_date + 30), '[]'::jsonb));
end $$;

create or replace function public.run_fleet_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  for r in select d.*, v.reg_no from vehicle_documents d join vehicles v on v.id = d.vehicle_id
            where v.status <> 'disposed' and d.expires_on is not null and d.expires_on <= current_date + 30
              and not exists (select 1 from vehicle_documents d2 where d2.vehicle_id = d.vehicle_id and d2.kind = d.kind and d2.expires_on > d.expires_on)
              and (d.reminded_for is null or (d.expires_on < current_date and d.reminded_for >= d.expires_on - 30 and d.reminded_for < d.expires_on) or (d.expires_on - current_date <= 7 and d.reminded_for > d.expires_on - 7)) is not false
              and coalesce(d.reminded_for, '1900-01-01') <> current_date loop
    if r.reminded_for is null or (r.expires_on < current_date and r.reminded_for < r.expires_on) or (r.expires_on - current_date <= 7 and r.reminded_for < r.expires_on - 7) then
      perform notify_users(r.company_id, transport_users(r.company_id), 'fleet_document', r.reg_no || ': ' || replace(r.kind, '_', ' ') || case when r.expires_on < current_date then ' has expired' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end, r.reference, '/fleet/vehicles', true);
      perform send_telegram(r.company_id, 'fleet', '📄 ' || r.reg_no || ': ' || replace(r.kind, '_', ' ') || case when r.expires_on < current_date then ' has EXPIRED' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end);
      update vehicle_documents set reminded_for = current_date where id = r.id; n := n + 1;
    end if;
  end loop;
  for r in select d.*, e.full_name, e.user_id from drivers d join employees e on e.id = d.employee_id
            where d.active and d.licence_expiry is not null and d.licence_expiry <= current_date + 30 and (d.reminded_for is null or d.reminded_for < d.licence_expiry - 30 or (d.licence_expiry < current_date and d.reminded_for < d.licence_expiry)) loop
    perform notify_users(r.company_id, transport_users(r.company_id) || array[r.user_id], 'driver_licence', r.full_name || '''s driving licence ' || case when r.licence_expiry < current_date then 'has expired' else 'expires ' || to_char(r.licence_expiry, 'DD Mon YYYY') end, null, '/fleet/drivers', true);
    update drivers set reminded_for = current_date where id = r.id; n := n + 1;
  end loop;
  for r in select l.* from software_licences l where l.expires_on is not null and l.expires_on <= current_date + 30 and (l.reminded_on is null or (l.expires_on < current_date and l.reminded_on < l.expires_on)) loop
    perform notify(r.company_id, array['store'], null, 'licence_expiry', 'Licence ' || r.name || case when r.expires_on < current_date then ' has expired' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end, null, '/assets/licences', true);
    update software_licences set reminded_on = current_date where id = r.id; n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_fleet_reminders() from public, anon, authenticated;

create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- New companies get a Head office location.
create or replace function public.company_seed_assets() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform set_config('sika.seed', 'on', true);
  insert into asset_locations (company_id, name, kind) values (new.id, 'Head office', 'head_office') on conflict do nothing;
  perform set_config('sika.seed', 'off', true);
  return null;
end $$;
create trigger companies_seed_assets after insert on public.companies for each row execute function public.company_seed_assets();

-- ---------------------------------------------------------------- 11. Security rules
do $$ declare t text; begin
  foreach t in array array['company_telegram','asset_locations','asset_transfers','asset_items','asset_item_stock','asset_item_moves','asset_item_checkouts',
                           'software_licences','licence_seats','vehicles','vehicle_documents','drivers','vehicle_requests','vehicle_trips','vehicle_fuel','vehicle_services','waybills','waybill_lines'] loop
    execute format('alter table public.%I enable row level security', t);
    if t <> 'company_telegram' then execute format('create policy "members read" on public.%I for select using (is_member(company_id))', t); end if;
  end loop;
end $$;
create policy "owners manage telegram" on public.company_telegram for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));
create policy "store edits asset details" on public.assets for update using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "locations write" on public.asset_locations for all using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "items write" on public.asset_items for all using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "licences write" on public.software_licences for all using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "seats write" on public.licence_seats for all using (asset_manager(company_id)) with check (is_member(company_id));
create policy "fleet write vehicles" on public.vehicles for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "fleet write documents" on public.vehicle_documents for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "fleet write drivers" on public.drivers for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "fleet write services" on public.vehicle_services for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "anyone requests a vehicle" on public.vehicle_requests for insert with check (is_member(company_id));
create policy "requests update" on public.vehicle_requests for update using (is_member(company_id));
create policy "trips insert" on public.vehicle_trips for insert with check (is_member(company_id));
create policy "trips edit" on public.vehicle_trips for update using (is_transport(company_id));
create policy "fuel insert" on public.vehicle_fuel for insert with check (true);
create policy "fuel delete" on public.vehicle_fuel for delete using (is_transport(company_id));
create policy "waybills insert" on public.waybills for insert with check (is_member(company_id));
create policy "waybills edit" on public.waybills for update using (is_member(company_id));
create policy "waybills delete drafts" on public.waybills for delete using (status = 'draft' and is_transport(company_id));
create policy "waybill lines" on public.waybill_lines for all using (is_member(company_id)) with check (true);

do $$ declare t text; begin
  foreach t in array array['asset_locations','asset_transfers','asset_items','asset_item_moves','software_licences','licence_seats','vehicles','vehicle_documents','drivers','vehicle_fuel','vehicle_services','waybills'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
  end loop;
end $$;
revoke execute on function public.transport_users(uuid) from public, anon, authenticated;

-- ================================================================ 0019_asnys_v3_1_1.sql
-- Asnys ERP v3.1.1 — Fleet reminders reach admins as well as transport officers
--   * Roadworthy, insurance, road use, permits and statutory inspections: reminders 30 days before, 7 days before,
--     and on expiry, then every 7 days while it stays expired. Sent to transport officers, the storekeeper,
--     owners and admins (and the vehicle's driver when it has expired).
--   * New document kind: statutory inspection (crane, lifting gear, pressure vessel, fire extinguishers on the vehicle).
--   * Each company can choose how many days ahead the first reminder goes (default 30).
--   * Drivers' licences and medicals are reminded the same way.
-- Run after 0018. Safe to run more than once.

alter table public.vehicle_documents drop constraint if exists vehicle_documents_kind_check;
alter table public.vehicle_documents add constraint vehicle_documents_kind_check
  check (kind in ('roadworthy','insurance','road_use','registration','permit','tracker','inspection','fire_extinguisher','other'));
alter table public.companies add column if not exists fleet_reminder_days int not null default 30 check (fleet_reminder_days between 1 and 120);
alter table public.drivers add column if not exists medical_reminded_for date;

-- Who hears about fleet papers: transport officers, the storekeeper, owners and admins.
create or replace function public.fleet_alert_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or role in ('store','owner','admin'));
$$;
revoke execute on function public.fleet_alert_users(uuid) from public, anon, authenticated;

-- One reminder per stage: first warning, final week, expiry, then weekly while expired.
create or replace function public.fleet_reminder_due(p_expires date, p_last date, p_lead int) returns boolean
language sql immutable as $$
  select p_expires is not null and p_expires <= current_date + p_lead and coalesce(p_last, '1900-01-01') < current_date and (
       p_last is null
    or p_last < p_expires - p_lead
    or (p_expires - current_date <= 7 and p_last < p_expires - 7)
    or (p_expires <= current_date and p_last < p_expires)
    or (p_expires < current_date and p_last <= current_date - 7));
$$;

create or replace function public.run_fleet_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; v_title text; v_kind text;
begin
  for r in select d.*, v.reg_no, v.driver_id as v_driver, c.fleet_reminder_days lead
             from vehicle_documents d join vehicles v on v.id = d.vehicle_id join companies c on c.id = d.company_id
            where v.status <> 'disposed' and d.expires_on is not null
              and not exists (select 1 from vehicle_documents d2 where d2.vehicle_id = d.vehicle_id and d2.kind = d.kind and d2.expires_on > d.expires_on)
              and fleet_reminder_due(d.expires_on, d.reminded_for, c.fleet_reminder_days) loop
    v_kind := case r.kind when 'roadworthy' then 'Roadworthy certificate' when 'insurance' then 'Insurance' when 'road_use' then 'Road use fee'
                          when 'inspection' then 'Statutory inspection' when 'fire_extinguisher' then 'Fire extinguisher service' else initcap(replace(r.kind, '_', ' ')) end;
    v_title := r.reg_no || ': ' || v_kind || case when r.expires_on < current_date then ' EXPIRED on ' || to_char(r.expires_on, 'DD Mon YYYY')
                                                  when r.expires_on = current_date then ' expires TODAY'
                                                  else ' due ' || to_char(r.expires_on, 'DD Mon YYYY') || ' (' || (r.expires_on - current_date) || ' days)' end;
    perform notify_users(r.company_id, fleet_alert_users(r.company_id)
      || case when r.expires_on <= current_date then array[(select user_id from employees where id = r.v_driver)] else '{}'::uuid[] end,
      'fleet_document', v_title, coalesce('Ref ' || r.reference, '') || case when r.expires_on < current_date then ' — do not use the vehicle on the road until renewed.' else '' end,
      '/fleet/vehicles/' || r.vehicle_id, true);
    perform send_telegram(r.company_id, 'fleet', case when r.expires_on <= current_date then '🚫 ' else '📄 ' end || v_title);
    update vehicle_documents set reminded_for = current_date where id = r.id; n := n + 1;
  end loop;

  for r in select d.*, e.full_name, e.user_id, c.fleet_reminder_days lead from drivers d join employees e on e.id = d.employee_id join companies c on c.id = d.company_id
            where d.active and fleet_reminder_due(d.licence_expiry, d.reminded_for, c.fleet_reminder_days) loop
    perform notify_users(r.company_id, fleet_alert_users(r.company_id) || array[r.user_id], 'driver_licence',
      r.full_name || '''s driving licence ' || case when r.licence_expiry < current_date then 'EXPIRED on ' || to_char(r.licence_expiry, 'DD Mon YYYY') else 'expires ' || to_char(r.licence_expiry, 'DD Mon YYYY') end,
      'Renew at DVLA.', '/fleet/drivers', true);
    perform send_telegram(r.company_id, 'fleet', '🪪 ' || r.full_name || '''s driving licence ' || case when r.licence_expiry < current_date then 'has EXPIRED' else 'expires ' || to_char(r.licence_expiry, 'DD Mon YYYY') end);
    update drivers set reminded_for = current_date where id = r.id; n := n + 1;
  end loop;

  for r in select d.*, e.full_name, e.user_id, c.fleet_reminder_days lead from drivers d join employees e on e.id = d.employee_id join companies c on c.id = d.company_id
            where d.active and fleet_reminder_due(d.medical_expiry, d.medical_reminded_for, c.fleet_reminder_days) loop
    perform notify_users(r.company_id, fleet_alert_users(r.company_id) || array[r.user_id], 'driver_licence',
      r.full_name || '''s driver medical ' || case when r.medical_expiry < current_date then 'has expired' else 'is due ' || to_char(r.medical_expiry, 'DD Mon YYYY') end, null, '/fleet/drivers', true);
    update drivers set medical_reminded_for = current_date where id = r.id; n := n + 1;
  end loop;

  for r in select l.* from software_licences l where l.expires_on is not null and l.expires_on <= current_date + 30 and (l.reminded_on is null or (l.expires_on < current_date and l.reminded_on < l.expires_on)) loop
    perform notify(r.company_id, array['store'], null, 'licence_expiry', 'Licence ' || r.name || case when r.expires_on < current_date then ' has expired' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end, null, '/assets/licences', true);
    update software_licences set reminded_on = current_date where id = r.id; n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_fleet_reminders() from public, anon, authenticated;

-- A renewed or corrected expiry date starts the reminders afresh.
create or replace function public.vehicle_document_reset() returns trigger
language plpgsql as $$
begin
  if new.expires_on is distinct from old.expires_on then new.reminded_for := null; end if;
  return new;
end $$;
drop trigger if exists vehicle_documents_reset on public.vehicle_documents;
create trigger vehicle_documents_reset before update on public.vehicle_documents for each row execute function public.vehicle_document_reset();

-- Owners or admins choose how far ahead the first reminder goes.
create or replace function public.set_fleet_reminder_days(cid uuid, p_days int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  if p_days not between 1 and 120 then raise exception 'Choose between 1 and 120 days'; end if;
  update companies set fleet_reminder_days = p_days where id = cid;
end $$;

-- ================================================================ 0020_asnys_v3_2.sql
-- Asnys ERP v3.2 — Approvals reach people on Telegram and by email; HR creates logins with temporary passwords
--   1. Every approval in the system raises a notification to the people who must decide, and tells the requester
--      the outcome. Flows that had no notification now have one: the approval chain (bills, payroll, purchase orders,
--      purchase requests and expense claims above the limits), site purchase requests, expense claims, timesheets,
--      training requests, document reviews and stock requests from sites.
--   2. Each person can connect their own Telegram (a private chat with the company's bot). Notifications go to
--      them personally, not to a group. Everyone chooses: all notifications, approvals only, or none.
--   3. Approval emails through Brevo's API (an API key and a verified sender address; no SMTP needed).
--   4. HR and admins can create logins with a temporary password and reset passwords (with the updated
--      invite-member function). People must choose their own password at first sign-in.
-- Telegram and email need the pg_net extension (Database → Extensions → pg_net). Without it, everything else
-- works and the in-app notifications are unchanged.
-- Run after 0019.

-- ---------------------------------------------------------------- 0. Sending through pg_net (skipped quietly when it is off)
create or replace function public.http_post_safe(p_url text, p_body jsonb, p_headers jsonb default '{"Content-Type":"application/json"}') returns bigint
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if to_regnamespace('net') is null then return null; end if;
  begin
    execute 'select net.http_post(url := $1, body := $2, headers := $3)' into v using p_url, p_body, p_headers;
  exception when others then return null;
  end;
  return v;
end $$;
revoke execute on function public.http_post_safe(text, jsonb, jsonb) from public, anon, authenticated;

-- ---------------------------------------------------------------- 1. Company settings
alter table public.company_telegram add column if not exists bot_username text;
alter table public.company_telegram add column if not exists personal boolean not null default true;   -- private messages to people who connect
alter table public.company_telegram add column if not exists app_url text not null default 'https://asnys-erp.pages.dev';
alter table public.company_telegram add column if not exists last_update_id bigint;
-- The group chat is now optional: "enabled" switches the group on; private messages only need the bot token.

create table if not exists public.company_email (
  company_id uuid primary key references public.companies(id) on delete cascade,
  provider text not null default 'brevo' check (provider in ('brevo')),
  api_key text,
  from_email text,
  from_name text,
  enabled boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.company_email enable row level security;
drop policy if exists "owners manage email" on public.company_email;
create policy "owners manage email" on public.company_email for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));

-- ---------------------------------------------------------------- 2. Each person's channels
create table if not exists public.user_channels (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null,
  telegram_chat_id text,
  telegram_username text,
  telegram_linked_at timestamptz,
  telegram_code text,
  telegram_code_at timestamptz,
  telegram_poll_id bigint,
  telegram_poll_at timestamptz,
  telegram_level text not null default 'all' check (telegram_level in ('all','approvals','off')),
  email_level text not null default 'approvals' check (email_level in ('all','approvals','off')),
  updated_at timestamptz not null default now(),
  primary key (company_id, user_id)
);
alter table public.user_channels enable row level security;
drop policy if exists "own channels" on public.user_channels;
create policy "own channels" on public.user_channels for select using (user_id = auth.uid() or has_role(company_id, array['owner','admin']));

create table if not exists public.message_log (
  id bigserial primary key,
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid,
  channel text not null check (channel in ('telegram','email')),
  notification_id uuid,
  title text,
  request_id bigint,
  status text not null default 'queued' check (status in ('queued','skipped')),
  note text,
  created_at timestamptz not null default now()
);
create index if not exists message_log_company on public.message_log (company_id, created_at desc);
alter table public.message_log enable row level security;
drop policy if exists "admins read log" on public.message_log;
create policy "admins read log" on public.message_log for select using (has_role(company_id, array['owner','admin']) or user_id = auth.uid());

-- My settings (and whether the company has Telegram and email set up), for the Notifications page.
create or replace function public.my_channels(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email;
begin
  perform require_member(cid);
  select * into uc from user_channels where company_id = cid and user_id = auth.uid();
  select * into t from company_telegram where company_id = cid;
  select * into e from company_email where company_id = cid;
  return jsonb_build_object(
    'telegram_ready', t.bot_token is not null and t.personal and t.bot_username is not null,
    'bot_username', t.bot_username,
    'email_ready', coalesce(e.enabled, false) and e.api_key is not null and e.from_email is not null,
    'pg_net', to_regnamespace('net') is not null,
    'telegram_linked', uc.telegram_chat_id is not null,
    'telegram_username', uc.telegram_username,
    'telegram_linked_at', uc.telegram_linked_at,
    'telegram_level', coalesce(uc.telegram_level, 'all'),
    'email_level', coalesce(uc.email_level, 'approvals'),
    'email', (select coalesce(m.email, u.email) from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid()));
end $$;

create or replace function public.set_my_channels(cid uuid, p_telegram_level text, p_email_level text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform require_member(cid);
  if p_telegram_level not in ('all','approvals','off') or p_email_level not in ('all','approvals','off') then raise exception 'Choose all, approvals or off'; end if;
  insert into user_channels (company_id, user_id, telegram_level, email_level) values (cid, auth.uid(), p_telegram_level, p_email_level)
  on conflict (company_id, user_id) do update set telegram_level = excluded.telegram_level, email_level = excluded.email_level, updated_at = now();
end $$;

-- ---------------------------------------------------------------- 3. Which notifications are approvals
-- Requests that wait for someone's decision, and the decisions that go back to the person who asked.
create or replace function public.is_approval_kind(p_kind text) returns boolean
language sql immutable as $$
  select p_kind = any(array[
      'approval_needed','approval_decided','request_submitted','request_decided','expense_submitted','expense_decided',
      'time_submitted','time_decided','training_request','training_decided','doc_review','doc_reviewed','stock_request',
      'leave_request','leave_decided','hr_profile_change','hr_profile_decided','asset_requested','asset_request_decided',
      'asset_transfer','vehicle_request','spend_request','spend_request_done','budget.submitted','budget.decided',
      'progress.submitted','retirement_submitted','retirement_returned','variation_proposed','variation_decided',
      'tender.review','project.registered','hse_permit','hse_action_done','hse_investigate','petty_count_difference'])
    or p_kind like 'spend_request\_%' or p_kind like 'asset_transfer\_%' or p_kind like 'hse_permit\_%';
$$;

-- ---------------------------------------------------------------- 4. Delivery: every new notification goes to Telegram and email as each person chose
create or replace function public.tg_escape(t text) returns text language sql immutable as $$
  select replace(replace(replace(coalesce(t, ''), '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
$$;

create or replace function public.deliver_notification() returns trigger
language plpgsql security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email; v_appr boolean; v_url text; v_email text; v_req bigint; v_text text;
begin
  begin
    select * into t from company_telegram where company_id = new.company_id;
    select * into e from company_email where company_id = new.company_id;
    if t.company_id is null and e.company_id is null then return null; end if;
    select * into uc from user_channels where company_id = new.company_id and user_id = new.user_id;
    v_appr := is_approval_kind(new.kind);
    v_url := rtrim(coalesce(t.app_url, 'https://asnys-erp.pages.dev'), '/') || coalesce(new.path, '/notifications');

    -- Telegram, privately
    if t.bot_token is not null and t.personal and uc.telegram_chat_id is not null
       and (uc.telegram_level = 'all' or (uc.telegram_level = 'approvals' and v_appr)) then
      v_text := case when v_appr then '🔔 ' else '' end || '<b>' || tg_escape(new.title) || '</b>'
             || coalesce(E'\n' || tg_escape(new.body), '') || E'\n\n<a href="' || tg_escape(v_url) || '">' || case when v_appr then 'Open and decide' else 'Open in Asnys' end || '</a>';
      v_req := http_post_safe('https://api.telegram.org/bot' || t.bot_token || '/sendMessage',
        jsonb_build_object('chat_id', uc.telegram_chat_id, 'text', left(v_text, 4000), 'parse_mode', 'HTML', 'disable_web_page_preview', true));
      insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
      values (new.company_id, new.user_id, 'telegram', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' end);
    end if;

    -- Email through Brevo
    if coalesce(e.enabled, false) and e.api_key is not null and e.from_email is not null
       and (coalesce(uc.email_level, 'approvals') = 'all' or (coalesce(uc.email_level, 'approvals') = 'approvals' and v_appr)) then
      select coalesce(m.email, u.email) into v_email from memberships m left join auth.users u on u.id = m.user_id where m.company_id = new.company_id and m.user_id = new.user_id;
      if v_email is not null then
        v_req := http_post_safe('https://api.brevo.com/v3/smtp/email',
          jsonb_build_object(
            'sender', jsonb_build_object('email', e.from_email, 'name', coalesce(e.from_name, (select name from companies where id = new.company_id))),
            'to', jsonb_build_array(jsonb_build_object('email', v_email)),
            'subject', left(case when v_appr then '[Action] ' else '' end || new.title, 200),
            'htmlContent', '<div style="font-family:Arial,sans-serif;font-size:15px;color:#17231e">'
              || '<p style="margin:0 0 8px"><b>' || tg_escape(new.title) || '</b></p>'
              || coalesce('<p style="margin:0 0 16px;white-space:pre-wrap">' || tg_escape(new.body) || '</p>', '')
              || '<p><a href="' || tg_escape(v_url) || '" style="background:#1d6b55;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;display:inline-block">'
              || case when v_appr then 'Open and decide' else 'Open in Asnys ERP' end || '</a></p>'
              || '<p style="color:#5b6b63;font-size:12px">Sent by Asnys ERP for ' || tg_escape((select name from companies where id = new.company_id))
              || '. Change what you receive under Notifications → Settings.</p></div>',
            'textContent', new.title || coalesce(E'\n' || new.body, '') || E'\n\n' || v_url),
          jsonb_build_object('api-key', e.api_key, 'Content-Type', 'application/json', 'accept', 'application/json'));
        insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
        values (new.company_id, new.user_id, 'email', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' else v_email end);
      end if;
    end if;
  exception when others then
    null;   -- sending must never stop the work that raised the notification
  end;
  return null;
end $$;
drop trigger if exists notifications_deliver on public.notifications;
create trigger notifications_deliver after insert on public.notifications for each row execute function public.deliver_notification();

-- ---------------------------------------------------------------- 5. Connecting a person's Telegram
-- The app opens t.me/<bot>?start=<code>; the person presses Start; the app then asks the database to look for it.
create or replace function public.telegram_link_start(cid uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare t company_telegram; v_code text := substr(md5(gen_random_uuid()::text || clock_timestamp()::text), 1, 12);
begin
  perform require_member(cid);
  select * into t from company_telegram where company_id = cid;
  if t.bot_token is null or t.bot_username is null then raise exception 'Telegram is not set up for this company yet. Ask an owner or admin to add the bot under Settings → Telegram & email.'; end if;
  insert into user_channels (company_id, user_id, telegram_code, telegram_code_at) values (cid, auth.uid(), v_code, now())
  on conflict (company_id, user_id) do update set telegram_code = v_code, telegram_code_at = now(), telegram_poll_id = null, updated_at = now();
  return jsonb_build_object('code', v_code, 'url', 'https://t.me/' || ltrim(t.bot_username, '@') || '?start=' || v_code, 'bot_username', ltrim(t.bot_username, '@'));
end $$;

-- Reads Telegram's reply to an earlier getUpdates, links anyone in this company who pressed Start with their code,
-- then asks again. Returns linked, pending or expired.
create or replace function public.telegram_link_check(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare uc user_channels; t company_telegram; v_content text; v_json jsonb; u jsonb; v_text text; v_code text; v_max bigint; v_chat text; r record; v_req bigint;
begin
  perform require_member(cid);
  select * into uc from user_channels where company_id = cid and user_id = auth.uid();
  if uc.telegram_chat_id is not null then return 'linked'; end if;
  if uc.telegram_code is null then raise exception 'Press Connect Telegram first'; end if;
  if uc.telegram_code_at < now() - interval '30 minutes' then return 'expired'; end if;
  select * into t from company_telegram where company_id = cid;
  if t.bot_token is null then raise exception 'Telegram is not set up for this company'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;

  if uc.telegram_poll_id is not null then
    begin
      execute 'select content from net._http_response where id = $1' into v_content using uc.telegram_poll_id;
    exception when others then v_content := null;
    end;
    if v_content is null and uc.telegram_poll_at > now() - interval '15 seconds' then return 'pending'; end if;
    update user_channels set telegram_poll_id = null where company_id = cid and user_id = auth.uid();
    if v_content is not null then
      begin v_json := v_content::jsonb; exception when others then v_json := null; end;
      v_max := t.last_update_id;
      for u in select * from jsonb_array_elements(coalesce(v_json->'result', '[]'::jsonb)) loop
        v_max := greatest(coalesce(v_max, 0), (u->>'update_id')::bigint);
        v_text := u->'message'->>'text';
        if v_text like '/start %' then
          v_code := trim(split_part(v_text, ' ', 2));
          v_chat := u->'message'->'chat'->>'id';
          for r in update user_channels set telegram_chat_id = v_chat, telegram_username = u->'message'->'from'->>'username', telegram_linked_at = now(),
                     telegram_code = null, updated_at = now()
                    where company_id = cid and telegram_code = v_code and telegram_chat_id is null returning user_id loop
            perform http_post_safe('https://api.telegram.org/bot' || t.bot_token || '/sendMessage',
              jsonb_build_object('chat_id', v_chat, 'text', '✅ Connected to Asnys ERP for ' || (select name from companies where id = cid)
                || '. You will get your approvals and notifications here. Change what you receive in Asnys under Notifications → Settings.'));
          end loop;
        end if;
      end loop;
      if v_max is distinct from t.last_update_id then update company_telegram set last_update_id = v_max where company_id = cid; end if;
      if exists (select 1 from user_channels where company_id = cid and user_id = auth.uid() and telegram_chat_id is not null) then return 'linked'; end if;
    end if;
  end if;

  execute 'select net.http_get(url := $1)' into v_req
    using 'https://api.telegram.org/bot' || t.bot_token || '/getUpdates?timeout=0&offset=' || coalesce((select last_update_id from company_telegram where company_id = cid) + 1, 0);
  update user_channels set telegram_poll_id = v_req, telegram_poll_at = now() where company_id = cid and user_id = auth.uid();
  return 'pending';
end $$;

create or replace function public.telegram_unlink(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform require_member(cid);
  update user_channels set telegram_chat_id = null, telegram_username = null, telegram_linked_at = null, telegram_code = null, updated_at = now()
   where company_id = cid and user_id = auth.uid();
end $$;

-- Sends me a test on each channel I have.
create or replace function public.test_my_channels(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
begin
  perform require_member(cid);
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  insert into notifications (company_id, user_id, kind, title, body, path)
  values (cid, auth.uid(), 'approval_needed', 'Test: this is how an approval looks', 'Nothing to do; this is a test from Notifications → Settings.', '/notifications');
  return 'sent';
end $$;

-- Owners and admins: how many people have connected.
create or replace function public.channel_overview(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  return jsonb_build_object(
    'members', (select count(*) from memberships where company_id = cid),
    'telegram_linked', (select count(*) from user_channels where company_id = cid and telegram_chat_id is not null),
    'email_off', (select count(*) from user_channels where company_id = cid and email_level = 'off'),
    'last_24h', (select coalesce(jsonb_object_agg(channel, n), '{}') from (select channel, count(*) n from message_log where company_id = cid and created_at > now() - interval '1 day' group by channel) x),
    'people', coalesce((select jsonb_agg(jsonb_build_object('email', coalesce(m.email, u.email), 'role', m.role, 'telegram', c.telegram_chat_id is not null,
                 'telegram_level', coalesce(c.telegram_level, 'all'), 'email_level', coalesce(c.email_level, 'approvals')) order by coalesce(m.email, u.email))
               from memberships m left join auth.users u on u.id = m.user_id left join user_channels c on c.company_id = m.company_id and c.user_id = m.user_id
              where m.company_id = cid), '[]'));
end $$;

-- ---------------------------------------------------------------- 6. Approval notifications for the flows that had none
-- 6a. The approval chain (bills, payroll, purchase orders, purchase requests and expense claims above the limits).
alter table public.approval_steps add column if not exists notified_at timestamptz;

create or replace function public.step_approvers(s approval_steps) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct u), '{}') from (
    select s.approver_user u where s.approver_user is not null
    union select m.user_id from memberships m where m.company_id = s.company_id and s.approver_role is not null and m.role = s.approver_role
    union select m.user_id from memberships m where m.company_id = s.company_id and m.role = 'owner'
      and not exists (select 1 from memberships x where x.company_id = s.company_id and ((s.approver_role is not null and x.role = s.approver_role) or x.user_id = s.approver_user))
  ) x where u is not null and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = u);
$$;

create or replace function public.approval_step_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare cur approval_steps; d record; v_left int; v_rej boolean; v_amt text;
begin
  if new.doc_type = 'spend_request' then return null; end if;   -- spend requests already notify themselves
  select * into d from doc_info(new.doc_type, new.doc_id);
  v_amt := case when new.amount is not null then ' (GH₵ ' || to_char(new.amount, 'FM999,999,999,990.00') || ')' else '' end;
  -- The step now waiting, if nobody has been told about it yet.
  select * into cur from approval_steps where doc_type = new.doc_type and doc_id = new.doc_id and status = 'pending' order by step_no limit 1;
  if found and cur.notified_at is null then
    update approval_steps set notified_at = now() where id = cur.id;
    perform notify_users(cur.company_id, step_approvers(cur), 'approval_needed',
      'Approval needed: ' || coalesce(d.label, replace(new.doc_type, '_', ' ')) || v_amt,
      'Step ' || cur.step_no || ' of ' || (select count(*) from approval_steps where doc_type = new.doc_type and doc_id = new.doc_id) || ': ' || cur.label
        || coalesce(' · asked by ' || (select email from memberships where company_id = cur.company_id and user_id = cur.requested_by), ''),
      '/approvals-inbox', false);
  end if;
  -- The outcome, back to whoever asked.
  if tg_op = 'UPDATE' and new.status is distinct from old.status and new.status in ('approved','rejected') then
    select count(*) filter (where status = 'pending'), bool_or(status = 'rejected') into v_left, v_rej from approval_steps where doc_type = new.doc_type and doc_id = new.doc_id;
    if new.status = 'rejected' or (v_left = 0 and not coalesce(v_rej, false)) then
      perform notify_users(new.company_id, array[new.requested_by], 'approval_decided',
        coalesce(d.label, replace(new.doc_type, '_', ' ')) || case when new.status = 'rejected' then ' was rejected' else ' is fully approved' end,
        case when new.status = 'rejected' then coalesce('Reason: ' || new.note, null) end, coalesce(d.path, '/approvals-inbox'), false);
    end if;
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists approval_steps_notice on public.approval_steps;
create trigger approval_steps_notice after insert or update on public.approval_steps for each row execute function public.approval_step_notice();

-- Project managers of a project, or Finance when there is none.
create or replace function public.project_deciders(cid uuid, pid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct u), '{}') from (
    select p.manager_id u from projects p where p.id = pid and p.manager_id is not null
    union select m.user_id from memberships m where m.company_id = cid and m.role = 'accountant'
      and (pid is null or not exists (select 1 from projects p where p.id = pid and p.manager_id is not null))
  ) x where u is not null;
$$;
revoke execute on function public.project_deciders(uuid, uuid) from public, anon, authenticated;
revoke execute on function public.step_approvers(approval_steps) from public, anon, authenticated;

-- 6b. Site purchase requests (first approval by the project manager).
create or replace function public.project_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare p projects;
begin
  select * into p from projects where id = new.project_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    perform notify_users(new.company_id, project_deciders(new.company_id, new.project_id), 'request_submitted',
      coalesce(new.number, 'Purchase request') || ' needs approval: ' || coalesce(new.description, new.kind),
      concat_ws(' · ', p.number || ' ' || p.name, new.qty || ' × GH₵ ' || to_char(coalesce(new.est_unit_cost, 0), 'FM999,999,990.00'), new.requested_email), '/approvals', false);
  elsif tg_op = 'UPDATE' and new.status in ('approved','rejected') and old.status is distinct from new.status then
    perform notify_users(new.company_id, array[new.requested_by], 'request_decided',
      coalesce(new.number, 'Your request') || ' was ' || new.status, case when new.status = 'rejected' then 'Reason: ' || new.reject_reason end, '/my', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists project_requests_notice on public.project_requests;
create trigger project_requests_notice after insert or update of status on public.project_requests for each row execute function public.project_request_notice();

-- 6c. Expense claims.
create or replace function public.expense_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_who text;
begin
  select full_name into v_who from employees where id = new.employee_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    perform notify_users(new.company_id, project_deciders(new.company_id, new.project_id), 'expense_submitted',
      'Expense claim to approve: ' || coalesce(v_who, 'staff') || ', GH₵ ' || to_char(coalesce(new.amount_home, new.amount, 0), 'FM999,999,990.00'),
      left(coalesce(new.description, ''), 300), '/approvals', false);
  elsif tg_op = 'UPDATE' and new.status in ('approved','rejected') and old.status is distinct from new.status then
    perform notify_users(new.company_id, array[new.submitted_by, (select user_id from employees where id = new.employee_id)], 'expense_decided',
      'Your expense claim of GH₵ ' || to_char(coalesce(new.amount_home, new.amount, 0), 'FM999,999,990.00') || ' was ' || new.status,
      case when new.status = 'rejected' then 'Reason: ' || new.reject_reason end, '/my', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists expense_claims_notice on public.expense_claims;
create trigger expense_claims_notice after insert or update of status on public.expense_claims for each row execute function public.expense_notice();

-- 6d. Timesheets: one message per person, project and day, however many lines were submitted.
create or replace function public.timesheet_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare p projects; v_who text; v_user uuid;
begin
  select * into p from projects where id = new.project_id;
  select full_name, user_id into v_who, v_user from employees where id = new.employee_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    if exists (select 1 from notifications n where n.company_id = p.company_id and n.kind = 'time_submitted' and n.read_at is null
                 and n.created_at > now() - interval '12 hours' and n.title = 'Time to approve: ' || coalesce(v_who, 'staff') || ' on ' || coalesce(p.number, p.name)) then
      return null;
    end if;
    perform notify_users(p.company_id, project_deciders(p.company_id, p.id), 'time_submitted',
      'Time to approve: ' || coalesce(v_who, 'staff') || ' on ' || coalesce(p.number, p.name), p.name, '/approvals', false);
  elsif tg_op = 'UPDATE' and new.status = 'rejected' and old.status = 'submitted' then
    perform notify_users(p.company_id, array[v_user, new.submitted_by], 'time_decided', 'Time rejected on ' || coalesce(p.number, p.name), 'Ask the project manager why, correct it and submit again.', '/my', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists timesheets_notice on public.timesheets;
create trigger timesheets_notice after insert or update of status on public.timesheets for each row execute function public.timesheet_notice();

-- 6e. Training requests (HR decides).
create or replace function public.training_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'submitted' and tg_op = 'INSERT' then
    perform notify_users(new.company_id, (select coalesce(array_agg(user_id), '{}') from memberships where company_id = new.company_id and role = 'hr'), 'training_request',
      coalesce(new.number, 'Training request') || ' to decide: ' || (select full_name from employees where id = new.employee_id), new.requested_email, '/training', false);
  elsif tg_op = 'UPDATE' and new.status in ('approved','rejected') and old.status is distinct from new.status then
    perform notify_users(new.company_id, array[new.requested_by, (select user_id from employees where id = new.employee_id)], 'training_decided',
      coalesce(new.number, 'Training request') || ' was ' || new.status, new.decision_note, '/training', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists training_requests_notice on public.training_requests;
create trigger training_requests_notice after insert or update of status on public.training_requests for each row execute function public.training_request_notice();

-- 6f. Document revisions sent for review (project manager), and the result back to whoever uploaded it.
create or replace function public.doc_review_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare d doc_register; p projects;
begin
  select * into d from doc_register where id = new.doc_id;
  select * into p from projects where id = d.project_id;
  if new.status = 'in_review' and old.status is distinct from 'in_review' then
    perform notify_users(d.company_id, project_deciders(d.company_id, d.project_id), 'doc_review',
      'Document to review: ' || coalesce(d.number, '') || ' rev ' || coalesce(new.rev, '') || ' ' || coalesce(d.title, ''), coalesce(p.number || ' ' || p.name, ''),
      '/projects/' || d.project_id, false);
  elsif old.status = 'in_review' and new.status in ('approved','approved_comments','rejected','ready') then
    perform notify_users(d.company_id, array[new.uploaded_by], 'doc_reviewed',
      coalesce(d.number, 'Document') || ' rev ' || coalesce(new.rev, '') || ': ' || replace(new.status, '_', ' '), new.review_note, '/projects/' || d.project_id, false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists doc_revisions_notice on public.doc_revisions;
create trigger doc_revisions_notice after update of status on public.doc_revisions for each row execute function public.doc_review_notice();

-- 6g. Stock requests from sites (the storekeeper dispatches).
create or replace function public.stock_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare p projects;
begin
  select * into p from projects where id = new.project_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    perform notify_users(new.company_id, (select coalesce(array_agg(user_id), '{}') from memberships where company_id = new.company_id and role = 'store'), 'stock_request',
      coalesce(new.number, 'Stock request') || ' from ' || coalesce(p.number || ' ' || p.name, 'a site') || ' to dispatch',
      concat_ws(' · ', new.requested_email, 'needed by ' || to_char(new.needed_by, 'DD Mon')), '/inventory/requests', false);
  elsif tg_op = 'UPDATE' and new.status = 'dispatched' and old.status is distinct from 'dispatched' then
    perform notify_users(new.company_id, array[new.requested_by], 'stock_request', coalesce(new.number, 'Your stock request') || ' has been dispatched', new.dispatch_note, '/inventory/requests', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists stock_requests_notice on public.stock_requests;
create trigger stock_requests_notice after insert or update of status on public.stock_requests for each row execute function public.stock_request_notice();

-- ---------------------------------------------------------------- 7. Logins with a temporary password (used by the invite-member function)
-- Invitations to give a password to: their login, if one exists, and whether it has ever signed in.
create or replace function public.invites_for_password(cid uuid, p_ids uuid[])
returns table (id uuid, email text, role text, company_name text, user_id uuid, signed_in boolean)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform require_member(cid, array['owner','admin','hr']);
  return query
    select i.id, i.email, i.role, c.name, u.id, u.last_sign_in_at is not null
      from member_invites i join companies c on c.id = i.company_id left join auth.users u on lower(u.email) = lower(i.email)
     where i.company_id = cid and i.id = any(p_ids) and i.status in ('pending','sent','failed') and can_invite(cid, i.role);
end $$;

-- Whether the caller may set a new password for this member. Owners and admins: anyone but the owner;
-- HR: staff only. Nobody resets their own this way. Logged.
create or replace function public.password_reset_target(cid uuid, p_user uuid) returns text
language plpgsql security definer set search_path = public as $$
declare m memberships; v_email text;
begin
  perform require_member(cid, array['owner','admin','hr']);
  select * into m from memberships where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
  if p_user = auth.uid() then raise exception 'Change your own password from your account menu'; end if;
  if m.role = 'owner' then raise exception 'The owner''s password cannot be reset by others'; end if;
  if not has_role(cid, array['owner','admin']) and m.role <> 'staff' then raise exception 'HR can reset passwords for staff only. Ask an admin.'; end if;
  select email into v_email from auth.users where id = p_user;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (cid, 'password.reset', 'memberships', p_user, jsonb_build_object('email', v_email));
  return v_email;
end $$;

-- The app shows Set new password only where it is allowed.
create or replace function public.can_reset_password(cid uuid, p_role text, p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select p_user is distinct from auth.uid() and p_role <> 'owner'
     and (has_role(cid, array['owner','admin']) or (p_role = 'staff' and has_role(cid, array['hr'])));
$$;


-- ---------------------------------------------------------------- 8. Activity log for the whole system
-- Secrets never go into the log.
create or replace function public.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare o jsonb; n jsonb; d_old jsonb := '{}'; d_new jsonb := '{}'; k text; cid uuid; rid uuid;
  ignore text[] := array['stock_qty','cost','score','sales_ready','updated_at','last_depreciated','accumulated_depreciation','percent_complete',
                         'telegram_poll_id','telegram_poll_at','reminded_for','reminded_on','notified_at'];
  secret text[] := array['bot_token','api_key','product_key','password','telegram_code','token','secret'];
begin
  if tg_op <> 'INSERT' then o := to_jsonb(old); end if;
  if tg_op <> 'DELETE' then n := to_jsonb(new); end if;
  cid := coalesce((n->>'company_id')::uuid, (o->>'company_id')::uuid, case when tg_table_name = 'companies' then coalesce((n->>'id')::uuid, (o->>'id')::uuid) end);
  begin rid := coalesce((n->>'id')::uuid, (o->>'id')::uuid); exception when others then rid := null; end;
  if tg_op = 'UPDATE' then
    for k in select jsonb_object_keys(n) loop
      if k <> all(ignore) and (o->k) is distinct from (n->k) then
        d_old := d_old || jsonb_build_object(k, o->k); d_new := d_new || jsonb_build_object(k, n->k);
      end if;
    end loop;
    if d_new = '{}'::jsonb then return null; end if;
    -- keep a name or number so the line says which record changed
    foreach k in array array['number','name','full_name','title','reg_no','tag','email','description'] loop
      if (to_jsonb(new)) ? k and not d_new ? k then d_new := d_new || jsonb_build_object('_label', to_jsonb(new)->k); exit; end if;
    end loop;
    o := d_old; n := d_new;
  end if;
  foreach k in array secret loop   -- a changed secret shows as changed, never its value
    if o ? k then o := o || jsonb_build_object(k, case when o->>k is null then null else '••••' end); end if;
    if n ? k then n := n || jsonb_build_object(k, case when n->>k is null then null else '••••' end); end if;
  end loop;
  insert into audit_log (company_id, action, table_name, row_id, old_data, new_data)
  values (cid, tg_table_name || '.' || lower(tg_op), tg_table_name, rid, o, n);
  return null;
end $$;

-- Every business table is logged, not only the money ones.
do $$ declare t text; begin
  for t in select c.table_name from information_schema.columns c join information_schema.tables x on x.table_schema = c.table_schema and x.table_name = c.table_name
            where c.table_schema = 'public' and c.column_name = 'company_id' and x.table_type = 'BASE TABLE'
              and c.table_name not in ('audit_log','notifications','message_log','user_channels','company_telegram','company_email','announcement_reads',
                                       'payment_reminders','journal_lines','asset_item_stock','esg_entries_cache')
              and not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || c.table_name)::regclass and p.proname = 'audit_row') loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', left(t, 50) || '_audit', t);
  end loop;
end $$;
-- Settings tables: logged, with their secrets hidden by audit_row.
do $$ declare t text; begin
  foreach t in array array['company_telegram','company_email'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- Sign-ins: recorded once per real sign-in (from the login time Supabase keeps).
alter table public.memberships add column if not exists last_sign_in_logged timestamptz;
create or replace function public.record_sign_in() returns int
language plpgsql security definer set search_path = public as $$
declare v_at timestamptz; v_email text; m record; n int := 0;
begin
  if auth.uid() is null then return 0; end if;
  select last_sign_in_at, email into v_at, v_email from auth.users where id = auth.uid();
  if v_at is null then return 0; end if;
  for m in select company_id from memberships where user_id = auth.uid() and (last_sign_in_logged is null or last_sign_in_logged < v_at) loop
    insert into audit_log (company_id, action, table_name, row_id, detail) values (m.company_id, 'user.signed_in', 'sign_in', auth.uid(), jsonb_build_object('email', v_email, 'at', v_at));
    update memberships set last_sign_in_logged = v_at where company_id = m.company_id and user_id = auth.uid();
    n := n + 1;
  end loop;
  return n;
end $$;

-- What has been logged, by area, for the filter list.
create or replace function public.audit_areas(cid uuid, p_from date, p_to date) returns table (table_name text, n bigint)
language sql stable security definer set search_path = public as $$
  select l.table_name, count(*) from audit_log l
   where l.company_id = cid and has_role(cid, array['owner','admin','accountant']) and l.created_at >= p_from and l.created_at < p_to + 1 and l.table_name is not null
   group by l.table_name order by 2 desc;
$$;

-- The trail, with an action filter (created, changed, deleted, sign-in, other).
create or replace function public.activity_log(cid uuid, p_from date, p_to date, p_table text default null, p_user text default null,
  p_search text default null, p_kind text default null, p_limit int default 100, p_offset int default 0)
returns table (id bigint, created_at timestamptz, user_email text, action text, table_name text, row_id uuid, old_data jsonb, new_data jsonb, detail jsonb, total bigint)
language sql stable security definer set search_path = public as $$
  select l.id, l.created_at, l.user_email, l.action, l.table_name, l.row_id, l.old_data, l.new_data, l.detail, count(*) over()
    from audit_log l
   where l.company_id = cid and has_role(cid, array['owner','admin','accountant'])
     and l.created_at >= p_from and l.created_at < p_to + 1
     and (p_table is null or l.table_name = p_table)
     and (p_user is null or l.user_email ilike '%' || p_user || '%')
     and (p_kind is null or (p_kind = 'insert' and l.action like '%.insert') or (p_kind = 'update' and l.action like '%.update')
          or (p_kind = 'delete' and l.action like '%.delete') or (p_kind = 'sign_in' and l.action = 'user.signed_in')
          or (p_kind = 'other' and l.action not like '%.insert' and l.action not like '%.update' and l.action not like '%.delete' and l.action <> 'user.signed_in'))
     and (p_search is null or l.action ilike '%' || p_search || '%' or coalesce(l.new_data::text,'') ilike '%' || p_search || '%'
          or coalesce(l.old_data::text,'') ilike '%' || p_search || '%' or coalesce(l.detail::text,'') ilike '%' || p_search || '%')
   order by l.created_at desc, l.id desc
   limit least(p_limit, 1000) offset p_offset;
$$;


-- ---------------------------------------------------------------- 9. Void entries made in error
-- Anything that has not been posted to the books can be voided with a reason. It stays on record (marked Voided,
-- with who, when and why) and drops out of totals, approvals and reminders. Posted money entries are corrected by
-- reversal instead: invoices with a credit note, bank and cash entries with Void, journals with Reverse.
create table if not exists public.void_rules (
  table_name text primary key,
  label text not null,
  from_status text[] not null,
  roles text[] not null,           -- who may void besides the person who entered it (owners and admins always can)
  creator_col text                 -- the column holding who entered it; that person may void their own
);
insert into public.void_rules (table_name, label, from_status, roles, creator_col) values
  ('tenders',              'Tender',              '{registered,preparing,review,submitted,no_bid,lost}', '{sales,accountant}', null),
  ('sales_quotes',         'Quote',               '{draft,sent,declined}',            '{sales,accountant}', null),
  ('purchase_orders',      'Purchase order',      '{draft,approved,sent}',            '{accountant,store}', 'created_by'),
  ('project_requests',     'Purchase request',    '{draft,submitted,approved}',       '{accountant,project_manager}', 'requested_by'),
  ('expense_claims',       'Expense claim',       '{submitted}',                      '{accountant}', 'submitted_by'),
  ('leave_requests',       'Leave request',       '{pending,approved}',               '{hr}', 'employee_id'),
  ('timesheets',           'Timesheet line',      '{submitted}',                      '{accountant,project_manager}', 'submitted_by'),
  ('stock_requests',       'Stock request',       '{draft,submitted}',                '{store,accountant}', 'requested_by'),
  ('asset_requests',       'Asset request',       '{pending,approved}',               '{store,accountant}', 'requested_by'),
  ('training_requests',    'Training request',    '{submitted,approved}',             '{hr}', 'requested_by'),
  ('contract_variations',  'Variation',           '{proposed}',                       '{accountant,project_manager,sales}', 'created_by'),
  ('vehicle_requests',     'Vehicle request',     '{pending,approved}',               '{store,accountant}', 'requested_by'),
  ('vehicle_trips',        'Trip',                '{planned}',                        '{store,accountant}', 'created_by'),
  ('hse_permits',          'Permit',              '{requested}',                      '{}', 'requested_by'),
  ('employee_change_requests','Profile change',   '{pending}',                        '{hr}', 'employee_id'),
  ('contracts',            'Contract',            '{draft}',                          '{accountant,sales}', 'created_by'),
  ('risk_assessments',     'Risk assessment',     '{draft}',                          '{project_manager}', 'assessed_by'),
  ('hse_inspections',      'Inspection',          '{draft}',                          '{}', null),
  ('hse_sessions',         'Toolbox talk / induction', '{draft}',                     '{}', 'created_by'),
  ('leads',                'Lead',                '{new,contacted,qualified,unqualified}', '{sales}', null)
on conflict (table_name) do update set label = excluded.label, from_status = excluded.from_status, roles = excluded.roles, creator_col = excluded.creator_col;
delete from public.void_rules where table_name in ('progress_reports','petty_vouchers','waybills');
alter table public.void_rules enable row level security;
drop policy if exists "read void rules" on public.void_rules;
create policy "read void rules" on public.void_rules for select using (true);

-- 'voided' becomes a valid status, and the reason is kept on the entry.
do $$ declare r record; c record; v_def text; begin
  for r in select table_name from void_rules where to_regclass('public.' || table_name) is not null loop
    execute format('alter table public.%I add column if not exists void_reason text', r.table_name);
    execute format('alter table public.%I add column if not exists voided_at timestamptz', r.table_name);
    execute format('alter table public.%I add column if not exists voided_by uuid', r.table_name);
    for c in select con.conname, pg_get_constraintdef(con.oid) def from pg_constraint con join pg_attribute a on a.attrelid = con.conrelid and a.attnum = any(con.conkey)
              where con.conrelid = ('public.' || r.table_name)::regclass and con.contype = 'c' and a.attname = 'status' loop
      if c.def not like '%''voided''%' then
        v_def := regexp_replace(c.def, '\](\)+)$', ', ''voided''::text]\1');
        if v_def = c.def then raise exception 'Could not add voided to %', r.table_name; end if;
        execute format('alter table public.%I drop constraint %I', r.table_name, c.conname);
        execute format('alter table public.%I add constraint %I %s', r.table_name, c.conname, v_def);
      end if;
    end loop;
  end loop;
end $$;

-- The person who entered it (an employee column means that employee's login).
create or replace function public.entry_owner(p_col text, p_table text, p_id uuid) returns uuid
language plpgsql stable security definer set search_path = public as $$
declare v uuid;
begin
  if p_col is null then return null; end if;
  execute format('select %I from public.%I where id = $1', p_col, p_table) into v using p_id;
  if p_col = 'employee_id' then select user_id into v from employees where id = v; end if;
  return v;
end $$;
revoke execute on function public.entry_owner(text, text, uuid) from public, anon, authenticated;

create or replace function public.void_entry(p_table text, p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid; f text;
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be voided here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  if not (has_role(v_cid, array['owner','admin']) or has_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid())) then
    raise exception 'You cannot void this %. Ask an admin.', lower(vr.label);
  end if;
  if v_status = 'voided' then raise exception 'Already voided'; end if;
  if not (v_status = any(vr.from_status)) then
    raise exception 'A % that is % cannot be voided. %', lower(vr.label), replace(v_status, '_', ' '),
      case when p_table = 'purchase_orders' then 'Goods have been received against it; close it instead.'
           when p_table = 'expense_claims' then 'It has been posted; reverse it with a journal.'
           when p_table = 'tenders' then 'An awarded tender has a project; cancel the project instead.'
           else 'It has already gone through.' end;
  end if;
  if p_table = 'timesheets' and exists (select 1 from timesheets where id = p_id and invoice_id is not null) then raise exception 'This time has been invoiced'; end if;
  -- Let the update through the usual "use the buttons" guards; the void itself is the controlled action.
  foreach f in array array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle'] loop
    perform set_config(f, 'on', true);
  end loop;
  execute format('update public.%I set status = ''voided'', void_reason = $2, voided_at = now(), voided_by = auth.uid() where id = $1', p_table) using p_id, trim(p_reason);
  foreach f in array array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle'] loop
    perform set_config(f, 'off', true);
  end loop;
  -- Nothing waits for approval on a voided entry.
  update approval_steps set status = 'skipped' where doc_id = p_id and status = 'pending';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.voided', p_table, p_id, jsonb_build_object('what', vr.label, 'was', v_status, 'reason', trim(p_reason)));
end $$;

-- Who may void a given entry (for showing the button).
create or replace function public.can_void(p_table text, p_id uuid) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid;
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then return false; end if;
  execute format('select company_id, status from public.%I where id = $1', p_table) into v_cid, v_status using p_id;
  if v_cid is null or not (v_status = any(vr.from_status)) then return false; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  return has_role(v_cid, array['owner','admin']) or has_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid());
end $$;

-- Manual journals posted in error: reverse them (a mirror entry dated when you choose). The original stays.
alter table public.journal_entries add column if not exists reversed_by_entry uuid;
create or replace function public.reverse_journal(p_entry uuid, p_date date, p_reason text) returns uuid
language plpgsql security definer set search_path = public as $$
declare e journal_entries; v uuid;
begin
  select * into e from journal_entries where id = p_entry for update;
  if not found then raise exception 'Journal not found'; end if;
  perform require_member(e.company_id, array['owner','admin','accountant']);
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being reversed'; end if;
  if e.reversed_by_entry is not null then raise exception 'This journal has already been reversed'; end if;
  if coalesce(e.source_type, 'manual') not in ('manual','journal','opening') then
    raise exception 'This journal was posted by a % — correct it there (credit note, void, or the document''s own reversal).', replace(e.source_type, '_', ' ');
  end if;
  v := post_journal(e.company_id, p_date, 'Reversal of ' || e.entry_no || ': ' || trim(p_reason),
    (select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit, 'project_id', l.project_id,
                                         'branch_id', l.branch_id, 'cost_centre_id', l.cost_centre_id, 'description', 'Reversal'))
       from journal_lines l where l.entry_id = e.id), 'reversal', e.id);
  update journal_entries set reversed_by_entry = v where id = e.id;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (e.company_id, 'journal.reversed', 'journal_entries', e.id, jsonb_build_object('entry', e.entry_no, 'reason', trim(p_reason)));
  return v;
end $$;

-- ================================================================ 0021_asnys_v3_3.sql
-- Asnys ERP v3.3 — Send email through the company's own Microsoft 365 (no Brevo)
-- Emails go out from a real mailbox (e.g. notifications@gulfaco.com) through Microsoft Graph, using an app
-- registered in the company's Microsoft 365 (Azure). The Microsoft keys stay in Supabase's secret store and the
-- send-mail function; the database only knows the function's address and a shared secret.
-- Brevo stays available as an alternative. Run after 0020. Safe to run twice.

alter table public.company_email drop constraint if exists company_email_provider_check;
alter table public.company_email add constraint company_email_provider_check check (provider in ('brevo','microsoft'));
alter table public.company_email add column if not exists function_url text;     -- https://<project>.supabase.co/functions/v1/send-mail
-- The shared secret lives in its own table that nobody can read from the app (RLS on, no policies).
create table if not exists public.company_email_secret (
  company_id uuid primary key references public.companies(id) on delete cascade,
  secret text not null default (md5(gen_random_uuid()::text || clock_timestamp()::text) || md5(gen_random_uuid()::text))
);
alter table public.company_email_secret enable row level security;
create or replace function public.company_email_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into company_email_secret (company_id) values (new.company_id) on conflict do nothing;
  return null;
end $$;
drop trigger if exists company_email_defaults on public.company_email;
create trigger company_email_defaults after insert or update on public.company_email for each row execute function public.company_email_defaults();
insert into public.company_email_secret (company_id) select company_id from public.company_email on conflict do nothing;

-- One email, by whichever service the company chose.
create or replace function public.send_company_email(cid uuid, p_to text, p_subject text, p_html text, p_text text) returns bigint
language plpgsql security definer set search_path = public as $$
declare e company_email;
begin
  select * into e from company_email where company_id = cid;
  if not found or not e.enabled or e.from_email is null or p_to is null then return null; end if;
  if e.provider = 'microsoft' then
    if e.function_url is null then return null; end if;
    return http_post_safe(e.function_url,
      jsonb_build_object('company_id', cid, 'to', p_to, 'subject', left(p_subject, 250), 'html', p_html, 'text', p_text),
      jsonb_build_object('Content-Type', 'application/json', 'x-asnys-secret', (select secret from company_email_secret where company_id = cid)));
  end if;
  if e.api_key is null then return null; end if;
  return http_post_safe('https://api.brevo.com/v3/smtp/email',
    jsonb_build_object('sender', jsonb_build_object('email', e.from_email, 'name', coalesce(e.from_name, (select name from companies where id = cid))),
      'to', jsonb_build_array(jsonb_build_object('email', p_to)), 'subject', left(p_subject, 200), 'htmlContent', p_html, 'textContent', p_text),
    jsonb_build_object('api-key', e.api_key, 'Content-Type', 'application/json', 'accept', 'application/json'));
end $$;
revoke execute on function public.send_company_email(uuid, text, text, text, text) from public, anon, authenticated;

-- Delivery now uses either service.
create or replace function public.deliver_notification() returns trigger
language plpgsql security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email; v_appr boolean; v_url text; v_email text; v_req bigint; v_text text; v_ready boolean;
begin
  begin
    select * into t from company_telegram where company_id = new.company_id;
    select * into e from company_email where company_id = new.company_id;
    if t.company_id is null and e.company_id is null then return null; end if;
    select * into uc from user_channels where company_id = new.company_id and user_id = new.user_id;
    v_appr := is_approval_kind(new.kind);
    v_url := rtrim(coalesce(t.app_url, 'https://asnys-erp.pages.dev'), '/') || coalesce(new.path, '/notifications');

    if t.bot_token is not null and t.personal and uc.telegram_chat_id is not null
       and (uc.telegram_level = 'all' or (uc.telegram_level = 'approvals' and v_appr)) then
      v_text := case when v_appr then '🔔 ' else '' end || '<b>' || tg_escape(new.title) || '</b>'
             || coalesce(E'\n' || tg_escape(new.body), '') || E'\n\n<a href="' || tg_escape(v_url) || '">' || case when v_appr then 'Open and decide' else 'Open in Asnys' end || '</a>';
      v_req := http_post_safe('https://api.telegram.org/bot' || t.bot_token || '/sendMessage',
        jsonb_build_object('chat_id', uc.telegram_chat_id, 'text', left(v_text, 4000), 'parse_mode', 'HTML', 'disable_web_page_preview', true));
      insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
      values (new.company_id, new.user_id, 'telegram', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' end);
    end if;

    v_ready := coalesce(e.enabled, false) and e.from_email is not null and ((e.provider = 'microsoft' and e.function_url is not null) or (e.provider = 'brevo' and e.api_key is not null));
    if v_ready and (coalesce(uc.email_level, 'approvals') = 'all' or (coalesce(uc.email_level, 'approvals') = 'approvals' and v_appr)) then
      select coalesce(m.email, u.email) into v_email from memberships m left join auth.users u on u.id = m.user_id where m.company_id = new.company_id and m.user_id = new.user_id;
      if v_email is not null then
        v_req := send_company_email(new.company_id, v_email, case when v_appr then '[Action] ' else '' end || new.title,
          '<div style="font-family:Arial,sans-serif;font-size:15px;color:#17231e">'
            || '<p style="margin:0 0 8px"><b>' || tg_escape(new.title) || '</b></p>'
            || coalesce('<p style="margin:0 0 16px;white-space:pre-wrap">' || tg_escape(new.body) || '</p>', '')
            || '<p><a href="' || tg_escape(v_url) || '" style="background:#1d6b55;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;display:inline-block">'
            || case when v_appr then 'Open and decide' else 'Open in Asnys ERP' end || '</a></p>'
            || '<p style="color:#5b6b63;font-size:12px">Sent by Asnys ERP for ' || tg_escape((select name from companies where id = new.company_id))
            || '. Change what you receive under Notifications → How you are notified.</p></div>',
          new.title || coalesce(E'\n' || new.body, '') || E'\n\n' || v_url);
        insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
        values (new.company_id, new.user_id, 'email', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' else v_email end);
      end if;
    end if;
  exception when others then
    null;
  end;
  return null;
end $$;

-- Used only by the send-mail function (with the service key) to check a request really came from this database.
create or replace function public.email_hook_config(cid uuid, p_secret text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('from_email', e.from_email, 'from_name', coalesce(e.from_name, c.name))
    from company_email e join companies c on c.id = e.company_id join company_email_secret x on x.company_id = e.company_id
   where e.company_id = cid and e.provider = 'microsoft' and e.enabled and x.secret = p_secret;
$$;
revoke execute on function public.email_hook_config(uuid, text) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then grant execute on function public.email_hook_config(uuid, text) to service_role; end if;
end $$;

-- Owners: send a test email to themselves now, and see how recent emails went.
create or replace function public.test_company_email(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_to text; v bigint; e company_email;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can test email'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  select * into e from company_email where company_id = cid;
  if not found or not e.enabled then raise exception 'Tick Send emails and save first'; end if;
  select coalesce(m.email, u.email) into v_to from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid();
  v := send_company_email(cid, v_to, 'Asnys ERP test email', '<p>This is a test from Asnys ERP. Email is working for ' || tg_escape((select name from companies where id = cid)) || '.</p>', 'This is a test from Asnys ERP.');
  if v is null then raise exception 'Not sent: check the settings above'; end if;
  insert into message_log (company_id, user_id, channel, title, request_id, status, note) values (cid, auth.uid(), 'email', 'Test email', v, 'queued', v_to);
  return v_to;
end $$;

create or replace function public.recent_email_results(cid uuid) returns table (sent_at timestamptz, to_email text, title text, status_code int, error text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  if to_regnamespace('net') is null then return; end if;
  return query execute
    'select l.created_at, l.note, l.title, r.status_code, left(coalesce(r.error_msg, case when r.status_code >= 300 then r.content end), 300)
       from message_log l left join net._http_response r on r.id = l.request_id
      where l.company_id = $1 and l.channel = ''email'' order by l.id desc limit 15' using cid;
end $$;

-- Each person's settings page counts Microsoft 365 as set up too.
create or replace function public.my_channels(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email;
begin
  perform require_member(cid);
  select * into uc from user_channels where company_id = cid and user_id = auth.uid();
  select * into t from company_telegram where company_id = cid;
  select * into e from company_email where company_id = cid;
  return jsonb_build_object(
    'telegram_ready', t.bot_token is not null and t.personal and t.bot_username is not null,
    'bot_username', t.bot_username,
    'email_ready', coalesce(e.enabled, false) and e.from_email is not null and ((e.provider = 'microsoft' and e.function_url is not null) or (e.provider = 'brevo' and e.api_key is not null)),
    'pg_net', to_regnamespace('net') is not null,
    'telegram_linked', uc.telegram_chat_id is not null,
    'telegram_username', uc.telegram_username,
    'telegram_linked_at', uc.telegram_linked_at,
    'telegram_level', coalesce(uc.telegram_level, 'all'),
    'email_level', coalesce(uc.email_level, 'approvals'),
    'email', (select coalesce(m.email, u.email) from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid()));
end $$;

-- ================================================================ 0022_asnys_v3_4.sql
-- Asnys ERP v3.4 — Gulfaco's requests: numbering, customers and tax, stricter invoices, payment milestones,
-- SR/ADR/MRO requests with several items and attachments, stock for sale or for use, subcontractors,
-- company logo, backups to OneDrive, Microsoft 365 certificate, password reset by email, 2-step sign-in.
-- Run after 0021. Safe to run twice.

-- ---------------------------------------------------------------- 1. Document numbering: a company code in front (GUF-INV-00001), and set your own
alter table public.companies add column if not exists doc_prefix text check (doc_prefix ~ '^[A-Z0-9]{1,6}$');
create table if not exists public.number_formats (
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  prefix text not null check (prefix ~ '^[A-Z0-9/-]{1,12}$'),
  primary key (company_id, key)
);
alter table public.number_formats enable row level security;
drop policy if exists "members read formats" on public.number_formats;
create policy "members read formats" on public.number_formats for select using (is_member(company_id));

create or replace function public.next_number(cid uuid, p_key text, p_prefix text)
returns text language plpgsql security definer set search_path = public as $$
declare v int; v_code text; v_pre text;
begin
  insert into number_sequences (company_id, key, next_value) values (cid, p_key, 2)
  on conflict (company_id, key) do update set next_value = number_sequences.next_value + 1
  returning next_value - 1 into v;
  select doc_prefix into v_code from companies where id = cid;
  select prefix into v_pre from number_formats where company_id = cid and key = p_key;
  v_pre := coalesce(v_pre || '-', p_prefix);
  return case when v_code is not null then v_code || '-' else '' end || v_pre || lpad(v::text, 5, '0');
end $$;
revoke execute on function public.next_number(uuid, text, text) from public, anon, authenticated;

-- Settings: every sequence, its prefix and the next number; owners and Finance can change them.
create or replace function public.number_settings(cid uuid) returns table (key text, prefix text, next_value int, example text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare v_code text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  select doc_prefix into v_code from companies where id = cid;
  return query
    select s.key, coalesce(f.prefix, s.key), s.next_value,
           case when v_code is not null then v_code || '-' else '' end || coalesce(f.prefix, s.key) || '-' || lpad(s.next_value::text, 5, '0')
      from number_sequences s left join number_formats f on f.company_id = s.company_id and f.key = s.key
     where s.company_id = cid order by s.key;
end $$;

create or replace function public.set_numbering(cid uuid, p_code text, p_key text default null, p_prefix text default null, p_next int default null) returns void
language plpgsql security definer set search_path = public as $$
declare v_used int;
begin
  if not has_role(cid, array['owner','admin','accountant']) then raise exception 'Only an owner, admin or Finance can change numbering'; end if;
  update companies set doc_prefix = nullif(upper(trim(p_code)), '') where id = cid;
  if p_key is not null then
    if nullif(trim(p_prefix), '') is not null then
      insert into number_formats (company_id, key, prefix) values (cid, p_key, upper(trim(p_prefix)))
      on conflict (company_id, key) do update set prefix = excluded.prefix;
    end if;
    if p_next is not null then
      select next_value into v_used from number_sequences where company_id = cid and key = p_key;
      if p_next < 1 then raise exception 'The next number must be 1 or more'; end if;
      insert into number_sequences (company_id, key, next_value) values (cid, p_key, p_next)
      on conflict (company_id, key) do update set next_value = excluded.next_value;
    end if;
  end if;
  insert into audit_log (company_id, action, table_name, detail) values (cid, 'numbering.changed', 'number_sequences', jsonb_build_object('code', p_code, 'key', p_key, 'prefix', p_prefix, 'next', p_next));
end $$;

-- Gulfaco's request codes: SR service request, ADR procurement request, MRO material request.
insert into public.number_formats (company_id, key, prefix)
select id, k, p from public.companies, (values ('ADR','ADR'),('SR','SR'),('MRO','MRO')) v(k, p) on conflict do nothing;

-- ---------------------------------------------------------------- 2. Customers and suppliers: contacts, TIN, tax position
alter table public.customers add column if not exists contact_name text;
alter table public.customers add column if not exists contact_phone text;
alter table public.customers add column if not exists contact_email text;
alter table public.customers add column if not exists tax_status text not null default 'standard'
  check (tax_status in ('standard','exempt','zero_rated','diplomatic','free_zone'));
alter table public.customers add column if not exists exemption_ref text;
alter table public.customers add column if not exists exemption_expiry date;
alter table public.customers add column if not exists wht_agent boolean not null default false;
alter table public.customers add column if not exists wht_rate numeric(5,2) check (wht_rate between 0 and 30);
alter table public.customers add column if not exists vat_wht_agent boolean not null default false;
alter table public.customers add column if not exists tax_note text;

alter table public.suppliers add column if not exists contact_phone text;
alter table public.suppliers add column if not exists contact_email text;
alter table public.suppliers add column if not exists vat_registered boolean not null default true;
alter table public.suppliers add column if not exists wht_rate numeric(5,2) check (wht_rate between 0 and 30);
alter table public.suppliers add column if not exists tax_note text;

alter table public.companies add column if not exists strict_invoices boolean not null default false;
alter table public.companies add column if not exists wht_default_rate numeric(5,2) not null default 7.5;
update public.companies set strict_invoices = true where not strict_invoices and created_at < now() - interval '1 minute';

-- Withholding tax credit (what customers deduct and pay to GRA on Gulfaco's behalf).
create or replace function public.seed_accounts_v34(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into accounts (company_id, code, name, type, system_key) values
  (cid, '1285', 'Withholding tax credit (deducted by customers)', 'asset', 'wht_receivable')
  on conflict do nothing;
$$;
select public.seed_accounts_v34(id) from public.companies;
revoke execute on function public.seed_accounts_v34(uuid) from public, anon, authenticated;

-- ---------------------------------------------------------------- 3. Invoices tied to something, with a reference, VAT on or off
alter table public.invoices add column if not exists quote_id uuid references public.sales_quotes(id) on delete set null;
alter table public.invoices add column if not exists contract_id uuid references public.contracts(id) on delete set null;
alter table public.invoices add column if not exists milestone_id uuid references public.project_milestones(id) on delete set null;
alter table public.invoices add column if not exists customer_po text;
alter table public.invoices add column if not exists reference text;
alter table public.invoices add column if not exists charge_vat boolean not null default true;
alter table public.invoices add column if not exists wht_rate numeric(5,2);
alter table public.invoices add column if not exists wht_amount numeric(14,2) not null default 0;

-- VAT off: every line is untaxed.
create or replace function public.invoice_vat_lines() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_table_name = 'invoices' then
    if new.charge_vat is distinct from old.charge_vat and new.status = 'draft' then
      update invoice_lines l set taxable = case when new.charge_vat then coalesce((select taxable from products p where p.id = l.product_id), true) else false end where l.invoice_id = new.id;
    end if;
    return new;
  end if;
  if not coalesce((select charge_vat from invoices where id = new.invoice_id), true) then new.taxable := false; end if;
  return new;
end $$;
drop trigger if exists invoices_vat_lines on public.invoices;
create trigger invoices_vat_lines after update of charge_vat on public.invoices for each row execute function public.invoice_vat_lines();
drop trigger if exists invoice_lines_vat on public.invoice_lines;
create trigger invoice_lines_vat before insert or update on public.invoice_lines for each row execute function public.invoice_vat_lines();

-- New invoices take the customer's tax position: exempt or zero-rated → no VAT; withholding agent → expected WHT.
create or replace function public.invoice_customer_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers;
begin
  select * into c from customers where id = new.customer_id;
  if found then
    if c.tax_status in ('exempt','zero_rated','diplomatic','free_zone') and (c.exemption_expiry is null or c.exemption_expiry >= coalesce(new.invoice_date, current_date)) then new.charge_vat := false; end if;
    if c.wht_agent and new.wht_rate is null then new.wht_rate := coalesce(c.wht_rate, (select wht_default_rate from companies where id = new.company_id)); end if;
  end if;
  return new;
end $$;
drop trigger if exists invoices_customer_defaults on public.invoices;
create trigger invoices_customer_defaults before insert on public.invoices for each row execute function public.invoice_customer_defaults();

-- With strict invoices on (Settings), an invoice can only be posted when it is tied to a quote, contract, project or the
-- customer's PO, has a reference, and the customer has a TIN.
create or replace function public.invoice_post_rules() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers; v_strict boolean;
begin
  if old.status = 'draft' and new.status <> 'draft' then
    select strict_invoices into v_strict from companies where id = new.company_id;
    if v_strict then
      select * into c from customers where id = new.customer_id;
      if coalesce(trim(c.tin), '') = '' then raise exception 'Add % TIN to the customer record before posting (Sales → Customers)', c.name || '''s'; end if;
      if coalesce(trim(new.reference), '') = '' then raise exception 'Enter the invoice reference before posting'; end if;
      if new.quote_id is null and new.contract_id is null and new.project_id is null and coalesce(trim(new.customer_po), '') = '' then
        raise exception 'Tie the invoice to a quotation, contract, project or the customer''s PO number before posting';
      end if;
    end if;
    if new.wht_rate is not null then new.wht_amount := round(new.subtotal * new.wht_rate / 100, 2); end if;
  end if;
  return new;
end $$;
drop trigger if exists invoices_post_rules on public.invoices;
create trigger invoices_post_rules before update of status on public.invoices for each row execute function public.invoice_post_rules();

-- A quote converted to an invoice stays linked, with its number as the reference.
do $$ begin
  if to_regprocedure('public.convert_quote_v22(uuid)') is null then alter function public.convert_quote(uuid) rename to convert_quote_v22; end if;
end $$;
create or replace function public.convert_quote(p_quote uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid; q sales_quotes;
begin
  v := convert_quote_v22(p_quote);
  select * into q from sales_quotes where id = p_quote;
  update invoices set quote_id = p_quote, reference = coalesce(reference, q.number) where id = v;
  return v;
end $$;
revoke execute on function public.convert_quote_v22(uuid) from public, anon, authenticated;

-- Receiving a payment when the customer withheld tax: the cash is what reached the bank; the withheld part becomes a tax credit.
create or replace function public.record_payment_wht(p_invoice uuid, p_cash numeric, p_wht numeric, p_date date, p_method text,
  p_reference text default null, p_rate numeric default null, p_certificate text default null) returns void
language plpgsql security definer set search_path = public as $$
declare inv invoices; v_rate numeric; g numeric; v_je uuid;
begin
  select * into inv from invoices where id = p_invoice;
  if not found then raise exception 'Invoice not found'; end if;
  if coalesce(p_wht, 0) < 0 then raise exception 'Withholding tax cannot be negative'; end if;
  perform record_payment(p_invoice, round(coalesce(p_cash, 0) + coalesce(p_wht, 0), 2), p_date, p_method, p_reference, p_rate);
  if coalesce(p_wht, 0) > 0 then
    v_rate := case when inv.currency = 'GHS' then 1 else coalesce(nullif(p_rate, 0), inv.exchange_rate) end;
    g := round(p_wht * v_rate, 2);
    v_je := post_journal(inv.company_id, p_date, 'Withholding tax deducted by customer on ' || inv.number || coalesce(' (certificate ' || p_certificate || ')', ''),
      jsonb_build_array(jl(acct(inv.company_id, 'wht_receivable'), g, 0), jl(acct(inv.company_id, p_method), 0, g)), 'wht', inv.id);
  end if;
end $$;

-- ---------------------------------------------------------------- 4. Payment milestones as a percentage of the contract, due when work reaches a stage
alter table public.project_milestones add column if not exists kind text not null default 'progress'
  check (kind in ('advance','progress','completion','retention','other'));
alter table public.project_milestones add column if not exists pct numeric(6,2) check (pct > 0 and pct <= 100);
alter table public.project_milestones add column if not exists trigger_pct int check (trigger_pct between 0 and 100);
alter table public.project_milestones add column if not exists terms_days int check (terms_days between 0 and 365);

create or replace function public.milestone_amount() returns trigger
language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if new.pct is not null and new.status <> 'invoiced' then
    select contract_value into v from projects where id = new.project_id;
    if coalesce(v, 0) > 0 then new.amount := round(v * new.pct / 100, 2); end if;
  end if;
  if new.status = 'planned' and new.trigger_pct = 0 then new.status := 'ready'; end if;
  return new;
end $$;
drop trigger if exists project_milestones_amount on public.project_milestones;
create trigger project_milestones_amount before insert or update on public.project_milestones for each row execute function public.milestone_amount();

-- A change of contract value re-prices the milestones not yet invoiced.
create or replace function public.project_value_milestones() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.contract_value is distinct from old.contract_value then
    update project_milestones set pct = pct where project_id = new.id and pct is not null and status <> 'invoiced';
  end if;
  return null;
end $$;
drop trigger if exists projects_value_milestones on public.projects;
create trigger projects_value_milestones after update of contract_value on public.projects for each row execute function public.project_value_milestones();

-- How far the work is: the manager's figure, else the tasks (weighted by estimated hours).
create or replace function public.project_pct(p_project uuid) returns int
language sql stable security definer set search_path = public as $$
  select coalesce(p.percent_complete_override,
    (select case when sum(coalesce(estimated_hours,0)) > 0
                 then round(sum(coalesce(estimated_hours,0) * coalesce(percent_complete, case status when 'done' then 100 when 'doing' then 50 else 0 end) / 100.0) / sum(coalesce(estimated_hours,0)) * 100)::int
                 when count(*) > 0 then round(count(*) filter (where status = 'done')::numeric / count(*) * 100)::int else 0 end
       from tasks where project_id = p.id))
  from projects p where p.id = p_project;
$$;

-- Milestones whose stage of work has been reached become ready to invoice, and the project manager and Finance are told.
create or replace function public.check_milestones(p_project uuid default null) returns int
language plpgsql security definer set search_path = public as $$
declare r record; v_pct int; n int := 0;
begin
  if p_project is not null and auth.uid() is not null and not is_member((select company_id from projects where id = p_project)) then raise exception 'Not your project'; end if;
  for r in select m.*, p.company_id cid, p.number pnum, p.name pname, p.manager_id from project_milestones m join projects p on p.id = m.project_id
            where m.status = 'planned' and m.trigger_pct is not null and (p_project is null or m.project_id = p_project) loop
    v_pct := project_pct(r.project_id);
    if coalesce(v_pct, 0) >= r.trigger_pct then
      update project_milestones set status = 'ready' where id = r.id;
      perform notify(r.cid, array['accountant'], array[r.manager_id], 'milestone.ready',
        'Ready to invoice: ' || r.name || ' (' || coalesce(r.pct || '% of contract', 'GH₵ ' || r.amount) || ')',
        coalesce(r.pnum || ' ', '') || r.pname || ' is ' || v_pct || '% complete', '/projects/' || r.project_id, true);
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

-- Invoicing a milestone: due date from its payment terms; linked and referenced.
do $$ begin
  if to_regprocedure('public.invoice_milestone_v22(uuid)') is null then alter function public.invoice_milestone(uuid) rename to invoice_milestone_v22; end if;
end $$;
create or replace function public.invoice_milestone(p_milestone uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid; m project_milestones; p projects;
begin
  select * into m from project_milestones where id = p_milestone;
  select * into p from projects where id = m.project_id;
  v := invoice_milestone_v22(p_milestone);
  update invoices set milestone_id = m.id, reference = coalesce(reference, coalesce(p.number || ' ', '') || m.name),
    due_date = case when m.terms_days is not null then invoice_date + m.terms_days else coalesce(m.due_date, due_date) end,
    customer_po = coalesce(customer_po, p.client_po)
   where id = v;
  update invoice_lines set description = 'Milestone: ' || m.name || coalesce(' (' || m.pct || '% of contract sum)', '') where invoice_id = v;
  return v;
end $$;
revoke execute on function public.invoice_milestone_v22(uuid) from public, anon, authenticated;
alter table public.projects add column if not exists client_po text;

-- ---------------------------------------------------------------- 5. Stock for sale, for use in the work, or both; each item's home store
alter table public.products add column if not exists use_for text not null default 'both' check (use_for in ('sale','internal','both'));
alter table public.products add column if not exists home_warehouse_id uuid references public.warehouses(id) on delete set null;

-- ---------------------------------------------------------------- 6. Requests: SR (services), ADR (purchases), MRO (materials from store); several items; attachments
alter table public.project_requests drop constraint if exists project_requests_kind_check;
alter table public.project_requests add constraint project_requests_kind_check check (kind in ('material','subcontract','equipment','other','service'));
alter table public.project_requests add column if not exists group_no text;
alter table public.project_requests add column if not exists line_no int;
create index if not exists project_requests_group on public.project_requests (company_id, group_no);

create or replace function public.project_request_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.company_id := (select company_id from projects where id = new.project_id);
    if new.number is null then
      new.number := case when new.kind in ('service','subcontract') then next_number(new.company_id, 'SR', 'SR-') else next_number(new.company_id, 'ADR', 'ADR-') end;
    end if;
    new.requested_by := coalesce(auth.uid(), new.requested_by);
    new.requested_email := (select email from auth.users where id = new.requested_by);
    if new.status not in ('draft','submitted') then raise exception 'New requests start as draft or submitted'; end if;
  elsif new.status is distinct from old.status and new.status in ('approved','rejected','billed','ordered')
        and coalesce(current_setting('sika.requests', true), '') <> 'on' then
    raise exception 'Use Approve or Reject to decide a request';
  end if;
  if tg_op = 'UPDATE' and old.status in ('approved','billed','ordered') and coalesce(current_setting('sika.requests', true), '') <> 'on'
     and (new.qty, new.est_unit_cost, new.project_id) is distinct from (old.qty, old.est_unit_cost, old.project_id) then
    raise exception 'An approved request cannot be changed. Cancel it and raise a new one.';
  end if;
  return new;
end $$;

-- One request with several items: one number (ADR-00012 or SR-00004) and a line for each item (ADR-00012/1, /2…).
-- p_lines: [{"description","qty","unit","est_unit_cost","product_id","supplier_id","notes"}]
create or replace function public.raise_project_request(p_project uuid, p_kind text, p_lines jsonb, p_needed_by date default null,
  p_notes text default null, p_submit boolean default true) returns text
language plpgsql security definer set search_path = public as $$
declare cid uuid; v_no text; l jsonb; i int := 0; n int;
begin
  select company_id into cid from projects where id = p_project;
  if cid is null then raise exception 'Choose the project'; end if;
  perform require_member(cid);
  n := jsonb_array_length(coalesce(p_lines, '[]'::jsonb));
  if n = 0 then raise exception 'Add at least one item'; end if;
  v_no := case when p_kind in ('service','subcontract') then next_number(cid, 'SR', 'SR-') else next_number(cid, 'ADR', 'ADR-') end;
  for l in select * from jsonb_array_elements(p_lines) loop
    i := i + 1;
    if coalesce(trim(l->>'description'), '') = '' then raise exception 'Item % has no description', i; end if;
    if coalesce((l->>'qty')::numeric, 0) <= 0 then raise exception 'Item % needs a quantity', i; end if;
    insert into project_requests (company_id, project_id, kind, description, product_id, account_id, task_id, qty, unit, est_unit_cost, supplier_id, needed_by, status, notes, number, group_no, line_no)
    values (cid, p_project, p_kind, trim(l->>'description'), nullif(l->>'product_id', '')::uuid, nullif(l->>'account_id', '')::uuid, nullif(l->>'task_id', '')::uuid, (l->>'qty')::numeric, nullif(l->>'unit', ''),
            coalesce(nullif(l->>'est_unit_cost', '')::numeric, 0), nullif(l->>'supplier_id', '')::uuid, p_needed_by,
            case when p_submit then 'submitted' else 'draft' end, concat_ws(E'\n', p_notes, nullif(l->>'notes', '')),
            case when n > 1 then v_no || '/' || i else v_no end, v_no, i);
  end loop;
  return v_no;
end $$;

-- Material requests from the store are numbered MRO.
create or replace function public.stock_request_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.company_id := (select company_id from projects where id = new.project_id);
    new.number := coalesce(new.number, next_number(new.company_id, 'MRO', 'MRO-'));
    new.requested_by := coalesce(auth.uid(), new.requested_by);
    new.requested_email := (select email from auth.users where id = new.requested_by);
    if new.status not in ('draft','submitted') then raise exception 'A new stock request starts as a draft'; end if;
    if (select project_id from warehouses where id = new.to_warehouse_id) is distinct from new.project_id then
      raise exception 'Deliver the request to this project''s site store';
    end if;
  elsif new.status is distinct from old.status and coalesce(current_setting('sika.posting', true), '') <> 'on'
        and not (old.status = 'draft' and new.status in ('submitted','cancelled')) and not (old.status = 'submitted' and new.status = 'cancelled') then
    raise exception 'Use Send or Receive to move a stock request on';
  end if;
  return new;
end $$;

-- Attachments (PDF, Excel, photos) for requests and other records.
create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  parent_type text not null,          -- 'request' (by request number), 'invoice', 'customer', ...
  parent_key text not null,
  name text not null,
  storage_path text not null,
  size_bytes bigint,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists attachments_parent on public.attachments (company_id, parent_type, parent_key);
alter table public.attachments enable row level security;
drop policy if exists "members read attachments" on public.attachments;
create policy "members read attachments" on public.attachments for select using (is_member(company_id));
drop policy if exists "members add attachments" on public.attachments;
create policy "members add attachments" on public.attachments for insert with check (is_member(company_id) and uploaded_by = auth.uid());
drop policy if exists "remove own attachments" on public.attachments;
create policy "remove own attachments" on public.attachments for delete using (uploaded_by = auth.uid() or has_role(company_id, array['owner','admin']));

-- ---------------------------------------------------------------- 7. Subcontractors in HR (site records, inductions, timesheets; not on payroll)
alter table public.employees drop constraint if exists employees_employment_type_check;
alter table public.employees add constraint employees_employment_type_check
  check (employment_type in ('permanent','fixed_term','casual','contract','intern','national_service','consultant','subcontractor'));
alter table public.employees add column if not exists subcontractor_supplier_id uuid references public.suppliers(id) on delete set null;
alter table public.employees add column if not exists subcontractor_company text;
alter table public.employees add column if not exists id_type text;
alter table public.employees add column if not exists id_number text;
alter table public.employees add column if not exists trade text;

do $$ begin
  if to_regprocedure('public.calc_run_v30(uuid)') is null then alter function public.calc_run(uuid) rename to calc_run_v30; end if;
end $$;
create or replace function public.calc_run(p_run uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform calc_run_v30(p_run);
  -- Subcontractors are paid through their company's bills, never through payroll.
  delete from payslips where run_id = p_run and employee_id in (select id from employees where employment_type = 'subcontractor');
end $$;
revoke execute on function public.calc_run_v30(uuid) from public, anon, authenticated;
revoke execute on function public.calc_run(uuid) from public, anon, authenticated;

-- ---------------------------------------------------------------- 8. Company logo on documents and in the app
alter table public.companies add column if not exists logo_data text check (logo_data is null or (logo_data like 'data:image/%' and length(logo_data) < 400000));

-- ---------------------------------------------------------------- 9. Backups to the company's OneDrive (Microsoft 365), daily
create table if not exists public.company_backup (
  company_id uuid primary key references public.companies(id) on delete cascade,
  enabled boolean not null default false,
  onedrive_user text,                 -- the Microsoft 365 account whose OneDrive holds the backups
  folder text not null default 'Asnys ERP backups',
  keep_days int not null default 90 check (keep_days between 7 and 3650),
  function_url text,
  last_run_at timestamptz,
  last_status text,
  last_file text,
  last_size bigint,
  updated_at timestamptz not null default now()
);
alter table public.company_backup enable row level security;
drop policy if exists "owners manage backup" on public.company_backup;
create policy "owners manage backup" on public.company_backup for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));
insert into public.company_email_secret (company_id) select company_id from public.company_backup on conflict do nothing;
create or replace function public.company_backup_secret() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into company_email_secret (company_id) values (new.company_id) on conflict do nothing;
  return null;
end $$;
drop trigger if exists company_backup_secret on public.company_backup;
create trigger company_backup_secret after insert or update on public.company_backup for each row execute function public.company_backup_secret();

-- The tables that belong to a company (everything with a company_id), for the backup function.
create or replace function public.backup_tables() returns text[]
language sql stable security definer set search_path = public as $$
  select array_agg(c.table_name::text order by c.table_name) from information_schema.columns c join information_schema.tables t on t.table_schema = c.table_schema and t.table_name = c.table_name
   where c.table_schema = 'public' and c.column_name = 'company_id' and t.table_type = 'BASE TABLE'
     and c.table_name not in ('company_email','company_email_secret','company_telegram','message_log','notifications','user_channels');
$$;
create or replace function public.backup_hook_config(cid uuid, p_secret text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('onedrive_user', b.onedrive_user, 'folder', b.folder, 'keep_days', b.keep_days, 'company', c.name, 'code', coalesce(c.doc_prefix, ''), 'tables', backup_tables())
    from company_backup b join companies c on c.id = b.company_id join company_email_secret x on x.company_id = b.company_id
   where b.company_id = cid and b.enabled and x.secret = p_secret;
$$;
create or replace function public.backup_done(cid uuid, p_secret text, p_status text, p_file text, p_size bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from company_email_secret where company_id = cid and secret = p_secret) then raise exception 'Not allowed'; end if;
  update company_backup set last_run_at = now(), last_status = left(p_status, 500), last_file = p_file, last_size = p_size where company_id = cid;
  if p_status <> 'ok' then
    perform notify(cid, array[]::text[], null, 'backup_failed', 'Backup to OneDrive failed', left(p_status, 300), '/settings/security', true);
  end if;
end $$;
do $$ begin
  revoke execute on function public.backup_hook_config(uuid, text) from public, anon, authenticated;
  revoke execute on function public.backup_done(uuid, text, text, text, bigint) from public, anon, authenticated;
  revoke execute on function public.backup_tables() from public, anon, authenticated;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.backup_hook_config(uuid, text) to service_role;
    grant execute on function public.backup_done(uuid, text, text, text, bigint) to service_role;
    grant execute on function public.backup_tables() to service_role;
  end if;
end $$;

create or replace function public.start_backup(cid uuid) returns bigint
language plpgsql security definer set search_path = public as $$
declare b company_backup;
begin
  select * into b from company_backup where company_id = cid;
  if not found or not b.enabled or b.function_url is null or b.onedrive_user is null then return null; end if;
  return http_post_safe(b.function_url, jsonb_build_object('action', 'backup', 'company_id', cid),
    jsonb_build_object('Content-Type', 'application/json', 'x-asnys-secret', (select secret from company_email_secret where company_id = cid)));
end $$;
revoke execute on function public.start_backup(uuid) from public, anon, authenticated;

-- Owners can also download a backup to their own computer from the app (the same tables).
create or replace function public.my_backup_tables(cid uuid) returns text[]
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can download a backup'; end if;
  return backup_tables();
end $$;

create or replace function public.backup_now(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can start a backup'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  v := start_backup(cid);
  if v is null then raise exception 'Tick Back up to OneDrive, enter the OneDrive account and save first'; end if;
  return 'started';
end $$;

-- ---------------------------------------------------------------- 10. Microsoft 365 sign-in by certificate (10 years) and its expiry reminder
alter table public.company_email add column if not exists cert_thumbprint text;
alter table public.company_email add column if not exists cert_expires date;
alter table public.company_email add column if not exists secret_expires date;
alter table public.company_email add column if not exists reminded_on date;
-- The v3.3 send-mail function is replaced by asnys-m365 (email, backups and password reset in one).
update public.company_email set function_url = replace(function_url, '/functions/v1/send-mail', '/functions/v1/asnys-m365') where function_url like '%/functions/v1/send-mail';

create or replace function public.run_integration_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; v_date date; v_what text;
begin
  for r in select * from company_email where provider = 'microsoft' and enabled loop
    v_date := least(coalesce(r.cert_expires, '9999-12-31'), coalesce(r.secret_expires, '9999-12-31'));
    v_what := case when v_date = r.cert_expires then 'certificate' else 'client secret' end;
    if v_date <= current_date + 30 and (r.reminded_on is null or r.reminded_on < current_date - 7) then
      perform notify(r.company_id, array[]::text[], null, 'integration_expiry', 'Microsoft 365 ' || v_what || case when v_date < current_date then ' has EXPIRED' else ' expires ' || to_char(v_date, 'DD Mon YYYY') end,
        'Emails, invitations and OneDrive backups stop when it expires. Renew it under Settings → Telegram & email.', '/settings/messaging', true);
      update company_email set reminded_on = current_date where company_id = r.company_id; n := n + 1;
    end if;
  end loop;
  -- Daily backups to OneDrive
  for r in select company_id from company_backup where enabled and (last_run_at is null or last_run_at < now() - interval '20 hours') loop
    perform start_backup(r.company_id); n := n + 1;
  end loop;
  -- Payment milestones whose stage of work has been reached
  n := n + coalesce(check_milestones(null), 0);
  return n;
end $$;
revoke execute on function public.run_integration_reminders() from public, anon, authenticated;

create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_integration_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 11. "Forgot password" by the company's Microsoft 365 email
create table if not exists public.password_reset_log (
  id bigserial primary key,
  email text not null,
  requested_at timestamptz not null default now(),
  sent boolean not null default false
);
alter table public.password_reset_log enable row level security;
-- Called by the asnys-m365 function (service key): may this email have a reset link now, and from which company's mailbox?
create or replace function public.reset_target(p_email text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_user uuid; v_cid uuid; v_recent int;
begin
  select count(*) into v_recent from password_reset_log where lower(email) = lower(p_email) and requested_at > now() - interval '1 hour';
  insert into password_reset_log (email) values (lower(p_email));
  if v_recent >= 3 then return null; end if;
  select id into v_user from auth.users where lower(email) = lower(p_email);
  if v_user is null then return null; end if;
  select m.company_id into v_cid from memberships m join company_email e on e.company_id = m.company_id
   where m.user_id = v_user and e.provider = 'microsoft' and e.enabled order by m.created_at limit 1;
  if v_cid is null then return null; end if;
  update password_reset_log set sent = true where id = currval(pg_get_serial_sequence('public.password_reset_log', 'id'));
  return jsonb_build_object('company_id', v_cid, 'company', (select name from companies where id = v_cid),
    'from_email', (select from_email from company_email where company_id = v_cid), 'from_name', (select coalesce(from_name, (select name from companies where id = v_cid)) from company_email where company_id = v_cid),
    'app_url', coalesce((select app_url from company_telegram where company_id = v_cid), 'https://asnys-erp.pages.dev'));
end $$;
-- For invitations sent by invite-member: the company's Microsoft 365 sender, if it has one.
create or replace function public.m365_sender(cid uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('from_email', e.from_email, 'from_name', coalesce(e.from_name, c.name), 'company', c.name)
    from company_email e join companies c on c.id = e.company_id where e.company_id = cid and e.provider = 'microsoft' and e.enabled and e.from_email is not null;
$$;
do $$ begin
  revoke execute on function public.reset_target(text) from public, anon, authenticated;
  revoke execute on function public.m365_sender(uuid) from public, anon, authenticated;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.reset_target(text) to service_role;
    grant execute on function public.m365_sender(uuid) to service_role;
  end if;
end $$;

-- ---------------------------------------------------------------- 12. 2-step sign-in (authenticator app): who must use it, and who has it
alter table public.companies add column if not exists mfa_roles text[] not null default '{}';
create or replace function public.my_mfa_required() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships m join companies c on c.id = m.company_id where m.user_id = auth.uid() and m.role = any(c.mfa_roles));
$$;
create or replace function public.security_overview(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_mfa boolean := to_regclass('auth.mfa_factors') is not null; v jsonb;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  if v_mfa then
    execute 'select coalesce(jsonb_agg(jsonb_build_object(''email'', coalesce(m.email, u.email), ''role'', m.role, ''last_sign_in_at'', u.last_sign_in_at,
               ''mfa'', exists (select 1 from auth.mfa_factors f where f.user_id = m.user_id and f.status = ''verified'')) order by m.role, coalesce(m.email, u.email)), ''[]'')
               from memberships m left join auth.users u on u.id = m.user_id where m.company_id = $1' into v using cid;
  else
    select coalesce(jsonb_agg(jsonb_build_object('email', coalesce(m.email, u.email), 'role', m.role, 'last_sign_in_at', u.last_sign_in_at, 'mfa', false)), '[]')
      into v from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid;
  end if;
  return jsonb_build_object('people', v, 'mfa_roles', (select mfa_roles from companies where id = cid),
    'backup', (select to_jsonb(b) - 'function_url' from company_backup b where company_id = cid),
    'cert_expires', (select cert_expires from company_email where company_id = cid),
    'secret_expires', (select secret_expires from company_email where company_id = cid),
    'failed_resets_24h', (select count(*) from password_reset_log where requested_at > now() - interval '1 day' and not sent));
end $$;
create or replace function public.set_mfa_roles(cid uuid, p_roles text[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  update companies set mfa_roles = coalesce(p_roles, '{}') where id = cid;
  insert into audit_log (company_id, action, table_name, detail) values (cid, 'security.mfa_roles', 'companies', jsonb_build_object('roles', p_roles));
end $$;

-- ---------------------------------------------------------------- 12b. Custom roles: tick the modules and pages, and whether they may approve and void
-- A person keeps one main role and can hold any number of custom roles; they get everything those roles allow combined.
-- What a custom role may do in the database is expressed as the built-in roles it "acts as" (worked out by the app from
-- the pages ticked); owner and admin can never be granted this way.
create table if not exists public.custom_roles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null check (length(trim(name)) between 2 and 60),
  description text,
  pages text[] not null default '{}',           -- app pages (paths) this role can open
  grants text[] not null default '{}' check (grants <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  approve text[] not null default '{}' check (approve <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  void_grants text[] not null default '{}' check (void_grants <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  created_at timestamptz not null default now(),
  unique (company_id, name)
);
alter table public.custom_roles enable row level security;
drop policy if exists "members read custom roles" on public.custom_roles;
create policy "members read custom roles" on public.custom_roles for select using (is_member(company_id));
drop policy if exists "admins manage custom roles" on public.custom_roles;
create policy "admins manage custom roles" on public.custom_roles for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));

alter table public.memberships add column if not exists custom_role_ids uuid[] not null default '{}';
alter table public.memberships add column if not exists extra_roles text[] not null default '{}';
alter table public.memberships add column if not exists approve_roles text[] not null default '{}';
alter table public.memberships add column if not exists void_roles text[] not null default '{}';
alter table public.memberships add column if not exists allowed_pages text[];      -- null: the main role decides

-- The combined rights are always worked out here from the roles held, so nobody can write them directly.
create or replace function public.membership_custom_sync() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.extra_roles
    from custom_roles r left join lateral unnest(r.grants) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.approve_roles
    from custom_roles r left join lateral unnest(r.approve) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.void_roles
    from custom_roles r left join lateral unnest(r.void_grants) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  if cardinality(new.custom_role_ids) = 0 then new.allowed_pages := null;
  else select coalesce(array_agg(distinct pg) filter (where pg is not null), '{}') into new.allowed_pages
         from custom_roles r left join lateral unnest(r.pages) pg on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  end if;
  return new;
end $$;
drop trigger if exists memberships_custom_sync on public.memberships;
create trigger memberships_custom_sync before insert or update on public.memberships for each row execute function public.membership_custom_sync();

create or replace function public.custom_role_changed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update memberships set custom_role_ids = case when tg_op = 'DELETE' then array_remove(custom_role_ids, old.id) else custom_role_ids end
   where company_id = coalesce(new.company_id, old.company_id) and coalesce(new.id, old.id) = any(custom_role_ids);
  return null;
end $$;
drop trigger if exists custom_roles_changed on public.custom_roles;
create trigger custom_roles_changed after update or delete on public.custom_roles for each row execute function public.custom_role_changed();

-- A role check now also counts the custom roles a person holds.
create or replace function public.has_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or extra_roles && roles));
$$;
-- Approving a step of an approval chain needs the main role, or a custom role with "Can approve" ticked.
create or replace function public.has_approve_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or approve_roles && roles));
$$;
-- Voiding needs the main role, or a custom role with "Can void" ticked.
create or replace function public.has_void_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or void_roles && roles));
$$;

create or replace function public.can_approve_step(s approval_steps) returns boolean
language sql stable security definer set search_path = public as $$
  select s.status = 'pending'
     and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'pending' and o.step_no < s.step_no)
     and (has_role(s.company_id, array['owner'])
          or ((s.approver_user = auth.uid() or (s.approver_role is not null and has_approve_role(s.company_id, array[s.approver_role])))
              and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = auth.uid())));
$$;

create or replace function public.step_approvers(s approval_steps) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct u), '{}') from (
    select s.approver_user u where s.approver_user is not null
    union select m.user_id from memberships m where m.company_id = s.company_id and s.approver_role is not null and (m.role = s.approver_role or s.approver_role = any(m.approve_roles))
    union select m.user_id from memberships m where m.company_id = s.company_id and m.role = 'owner'
      and not exists (select 1 from memberships x where x.company_id = s.company_id and ((s.approver_role is not null and (x.role = s.approver_role or s.approver_role = any(x.approve_roles))) or x.user_id = s.approver_user))
  ) x where u is not null and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = u);
$$;

create or replace function public.can_void(p_table text, p_id uuid) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid;
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then return false; end if;
  execute format('select company_id, status from public.%I where id = $1', p_table) into v_cid, v_status using p_id;
  if v_cid is null or not (v_status = any(vr.from_status)) then return false; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  return has_role(v_cid, array['owner','admin']) or has_void_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid());
end $$;

-- Notices sent "to Finance", "to HR" etc. also reach people holding that right through a custom role.
create or replace function public.notify(cid uuid, p_roles text[], p_users uuid[], p_kind text, p_title text, p_body text default null, p_path text default null, p_include_self boolean default false)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into notifications (company_id, user_id, kind, title, body, path)
  select distinct cid, u, p_kind, p_title, p_body, p_path from (
    select m.user_id u from memberships m where m.company_id = cid and (m.role = any(p_roles) or m.extra_roles && p_roles or m.role in ('owner','admin'))
    union select unnest(coalesce(p_users, '{}'::uuid[]))) x
  where u is not null and (p_include_self or u is distinct from auth.uid());
  get diagnostics n = row_count;
  return n;
end $$;

-- Transport officers and HSE officers can also come from a custom role.
create or replace function public.is_hse(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (hse or 'hse' = any(extra_roles) or role in ('owner','admin')));
$$;
create or replace function public.hse_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (hse or 'hse' = any(extra_roles));
$$;
create or replace function public.is_transport(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (transport or 'transport' = any(extra_roles) or role in ('owner','admin','accountant','store')));
$$;
create or replace function public.transport_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or 'transport' = any(extra_roles) or role = 'store');
$$;
create or replace function public.fleet_alert_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or 'transport' = any(extra_roles) or role in ('store','owner','admin'));
$$;
revoke execute on function public.fleet_alert_users(uuid) from public, anon, authenticated;

-- Owners and admins give or take away custom roles.
create or replace function public.set_member_custom_roles(cid uuid, p_user uuid, p_roles uuid[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can give custom roles'; end if;
  if exists (select 1 from unnest(coalesce(p_roles, '{}')) r where not exists (select 1 from custom_roles c where c.id = r and c.company_id = cid)) then
    raise exception 'Unknown role';
  end if;
  update memberships set custom_role_ids = coalesce(p_roles, '{}') where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (cid, 'member.custom_roles', 'memberships', p_user, jsonb_build_object('roles', (select coalesce(jsonb_agg(name), '[]') from custom_roles where id = any(p_roles))));
end $$;

-- ---------------------------------------------------------------- 12c. Several bank accounts; each invoice says which one to pay into
create table if not exists public.company_banks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  bank_name text not null,
  branch text,
  account_name text,
  account_no text not null,
  swift text,
  currency text not null default 'GHS',
  is_default boolean not null default false,
  active boolean not null default true,
  sort int not null default 0,
  created_at timestamptz not null default now()
);
create unique index if not exists company_banks_one_default on public.company_banks (company_id) where is_default;
alter table public.company_banks enable row level security;
drop policy if exists "members read banks" on public.company_banks;
create policy "members read banks" on public.company_banks for select using (is_member(company_id));
drop policy if exists "finance manages banks" on public.company_banks;
create policy "finance manages banks" on public.company_banks for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));
alter table public.invoices add column if not exists bank_id uuid references public.company_banks(id) on delete set null;
alter table public.sales_quotes add column if not exists bank_id uuid references public.company_banks(id) on delete set null;

-- A new invoice pays into the account in its currency, else the default account.
create or replace function public.invoice_bank_default() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.bank_id is null then
    select id into new.bank_id from company_banks where company_id = new.company_id and active
     order by (currency = coalesce(new.currency, 'GHS')) desc, is_default desc, sort limit 1;
  end if;
  return new;
end $$;
drop trigger if exists invoices_bank_default on public.invoices;
create trigger invoices_bank_default before insert on public.invoices for each row execute function public.invoice_bank_default();

-- ---------------------------------------------------------------- 13. Voiding: also lets material requests through their store guard
create or replace function public.void_entry(p_table text, p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid; f text;
  flags text[] := array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle','sika.posting'];
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be voided here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  if not (has_role(v_cid, array['owner','admin']) or has_void_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid())) then
    raise exception 'You cannot void this %. Ask an admin.', lower(vr.label);
  end if;
  if v_status = 'voided' then raise exception 'Already voided'; end if;
  if not (v_status = any(vr.from_status)) then
    raise exception 'A % that is % cannot be voided. %', lower(vr.label), replace(v_status, '_', ' '),
      case when p_table = 'purchase_orders' then 'Goods have been received against it; close it instead.'
           when p_table = 'expense_claims' then 'It has been posted; reverse it with a journal.'
           when p_table = 'tenders' then 'An awarded tender has a project; cancel the project instead.'
           else 'It has already gone through.' end;
  end if;
  if p_table = 'timesheets' and exists (select 1 from timesheets where id = p_id and invoice_id is not null) then raise exception 'This time has been invoiced'; end if;
  foreach f in array flags loop perform set_config(f, 'on', true); end loop;
  execute format('update public.%I set status = ''voided'', void_reason = $2, voided_at = now(), voided_by = auth.uid() where id = $1', p_table) using p_id, trim(p_reason);
  foreach f in array flags loop perform set_config(f, 'off', true); end loop;
  update approval_steps set status = 'skipped' where doc_id = p_id and status = 'pending';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.voided', p_table, p_id, jsonb_build_object('what', vr.label, 'was', v_status, 'reason', trim(p_reason)));
end $$;

-- ---------------------------------------------------------------- 13a. Restore (un-void): owners and admins, with a reason; back to the status it had
create or replace function public.unvoid_entry(p_table text, p_id uuid, p_reason text) returns text
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_was text; f text;
  flags text[] := array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle','sika.posting'];
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be restored here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being restored'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  if not has_role(v_cid, array['owner','admin']) then raise exception 'Only an owner or admin can restore a voided entry'; end if;
  if v_status <> 'voided' then raise exception 'This % is not voided', lower(vr.label); end if;
  select detail->>'was' into v_was from audit_log where company_id = v_cid and action = 'entry.voided' and table_name = p_table and row_id = p_id order by id desc limit 1;
  if v_was is null then raise exception 'The status before voiding is not on record, so it cannot be restored'; end if;
  foreach f in array flags loop perform set_config(f, 'on', true); end loop;
  execute format('update public.%I set status = $2, void_reason = null, voided_at = null, voided_by = null where id = $1', p_table) using p_id, v_was;
  foreach f in array flags loop perform set_config(f, 'off', true); end loop;
  update approval_steps set status = 'pending' where doc_id = p_id and status = 'skipped';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.restored', p_table, p_id, jsonb_build_object('what', vr.label, 'back_to', v_was, 'reason', trim(p_reason)));
  return v_was;
end $$;

-- ---------------------------------------------------------------- 13b. Numbered entries are never deleted: void them instead
-- Once a document has a number it stays in the system for the audit trail. Drafts without a number can still be deleted,
-- and deleting a whole company (cascade) is not blocked.
create or replace function public.keep_numbered() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if pg_trigger_depth() = 1 and coalesce(to_jsonb(old)->>'number', '') <> '' and coalesce(current_setting('asnys.purge', true), '') <> 'on' then
    raise exception '% is numbered, so it cannot be deleted. Use Void instead: it stays in the records marked voided, with the reason.', to_jsonb(old)->>'number';
  end if;
  return old;
end $$;
do $$ declare t text; begin
  for t in select v.table_name from void_rules v
             where exists (select 1 from information_schema.columns c where c.table_schema = 'public' and c.table_name = v.table_name and c.column_name = 'number') loop
    execute format('drop trigger if exists %I on public.%I', t || '_keep_numbered', t);
    execute format('create trigger %I before delete on public.%I for each row execute function public.keep_numbered()', t || '_keep_numbered', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- 14. New companies
create or replace function public.company_seed_v34() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform seed_accounts_v34(new.id);
  insert into number_formats (company_id, key, prefix) values (new.id, 'ADR', 'ADR'), (new.id, 'SR', 'SR'), (new.id, 'MRO', 'MRO') on conflict do nothing;
  return null;
end $$;
drop trigger if exists companies_seed_v34 on public.companies;
create trigger companies_seed_v34 after insert on public.companies for each row execute function public.company_seed_v34();

-- Audit the new settings tables too.
do $$ declare t text; begin
  foreach t in array array['number_formats','attachments','company_backup','custom_roles','company_banks'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- Progress changes make milestones ready straight away.
create or replace function public.progress_milestones() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform check_milestones(case when tg_table_name = 'tasks' then (to_jsonb(new)->>'project_id')::uuid else new.id end);
  return null;
end $$;
drop trigger if exists tasks_progress_milestones on public.tasks;
create trigger tasks_progress_milestones after update of status, percent_complete on public.tasks for each row execute function public.progress_milestones();
drop trigger if exists projects_progress_milestones on public.projects;
create trigger projects_progress_milestones after update of percent_complete_override on public.projects for each row execute function public.progress_milestones();

-- ================================================================ 0023_asnys_v3_5.sql
-- Asnys ERP v3.5 — QuickBooks-style sales and accounting
--   1. Receive payment: one receipt split over several invoices, into the bank account you choose; anything extra is kept
--      as the customer's credit (customer deposits) and applied to later invoices.
--   2. Sales receipt: a cash sale in one step (invoice + payment), without the strict-invoice checks.
--   3. Pay bills: several supplier bills paid together from one account, with withholding tax deducted.
--   4. Bank feed: statement lines imported from the bank's CSV, rules that suggest the account, matched or posted.
--   5. Reports: cash flow, sales by customer, sales by product, profit by project and by customer.
-- Run after 0022. Safe to run twice.

-- ---------------------------------------------------------------- 0. Accounts
create or replace function public.seed_accounts_v35(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  -- 2500 has existed since v1.1 without a key; give it one so receipts can use it.
  if not exists (select 1 from accounts where company_id = cid and system_key = 'customer_deposits') then
    if exists (select 1 from accounts where company_id = cid and code = '2500' and system_key is null) then
      update accounts set system_key = 'customer_deposits' where company_id = cid and code = '2500';
    else
      insert into accounts (company_id, code, name, type, system_key)
      values (cid, case when exists (select 1 from accounts where company_id = cid and code = '2500') then '2510' else '2500' end, 'Customer deposits and credits', 'liability', 'customer_deposits')
      on conflict do nothing;
    end if;
  end if;
  if not exists (select 1 from accounts where company_id = cid and system_key = 'wht_payable') then
    insert into accounts (company_id, code, name, type, system_key)
    values (cid, case when exists (select 1 from accounts where company_id = cid and code = '2270') then '2275' else '2270' end, 'Withholding tax payable (deducted from suppliers)', 'liability', 'wht_payable')
    on conflict do nothing;
  end if;
end $$;
select public.seed_accounts_v35(id) from public.companies;

-- Which payment method a cash, MoMo or bank account counts as.
create or replace function public.method_of(p_account uuid) returns text
language sql stable security definer set search_path = public as $$
  select case when system_key = 'cash' or name ilike '%cash%' then 'cash' when system_key = 'momo' or name ilike '%momo%' or name ilike '%mobile money%' then 'momo' else 'bank' end
    from accounts where id = p_account;
$$;

alter table public.payments add column if not exists account_id uuid references public.accounts(id);
alter table public.payments add column if not exists receipt_id uuid;
alter table public.bill_payments add column if not exists account_id uuid references public.accounts(id);
alter table public.bill_payments add column if not exists batch_id uuid;
alter table public.bill_payments add column if not exists wht_amount numeric(14,2) not null default 0;

-- ---------------------------------------------------------------- 1. Receive payment over several invoices, with customer credit
create table if not exists public.customer_receipts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  customer_id uuid not null references public.customers(id),
  receipt_date date not null,
  account_id uuid not null references public.accounts(id),
  currency text not null default 'GHS',
  exchange_rate numeric(14,6) not null default 1,
  amount numeric(14,2) not null check (amount > 0),
  unapplied numeric(14,2) not null default 0 check (unapplied >= 0),
  reference text,
  memo text,
  status text not null default 'posted' check (status in ('posted','voided')),
  journal_entry_id uuid references public.journal_entries(id),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists customer_receipts_customer on public.customer_receipts (company_id, customer_id);
alter table public.customer_receipts enable row level security;
drop policy if exists "finance and sales read receipts" on public.customer_receipts;
create policy "finance and sales read receipts" on public.customer_receipts for select using (has_role(company_id, array['owner','admin','accountant','sales']));

-- p_allocs: [{"invoice_id": "...", "amount": 1000}] in the receipt's currency. Every invoice must be this customer's and in that currency.
create or replace function public.receive_payment(cid uuid, p_customer uuid, p_date date, p_account uuid, p_amount numeric,
  p_allocs jsonb default '[]', p_reference text default null, p_memo text default null, p_currency text default 'GHS', p_rate numeric default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_no text; a jsonb; inv invoices; v_alloc numeric; v_wht numeric; v_total numeric := 0; v_rate numeric; v_lines jsonb := '[]'; v_je uuid;
  g_bank numeric; g_ar numeric; g_wht numeric; g_sum_ar numeric := 0; g_sum_wht numeric := 0; v_left numeric; v_method text; v_cust customers;
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  select * into v_cust from customers where id = p_customer and company_id = cid;
  if not found then raise exception 'Choose the customer'; end if;
  perform paying_account(cid, p_account);
  if round(coalesce(p_amount, 0), 2) <= 0 then raise exception 'Enter the amount received'; end if;
  v_rate := case when coalesce(p_currency, 'GHS') = 'GHS' then 1 else nullif(p_rate, 0) end;
  if v_rate is null then raise exception 'Type in the exchange rate for %', p_currency; end if;
  v_method := method_of(p_account);
  select coalesce(sum(round((x->>'amount')::numeric, 2)), 0) into v_total from jsonb_array_elements(coalesce(p_allocs, '[]')) x where coalesce((x->>'amount')::numeric, 0) > 0;
  if v_total > round(p_amount, 2) then raise exception 'You applied % to invoices but received only %', v_total, round(p_amount, 2); end if;

  v_no := next_number(cid, 'RCP', 'RCP-');
  insert into customer_receipts (company_id, number, customer_id, receipt_date, account_id, currency, exchange_rate, amount, unapplied, reference, memo)
  values (cid, v_no, p_customer, p_date, p_account, coalesce(p_currency, 'GHS'), v_rate, round(p_amount, 2), round(p_amount, 2) - v_total, p_reference, p_memo)
  returning id into v_id;

  g_bank := round(p_amount * v_rate, 2);
  for a in select * from jsonb_array_elements(coalesce(p_allocs, '[]')) loop
    v_alloc := round(coalesce((a->>'amount')::numeric, 0), 2);
    v_wht := round(coalesce((a->>'wht')::numeric, 0), 2);     -- withholding tax the customer deducted (paid to GRA for us)
    continue when v_alloc + v_wht <= 0;
    if v_alloc < 0 or v_wht < 0 then raise exception 'Amounts cannot be negative'; end if;
    select * into inv from invoices where id = (a->>'invoice_id')::uuid and company_id = cid for update;
    if not found or inv.customer_id <> p_customer then raise exception 'An invoice is not this customer''s'; end if;
    if inv.status not in ('posted') then raise exception '% is not open for payment', coalesce(inv.number, 'A draft invoice'); end if;
    if inv.currency <> coalesce(p_currency, 'GHS') then raise exception '% is in %; receive it in that currency', inv.number, inv.currency; end if;
    v_left := inv.total - inv.amount_paid - inv.amount_credited;
    if v_alloc + v_wht > v_left then raise exception '% has only % left to pay', inv.number, v_left; end if;
    g_ar := round((v_alloc + v_wht) * inv.exchange_rate, 2);
    g_wht := round(v_wht * v_rate, 2);
    g_sum_ar := g_sum_ar + g_ar; g_sum_wht := g_sum_wht + g_wht;
    insert into payments (company_id, invoice_id, payment_date, amount, method, reference, exchange_rate, account_id, receipt_id)
    values (cid, inv.id, p_date, v_alloc + v_wht, v_method, coalesce(p_reference, v_no) || case when v_wht > 0 then ' (incl. WHT ' || v_wht || ')' else '' end, v_rate, p_account, v_id);
    update invoices set amount_paid = amount_paid + v_alloc + v_wht,
      status = case when amount_paid + amount_credited + v_alloc + v_wht >= total then 'paid' else 'posted' end where id = inv.id;
    v_lines := v_lines || jl(acct(cid, 'ar'), 0, g_ar);
    if g_wht > 0 then v_lines := v_lines || jl(acct(cid, 'wht_receivable'), g_wht, 0); end if;
  end loop;
  -- Bank in full; receivables at each invoice's own rate; the extra waits as the customer's credit; rounding/rate difference to FX.
  v_lines := v_lines || jl(p_account, g_bank, 0);
  if round(p_amount, 2) - v_total > 0 then v_lines := v_lines || jl(acct(cid, 'customer_deposits'), 0, round((round(p_amount, 2) - v_total) * v_rate, 2)); end if;
  declare d numeric;
  begin
    d := g_bank + g_sum_wht - g_sum_ar - case when round(p_amount, 2) - v_total > 0 then round((round(p_amount, 2) - v_total) * v_rate, 2) else 0 end;
    if d <> 0 then v_lines := v_lines || jl(acct(cid, 'fx'), greatest(-d, 0), greatest(d, 0)); end if;
  end;
  v_je := post_journal(cid, p_date, 'Payment received from ' || v_cust.name || ' (' || v_no || ')' || coalesce(' — ' || p_reference, ''), v_lines, 'receipt', v_id);
  update customer_receipts set journal_entry_id = v_je where id = v_id;
  return v_id;
end $$;

-- Use a customer's unapplied credit against an invoice (same currency).
create or replace function public.apply_customer_credit(p_receipt uuid, p_invoice uuid, p_amount numeric, p_date date default current_date)
returns void language plpgsql security definer set search_path = public as $$
declare r customer_receipts; inv invoices; v numeric; g_dep numeric; g_ar numeric; v_je uuid;
begin
  select * into r from customer_receipts where id = p_receipt for update;
  if not found or r.status <> 'posted' then raise exception 'Receipt not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant','sales']);
  select * into inv from invoices where id = p_invoice for update;
  if not found or inv.customer_id <> r.customer_id or inv.status <> 'posted' then raise exception 'Choose an open invoice of the same customer'; end if;
  if inv.currency <> r.currency then raise exception 'The credit is in % but the invoice is in %', r.currency, inv.currency; end if;
  v := round(least(coalesce(p_amount, 0), r.unapplied, inv.total - inv.amount_paid - inv.amount_credited), 2);
  if v <= 0 then raise exception 'Nothing to apply'; end if;
  g_dep := round(v * r.exchange_rate, 2); g_ar := round(v * inv.exchange_rate, 2);
  v_je := post_journal(r.company_id, greatest(p_date, r.receipt_date), 'Customer credit ' || r.number || ' applied to ' || inv.number,
    jsonb_build_array(jl(acct(r.company_id, 'customer_deposits'), g_dep, 0), jl(acct(r.company_id, 'ar'), 0, g_ar),
      jl(acct(r.company_id, 'fx'), greatest(g_ar - g_dep, 0), greatest(g_dep - g_ar, 0))), 'receipt', r.id);
  insert into payments (company_id, invoice_id, payment_date, amount, method, reference, exchange_rate, account_id, receipt_id, journal_entry_id)
  values (r.company_id, inv.id, greatest(p_date, r.receipt_date), v, method_of(r.account_id), 'Credit ' || r.number, r.exchange_rate, r.account_id, r.id, v_je);
  update invoices set amount_paid = amount_paid + v, status = case when amount_paid + amount_credited + v >= total then 'paid' else 'posted' end where id = inv.id;
  update customer_receipts set unapplied = unapplied - v where id = r.id;
end $$;

-- A receipt entered in error: reverse its journal, take the amounts off the invoices; it stays on record as voided.
create or replace function public.void_customer_receipt(p_receipt uuid, p_reason text, p_date date default current_date)
returns void language plpgsql security definer set search_path = public as $$
declare r customer_receipts; p record; v_lines jsonb;
begin
  select * into r from customer_receipts where id = p_receipt for update;
  if not found then raise exception 'Receipt not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant']);
  if r.status = 'voided' then raise exception 'Already voided'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  if exists (select 1 from payments where receipt_id = r.id and reference like 'Credit %') then raise exception 'Part of this credit has been applied to invoices. Reverse those first with a credit note or journal.'; end if;
  for p in select * from payments where receipt_id = r.id loop
    update invoices set amount_paid = amount_paid - p.amount, status = 'posted' where id = p.invoice_id;
  end loop;
  delete from payments where receipt_id = r.id;
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit, 'project_id', l.project_id)) into v_lines
    from journal_lines l where l.entry_id = r.journal_entry_id;
  perform post_journal(r.company_id, greatest(p_date, r.receipt_date), 'Void of receipt ' || r.number || ': ' || trim(p_reason), v_lines, 'receipt', r.id);
  update customer_receipts set status = 'voided', unapplied = 0 where id = r.id;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (r.company_id, 'entry.voided', 'customer_receipts', r.id, jsonb_build_object('what', 'Receipt', 'number', r.number, 'reason', trim(p_reason)));
end $$;

-- Open items for the Receive payment screen.
create or replace function public.customer_open_items(cid uuid, p_customer uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  return jsonb_build_object(
    'invoices', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'number', i.number, 'invoice_date', i.invoice_date, 'due_date', i.due_date, 'currency', i.currency,
        'total', i.total, 'open', i.total - i.amount_paid - i.amount_credited, 'reference', i.reference, 'customer_po', i.customer_po, 'wht_amount', i.wht_amount) order by i.due_date nulls last, i.invoice_date)
      from invoices i where i.company_id = cid and i.customer_id = p_customer and i.status = 'posted' and i.total - i.amount_paid - i.amount_credited > 0), '[]'),
    'credits', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'number', r.number, 'receipt_date', r.receipt_date, 'currency', r.currency, 'unapplied', r.unapplied) order by r.receipt_date)
      from customer_receipts r where r.company_id = cid and r.customer_id = p_customer and r.status = 'posted' and r.unapplied > 0), '[]'));
end $$;

-- ---------------------------------------------------------------- 2. Sales receipt (cash sale): invoice and payment in one step
alter table public.invoices add column if not exists cash_sale boolean not null default false;
create or replace function public.invoice_post_rules() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers; v_strict boolean;
begin
  if old.status = 'draft' and new.status <> 'draft' then
    select strict_invoices into v_strict from companies where id = new.company_id;
    if v_strict and not new.cash_sale then
      select * into c from customers where id = new.customer_id;
      if coalesce(trim(c.tin), '') = '' then raise exception 'Add % TIN to the customer record before posting (Sales → Customers)', c.name || '''s'; end if;
      if coalesce(trim(new.reference), '') = '' then raise exception 'Enter the invoice reference before posting'; end if;
      if new.quote_id is null and new.contract_id is null and new.project_id is null and coalesce(trim(new.customer_po), '') = '' then
        raise exception 'Tie the invoice to a quotation, contract, project or the customer''s PO number before posting';
      end if;
    end if;
    if new.wht_rate is not null then new.wht_amount := round(new.subtotal * new.wht_rate / 100, 2); end if;
  end if;
  return new;
end $$;

create or replace function public.complete_sales_receipt(p_invoice uuid, p_account uuid, p_reference text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare inv invoices; v uuid;
begin
  select * into inv from invoices where id = p_invoice;
  if not found then raise exception 'Invoice not found'; end if;
  perform require_member(inv.company_id, array['owner','admin','accountant','sales']);
  update invoices set cash_sale = true, due_date = coalesce(due_date, invoice_date) where id = p_invoice and status = 'draft';
  if inv.status = 'draft' then perform post_invoice(p_invoice); end if;
  select * into inv from invoices where id = p_invoice;
  v := receive_payment(inv.company_id, inv.customer_id, inv.invoice_date, p_account, inv.total - inv.amount_paid - inv.amount_credited,
    jsonb_build_array(jsonb_build_object('invoice_id', inv.id, 'amount', inv.total - inv.amount_paid - inv.amount_credited)), p_reference, 'Sales receipt ' || inv.number, inv.currency, inv.exchange_rate);
  return v;
end $$;

-- ---------------------------------------------------------------- 3. Pay several bills at once, from the account you choose, with WHT deducted
create table if not exists public.bill_payment_batches (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  pay_date date not null,
  account_id uuid not null references public.accounts(id),
  reference text,
  total_paid numeric(14,2) not null default 0,
  total_wht numeric(14,2) not null default 0,
  bills int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
alter table public.bill_payment_batches enable row level security;
drop policy if exists "finance reads bill batches" on public.bill_payment_batches;
create policy "finance reads bill batches" on public.bill_payment_batches for select using (has_role(company_id, array['owner','admin','accountant']));

-- p_items: [{"bill_id": "...", "amount": 1000, "wht": 75, "rate": 15.2}] in each bill's currency; amount is what is paid out,
-- wht what is kept back for GRA. Both together come off the bill.
create or replace function public.pay_bills(cid uuid, p_date date, p_account uuid, p_items jsonb, p_reference text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_batch uuid; v_no text; x jsonb; b bills; v_pay numeric; v_wht numeric; v_rate numeric; g_bank numeric; g_ap numeric; g_wht numeric;
  v_je uuid; v_id uuid; n int := 0; t_pay numeric := 0; t_wht numeric := 0; v_method text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  perform paying_account(cid, p_account);
  v_method := method_of(p_account);
  v_no := next_number(cid, 'BPB', 'BPB-');
  insert into bill_payment_batches (company_id, number, pay_date, account_id, reference) values (cid, v_no, p_date, p_account, p_reference) returning id into v_batch;
  for x in select * from jsonb_array_elements(coalesce(p_items, '[]')) loop
    v_pay := round(coalesce((x->>'amount')::numeric, 0), 2); v_wht := round(coalesce((x->>'wht')::numeric, 0), 2);
    continue when v_pay + v_wht <= 0;
    if v_pay < 0 or v_wht < 0 then raise exception 'Amounts cannot be negative'; end if;
    select * into b from bills where id = (x->>'bill_id')::uuid and company_id = cid for update;
    if not found then raise exception 'Bill not found'; end if;
    if b.status <> 'posted' then raise exception '% is not open for payment', coalesce(b.number, 'A draft bill'); end if;
    if v_pay + v_wht > b.total - b.amount_paid then raise exception '% has only % left to pay', b.number, b.total - b.amount_paid; end if;
    v_rate := case when b.currency = 'GHS' then 1 else coalesce(nullif((x->>'rate')::numeric, 0), b.exchange_rate) end;
    g_bank := round(v_pay * v_rate, 2); g_wht := round(v_wht * v_rate, 2); g_ap := round((v_pay + v_wht) * b.exchange_rate, 2);
    insert into bill_payments (company_id, bill_id, payment_date, amount, method, reference, exchange_rate, account_id, batch_id, wht_amount)
    values (cid, b.id, p_date, v_pay + v_wht, v_method, coalesce(p_reference, v_no), v_rate, p_account, v_batch, v_wht) returning id into v_id;
    v_je := post_journal(cid, p_date, 'Payment to supplier for ' || b.number || ' (' || v_no || ')' || case when v_wht > 0 then ', WHT withheld' else '' end,
      jsonb_build_array(jl(acct(cid, 'ap'), g_ap, 0), jl(p_account, 0, g_bank),
        case when g_wht > 0 then jl(acct(cid, 'wht_payable'), 0, g_wht) else jl(p_account, 0, 0) end,
        jl(acct(cid, 'fx'), greatest(g_bank + g_wht - g_ap, 0), greatest(g_ap - g_bank - g_wht, 0))), 'bill_payment', v_id);
    update bill_payments set journal_entry_id = v_je where id = v_id;
    update bills set amount_paid = amount_paid + v_pay + v_wht, status = case when amount_paid + v_pay + v_wht >= total then 'paid' else 'posted' end where id = b.id;
    n := n + 1; t_pay := t_pay + g_bank; t_wht := t_wht + g_wht;
  end loop;
  if n = 0 then raise exception 'Tick at least one bill and enter what to pay'; end if;
  update bill_payment_batches set total_paid = t_pay, total_wht = t_wht, bills = n where id = v_batch;
  return v_batch;
end $$;

-- ---------------------------------------------------------------- 4. Bank feed: imported statement lines and rules
create table if not exists public.bank_rules (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  contains text not null,                      -- words in the bank's description, e.g. "ECG" or "SALARY"
  direction text not null default 'any' check (direction in ('in','out','any')),
  counter_account_id uuid not null references public.accounts(id),
  payee text,
  project_id uuid references public.projects(id) on delete set null,
  priority int not null default 100,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.bank_rules enable row level security;
drop policy if exists "finance manages rules" on public.bank_rules;
create policy "finance manages rules" on public.bank_rules for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

create table if not exists public.bank_feed_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id),
  txn_date date not null,
  description text not null,
  reference text,
  amount numeric(14,2) not null check (amount <> 0),   -- positive = money in, negative = money out
  fingerprint text not null,
  status text not null default 'new' check (status in ('new','done','ignored')),
  done_as text,                                        -- what it became: payment, bill payment, money in/out, matched
  done_ref text,
  batch text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  unique (company_id, account_id, fingerprint)
);
create index if not exists bank_feed_open on public.bank_feed_lines (company_id, account_id, status, txn_date);
alter table public.bank_feed_lines enable row level security;
drop policy if exists "finance manages feed" on public.bank_feed_lines;
create policy "finance manages feed" on public.bank_feed_lines for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

-- Upload: lines already imported (same date, amount, description and reference) are skipped.
create or replace function public.import_bank_lines(cid uuid, p_account uuid, p_lines jsonb, p_batch text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare x jsonb; n_new int := 0; n_dup int := 0; v_fp text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  perform paying_account(cid, p_account);
  for x in select * from jsonb_array_elements(coalesce(p_lines, '[]')) loop
    continue when coalesce((x->>'amount')::numeric, 0) = 0 or nullif(x->>'date', '') is null;
    v_fp := md5((x->>'date') || '|' || round((x->>'amount')::numeric, 2)::text || '|' || lower(trim(coalesce(x->>'description', ''))) || '|' || lower(trim(coalesce(x->>'reference', ''))));
    insert into bank_feed_lines (company_id, account_id, txn_date, description, reference, amount, fingerprint, batch)
    values (cid, p_account, (x->>'date')::date, left(coalesce(nullif(trim(x->>'description'), ''), '(no description)'), 400), nullif(trim(x->>'reference'), ''),
            round((x->>'amount')::numeric, 2), v_fp, p_batch)
    on conflict (company_id, account_id, fingerprint) do nothing;
    if found then n_new := n_new + 1; else n_dup := n_dup + 1; end if;
  end loop;
  return jsonb_build_object('added', n_new, 'skipped', n_dup);
end $$;

-- What each open line could be: an existing entry in the books with the same amount within 5 days, an open invoice or
-- bill of that amount (or whose number is in the description), or a rule.
create or replace function public.bank_feed_suggestions(cid uuid, p_account uuid)
returns table (line_id uuid, kind text, target_id uuid, label text, amount numeric, counter_account_id uuid, payee text, project_id uuid)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with open as (select * from bank_feed_lines f where f.company_id = cid and f.account_id = p_account and f.status = 'new'),
  booked as (   -- entries already in the books on this account and not yet matched to a line
    select je.id, je.entry_date, je.memo, sum(l.debit - l.credit) amt
      from journal_entries je join journal_lines l on l.entry_id = je.id
     where je.company_id = cid and l.account_id = p_account and l.reconciliation_id is null
       and not exists (select 1 from bank_feed_lines f where f.company_id = cid and f.done_ref = je.id::text)
     group by je.id, je.entry_date, je.memo)
  select o.id, 'match', b.id, 'Already in the books: ' || b.memo, b.amt, null::uuid, null::text, null::uuid
    from open o join booked b on b.amt = o.amount and abs(b.entry_date - o.txn_date) <= 5
  union all
  select o.id, 'invoice', i.id, 'Payment of ' || i.number || ' — ' || c.name, i.total - i.amount_paid - i.amount_credited, null, c.name, i.project_id
    from open o join invoices i on i.company_id = cid and i.status = 'posted' and i.currency = 'GHS'
    join customers c on c.id = i.customer_id
   where o.amount > 0 and (i.total - i.amount_paid - i.amount_credited = o.amount or (i.number is not null and o.description || ' ' || coalesce(o.reference, '') ilike '%' || i.number || '%')
        or (i.total - i.amount_paid - i.amount_credited - coalesce(i.wht_amount, 0) = o.amount and coalesce(i.wht_amount, 0) > 0))
  union all
  select o.id, 'bill', b.id, 'Pay ' || b.number || ' — ' || s.name, b.total - b.amount_paid, null, s.name, null
    from open o join bills b on b.company_id = cid and b.status = 'posted' and b.currency = 'GHS'
    join suppliers s on s.id = b.supplier_id
   where o.amount < 0 and (b.total - b.amount_paid = -o.amount or (b.number is not null and o.description ilike '%' || b.number || '%')
        or (b.supplier_ref is not null and length(b.supplier_ref) >= 3 and o.description || ' ' || coalesce(o.reference, '') ilike '%' || b.supplier_ref || '%'))
  union all
  select distinct on (o.id) o.id, 'rule', r.id, r.name || ' → ' || a.code || ' ' || a.name, abs(o.amount), r.counter_account_id, r.payee, r.project_id
    from open o join bank_rules r on r.company_id = cid and r.active and o.description || ' ' || coalesce(o.reference, '') ilike '%' || r.contains || '%'
         and (r.direction = 'any' or (r.direction = 'in' and o.amount > 0) or (r.direction = 'out' and o.amount < 0))
    join accounts a on a.id = r.counter_account_id
   order by 1, 2;
end $$;

-- Close a line: matched to an entry already in the books, or after the app posted it (payment, bill payment, money in/out).
create or replace function public.bank_line_done(p_line uuid, p_as text, p_ref text default null) returns void
language plpgsql security definer set search_path = public as $$
declare f bank_feed_lines;
begin
  select * into f from bank_feed_lines where id = p_line for update;
  if not found then raise exception 'Line not found'; end if;
  perform require_member(f.company_id, array['owner','admin','accountant']);
  update bank_feed_lines set status = case when p_as = 'ignored' then 'ignored' when p_as = 'reopen' then 'new' else 'done' end,
    done_as = case when p_as in ('ignored','reopen') then null else p_as end, done_ref = case when p_as in ('ignored','reopen') then null else p_ref end where id = p_line;
end $$;

-- ---------------------------------------------------------------- 5. Reports
-- Cash flow (direct): every movement on cash, MoMo and bank accounts, sorted by what was on the other side.
create or replace function public.cash_flow(cid uuid, p_from date, p_to date)
returns table (section text, line text, amount numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with banks as (select id from accounts where company_id = cid and is_bank),
  ent as (select distinct l.entry_id from journal_lines l join journal_entries e on e.id = l.entry_id
           where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date between p_from and p_to),
  other as (select a.*, l.credit - l.debit amt from journal_lines l join accounts a on a.id = l.account_id
             where l.entry_id in (select entry_id from ent) and l.account_id not in (select id from banks)),
  classed as (
    select case
             when o.system_key in ('fa_cost','fa_accdep','disposal') or (o.type = 'asset' and o.system_key is null and o.code between '1500' and '1999') then '2 Investing'
             when o.type = 'equity' or o.code = '2400' or (o.type = 'liability' and o.system_key is null and o.name ilike '%loan%') then '3 Financing'
             else '1 Operating' end sec,
           case
             when o.system_key = 'ar' then 'Received from customers'
             when o.system_key = 'customer_deposits' then 'Customer deposits'
             when o.system_key in ('ap','grni') then 'Paid to suppliers'
             when o.system_key in ('net_pay','salaries','paye','ssnit1','tier2','payroll_deductions','employer_ssnit') then 'Salaries, PAYE and pensions'
             when o.system_key in ('vat_out','nhil_out','getf_out','vat_in','nhil_in','getf_in','wht_payable','wht_receivable') then 'VAT, levies and withholding tax'
             when o.system_key in ('staff_advances','staff_loans','reimburse') then 'Staff advances, loans and claims'
             when o.type = 'income' then 'Other income received'
             when o.type = 'expense' then o.code || ' ' || o.name
             else o.code || ' ' || o.name end ln,
           o.amt from other o)
  select c.sec, c.ln, round(sum(c.amt), 2) from classed c group by c.sec, c.ln having round(sum(c.amt), 2) <> 0
  union all
  select '0 Opening', 'Cash and bank at ' || to_char(p_from, 'DD Mon YYYY'), round(coalesce(sum(l.debit - l.credit), 0), 2)
    from journal_lines l join journal_entries e on e.id = l.entry_id where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date < p_from
  union all
  select '9 Closing', 'Cash and bank at ' || to_char(p_to, 'DD Mon YYYY'), round(coalesce(sum(l.debit - l.credit), 0), 2)
    from journal_lines l join journal_entries e on e.id = l.entry_id where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date <= p_to
  order by 1, 3;
end $$;

-- Sales by customer or by product/service, in GH₵, net of credit notes.
create or replace function public.sales_by(cid uuid, p_from date, p_to date, p_by text default 'customer')
returns table (name text, docs bigint, qty numeric, net numeric, tax numeric, total numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  if p_by = 'product' then
    return query
    select coalesce(p.name, '(services and other lines)'), count(distinct i.id), sum(l.qty), round(sum(l.qty * l.unit_price * i.exchange_rate), 2), 0::numeric, round(sum(l.qty * l.unit_price * i.exchange_rate), 2)
      from invoices i join invoice_lines l on l.invoice_id = i.id left join products p on p.id = l.product_id
     where i.company_id = cid and i.status in ('posted','paid') and i.invoice_date between p_from and p_to
     group by coalesce(p.name, '(services and other lines)') order by 4 desc;
  else
    return query
    with s as (
      select i.customer_id, count(*) n, sum(i.subtotal * i.exchange_rate) sub, sum((i.total - i.subtotal) * i.exchange_rate) tx
        from invoices i where i.company_id = cid and i.status in ('posted','paid') and i.invoice_date between p_from and p_to group by i.customer_id),
    cr as (
      select n.customer_id, sum(n.subtotal * coalesce(n.exchange_rate, 1)) sub, sum((n.total - n.subtotal) * coalesce(n.exchange_rate, 1)) tx
        from credit_notes n where n.company_id = cid and n.status = 'posted' and n.credit_date between p_from and p_to group by n.customer_id)
    select c.name, coalesce(s.n, 0), null::numeric, round(coalesce(s.sub, 0) - coalesce(cr.sub, 0), 2), round(coalesce(s.tx, 0) - coalesce(cr.tx, 0), 2),
           round(coalesce(s.sub, 0) + coalesce(s.tx, 0) - coalesce(cr.sub, 0) - coalesce(cr.tx, 0), 2)
      from customers c left join s on s.customer_id = c.id left join cr on cr.customer_id = c.id
     where c.company_id = cid and (s.customer_id is not null or cr.customer_id is not null)
     order by 4 desc;
  end if;
end $$;

-- Profit by project (from the ledger lines tagged to each project) or by customer (their projects plus invoices without a project).
create or replace function public.profit_by(cid uuid, p_from date, p_to date, p_by text default 'project')
returns table (name text, detail text, income numeric, costs numeric, profit numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  if p_by = 'customer' then
    return query
    with pl as (
      select pr.customer_id, sum(case when a.type = 'income' then l.credit - l.debit else 0 end) inc, sum(case when a.type = 'expense' then l.debit - l.credit else 0 end) cst
        from journal_lines l join journal_entries e on e.id = l.entry_id join accounts a on a.id = l.account_id join projects pr on pr.id = l.project_id
       where l.company_id = cid and e.entry_date between p_from and p_to group by pr.customer_id),
    loose as (   -- invoices with no project: their income only
      select i.customer_id, sum(i.subtotal * i.exchange_rate) inc from invoices i
       where i.company_id = cid and i.project_id is null and i.status in ('posted','paid') and i.invoice_date between p_from and p_to group by i.customer_id)
    select coalesce(c.name, '(no customer)'), (select count(*) from projects x where x.customer_id = c.id and not x.is_template)::text || ' project(s)',
           round(coalesce(pl.inc, 0) + coalesce(loose.inc, 0), 2), round(coalesce(pl.cst, 0), 2), round(coalesce(pl.inc, 0) + coalesce(loose.inc, 0) - coalesce(pl.cst, 0), 2)
      from pl full join loose on loose.customer_id = pl.customer_id left join customers c on c.id = coalesce(pl.customer_id, loose.customer_id)
     order by 5 desc;
  else
    return query
    select coalesce(p.number || ' ', '') || p.name, coalesce(c.name, 'Internal'),
           round(sum(case when a.type = 'income' then l.credit - l.debit else 0 end), 2), round(sum(case when a.type = 'expense' then l.debit - l.credit else 0 end), 2),
           round(sum(case when a.type = 'income' then l.credit - l.debit when a.type = 'expense' then l.credit - l.debit else 0 end), 2)
      from journal_lines l join journal_entries e on e.id = l.entry_id join accounts a on a.id = l.account_id join projects p on p.id = l.project_id
      left join customers c on c.id = p.customer_id
     where l.company_id = cid and e.entry_date between p_from and p_to and a.type in ('income','expense')
     group by p.id, p.number, p.name, c.name order by 5 desc;
  end if;
end $$;

-- ---------------------------------------------------------------- 6. New companies, numbering names, audit, voiding rules
create or replace function public.company_seed_v35() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform seed_accounts_v35(new.id); return null; end $$;
drop trigger if exists companies_seed_v35 on public.companies;
create trigger companies_seed_v35 after insert on public.companies for each row execute function public.company_seed_v35();

do $$ declare t text; begin
  foreach t in array array['customer_receipts','bill_payment_batches','bank_rules'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- ================================================================ 0024_asnys_v3_6.sql
-- Asnys ERP v3.6 — Bank of Ghana exchange rates, filled in automatically, and month-end revaluation
--   1. Every working day the BoG interbank rates (buying, mid, selling) are fetched by the asnys-m365 edge function
--      (from a rates service that republishes the BoG table, with the BoG web page as the backup) and kept as history.
--   2. Each company's currency list takes the BoG mid-rate; new documents and payments fill in the BoG mid-rate for
--      their date (staff can still change it).
--   3. Month-end revaluation restates unpaid foreign-currency invoices and bills at the month-end BoG rate; the
--      unrealised gain or loss is posted and reversed on the first day of the next month.
-- The books stay in cedis. Run after 0023. Safe to run twice.

-- ---------------------------------------------------------------- 1. Rate history (the same BoG rates for every company)
create table if not exists public.fx_rates (
  rate_date date not null,
  code text not null check (code ~ '^[A-Z]{3}$'),
  buying numeric(14,6),
  mid numeric(14,6) not null check (mid > 0),
  selling numeric(14,6),
  source text not null default 'BoG',
  fetched_at timestamptz not null default now(),
  primary key (rate_date, code)
);
alter table public.fx_rates enable row level security;
drop policy if exists "signed in read rates" on public.fx_rates;
create policy "signed in read rates" on public.fx_rates for select using (auth.uid() is not null);

-- One row of settings for the daily fetch. The shared secret is only readable by the database and the edge function.
create table if not exists public.fx_settings (
  id int primary key default 1 check (id = 1),
  enabled boolean not null default true,
  function_url text,
  secret text not null default (md5(gen_random_uuid()::text || clock_timestamp()::text) || md5(gen_random_uuid()::text)),
  last_run_at timestamptz,
  last_status text,
  last_rate_date date,
  last_alert date
);
insert into public.fx_settings (id) values (1) on conflict do nothing;
alter table public.fx_settings enable row level security;   -- no policies: reached only through the functions below

alter table public.currencies add column if not exists rate_date date;
alter table public.currencies add column if not exists rate_source text;
alter table public.currencies add column if not exists auto_rate boolean not null default true;

-- The rate for a currency on a day: the latest BoG mid-rate on or before that day (weekends and holidays use Friday's).
create or replace function public.fx_rate(cid uuid, p_code text, p_date date default current_date)
returns jsonb language sql stable security definer set search_path = public as $$
  select case when p_code = 'GHS' then jsonb_build_object('rate', 1, 'rate_date', p_date, 'source', 'GHS')
         else (select jsonb_build_object('rate', r.mid, 'buying', r.buying, 'selling', r.selling, 'rate_date', r.rate_date, 'source', r.source)
                 from fx_rates r where r.code = upper(p_code) and r.rate_date <= coalesce(p_date, current_date)
                order by r.rate_date desc limit 1) end
   where is_member(cid);
$$;

-- Settings screen: the last fetch and today's table.
create or replace function public.fx_status(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s fx_settings;
begin
  perform require_member(cid);
  select * into s from fx_settings where id = 1;
  return jsonb_build_object('enabled', s.enabled, 'function_url_set', s.function_url is not null, 'last_run_at', s.last_run_at, 'last_status', s.last_status,
    'last_rate_date', s.last_rate_date, 'pg_net', to_regnamespace('net') is not null,
    'latest', coalesce((select jsonb_agg(jsonb_build_object('code', r.code, 'buying', r.buying, 'mid', r.mid, 'selling', r.selling, 'rate_date', r.rate_date, 'source', r.source) order by r.code)
                 from fx_rates r where r.rate_date = (select max(rate_date) from fx_rates)), '[]'));
end $$;

-- Owners point the daily fetch at their asnys-m365 function (any company owner of this installation may set it).
create or replace function public.fx_configure(cid uuid, p_function_url text, p_enabled boolean default true) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  if p_function_url !~ '^https://.+/functions/v1/asnys-m365$' then raise exception 'The address should end in /functions/v1/asnys-m365'; end if;
  update fx_settings set function_url = p_function_url, enabled = p_enabled where id = 1;
end $$;

-- Ask the edge function to fetch today's table.
create or replace function public.start_fx_fetch() returns bigint
language plpgsql security definer set search_path = public as $$
declare s fx_settings; v_url text;
begin
  select * into s from fx_settings where id = 1;
  if not s.enabled then return null; end if;
  v_url := coalesce(s.function_url, (select function_url from company_email where function_url like '%/functions/v1/asnys-m365' limit 1));
  if v_url is null then return null; end if;
  update fx_settings set last_run_at = now(), last_status = 'started' where id = 1;
  return http_post_safe(v_url, jsonb_build_object('action', 'fx'), jsonb_build_object('Content-Type', 'application/json', 'x-asnys-fx', s.secret));
end $$;
revoke execute on function public.start_fx_fetch() from public, anon, authenticated;

create or replace function public.fx_fetch_now(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if not has_role(cid, array['owner','admin','accountant']) then raise exception 'Only Finance can fetch rates'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  v := start_fx_fetch();
  if v is null then raise exception 'Set the asnys-m365 function address under Foreign currencies first'; end if;
  return 'started';
end $$;

-- Used only by the edge function (service key + the shared secret): save the table and update every company's rates.
create or replace function public.fx_save(p_secret text, p_rows jsonb, p_source text, p_status text default 'ok') returns int
language plpgsql security definer set search_path = public as $$
declare x jsonb; n int := 0; v_date date; c record;
begin
  if not exists (select 1 from fx_settings where id = 1 and secret = p_secret) then raise exception 'Not allowed'; end if;
  for x in select * from jsonb_array_elements(coalesce(p_rows, '[]')) loop
    continue when coalesce((x->>'mid')::numeric, 0) <= 0 or coalesce(x->>'code', '') !~ '^[A-Z]{3}$' or (x->>'code') = 'GHS';
    insert into fx_rates (rate_date, code, buying, mid, selling, source)
    values ((x->>'date')::date, x->>'code', nullif(x->>'buying', '')::numeric, (x->>'mid')::numeric, nullif(x->>'selling', '')::numeric, coalesce(p_source, 'BoG'))
    on conflict (rate_date, code) do update set buying = excluded.buying, mid = excluded.mid, selling = excluded.selling, source = excluded.source, fetched_at = now();
    n := n + 1; v_date := greatest(v_date, (x->>'date')::date);
  end loop;
  update fx_settings set last_status = case when n > 0 then 'ok' else coalesce(p_status, 'no rates found') end,
    last_rate_date = coalesce(v_date, last_rate_date), last_run_at = now() where id = 1;
  if n > 0 then
    update currencies cu set rate = r.mid, rate_date = r.rate_date, rate_source = r.source, updated_at = now()
      from (select distinct on (code) code, mid, rate_date, source from fx_rates order by code, rate_date desc) r
     where cu.code = r.code and cu.auto_rate;
  elsif (select coalesce(last_alert, '1900-01-01') < current_date from fx_settings where id = 1) then
    -- Tell Finance once a day that the rates could not be fetched; the last rates stay in use.
    update fx_settings set last_alert = current_date where id = 1;
    for c in select distinct company_id from currencies loop
      perform notify(c.company_id, array['accountant'], null, 'fx_failed', 'Bank of Ghana rates could not be fetched today',
        'The last rates stay in use. Check the rate on each foreign-currency document, or type it in. ' || coalesce(p_status, ''), '/settings', true);
    end loop;
  end if;
  return n;
end $$;
revoke execute on function public.fx_save(text, jsonb, text, text) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then grant execute on function public.fx_save(text, jsonb, text, text) to service_role; end if;
end $$;

-- Daily at 15:00 and 17:00 Ghana time (UTC) on working days, if pg_cron is on.
do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    begin perform cron.unschedule('asnys-bog-rates'); exception when others then null; end;
    perform cron.schedule('asnys-bog-rates', '0 15,17 * * 1-5', 'select public.start_fx_fetch()');
  end if;
exception when others then null;
end $$;

-- ---------------------------------------------------------------- 2. Month-end revaluation of unpaid foreign-currency invoices and bills
create table if not exists public.fx_revaluations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  reval_date date not null,
  ar_change numeric(14,2) not null default 0,     -- + = receivables worth more in cedis (gain)
  ap_change numeric(14,2) not null default 0,     -- + = payables cost more in cedis (loss)
  detail jsonb not null default '[]',
  journal_entry_id uuid references public.journal_entries(id),
  reversal_entry_id uuid references public.journal_entries(id),
  status text not null default 'posted' check (status in ('posted','undone')),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create unique index if not exists fx_revaluations_one_per_date on public.fx_revaluations (company_id, reval_date) where status = 'posted';
alter table public.fx_revaluations enable row level security;
drop policy if exists "finance reads revaluations" on public.fx_revaluations;
create policy "finance reads revaluations" on public.fx_revaluations for select using (has_role(company_id, array['owner','admin','accountant']));

-- What revaluing at a date would do (nothing is posted).
create or replace function public.fx_revalue_preview(cid uuid, p_date date)
returns table (kind text, doc_id uuid, number text, party text, currency text, open_amount numeric, booked_rate numeric, new_rate numeric, change numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with r as (select distinct on (code) code, mid from fx_rates where rate_date <= p_date order by code, rate_date desc)
  select 'invoice', i.id, i.number, c.name, i.currency, round(i.total - i.amount_paid - i.amount_credited, 2), i.exchange_rate, r.mid,
         round((i.total - i.amount_paid - i.amount_credited) * (r.mid - i.exchange_rate), 2)
    from invoices i join customers c on c.id = i.customer_id join r on r.code = i.currency
   where i.company_id = cid and i.currency <> 'GHS' and i.status = 'posted' and i.invoice_date <= p_date and i.total - i.amount_paid - i.amount_credited > 0
  union all
  select 'bill', b.id, b.number, s.name, b.currency, round(b.total - b.amount_paid, 2), b.exchange_rate, r.mid,
         round((b.total - b.amount_paid) * (r.mid - b.exchange_rate), 2)
    from bills b join suppliers s on s.id = b.supplier_id join r on r.code = b.currency
   where b.company_id = cid and b.currency <> 'GHS' and b.status = 'posted' and b.bill_date <= p_date and b.total - b.amount_paid > 0
  order by 1, 3;
end $$;

-- Post it: one entry at the date, reversed the next day, so payments later still clear at each document's own rate.
create or replace function public.fx_revalue(cid uuid, p_date date) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_ar numeric; v_ap numeric; v_det jsonb; v_lines jsonb := '[]'; v_je uuid; v_rev uuid; v_id uuid; v_net numeric;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  if exists (select 1 from fx_revaluations where company_id = cid and reval_date = p_date and status = 'posted') then raise exception 'Already revalued at %. Undo that one first.', p_date; end if;
  select coalesce(sum(change) filter (where kind = 'invoice'), 0), coalesce(sum(change) filter (where kind = 'bill'), 0), coalesce(jsonb_agg(to_jsonb(p)), '[]')
    into v_ar, v_ap, v_det from fx_revalue_preview(cid, p_date) p;
  if v_ar = 0 and v_ap = 0 then raise exception 'Nothing to revalue: no unpaid foreign-currency invoices or bills, or no BoG rate on or before %', p_date; end if;
  -- Receivables up = gain; payables up = loss.
  if v_ar <> 0 then v_lines := v_lines || jl(acct(cid, 'ar'), greatest(v_ar, 0), greatest(-v_ar, 0)); end if;
  if v_ap <> 0 then v_lines := v_lines || jl(acct(cid, 'ap'), greatest(-v_ap, 0), greatest(v_ap, 0)); end if;
  v_net := v_ar - v_ap;
  if v_net <> 0 then v_lines := v_lines || jl(acct(cid, 'fx'), greatest(-v_net, 0), greatest(v_net, 0)); end if;
  insert into fx_revaluations (company_id, reval_date, ar_change, ap_change, detail) values (cid, p_date, v_ar, v_ap, v_det) returning id into v_id;
  v_je := post_journal(cid, p_date, 'Unrealised exchange gain/loss: foreign-currency invoices and bills restated at the BoG rate of ' || to_char(p_date, 'DD Mon YYYY'), v_lines, 'fx_reval', v_id);
  select jsonb_agg(jsonb_build_object('account_id', l->>'account_id', 'debit', l->>'credit', 'credit', l->>'debit')) into v_lines from jsonb_array_elements(v_lines) l;
  v_rev := post_journal(cid, p_date + 1, 'Reversal of the ' || to_char(p_date, 'DD Mon YYYY') || ' exchange revaluation', v_lines, 'fx_reval', v_id);
  update fx_revaluations set journal_entry_id = v_je, reversal_entry_id = v_rev where id = v_id;
  return v_id;
end $$;

create or replace function public.fx_revalue_undo(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r fx_revaluations; v_lines jsonb;
begin
  select * into r from fx_revaluations where id = p_id for update;
  if not found or r.status <> 'posted' then raise exception 'Revaluation not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant']);
  -- Cancel both entries with mirror entries (dated as the originals; the books must not be locked over those dates).
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit)) into v_lines from journal_lines l where l.entry_id = r.journal_entry_id;
  perform post_journal(r.company_id, r.reval_date, 'Undo exchange revaluation of ' || to_char(r.reval_date, 'DD Mon YYYY'), v_lines, 'fx_reval', r.id);
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit)) into v_lines from journal_lines l where l.entry_id = r.reversal_entry_id;
  perform post_journal(r.company_id, r.reval_date + 1, 'Undo reversal of exchange revaluation of ' || to_char(r.reval_date, 'DD Mon YYYY'), v_lines, 'fx_reval', r.id);
  update fx_revaluations set status = 'undone' where id = r.id;
end $$;

do $$ declare t text; begin
  foreach t in array array['fx_revaluations'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;
-- ================================================================ 0025_asnys_v3_7.sql
-- Asnys ERP v3.7 — Gulfaco's notes of 18 Nov 2026
--   1. Supplier / subcontractor onboarding: type, Ghana Card, full bank and MoMo details, what they supply, documents
--      (business registration, incorporation, VAT, ISO, HSE and quality policies, tax exemption, BoG / foreign exchange,
--      others) with expiry, a requirements list per type, and approval by Finance.
--   2. Contracts: type (goods, works, services…), client sector, currency from the list; a draft contract can be started
--      from a tender before award; contract drafts kept as numbered versions; one contract or tender with several projects.
--   3. A purchase order's project can be changed (before goods are received or billed).
--   4. Policies: document / reference number generated from the company's numbering procedure; HSE policies and HR & Admin
--      compliance policies kept apart; "Other" with what it is.
-- Run after 0024. Safe to run twice.

-- ---------------------------------------------------------------- 1. Supplier onboarding
alter table public.suppliers add column if not exists supplier_type text not null default 'vendor';
alter table public.suppliers drop constraint if exists suppliers_supplier_type_check;
alter table public.suppliers add constraint suppliers_supplier_type_check check (supplier_type in ('vendor','subcontractor','both'));
alter table public.suppliers add column if not exists ghana_card text;
alter table public.suppliers add column if not exists products_services text;          -- what they supply or do
alter table public.suppliers add column if not exists bank_branch text;
alter table public.suppliers add column if not exists bank_account_name text;
alter table public.suppliers add column if not exists bank_swift text;
alter table public.suppliers add column if not exists bank_address text;
alter table public.suppliers add column if not exists momo_name text;
alter table public.suppliers add column if not exists momo_network text;
alter table public.suppliers drop constraint if exists suppliers_momo_network_check;
alter table public.suppliers add constraint suppliers_momo_network_check check (momo_network is null or momo_network in ('mtn','telecel','airteltigo','other'));
-- Suppliers already in use before onboarding existed count as approved (only the first time this runs).
do $$ begin
  if not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'suppliers' and column_name = 'onboarding_status') then
    alter table public.suppliers add column onboarding_status text not null default 'pending';
    update public.suppliers set onboarding_status = 'approved';
  end if;
end $$;
alter table public.suppliers drop constraint if exists suppliers_onboarding_status_check;
alter table public.suppliers add constraint suppliers_onboarding_status_check check (onboarding_status in ('pending','approved','rejected','suspended'));
alter table public.suppliers add column if not exists onboarded_at timestamptz;
alter table public.suppliers add column if not exists onboarded_by uuid;
alter table public.suppliers add column if not exists onboarding_note text;

create table if not exists public.supplier_documents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_id uuid not null references public.suppliers(id) on delete cascade,
  doc_type text not null check (doc_type in ('business_registration','incorporation','vat_certificate','tax_clearance','iso_certificate','hse_policy',
                                             'quality_policy','tax_exemption','bog_fx','ssnit','insurance','other')),
  doc_label text,                    -- for "other": what it is
  ref_no text,
  issued_on date,
  expires_on date,
  name text,
  storage_path text,
  status text not null default 'submitted' check (status in ('submitted','verified','rejected')),
  verified_by uuid,
  verified_at timestamptz,
  note text,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists supplier_documents_supplier on public.supplier_documents (supplier_id);
alter table public.supplier_documents enable row level security;
drop policy if exists "members read supplier docs" on public.supplier_documents;
create policy "members read supplier docs" on public.supplier_documents for select using (is_member(company_id));
drop policy if exists "buyers add supplier docs" on public.supplier_documents;
create policy "buyers add supplier docs" on public.supplier_documents for insert with check (has_role(company_id, array['owner','admin','accountant','store','project_manager']));
drop policy if exists "finance edits supplier docs" on public.supplier_documents;
create policy "finance edits supplier docs" on public.supplier_documents for update using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));
drop policy if exists "finance removes supplier docs" on public.supplier_documents;
create policy "finance removes supplier docs" on public.supplier_documents for delete using (has_role(company_id, array['owner','admin','accountant']) or (uploaded_by = auth.uid() and status = 'submitted'));

-- Which documents each kind of supplier must give (Settings → Supplier onboarding).
create table if not exists public.onboarding_requirements (
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_type text not null check (supplier_type in ('vendor','subcontractor')),
  doc_type text not null,
  required boolean not null default true,
  primary key (company_id, supplier_type, doc_type)
);
alter table public.onboarding_requirements enable row level security;
drop policy if exists "members read requirements" on public.onboarding_requirements;
create policy "members read requirements" on public.onboarding_requirements for select using (is_member(company_id));
drop policy if exists "finance sets requirements" on public.onboarding_requirements;
create policy "finance sets requirements" on public.onboarding_requirements for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

create or replace function public.seed_onboarding(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into onboarding_requirements (company_id, supplier_type, doc_type, required)
  select cid, t, d, r from (values
    ('vendor','business_registration',true),('vendor','incorporation',true),('vendor','vat_certificate',true),('vendor','iso_certificate',false),
    ('vendor','hse_policy',false),('vendor','quality_policy',false),('vendor','tax_exemption',false),('vendor','bog_fx',false),
    ('subcontractor','business_registration',true),('subcontractor','incorporation',true),('subcontractor','vat_certificate',false),('subcontractor','iso_certificate',false),
    ('subcontractor','hse_policy',true),('subcontractor','quality_policy',true),('subcontractor','tax_exemption',false),('subcontractor','bog_fx',false)) v(t, d, r)
  on conflict do nothing;
$$;
select public.seed_onboarding(id) from public.companies;

-- What is still missing for a supplier (required documents not uploaded, or rejected or expired).
create or replace function public.supplier_missing_docs(p_supplier uuid) returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(r.doc_type order by r.doc_type), '{}')
    from suppliers s join onboarding_requirements r on r.company_id = s.company_id and r.required
         and (r.supplier_type = s.supplier_type or (s.supplier_type = 'both'))
   where s.id = p_supplier
     and not exists (select 1 from supplier_documents d where d.supplier_id = s.id and d.doc_type = r.doc_type
                      and d.status <> 'rejected' and (d.expires_on is null or d.expires_on >= current_date));
$$;

create or replace function public.decide_supplier(p_supplier uuid, p_status text, p_note text default null, p_override boolean default false) returns void
language plpgsql security definer set search_path = public as $$
declare s suppliers; v_missing text[];
begin
  select * into s from suppliers where id = p_supplier for update;
  if not found then raise exception 'Supplier not found'; end if;
  if not has_role(s.company_id, array['owner','admin','accountant']) then raise exception 'Only Finance or an admin approves suppliers'; end if;
  if p_status not in ('approved','rejected','suspended','pending') then raise exception 'Unknown status'; end if;
  if p_status = 'approved' then
    v_missing := supplier_missing_docs(p_supplier);
    if cardinality(v_missing) > 0 and not p_override then
      raise exception 'Still missing: %. Upload them, or approve anyway with a note.', replace(array_to_string(v_missing, ', '), '_', ' ');
    end if;
    if cardinality(v_missing) > 0 and coalesce(trim(p_note), '') = '' then raise exception 'Say why it is approved without every document'; end if;
  end if;
  if p_status in ('rejected','suspended') and coalesce(trim(p_note), '') = '' then raise exception 'Give the reason'; end if;
  update suppliers set onboarding_status = p_status, onboarded_at = now(), onboarded_by = auth.uid(), onboarding_note = p_note where id = p_supplier;
  update supplier_documents set status = 'verified', verified_by = auth.uid(), verified_at = now() where supplier_id = p_supplier and status = 'submitted' and p_status = 'approved';
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (s.company_id, 'supplier.' || p_status, 'suppliers', s.id, jsonb_build_object('supplier', s.name, 'note', p_note, 'missing', v_missing));
end $$;

-- Reminders: supplier documents that expire within 30 days (once a week per document).
alter table public.supplier_documents add column if not exists reminded_on date;
create or replace function public.run_supplier_doc_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare d record; n int := 0;
begin
  for d in select sd.*, s.name supplier from supplier_documents sd join suppliers s on s.id = sd.supplier_id
            where sd.expires_on is not null and sd.expires_on <= current_date + 30 and sd.status <> 'rejected' and s.onboarding_status = 'approved'
              and (sd.reminded_on is null or sd.reminded_on < current_date - 7) loop
    perform notify(d.company_id, array['accountant','store'], null, 'supplier_doc_expiry',
      d.supplier || ': ' || replace(d.doc_type, '_', ' ') || case when d.expires_on < current_date then ' has expired' else ' expires ' || to_char(d.expires_on, 'DD Mon YYYY') end,
      'Ask the supplier for the renewed document and upload it on their page.', '/suppliers/' || d.supplier_id, true);
    update supplier_documents set reminded_on = current_date where id = d.id;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_supplier_doc_reminders() from public, anon, authenticated;
create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_integration_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_supplier_doc_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 2. Contracts: type, sector, drafts, several projects
alter table public.contracts add column if not exists contract_type text;
alter table public.contracts drop constraint if exists contracts_contract_type_check;
alter table public.contracts add constraint contracts_contract_type_check check (contract_type is null or contract_type in ('goods','works','services','goods_works','consultancy','other'));
alter table public.contracts add column if not exists sector text;
alter table public.contracts drop constraint if exists contracts_sector_check;
alter table public.contracts add constraint contracts_sector_check check (sector is null or sector in ('oil_gas','power_energy','mining','manufacturing','construction','government','telecom','other'));
alter table public.tenders add column if not exists contract_type text;
alter table public.tenders add column if not exists sector text;
alter table public.customers add column if not exists sector text;

alter table public.contract_files drop constraint if exists contract_files_kind_check;
alter table public.contract_files add constraint contract_files_kind_check check (kind in ('draft','signed_contract','variation','security','correspondence','other'));
alter table public.contract_files add column if not exists version int;
alter table public.contract_files add column if not exists note text;
-- Drafts are numbered Draft 1, 2, 3… per contract.
create or replace function public.contract_file_version() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.kind = 'draft' and new.version is null then
    select coalesce(max(version), 0) + 1 into new.version from contract_files where contract_id = new.contract_id and kind = 'draft';
  end if;
  return new;
end $$;
drop trigger if exists contract_files_version on public.contract_files;
create trigger contract_files_version before insert on public.contract_files for each row execute function public.contract_file_version();

-- A tender's contract can be started as a draft before award; on award the draft becomes the active contract.
create or replace function public.contract_from_tender(p_tender uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders; v uuid; pj uuid; c contracts;
begin
  select * into t from tenders where id = p_tender;
  if not found then raise exception 'Tender not found'; end if;
  pj := coalesce(t.project_id, (select id from projects where tender_id = t.id order by created_at limit 1));
  select * into c from contracts where tender_id = p_tender;
  if found then
    if t.status = 'awarded' and c.status = 'draft' then
      update contracts set status = 'active', value = coalesce(t.awarded_value, value), their_ref = coalesce(t.contract_ref, their_ref),
             signed_on = coalesce(t.contract_signed_on, signed_on), project_id = coalesce(project_id, pj),
             payment_terms_days = coalesce((to_jsonb(t)->>'payment_terms_days')::int, payment_terms_days),
             advance_pct = coalesce((to_jsonb(t)->>'advance_pct')::numeric, advance_pct), retention_pct = coalesce((to_jsonb(t)->>'retention_pct')::numeric, retention_pct)
       where id = c.id;
    end if;
    return c.id;
  end if;
  insert into contracts (company_id, title, kind, customer_id, counterparty, their_ref, project_id, tender_id, value, currency, signed_on, start_date, status,
                         payment_terms_days, advance_pct, retention_pct, owner_id, description, contract_type, sector)
  values (t.company_id, t.title, 'client', t.customer_id, t.client_name, t.contract_ref, pj, t.id,
          coalesce(t.awarded_value, t.submitted_value, t.est_value, 0), t.currency, t.contract_signed_on,
          coalesce((select start_date from projects where id = pj), t.contract_signed_on),
          case when t.status = 'awarded' then 'active' else 'draft' end,
          (to_jsonb(t)->>'payment_terms_days')::int, (to_jsonb(t)->>'advance_pct')::numeric, (to_jsonb(t)->>'retention_pct')::numeric,
          coalesce(t.bd_owner_id, auth.uid()),
          case when t.status = 'awarded' then 'Awarded on ' || t.number || coalesce(' (' || replace(t.award_type, '_', ' ') || ')', '') else 'Draft from ' || t.number end,
          t.contract_type, t.sector)
  returning id into v;
  return v;
end $$;

-- From the tender page: start (or open) the contract.
create or replace function public.start_contract_from_tender(p_tender uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders;
begin
  select * into t from tenders where id = p_tender;
  if not found then raise exception 'Tender not found'; end if;
  if not has_role(t.company_id, array['owner','admin','accountant','sales','project_manager']) then raise exception 'Your role cannot start contracts'; end if;
  if t.status in ('lost','no_bid','cancelled','voided') then raise exception 'This tender is %; it cannot have a contract', t.status; end if;
  return contract_from_tender(p_tender);
end $$;

-- Several projects under one contract or tender.
alter table public.projects add column if not exists contract_id uuid references public.contracts(id) on delete set null;
update public.projects p set contract_id = c.id from public.contracts c where c.project_id = p.id and p.contract_id is null;
update public.projects p set contract_id = c.id from public.contracts c where c.tender_id is not null and p.tender_id = c.tender_id and p.contract_id is null;

drop function if exists public.register_project_from_tender(uuid, text, uuid, uuid, date, date, text, uuid);
create or replace function public.register_project_from_tender(p_tender uuid, p_name text, p_cost_centre uuid, p_manager uuid, p_start date, p_end date,
  p_billing text default 'fixed_price', p_branch uuid default null, p_value numeric default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders; v uuid; v_value numeric; v_contract uuid;
begin
  select * into t from tenders where id = p_tender for update;
  if not found then raise exception 'Tender not found'; end if;
  if not has_role(t.company_id, array['owner','admin','accountant']) then raise exception 'Only Finance registers projects'; end if;
  if t.status <> 'awarded' then raise exception 'Only an awarded tender becomes a project'; end if;
  -- The first project takes the whole award unless a share is given; further projects take the share given.
  v_value := coalesce(p_value, case when t.project_id is null then t.awarded_value else 0 end);
  v_contract := (select id from contracts where tender_id = t.id);
  insert into projects (company_id, name, customer_id, status, start_date, end_date, manager_id, billing_type, contract_value, currency, location, description, hourly_rate, tender_id, contract_ref, contract_id)
  values (t.company_id, coalesce(nullif(trim(p_name), ''), t.title), t.customer_id, 'planned', p_start, p_end, p_manager, p_billing, v_value, 'GHS', t.location,
          'From ' || t.number || ' (' || replace(coalesce(t.award_type, 'award'), '_', ' ') || ' ' || coalesce(t.contract_ref, '') || ')', 0, t.id, t.contract_ref, v_contract)
  returning id into v;
  if t.project_id is null then
    perform set_config('sika.cycle','on', true);
    update tenders set project_id = v where id = p_tender;
    perform set_config('sika.cycle','off', true);
  end if;
  perform register_project(v, p_cost_centre, p_branch, t.contract_ref, v_value);
  return v;
end $$;

create or replace function public.link_project_contract(p_project uuid, p_contract uuid) returns void
language plpgsql security definer set search_path = public as $$
declare p projects; c contracts;
begin
  select * into p from projects where id = p_project;
  if not found then raise exception 'Project not found'; end if;
  if not has_role(p.company_id, array['owner','admin','accountant','project_manager']) then raise exception 'Your role cannot link projects to contracts'; end if;
  if p_contract is not null then
    select * into c from contracts where id = p_contract and company_id = p.company_id;
    if not found then raise exception 'Contract not found'; end if;
  end if;
  update projects set contract_id = p_contract where id = p_project;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (p.company_id, 'project.contract', 'projects', p.id, jsonb_build_object('contract', c.number));
end $$;

-- ---------------------------------------------------------------- 3. Move a purchase order to another project
create or replace function public.set_po_project(p_po uuid, p_project uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare po purchase_orders; v_old uuid;
begin
  select * into po from purchase_orders where id = p_po for update;
  if not found then raise exception 'Purchase order not found'; end if;
  if not has_role(po.company_id, array['owner','admin','accountant','store']) then raise exception 'Only Finance or the storekeeper can change the project of an order'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why the project is changing'; end if;
  if po.status in ('cancelled','closed') then raise exception 'This order is %', po.status; end if;
  if exists (select 1 from po_lines where po_id = p_po and (received_qty > 0 or billed_qty > 0)) then
    raise exception 'Goods have been received or billed on this order; their cost is already on the old project. Raise a new order for the other project instead.';
  end if;
  if p_project is not null and not exists (select 1 from projects where id = p_project and company_id = po.company_id and not is_template) then raise exception 'Project not found'; end if;
  v_old := po.project_id;
  perform set_config('sika.po', 'on', true);
  update purchase_orders set project_id = p_project where id = p_po;
  update po_lines set project_id = p_project where po_id = p_po and (project_id is not distinct from v_old or project_id is null);
  perform set_config('sika.po', 'off', true);
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (po.company_id, 'po.project_changed', 'purchase_orders', po.id, jsonb_build_object('number', po.number, 'from', (select number from projects where id = v_old),
          'to', (select number from projects where id = p_project), 'reason', trim(p_reason)));
end $$;

-- ---------------------------------------------------------------- 4. Policies: numbers from the numbering procedure; HSE vs HR & Admin
alter table public.hse_policies add column if not exists doc_number text;
alter table public.hse_policies add column if not exists area_other text;          -- when the area is "other": what it is
alter table public.hse_policies add column if not exists scope text not null default 'hse';
alter table public.hse_policies drop constraint if exists hse_policies_scope_check;
alter table public.hse_policies add constraint hse_policies_scope_check check (scope in ('hse','hr_admin'));
update public.hse_policies set scope = 'hr_admin' where scope = 'hse' and area in ('legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it');
alter table public.hse_policies drop constraint if exists hse_policies_area_check;
alter table public.hse_policies add constraint hse_policies_area_check
  check (area in ('safety','environment','quality','security','emergency','legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it','compliance','other'));

-- The numbering procedure: e.g. "{CO}-{AREA}-POL-{SEQ}" → GUF-HSE-POL-001. Tokens: {CO} company code, {AREA} area code,
-- {YYYY} year, {SEQ} running number (3 digits).
alter table public.companies add column if not exists policy_numbering text not null default '{CO}-{AREA}-POL-{SEQ}';
alter table public.companies add column if not exists policy_numbering_note text;

create or replace function public.policy_area_code(p_area text) returns text
language sql immutable as $$
  select case p_area when 'safety' then 'HSE' when 'environment' then 'ENV' when 'quality' then 'QA' when 'security' then 'SEC' when 'emergency' then 'ERP'
    when 'legal' then 'LEG' when 'tax_finance' then 'FIN' when 'labour' then 'HRA' when 'hr' then 'HR' when 'admin' then 'ADM' when 'it' then 'IT'
    when 'data_protection' then 'DPP' when 'anti_bribery' then 'ABC' when 'compliance' then 'CMP' else 'GEN' end;
$$;

create or replace function public.next_policy_number(cid uuid, p_area text) returns text
language plpgsql security definer set search_path = public as $$
declare f text; v int; code text := policy_area_code(p_area);
begin
  if not (is_hse(cid) or has_role(cid, array['owner','admin','hr'])) then raise exception 'Only HSE, HR or an admin numbers policies'; end if;
  select policy_numbering into f from companies where id = cid;
  insert into number_sequences (company_id, key, next_value) values (cid, 'POL-' || code, 2)
  on conflict (company_id, key) do update set next_value = number_sequences.next_value + 1
  returning next_value - 1 into v;
  return replace(replace(replace(replace(coalesce(f, '{CO}-{AREA}-POL-{SEQ}'),
    '{CO}', coalesce((select doc_prefix from companies where id = cid), 'CO')), '{AREA}', code), '{YYYY}', to_char(current_date, 'YYYY')), '{SEQ}', lpad(v::text, 3, '0'));
end $$;

create or replace function public.set_policy_numbering(cid uuid, p_format text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hse(cid) or has_role(cid, array['owner','admin','hr'])) then raise exception 'Only HSE, HR or an admin can change this'; end if;
  if position('{SEQ}' in coalesce(p_format, '')) = 0 then raise exception 'The format must contain {SEQ} (the running number)'; end if;
  update companies set policy_numbering = trim(p_format), policy_numbering_note = nullif(trim(p_note), '') where id = cid;
end $$;

-- ---------------------------------------------------------------- 5. New companies and audit
create or replace function public.company_seed_v37() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform seed_onboarding(new.id); return null; end $$;
drop trigger if exists companies_seed_v37 on public.companies;
create trigger companies_seed_v37 after insert on public.companies for each row execute function public.company_seed_v37();

do $$ declare t text; begin
  foreach t in array array['supplier_documents'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- ================================================================ 0026_asnys_v3_8.sql
-- Asnys ERP v3.8 — Gulfaco's notes of 24 Nov 2026
--   1. "Who does what": each duty also says what NOT to do.
--   2. Your own contract types and client sectors (added from the drop-down), on top of the standard ones.
--   3. Supplier documents: "BoG exemption letter" (label only; uses the existing document type).
-- Run after 0025. Safe to run twice.

alter table public.cycle_responsibilities add column if not exists dont text;   -- what not to do

-- Lists the company extends itself: contract types and client sectors.
create table if not exists public.lookup_values (
  company_id uuid not null references public.companies(id) on delete cascade,
  list text not null check (list in ('contract_type','sector')),
  code text not null check (code ~ '^[a-z0-9_]{2,40}$'),
  label text not null check (length(trim(label)) between 2 and 60),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  primary key (company_id, list, code)
);
alter table public.lookup_values enable row level security;
drop policy if exists "members read lookups" on public.lookup_values;
create policy "members read lookups" on public.lookup_values for select using (is_member(company_id));
drop policy if exists "staff add lookups" on public.lookup_values;
create policy "staff add lookups" on public.lookup_values for insert with check (has_role(company_id, array['owner','admin','accountant','sales','project_manager']));
drop policy if exists "admins remove lookups" on public.lookup_values;
create policy "admins remove lookups" on public.lookup_values for delete using (has_role(company_id, array['owner','admin']));

-- Contract types and sectors are no longer limited to the fixed list.
alter table public.contracts drop constraint if exists contracts_contract_type_check;
alter table public.contracts drop constraint if exists contracts_sector_check;

-- Policies: a reference number as well as the document number.
alter table public.hse_policies add column if not exists reference_no text;

-- HR & Admin policy areas: "HR and administration" and "Compliance" replace labour/HR, administration,
-- legal and corporate, data protection and anti-bribery (existing policies move across; nothing is lost).
update public.hse_policies set area = 'hr' where scope = 'hr_admin' and area in ('labour','admin');
update public.hse_policies set area = 'compliance' where scope = 'hr_admin' and area in ('legal','data_protection','anti_bribery');
