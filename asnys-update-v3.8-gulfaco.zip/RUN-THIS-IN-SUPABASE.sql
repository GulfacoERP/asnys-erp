-- ============================================================================
-- Asnys ERP v3.8: ONE update to run. It brings any database from v3.0 up to v3.8:
--   v3.1 Assets + Fleet, v3.1.1 reminders, v3.2 Telegram/email approvals, temporary passwords, activity log, void,
--   v3.3 email through Microsoft 365, v3.4 Gulfaco changes (numbering GUF-…, customer tax, strict invoices, bank accounts,
--   payment milestones, SR/ADR/MRO requests with attachments, subcontractors, logo, custom roles, restore voided entries,
--   no deleting numbered entries, OneDrive backups, 2-step sign-in, password reset by email),
--   v3.5 QuickBooks-style receive payment, sales receipts, pay bills, bank feed and more reports,
--   v3.6 Bank of Ghana rates fetched daily and filled in, month-end exchange revaluation,
--   v3.7 supplier onboarding, contract drafts and several projects per contract, PO project change, policy numbering,
--   v3.8 your own contract types and sectors, what not to do, policy reference numbers.
-- Safe to run whether or not you ran earlier updates, and safe to run twice.
-- Supabase → SQL Editor → New query → paste all of this → Run.
-- ============================================================================

-- ======================================== Part A: v3.1 – v3.2 (skips what is already there)
-- Part 1: v3.1 (Assets upgrade and Fleet & Logistics), only if it is not there yet
do $v318$
begin
  if to_regclass('public.vehicles') is null then
    execute $sql318$-- Asnys ERP v3.1 — Assets to match the Gulfaco asset system, and Fleet & Logistics
-- Assets
--   1. Locations register (head office, branches, sites, stores, regions) with a manager for each.
--   2. Manufacturer, model and order number on assets.
--   3. Transfers between locations: In transit until the receiving location confirms; reject or recall.
--   4. Requests routed through the site: the site manager approves, or passes it to head office.
--   5. Accessories, components and consumables: quantities per location, check out to people or into an asset,
--      low-stock alerts.
--   6. Software licences: seats, product key, assignment to people or computers, expiry reminders.
--   7. Telegram alerts (optional) for transfers, requests, decisions, low stock and fleet.
-- Fleet & Logistics
--   8. Vehicle file (registration, DVLA roadworthy, insurance, road-use documents with reminders), drivers and licences.
--   9. Trip log with mileage; fuel log with km per litre and unusual consumption flagged; fuel feeds the CO2 figures.
--  10. Service and repairs by mileage or date (job cards, downtime); vehicle requests allocated by the transport officer.
--  11. Waybills for deliveries and collections, own vehicle or hired transport, with signed proof of delivery.
--  12. Fleet reports: cost per vehicle and per km, fuel use, transport by project.
-- Transport officer is a tick on a team member (like HSE officer); owners, admins, Finance and the storekeeper count as one.
-- Run after 0017.

-- ---------------------------------------------------------------- 0. People who manage the fleet
alter table public.memberships add column if not exists transport boolean not null default false;
create or replace function public.is_transport(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (transport or role in ('owner','admin','accountant','store')));
$$;
create or replace function public.transport_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or role = 'store');
$$;
create or replace function public.set_member_transport(cid uuid, p_user uuid, p_on boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can choose transport officers'; end if;
  update memberships set transport = p_on where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
end $$;

-- ---------------------------------------------------------------- 1. Telegram alerts (optional)
-- Needs the pg_net extension (Supabase: Database → Extensions → pg_net). Without it, alerts are skipped quietly.
create table public.company_telegram (
  company_id uuid primary key references public.companies(id) on delete cascade,
  bot_token text,
  chat_id text,
  events text[] not null default '{transfer,request,decision,low_stock,fleet,signup}',
  enabled boolean not null default false,
  updated_at timestamptz not null default now()
);
create or replace function public.send_telegram(cid uuid, p_event text, p_text text) returns void
language plpgsql security definer set search_path = public as $$
declare t company_telegram;
begin
  select * into t from company_telegram where company_id = cid;
  if not found or not t.enabled or t.bot_token is null or t.chat_id is null or not (p_event = any(t.events)) then return; end if;
  if to_regnamespace('net') is null then return; end if;
  begin
    execute 'select net.http_post(url := $1, body := $2, headers := ''{"Content-Type":"application/json"}''::jsonb)'
      using 'https://api.telegram.org/bot' || t.bot_token || '/sendMessage', jsonb_build_object('chat_id', t.chat_id, 'text', left(p_text, 4000));
  exception when others then null;
  end;
end $$;
revoke execute on function public.send_telegram(uuid, text, text) from public, anon, authenticated;
create or replace function public.test_telegram(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can set up Telegram'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  perform send_telegram(cid, (select coalesce(events[1], 'transfer') from company_telegram where company_id = cid), 'Asnys ERP: Telegram alerts are working for ' || (select name from companies where id = cid) || '.');
  return 'sent';
end $$;

-- ---------------------------------------------------------------- 2. Locations
create table public.asset_locations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  kind text not null default 'site' check (kind in ('head_office','branch','site','store','yard','other')),
  region text,
  address text,
  manager_id uuid,
  project_id uuid references public.projects(id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (company_id, name)
);
insert into public.asset_locations (company_id, name, kind)
select id, 'Head office', 'head_office' from public.companies on conflict do nothing;
-- Existing free-text locations become entries.
insert into public.asset_locations (company_id, name, kind)
select distinct company_id, trim(location), 'other' from public.assets where coalesce(trim(location), '') <> '' on conflict do nothing;

alter table public.assets add column if not exists location_id uuid references public.asset_locations(id) on delete set null;
alter table public.assets add column if not exists manufacturer text;
alter table public.assets add column if not exists model text;
alter table public.assets add column if not exists order_number text;
update public.assets a set location_id = l.id from public.asset_locations l where l.company_id = a.company_id and l.name = trim(a.location) and a.location_id is null;
alter table public.assets drop constraint if exists assets_state_check;
alter table public.assets add constraint assets_state_check check (state in ('ready','deployed','pending','repair','broken','lost','archived','transit'));

create or replace function public.location_manager(p_location uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from asset_locations where id = p_location and manager_id = auth.uid());
$$;

create or replace function public.location_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if coalesce(current_setting('sika.seed', true), '') <> 'on' and not asset_manager(coalesce(new.company_id, old.company_id)) then
    raise exception 'Only the storekeeper, Finance or an admin can change locations';
  end if;
  return coalesce(new, old);
end $$;
create trigger asset_locations_guard before insert or update or delete on public.asset_locations for each row execute function public.location_guard();

-- Keep the free-text location in step with the chosen location.
create or replace function public.asset_location_text() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.location_id is not null and (tg_op = 'INSERT' or new.location_id is distinct from old.location_id) then
    new.location := (select name from asset_locations where id = new.location_id);
  end if;
  return new;
end $$;
create trigger assets_location_text before insert or update of location_id on public.assets for each row execute function public.asset_location_text();

-- ---------------------------------------------------------------- 3. Transfers between locations
create table public.asset_transfers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  asset_id uuid not null references public.assets(id) on delete cascade,
  from_location_id uuid references public.asset_locations(id),
  to_location_id uuid not null references public.asset_locations(id),
  sent_by uuid default auth.uid(), sent_at timestamptz not null default now(),
  note text,
  waybill_id uuid,
  status text not null default 'in_transit' check (status in ('in_transit','received','rejected','recalled')),
  closed_by uuid, closed_at timestamptz, close_note text, condition text
);
create index on public.asset_transfers (company_id, status);

create or replace function public.send_asset_transfer(p_asset uuid, p_to uuid, p_note text default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare a assets; v uuid; n text; v_to asset_locations;
begin
  select * into a from assets where id = p_asset for update;
  if not found then raise exception 'Asset not found'; end if;
  if not (asset_manager(a.company_id) or location_manager(a.location_id)) then raise exception 'Only the storekeeper or the manager of the location holding it can send it'; end if;
  if a.state not in ('ready','pending','repair','broken') then raise exception '% is % — check it in first', a.tag, a.state; end if;
  select * into v_to from asset_locations where id = p_to and company_id = a.company_id and active;
  if not found then raise exception 'Choose where it is going'; end if;
  if a.location_id = p_to then raise exception '% is already at %', a.tag, v_to.name; end if;
  n := next_number(a.company_id, 'ATR', 'ATR-');
  insert into asset_transfers (company_id, number, asset_id, from_location_id, to_location_id, note) values (a.company_id, n, a.id, a.location_id, p_to, p_note) returning id into v;
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, note, state_after)
  values (a.company_id, a.id, 'move', a.location, v_to.name || ' (in transit)', concat_ws(' · ', n, p_note), 'transit');
  update assets set state = 'transit' where id = a.id;
  perform notify_users(a.company_id, array_remove(array[v_to.manager_id], null) || transport_users(a.company_id), 'asset_transfer', n || ': ' || a.tag || ' ' || a.name || ' is on its way to ' || v_to.name, p_note, '/assets/transfers', false);
  perform send_telegram(a.company_id, 'transfer', '🚚 ' || n || ': ' || a.tag || ' ' || a.name || ' sent from ' || coalesce(a.location, '—') || ' to ' || v_to.name || coalesce(' — ' || p_note, ''));
  return v;
end $$;

create or replace function public.close_asset_transfer(p_id uuid, p_action text, p_note text default null, p_condition text default 'good') returns void
language plpgsql security definer set search_path = public as $$
declare t asset_transfers; a assets; v_loc uuid; v_state text; v_name text;
begin
  select * into t from asset_transfers where id = p_id for update;
  if not found then raise exception 'Transfer not found'; end if;
  if t.status <> 'in_transit' then raise exception 'This transfer is already %', t.status; end if;
  if p_action = 'receive' then
    if not (asset_manager(t.company_id) or location_manager(t.to_location_id)) then raise exception 'Only the receiving location''s manager or the storekeeper can confirm receipt'; end if;
    v_loc := t.to_location_id; v_state := case when p_condition in ('broken') then 'broken' when p_condition = 'poor' then 'repair' else 'ready' end;
  elsif p_action = 'reject' then
    if not (asset_manager(t.company_id) or location_manager(t.to_location_id)) then raise exception 'Only the receiving location can reject it'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Say why it is rejected'; end if;
    v_loc := t.from_location_id; v_state := 'ready';
  elsif p_action = 'recall' then
    if not (asset_manager(t.company_id) or t.sent_by = auth.uid() or location_manager(t.from_location_id)) then raise exception 'Only the sender can recall it'; end if;
    v_loc := t.from_location_id; v_state := 'ready';
  else raise exception 'Unknown action %', p_action;
  end if;
  select * into a from assets where id = t.asset_id for update;
  select name into v_name from asset_locations where id = v_loc;
  perform set_config('sika.transfer', 'on', true);
  update asset_transfers set status = case p_action when 'receive' then 'received' when 'reject' then 'rejected' else 'recalled' end,
    closed_by = auth.uid(), closed_at = now(), close_note = p_note, condition = case when p_action = 'receive' then p_condition end where id = p_id;
  update assets set state = v_state, location_id = v_loc where id = a.id;
  insert into asset_movements (company_id, asset_id, kind, from_location, to_location, note, state_after)
  values (t.company_id, a.id, 'move', 'In transit', v_name, concat_ws(' · ', t.number, initcap(p_action) || case when p_action = 'receive' then 'd' else 'ed' end, p_note), v_state);
  perform set_config('sika.transfer', 'off', true);
  perform notify_users(t.company_id, array[t.sent_by], 'asset_transfer_' || p_action, t.number || ': ' || a.tag || ' ' || case p_action when 'receive' then 'received at ' when 'reject' then 'rejected, coming back to ' else 'recalled to ' end || coalesce(v_name, ''), p_note, '/assets/transfers', false);
  perform send_telegram(t.company_id, 'transfer', case p_action when 'receive' then '✅ ' when 'reject' then '⛔ ' else '↩️ ' end || t.number || ': ' || a.tag || ' ' || a.name || ' ' ||
    case p_action when 'receive' then 'received at ' || v_name || ' (' || p_condition || ')' when 'reject' then 'rejected — ' || p_note else 'recalled' end);
end $$;

-- While in transit, an asset can only be received, rejected or recalled.
create or replace function public.asset_transit_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.state = 'transit' and new.state is distinct from 'transit' and coalesce(current_setting('sika.transfer', true), '') <> 'on' then
    raise exception '% is in transit. Receive, reject or recall the transfer first.', old.tag;
  end if;
  return new;
end $$;
create trigger assets_transit_guard before update of state on public.assets for each row execute function public.asset_transit_guard();

-- ---------------------------------------------------------------- 4. Requests through the site, then head office
alter table public.asset_requests add column if not exists location_id uuid references public.asset_locations(id) on delete set null;
alter table public.asset_requests add column if not exists escalated boolean not null default false;
alter table public.asset_requests add column if not exists escalated_note text;
alter table public.asset_requests add column if not exists quantity int not null default 1 check (quantity > 0);

drop function if exists public.request_asset(uuid, text, uuid, uuid, uuid, date, date);
create or replace function public.request_asset(cid uuid, p_description text, p_asset uuid default null, p_category uuid default null, p_project uuid default null,
  p_from date default null, p_until date default null, p_location uuid default null, p_quantity int default 1)
returns uuid language plpgsql security definer set search_path = public as $$
declare v uuid; v_emp uuid; n text; v_mgr uuid; v_who text;
begin
  perform require_member(cid);
  if coalesce(trim(p_description), '') = '' and p_asset is null then raise exception 'Say what you need'; end if;
  if p_asset is not null and not exists (select 1 from assets where id = p_asset and company_id = cid and requestable and status = 'active') then raise exception 'That asset cannot be requested'; end if;
  if p_until is not null and p_until < coalesce(p_from, current_date) then raise exception 'The return date is before the start date'; end if;
  select id into v_emp from employees where company_id = cid and user_id = auth.uid() limit 1;
  select manager_id into v_mgr from asset_locations where id = p_location and company_id = cid;
  n := next_number(cid, 'ARQ', 'ARQ-');
  insert into asset_requests (company_id, number, asset_id, category_id, description, employee_id, project_id, needed_from, needed_until, location_id, quantity)
  values (cid, n, p_asset, p_category, coalesce(nullif(trim(p_description), ''), (select tag || ' ' || name from assets where id = p_asset)), v_emp, p_project,
          coalesce(p_from, current_date), p_until, p_location, greatest(coalesce(p_quantity, 1), 1))
  returning id into v;
  v_who := (select email from memberships where company_id = cid and user_id = auth.uid());
  if v_mgr is not null and v_mgr <> auth.uid() then
    perform notify_users(cid, array[v_mgr], 'asset_requested', n || ': ' || coalesce(nullif(trim(p_description), ''), 'asset requested'), v_who, '/assets/requests', false);
  else
    perform notify(cid, array['store'], null, 'asset_requested', n || ': ' || coalesce(nullif(trim(p_description), ''), 'asset requested'), v_who, '/assets/requests');
  end if;
  perform send_telegram(cid, 'request', '📝 ' || n || ': ' || coalesce(nullif(trim(p_description), ''), 'asset requested') || ' — ' || coalesce(split_part(v_who, '@', 1), '')
    || coalesce(' · ' || (select name from asset_locations where id = p_location), '') || ' · needed ' || to_char(coalesce(p_from, current_date), 'DD Mon') || coalesce(' to ' || to_char(p_until, 'DD Mon'), ''));
  return v;
end $$;

create or replace function public.decide_asset_request(p_id uuid, p_approve boolean, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r asset_requests;
begin
  select * into r from asset_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if r.requested_by = auth.uid() and not p_approve and not asset_manager(r.company_id) then
    if r.status not in ('pending','approved') then raise exception 'Already %', r.status; end if;
    update asset_requests set status = 'cancelled' where id = p_id; return;
  end if;
  if not (asset_manager(r.company_id) or (not r.escalated and location_manager(r.location_id))) then
    raise exception 'Only the site manager (or, once passed on, head office) can decide this request';
  end if;
  if r.requested_by = auth.uid() then raise exception 'You cannot approve your own request'; end if;
  if r.status <> 'pending' then raise exception 'Already %', r.status; end if;
  update asset_requests set status = case when p_approve then 'approved' else 'rejected' end, decided_by = auth.uid(), decided_on = current_date, decision_note = p_note where id = p_id;
  perform notify_users(r.company_id, array[r.requested_by], 'asset_request_decided', r.number || ' ' || case when p_approve then 'approved' else 'declined' end, p_note, '/assets/requests', true);
  perform send_telegram(r.company_id, 'decision', case when p_approve then '👍 ' else '👎 ' end || r.number || ' ' || case when p_approve then 'approved' else 'declined' end || ': ' || r.description || coalesce(' — ' || p_note, ''));
end $$;

-- The site manager passes a request on to head office (the storekeeper and Finance).
create or replace function public.escalate_asset_request(p_id uuid, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare r asset_requests;
begin
  select * into r from asset_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if not (location_manager(r.location_id) or asset_manager(r.company_id)) then raise exception 'Only the site manager can pass a request on'; end if;
  if r.status <> 'pending' or r.escalated then raise exception 'This request has already been passed on or decided'; end if;
  update asset_requests set escalated = true, escalated_note = p_note where id = p_id;
  perform notify(r.company_id, array['store'], null, 'asset_requested', r.number || ' passed to head office: ' || r.description, p_note, '/assets/requests');
  perform send_telegram(r.company_id, 'request', '⬆️ ' || r.number || ' passed to head office: ' || r.description || coalesce(' — ' || p_note, ''));
end $$;

drop policy if exists "requests read" on public.asset_requests;
create policy "requests read" on public.asset_requests for select using (requested_by = auth.uid() or asset_manager(company_id) or has_role(company_id, array['project_manager','hr']) or location_manager(location_id));

-- ---------------------------------------------------------------- 5. Accessories, components and consumables
create table public.asset_items (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  kind text not null check (kind in ('accessory','component','consumable')),
  name text not null,
  category text,
  manufacturer text,
  model_no text,
  unit text not null default 'each',
  min_qty numeric(12,2) not null default 0,
  unit_cost numeric(14,2),
  requestable boolean not null default false,
  notes text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.asset_item_stock (
  item_id uuid not null references public.asset_items(id) on delete cascade,
  location_id uuid not null references public.asset_locations(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete cascade,
  qty numeric(12,2) not null default 0 check (qty >= 0),
  primary key (item_id, location_id)
);
create table public.asset_item_moves (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  item_id uuid not null references public.asset_items(id) on delete cascade,
  kind text not null check (kind in ('receive','checkout','checkin','consume','transfer','adjust')),
  location_id uuid references public.asset_locations(id),
  to_location_id uuid references public.asset_locations(id),
  qty numeric(12,2) not null,
  employee_id uuid references public.employees(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  unit_cost numeric(14,2),
  note text,
  moved_by uuid default auth.uid(),
  moved_at timestamptz not null default now()
);
create index on public.asset_item_moves (item_id, moved_at desc);
create table public.asset_item_checkouts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  item_id uuid not null references public.asset_items(id) on delete cascade,
  location_id uuid not null references public.asset_locations(id),
  employee_id uuid references public.employees(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  qty numeric(12,2) not null check (qty > 0),
  returned_qty numeric(12,2) not null default 0,
  out_at timestamptz not null default now(),
  expected_return date,
  status text not null default 'out' check (status in ('out','returned')),
  note text
);

create or replace function public.item_total(p_item uuid) returns numeric
language sql stable security definer set search_path = public as $$ select coalesce(sum(qty), 0) from asset_item_stock where item_id = p_item; $$;

create or replace function public.item_stock_change(p_item uuid, p_location uuid, p_delta numeric) returns void
language plpgsql security definer set search_path = public as $$
declare i asset_items; v_have numeric;
begin
  select * into i from asset_items where id = p_item;
  insert into asset_item_stock (item_id, location_id, company_id, qty) values (p_item, p_location, i.company_id, 0) on conflict do nothing;
  select qty into v_have from asset_item_stock where item_id = p_item and location_id = p_location for update;
  if v_have + p_delta < 0 then raise exception 'Only % % of % at %', v_have, i.unit, i.name, (select name from asset_locations where id = p_location); end if;
  update asset_item_stock set qty = qty + p_delta where item_id = p_item and location_id = p_location;
  if p_delta < 0 and i.min_qty > 0 and item_total(p_item) < i.min_qty and item_total(p_item) - p_delta >= i.min_qty then
    perform notify(i.company_id, array['store'], null, 'low_stock', 'Low stock: ' || i.name, item_total(p_item) || ' ' || i.unit || ' left (minimum ' || i.min_qty || ')', '/assets/items', true);
    perform send_telegram(i.company_id, 'low_stock', '⚠️ Low stock: ' || i.name || ' — ' || item_total(p_item) || ' ' || i.unit || ' left (minimum ' || i.min_qty || ')');
  end if;
end $$;
revoke execute on function public.item_stock_change(uuid, uuid, numeric) from public, anon, authenticated;

-- Receive, issue, return, consume, transfer or adjust.
create or replace function public.item_move(p_item uuid, p_kind text, p_location uuid, p_qty numeric, p_to uuid default null, p_employee uuid default null,
  p_asset uuid default null, p_project uuid default null, p_unit_cost numeric default null, p_note text default null, p_checkout uuid default null, p_expected date default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare i asset_items; c asset_item_checkouts; v uuid;
begin
  select * into i from asset_items where id = p_item;
  if not found then raise exception 'Item not found'; end if;
  if not (asset_manager(i.company_id) or location_manager(p_location)) then raise exception 'Only the storekeeper or the location manager can move stock'; end if;
  if p_kind <> 'adjust' and coalesce(p_qty, 0) <= 0 then raise exception 'Enter a quantity'; end if;
  if p_kind = 'receive' then perform item_stock_change(p_item, p_location, p_qty);
    if p_unit_cost is not null then update asset_items set unit_cost = p_unit_cost where id = p_item; end if;
  elsif p_kind = 'consume' then perform item_stock_change(p_item, p_location, -p_qty);
  elsif p_kind = 'checkout' then
    if i.kind = 'consumable' then raise exception 'Consumables are used up, not checked out'; end if;
    if p_employee is null and p_asset is null then raise exception 'Check it out to a person or into an asset'; end if;
    perform item_stock_change(p_item, p_location, -p_qty);
    insert into asset_item_checkouts (company_id, item_id, location_id, employee_id, asset_id, qty, expected_return, note)
    values (i.company_id, p_item, p_location, p_employee, p_asset, p_qty, p_expected, p_note);
  elsif p_kind = 'checkin' then
    select * into c from asset_item_checkouts where id = p_checkout and item_id = p_item for update;
    if not found or c.status <> 'out' then raise exception 'Choose what is being returned'; end if;
    if p_qty > c.qty - c.returned_qty then raise exception 'Only % are out', c.qty - c.returned_qty; end if;
    perform item_stock_change(p_item, p_location, p_qty);
    update asset_item_checkouts set returned_qty = returned_qty + p_qty, status = case when returned_qty + p_qty >= qty then 'returned' else 'out' end where id = c.id;
    p_employee := c.employee_id; p_asset := c.asset_id;
  elsif p_kind = 'transfer' then
    if p_to is null or p_to = p_location then raise exception 'Choose where it is going'; end if;
    perform item_stock_change(p_item, p_location, -p_qty);
    perform item_stock_change(p_item, p_to, p_qty);
  elsif p_kind = 'adjust' then
    if coalesce(trim(p_note), '') = '' then raise exception 'Give a reason for the adjustment'; end if;
    perform item_stock_change(p_item, p_location, p_qty);
  else raise exception 'Unknown movement %', p_kind;
  end if;
  insert into asset_item_moves (company_id, item_id, kind, location_id, to_location_id, qty, employee_id, asset_id, project_id, unit_cost, note)
  values (i.company_id, p_item, p_kind, p_location, p_to, p_qty, p_employee, p_asset, p_project, coalesce(p_unit_cost, i.unit_cost), p_note) returning id into v;
  return v;
end $$;

-- ---------------------------------------------------------------- 6. Software licences
create table public.software_licences (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  manufacturer text,
  product_key text,
  seats int not null default 1 check (seats > 0),
  licensed_to_name text,
  licensed_to_email text,
  purchase_date date,
  cost numeric(14,2),
  expires_on date,
  order_number text,
  supplier_id uuid references public.suppliers(id) on delete set null,
  reassignable boolean not null default true,
  notes text,
  reminded_on date,
  created_at timestamptz not null default now()
);
create table public.licence_seats (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  licence_id uuid not null references public.software_licences(id) on delete cascade,
  employee_id uuid references public.employees(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  assigned_at timestamptz not null default now(),
  released_at timestamptz,
  note text,
  check (employee_id is not null or asset_id is not null)
);
create or replace function public.licence_seat_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare l software_licences; v_used int;
begin
  select * into l from software_licences where id = coalesce(new.licence_id, old.licence_id);
  if not asset_manager(l.company_id) then raise exception 'Only the storekeeper, Finance or an admin can assign licences'; end if;
  if tg_op = 'INSERT' then
    new.company_id := l.company_id;
    select count(*) into v_used from licence_seats where licence_id = l.id and released_at is null;
    if v_used >= l.seats then raise exception 'All % seats of % are in use. Free one first.', l.seats, l.name; end if;
  elsif tg_op = 'UPDATE' and old.released_at is null and new.released_at is not null and not l.reassignable then
    raise exception '% seats cannot be reassigned', l.name;
  end if;
  return coalesce(new, old);
end $$;
create trigger licence_seats_guard before insert or update or delete on public.licence_seats for each row execute function public.licence_seat_guard();

-- ---------------------------------------------------------------- 7. Fleet: vehicles, documents, drivers
create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  asset_id uuid references public.assets(id) on delete set null,
  reg_no text not null,
  make text, model text, year int,
  vehicle_type text not null default 'pickup' check (vehicle_type in ('car','pickup','van','truck','bus','motorbike','plant','crane','trailer','other')),
  fuel_type text not null default 'diesel' check (fuel_type in ('diesel','petrol','lpg','electric','hybrid')),
  chassis_no text, engine_no text, colour text,
  capacity_kg numeric(10,1), seats int,
  odometer numeric(10,0) not null default 0 check (odometer >= 0),
  tank_litres numeric(8,1),
  expected_km_per_l numeric(6,2),
  service_interval_km int,
  service_interval_months int,
  last_service_km numeric(10,0),
  last_service_date date,
  driver_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  location_id uuid references public.asset_locations(id) on delete set null,
  status text not null default 'available' check (status in ('available','in_use','maintenance','off_road','disposed')),
  notes text,
  created_at timestamptz not null default now(),
  unique (company_id, reg_no)
);
create table public.vehicle_documents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  kind text not null check (kind in ('roadworthy','insurance','road_use','registration','permit','tracker','other')),
  reference text,
  provider text,
  issued_on date,
  expires_on date,
  cost numeric(14,2),
  storage_path text,
  reminded_for date,
  created_at timestamptz not null default now()
);
create table public.drivers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  employee_id uuid not null references public.employees(id) on delete cascade,
  licence_no text,
  licence_class text,
  licence_expiry date,
  defensive_training_on date,
  medical_expiry date,
  active boolean not null default true,
  notes text,
  reminded_for date,
  unique (company_id, employee_id)
);

-- ---------------------------------------------------------------- 8. Trips, fuel, service, requests
create table public.vehicle_requests (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  requested_by uuid not null default auth.uid(),
  employee_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  purpose text not null,
  origin text, destination text,
  from_at timestamptz not null, to_at timestamptz not null,
  passengers int, load_desc text,
  vehicle_type text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','cancelled','done')),
  vehicle_id uuid references public.vehicles(id) on delete set null,
  driver_id uuid references public.employees(id) on delete set null,
  decided_by uuid, decided_at timestamptz, decision_note text,
  created_at timestamptz not null default now(),
  check (to_at > from_at)
);
create table public.vehicle_trips (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  driver_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  request_id uuid references public.vehicle_requests(id) on delete set null,
  purpose text not null,
  origin text, destination text,
  start_at timestamptz, end_at timestamptz,
  odometer_start numeric(10,0), odometer_end numeric(10,0),
  distance_km numeric(10,0) generated always as (odometer_end - odometer_start) stored,
  passengers int, load_desc text,
  status text not null default 'planned' check (status in ('planned','in_progress','completed','cancelled')),
  out_of_hours boolean not null default false,
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.vehicle_trips (vehicle_id, start_at desc);
create table public.vehicle_fuel (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  filled_on date not null default current_date,
  litres numeric(10,2) not null check (litres > 0),
  cost numeric(14,2) not null default 0 check (cost >= 0),
  odometer numeric(10,0),
  full_tank boolean not null default true,
  station text,
  paid_by text not null default 'cash' check (paid_by in ('cash','fuel_card','account','advance','petty_cash','other')),
  driver_id uuid references public.employees(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  receipt_path text,
  km_per_l numeric(8,2),
  flagged boolean not null default false,
  esg_entry_id uuid,
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index on public.vehicle_fuel (vehicle_id, filled_on desc);
create table public.vehicle_services (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  number text,
  service_date date not null default current_date,
  odometer numeric(10,0),
  kind text not null default 'service' check (kind in ('service','repair','tyres','battery','inspection','accident','bodywork','other')),
  description text not null,
  vendor text,
  cost numeric(14,2) not null default 0 check (cost >= 0),
  parts text,
  downtime_days numeric(6,1),
  next_due_km numeric(10,0),
  next_due_date date,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create or replace function public.fleet_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare cid uuid := coalesce(new.company_id, old.company_id);
begin
  if tg_table_name = 'vehicle_requests' then
    if tg_op = 'INSERT' then
      if not is_member(new.company_id) then raise exception 'You do not have access to this company'; end if;
      new.number := next_number(new.company_id, 'VRQ', 'VRQ-'); new.status := 'pending'; new.requested_by := auth.uid();
      new.employee_id := coalesce(new.employee_id, (select id from employees where company_id = new.company_id and user_id = auth.uid() limit 1));
    elsif coalesce(current_setting('sika.fleet', true), '') <> 'on' and (new.status, new.vehicle_id) is distinct from (old.status, old.vehicle_id) then
      raise exception 'Use Approve, Decline or Cancel';
    end if;
    return new;
  end if;
  if tg_table_name = 'vehicle_trips' and tg_op = 'INSERT' then
    new.number := next_number(new.company_id, 'TRP', 'TRP-');
    if not (is_transport(new.company_id) or exists (select 1 from employees where id = new.driver_id and user_id = auth.uid())) then
      raise exception 'Only the transport officer or the trip''s driver can log a trip';
    end if;
    return new;
  end if;
  if tg_table_name = 'vehicle_services' and tg_op = 'INSERT' then new.number := next_number(new.company_id, 'JOB', 'JOB-'); end if;
  if tg_table_name in ('vehicles','vehicle_documents','drivers','vehicle_services') and coalesce(current_setting('sika.fleet', true), '') <> 'on' and not is_transport(cid) then
    raise exception 'Only the transport officer, storekeeper, Finance or an admin can change fleet records';
  end if;
  return coalesce(new, old);
end $$;
create trigger vehicles_guard before insert or update or delete on public.vehicles for each row execute function public.fleet_defaults();
create trigger vehicle_documents_guard before insert or update or delete on public.vehicle_documents for each row execute function public.fleet_defaults();
create trigger drivers_guard before insert or update or delete on public.drivers for each row execute function public.fleet_defaults();
create trigger vehicle_services_guard before insert or update or delete on public.vehicle_services for each row execute function public.fleet_defaults();
create trigger vehicle_requests_defaults before insert or update on public.vehicle_requests for each row execute function public.fleet_defaults();
create trigger vehicle_trips_defaults before insert on public.vehicle_trips for each row execute function public.fleet_defaults();

-- A service updates the vehicle's last service.
create or replace function public.vehicle_service_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform set_config('sika.fleet', 'on', true);
  update vehicles set last_service_km = case when new.kind = 'service' then coalesce(new.odometer, last_service_km) else last_service_km end,
    last_service_date = case when new.kind = 'service' then new.service_date else last_service_date end,
    odometer = greatest(odometer, coalesce(new.odometer, 0))
  where id = new.vehicle_id;
  perform set_config('sika.fleet', 'off', true);
  return null;
end $$;
create trigger vehicle_services_after after insert on public.vehicle_services for each row execute function public.vehicle_service_after();

create or replace function public.decide_vehicle_request(p_id uuid, p_action text, p_vehicle uuid default null, p_driver uuid default null, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare r vehicle_requests; v vehicles; v_clash text;
begin
  select * into r from vehicle_requests where id = p_id for update;
  if not found then raise exception 'Request not found'; end if;
  if p_action = 'cancel' then
    if not (r.requested_by = auth.uid() or is_transport(r.company_id)) then raise exception 'Only the requester can cancel'; end if;
    if r.status not in ('pending','approved') then raise exception 'Already %', r.status; end if;
  else
    if not is_transport(r.company_id) then raise exception 'Only the transport officer allocates vehicles'; end if;
    if r.status <> 'pending' then raise exception 'Already %', r.status; end if;
    if p_action = 'approve' then
      select * into v from vehicles where id = p_vehicle and company_id = r.company_id;
      if not found then raise exception 'Choose a vehicle'; end if;
      if v.status in ('maintenance','off_road','disposed') then raise exception '% is %', v.reg_no, replace(v.status, '_', ' '); end if;
      select q.number into v_clash from vehicle_requests q where q.vehicle_id = p_vehicle and q.status = 'approved' and q.id <> r.id and tstzrange(q.from_at, q.to_at) && tstzrange(r.from_at, r.to_at) limit 1;
      if v_clash is not null then raise exception '% is already booked then (%)', v.reg_no, v_clash; end if;
    elsif p_action = 'reject' and coalesce(trim(p_note), '') = '' then raise exception 'Give a reason';
    end if;
  end if;
  perform set_config('sika.fleet', 'on', true);
  update vehicle_requests set status = case p_action when 'approve' then 'approved' when 'reject' then 'rejected' else 'cancelled' end,
    vehicle_id = case when p_action = 'approve' then p_vehicle else vehicle_id end, driver_id = case when p_action = 'approve' then coalesce(p_driver, (select driver_id from vehicles where id = p_vehicle)) else driver_id end,
    decided_by = auth.uid(), decided_at = now(), decision_note = p_note where id = p_id;
  perform set_config('sika.fleet', 'off', true);
  if p_action <> 'cancel' then
    perform notify_users(r.company_id, array[r.requested_by, (select user_id from employees where id = coalesce(p_driver, (select driver_id from vehicles where id = p_vehicle)))],
      'vehicle_request', r.number || case when p_action = 'approve' then ': ' || (select reg_no from vehicles where id = p_vehicle) || ' allocated' else ' declined' end, p_note, '/fleet/requests', false);
    perform send_telegram(r.company_id, 'decision', '🚗 ' || r.number || case when p_action = 'approve' then ' — ' || (select reg_no from vehicles where id = p_vehicle) || ' allocated for ' || r.purpose else ' declined: ' || p_note end);
  end if;
end $$;

create or replace function public.vehicle_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform notify_users(new.company_id, transport_users(new.company_id), 'vehicle_request', new.number || ': vehicle needed — ' || new.purpose,
    to_char(new.from_at, 'DD Mon HH24:MI') || ' to ' || to_char(new.to_at, 'DD Mon HH24:MI') || coalesce(' · ' || new.destination, ''), '/fleet/requests', false);
  perform send_telegram(new.company_id, 'request', '🚗 ' || new.number || ': vehicle needed — ' || new.purpose || ' · ' || to_char(new.from_at, 'DD Mon HH24:MI') || coalesce(' to ' || new.destination, ''));
  return null;
end $$;
create trigger vehicle_requests_notice after insert on public.vehicle_requests for each row execute function public.vehicle_request_notice();

-- Start and finish trips: mileage only goes forward; the vehicle is shown in use.
create or replace function public.trip_step(p_trip uuid, p_action text, p_odometer numeric default null, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare t vehicle_trips; v vehicles;
begin
  select * into t from vehicle_trips where id = p_trip for update;
  if not found then raise exception 'Trip not found'; end if;
  if not (is_transport(t.company_id) or exists (select 1 from employees where id = t.driver_id and user_id = auth.uid())) then raise exception 'Only the driver or the transport officer can update this trip'; end if;
  select * into v from vehicles where id = t.vehicle_id for update;
  perform set_config('sika.fleet', 'on', true);
  if p_action = 'start' then
    if t.status <> 'planned' then raise exception 'This trip has already started'; end if;
    if p_odometer is null then raise exception 'Enter the mileage at the start'; end if;
    if p_odometer < v.odometer then raise exception 'The mileage cannot be less than the last reading (% km)', v.odometer; end if;
    if v.status in ('in_use') and exists (select 1 from vehicle_trips where vehicle_id = v.id and status = 'in_progress') then raise exception '% is already on a trip', v.reg_no; end if;
    update vehicle_trips set status = 'in_progress', start_at = coalesce(start_at, now()), odometer_start = p_odometer,
      out_of_hours = extract(isodow from now()) > 5 or extract(hour from now()) not between 6 and 18 where id = t.id;
    update vehicles set status = 'in_use', odometer = p_odometer where id = v.id;
  elsif p_action = 'finish' then
    if t.status <> 'in_progress' then raise exception 'Start the trip first'; end if;
    if p_odometer is null or p_odometer < t.odometer_start then raise exception 'The mileage at the end must be at least % km', t.odometer_start; end if;
    if p_odometer - t.odometer_start > 2000 then raise exception 'That is more than 2,000 km in one trip. Check the reading.'; end if;
    update vehicle_trips set status = 'completed', end_at = now(), odometer_end = p_odometer, note = coalesce(p_note, note) where id = t.id;
    update vehicles set status = 'available', odometer = greatest(odometer, p_odometer) where id = v.id;
    if t.request_id is not null then update vehicle_requests set status = 'done' where id = t.request_id; end if;
  elsif p_action = 'cancel' then
    if t.status = 'completed' then raise exception 'A completed trip cannot be cancelled'; end if;
    update vehicle_trips set status = 'cancelled', note = coalesce(p_note, note) where id = t.id;
    if t.status = 'in_progress' then update vehicles set status = 'available' where id = v.id; end if;
  else raise exception 'Unknown action %', p_action;
  end if;
  perform set_config('sika.fleet', 'off', true);
end $$;

-- Fuel: km per litre between full tanks; low economy is flagged; the litres also go to the sustainability figures.
create or replace function public.vehicle_fuel_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare v vehicles; p vehicle_fuel; v_litres numeric; v_factor uuid; v_esg uuid;
begin
  select * into v from vehicles where id = new.vehicle_id;
  new.company_id := v.company_id;
  if not (is_transport(v.company_id) or v.driver_id in (select my_employee_ids()) or exists (select 1 from vehicle_trips t where t.vehicle_id = v.id and t.status = 'in_progress' and t.driver_id in (select my_employee_ids()))) then
    raise exception 'Only the vehicle''s driver or the transport officer can log fuel';
  end if;
  if new.odometer is not null and new.odometer < (select coalesce(max(odometer), 0) from vehicle_fuel where vehicle_id = v.id and filled_on <= new.filled_on) then
    raise exception 'The mileage is lower than at the previous fill';
  end if;
  new.driver_id := coalesce(new.driver_id, v.driver_id); new.project_id := coalesce(new.project_id, v.project_id);
  if new.full_tank and new.odometer is not null then
    select * into p from vehicle_fuel where vehicle_id = v.id and full_tank and odometer is not null and odometer < new.odometer order by odometer desc limit 1;
    if found then
      select coalesce(sum(litres), 0) into v_litres from vehicle_fuel where vehicle_id = v.id and odometer > p.odometer and odometer < new.odometer;
      new.km_per_l := round((new.odometer - p.odometer) / nullif(v_litres + new.litres, 0), 2);
      new.flagged := v.expected_km_per_l is not null and new.km_per_l < v.expected_km_per_l * 0.8;
    end if;
  end if;
  -- Sustainability (scope 1): diesel or petrol litres.
  select id into v_factor from esg_factors where company_id = v.company_id and key = case v.fuel_type when 'petrol' then 'petrol_l' when 'lpg' then 'lpg_l' else 'diesel_l' end and active;
  if v_factor is not null and v.fuel_type in ('diesel','petrol','lpg') then
    perform set_config('sika.hse', 'on', true);
    insert into esg_entries (company_id, period, factor_id, quantity, factor_used, kg_co2e, project_id, source_ref, note)
    select v.company_id, date_trunc('month', new.filled_on)::date, f.id, new.litres, f.kg_co2e, round(new.litres * f.kg_co2e, 3), new.project_id, 'Fuel log ' || v.reg_no, new.station
    from esg_factors f where f.id = v_factor returning id into v_esg;
    new.esg_entry_id := v_esg;
  end if;
  perform set_config('sika.fleet', 'on', true);
  update vehicles set odometer = greatest(odometer, coalesce(new.odometer, 0)) where id = v.id;
  perform set_config('sika.fleet', 'off', true);
  return new;
end $$;
create trigger vehicle_fuel_defaults before insert on public.vehicle_fuel for each row execute function public.vehicle_fuel_defaults();
create or replace function public.vehicle_fuel_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare v vehicles;
begin
  if new.flagged then
    select * into v from vehicles where id = new.vehicle_id;
    perform notify_users(new.company_id, transport_users(new.company_id), 'fuel_flag', 'Fuel use high: ' || v.reg_no, new.km_per_l || ' km/l against ' || v.expected_km_per_l || ' expected. Check for leaks, misuse or a wrong reading.', '/fleet/fuel', true);
    perform send_telegram(new.company_id, 'fleet', '⛽ Fuel use high on ' || v.reg_no || ': ' || new.km_per_l || ' km/l (expected ' || v.expected_km_per_l || ')');
  end if;
  return null;
end $$;
create trigger vehicle_fuel_notice after insert on public.vehicle_fuel for each row execute function public.vehicle_fuel_notice();

-- Sustainability entries made from the fuel log are allowed without the HSE checks.
create or replace function public.esg_entry_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare f esg_factors;
begin
  if coalesce(current_setting('sika.hse', true), '') <> 'on' and not (is_hse(new.company_id) or has_role(new.company_id, array['accountant','store','project_manager'])) then
    raise exception 'Only an HSE officer, Finance, the storekeeper or a project manager can record sustainability data';
  end if;
  select * into f from esg_factors where id = new.factor_id;
  if f.company_id is distinct from new.company_id then raise exception 'Choose one of your own emission factors'; end if;
  new.period := date_trunc('month', new.period)::date;
  if tg_op = 'INSERT' or new.factor_id is distinct from old.factor_id or new.quantity is distinct from old.quantity then
    new.factor_used := f.kg_co2e;
    new.kg_co2e := round(new.quantity * f.kg_co2e, 3);
  end if;
  return new;
end $$;

-- ---------------------------------------------------------------- 9. Waybills (deliveries and collections, own or hired transport)
create table public.waybills (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  kind text not null default 'delivery' check (kind in ('delivery','collection','transfer','return')),
  transport text not null default 'own' check (transport in ('own','hired','courier')),
  vehicle_id uuid references public.vehicles(id) on delete set null,
  driver_id uuid references public.employees(id) on delete set null,
  transporter_id uuid references public.suppliers(id) on delete set null,
  truck_reg text, driver_name text, driver_phone text,
  project_id uuid references public.projects(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null,
  from_place text not null,
  to_place text not null,
  contact_name text, contact_phone text,
  planned_on date not null default current_date,
  dispatched_at timestamptz, expected_at timestamptz, delivered_at timestamptz,
  status text not null default 'draft' check (status in ('draft','dispatched','delivered','partial','cancelled')),
  received_by_name text,
  pod_path text,
  pod_note text,
  transport_cost numeric(14,2) not null default 0 check (transport_cost >= 0),
  po_id uuid,
  note text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create table public.waybill_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  waybill_id uuid not null references public.waybills(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  asset_id uuid references public.assets(id) on delete set null,
  description text not null,
  qty numeric(12,2) not null check (qty > 0),
  unit text,
  weight_kg numeric(10,1),
  delivered_qty numeric(12,2),
  note text,
  sort int not null default 0
);
create or replace function public.waybill_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if not (is_transport(new.company_id) or has_role(new.company_id, array['project_manager','sales'])) then raise exception 'Only the transport officer, storekeeper, Finance or a project manager can raise waybills'; end if;
    new.number := next_number(new.company_id, 'WB', 'WB-'); new.status := 'draft';
  elsif coalesce(current_setting('sika.fleet', true), '') <> 'on' then
    if new.status is distinct from old.status then raise exception 'Use Dispatch, Delivered or Cancel'; end if;
    if old.status <> 'draft' and (new.from_place, new.to_place, new.vehicle_id, new.transport_cost) is distinct from (old.from_place, old.to_place, old.vehicle_id, old.transport_cost) and not is_transport(old.company_id) then
      raise exception 'A dispatched waybill can only be changed by the transport officer';
    end if;
    new.number := old.number;
  end if;
  return new;
end $$;
create trigger waybills_defaults before insert or update on public.waybills for each row execute function public.waybill_defaults();
create or replace function public.waybill_line_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare w waybills;
begin
  select * into w from waybills where id = coalesce(new.waybill_id, old.waybill_id);
  if coalesce(current_setting('sika.fleet', true), '') <> 'on' and w.status <> 'draft' then raise exception 'The waybill has been dispatched; its lines are fixed'; end if;
  if tg_op <> 'DELETE' then new.company_id := w.company_id; end if;
  return coalesce(new, old);
end $$;
create trigger waybill_lines_guard before insert or update or delete on public.waybill_lines for each row execute function public.waybill_line_guard();

create or replace function public.waybill_step(p_id uuid, p_action text, p_received_by text default null, p_note text default null, p_lines jsonb default null, p_pod text default null) returns text
language plpgsql security definer set search_path = public as $$
declare w waybills; v_to text; v_short int; l record;
begin
  select * into w from waybills where id = p_id for update;
  if not found then raise exception 'Waybill not found'; end if;
  perform set_config('sika.fleet', 'on', true);
  if p_action = 'dispatch' then
    if not (is_transport(w.company_id) or has_role(w.company_id, array['project_manager'])) then raise exception 'Only the transport officer or project manager can dispatch'; end if;
    if w.status <> 'draft' then raise exception 'Already %', w.status; end if;
    if not exists (select 1 from waybill_lines where waybill_id = p_id) then raise exception 'Add what is being carried'; end if;
    if w.transport = 'own' and w.vehicle_id is null then raise exception 'Choose the vehicle'; end if;
    if w.transport <> 'own' and coalesce(trim(w.truck_reg), '') = '' and w.transporter_id is null then raise exception 'Enter the transporter or truck registration'; end if;
    update waybills set status = 'dispatched', dispatched_at = now() where id = p_id; v_to := 'dispatched';
    perform notify_users(w.company_id, array[(select user_id from employees where id = w.driver_id), (select manager_id from projects where id = w.project_id)], 'waybill', w.number || ' on its way to ' || w.to_place, null, '/fleet/waybills', false);
    perform send_telegram(w.company_id, 'fleet', '📦 ' || w.number || ' dispatched: ' || w.from_place || ' → ' || w.to_place || coalesce(' · ' || (select reg_no from vehicles where id = w.vehicle_id), coalesce(' · ' || w.truck_reg, '')));
  elsif p_action = 'deliver' then
    if w.status <> 'dispatched' then raise exception 'Dispatch it first'; end if;
    if not (is_transport(w.company_id) or has_role(w.company_id, array['project_manager']) or exists (select 1 from employees where id = w.driver_id and user_id = auth.uid())) then raise exception 'Only the driver, the site or the transport officer can confirm delivery'; end if;
    if coalesce(trim(p_received_by), '') = '' then raise exception 'Enter the name of the person who received the goods'; end if;
    if p_lines is not null then
      for l in select (x->>'id')::uuid id, (x->>'delivered_qty')::numeric q from jsonb_array_elements(p_lines) x loop
        update waybill_lines set delivered_qty = l.q where id = l.id and waybill_id = p_id;
      end loop;
    end if;
    update waybill_lines set delivered_qty = coalesce(delivered_qty, qty) where waybill_id = p_id;
    select count(*) into v_short from waybill_lines where waybill_id = p_id and delivered_qty < qty;
    v_to := case when v_short > 0 then 'partial' else 'delivered' end;
    update waybills set status = v_to, delivered_at = now(), received_by_name = p_received_by, pod_note = p_note, pod_path = coalesce(p_pod, pod_path) where id = p_id;
    perform notify_users(w.company_id, transport_users(w.company_id) || array[w.created_by], 'waybill', w.number || ' ' || case when v_short > 0 then 'delivered short (' || v_short || ' line' || case when v_short = 1 then '' else 's' end || ')' else 'delivered' end || ' at ' || w.to_place, 'Received by ' || p_received_by, '/fleet/waybills', false);
    perform send_telegram(w.company_id, 'fleet', case when v_short > 0 then '⚠️ ' else '✅ ' end || w.number || ' ' || v_to || ' at ' || w.to_place || ' — received by ' || p_received_by);
  elsif p_action = 'cancel' then
    if not is_transport(w.company_id) then raise exception 'Only the transport officer can cancel'; end if;
    if w.status in ('delivered','partial') then raise exception 'A delivered waybill cannot be cancelled'; end if;
    if coalesce(trim(p_note), '') = '' then raise exception 'Give a reason'; end if;
    update waybills set status = 'cancelled', note = concat_ws(E'\n', note, 'Cancelled: ' || p_note) where id = p_id; v_to := 'cancelled';
  else raise exception 'Unknown action %', p_action;
  end if;
  perform set_config('sika.fleet', 'off', true);
  return v_to;
end $$;

-- ---------------------------------------------------------------- 10. Reports and reminders
create or replace function public.fleet_report(cid uuid, p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid);
  return jsonb_build_object(
    'vehicles', coalesce((select jsonb_agg(x order by x->>'reg_no') from (
      select jsonb_build_object('id', v.id, 'reg_no', v.reg_no, 'name', concat_ws(' ', v.make, v.model), 'type', v.vehicle_type, 'status', v.status, 'odometer', v.odometer,
        'km', coalesce((select sum(distance_km) from vehicle_trips t where t.vehicle_id = v.id and t.status = 'completed' and t.end_at::date between p_from and p_to), 0),
        'trips', (select count(*) from vehicle_trips t where t.vehicle_id = v.id and t.status = 'completed' and t.end_at::date between p_from and p_to),
        'litres', coalesce((select sum(litres) from vehicle_fuel f where f.vehicle_id = v.id and f.filled_on between p_from and p_to), 0),
        'fuel_cost', coalesce((select sum(cost) from vehicle_fuel f where f.vehicle_id = v.id and f.filled_on between p_from and p_to), 0),
        'service_cost', coalesce((select sum(cost) from vehicle_services s where s.vehicle_id = v.id and s.service_date between p_from and p_to), 0),
        'doc_cost', coalesce((select sum(cost) from vehicle_documents d where d.vehicle_id = v.id and d.issued_on between p_from and p_to), 0),
        'downtime', coalesce((select sum(downtime_days) from vehicle_services s where s.vehicle_id = v.id and s.service_date between p_from and p_to), 0),
        'km_per_l', (select round(avg(km_per_l), 2) from vehicle_fuel f where f.vehicle_id = v.id and f.km_per_l is not null and f.filled_on between p_from and p_to),
        'flags', (select count(*) from vehicle_fuel f where f.vehicle_id = v.id and f.flagged and f.filled_on between p_from and p_to),
        'service_due', case when v.service_interval_km is not null and v.odometer >= coalesce(v.last_service_km, 0) + v.service_interval_km - 500 then true
                            when v.service_interval_months is not null and coalesce(v.last_service_date, v.created_at::date) + make_interval(months => v.service_interval_months) <= current_date + 14 then true else false end) x
      from vehicles v where v.company_id = cid and v.status <> 'disposed') y), '[]'::jsonb),
    'projects', coalesce((select jsonb_agg(x) from (
      select jsonb_build_object('project_id', p.id, 'project', concat_ws(' ', p.number, p.name),
        'km', coalesce((select sum(distance_km) from vehicle_trips t where t.project_id = p.id and t.status = 'completed' and t.end_at::date between p_from and p_to), 0),
        'fuel_cost', coalesce((select sum(cost) from vehicle_fuel f where f.project_id = p.id and f.filled_on between p_from and p_to), 0),
        'waybills', (select count(*) from waybills w where w.project_id = p.id and w.planned_on between p_from and p_to and w.status <> 'cancelled'),
        'transport_cost', coalesce((select sum(transport_cost) from waybills w where w.project_id = p.id and w.planned_on between p_from and p_to and w.status <> 'cancelled'), 0)) x
      from projects p where p.company_id = cid and not p.is_template and (
        exists (select 1 from vehicle_trips t where t.project_id = p.id and t.end_at::date between p_from and p_to) or
        exists (select 1 from vehicle_fuel f where f.project_id = p.id and f.filled_on between p_from and p_to) or
        exists (select 1 from waybills w where w.project_id = p.id and w.planned_on between p_from and p_to))) y), '[]'::jsonb),
    'documents_due', coalesce((select jsonb_agg(jsonb_build_object('reg_no', v.reg_no, 'kind', d.kind, 'expires_on', d.expires_on) order by d.expires_on)
      from vehicle_documents d join vehicles v on v.id = d.vehicle_id where d.company_id = cid and v.status <> 'disposed' and d.expires_on <= current_date + 30
        and not exists (select 1 from vehicle_documents d2 where d2.vehicle_id = d.vehicle_id and d2.kind = d.kind and d2.expires_on > d.expires_on)), '[]'::jsonb),
    'licences_due', coalesce((select jsonb_agg(jsonb_build_object('name', e.full_name, 'licence_expiry', r.licence_expiry) order by r.licence_expiry)
      from drivers r join employees e on e.id = r.employee_id where r.company_id = cid and r.active and r.licence_expiry <= current_date + 30), '[]'::jsonb));
end $$;

create or replace function public.run_fleet_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  for r in select d.*, v.reg_no from vehicle_documents d join vehicles v on v.id = d.vehicle_id
            where v.status <> 'disposed' and d.expires_on is not null and d.expires_on <= current_date + 30
              and not exists (select 1 from vehicle_documents d2 where d2.vehicle_id = d.vehicle_id and d2.kind = d.kind and d2.expires_on > d.expires_on)
              and (d.reminded_for is null or (d.expires_on < current_date and d.reminded_for >= d.expires_on - 30 and d.reminded_for < d.expires_on) or (d.expires_on - current_date <= 7 and d.reminded_for > d.expires_on - 7)) is not false
              and coalesce(d.reminded_for, '1900-01-01') <> current_date loop
    if r.reminded_for is null or (r.expires_on < current_date and r.reminded_for < r.expires_on) or (r.expires_on - current_date <= 7 and r.reminded_for < r.expires_on - 7) then
      perform notify_users(r.company_id, transport_users(r.company_id), 'fleet_document', r.reg_no || ': ' || replace(r.kind, '_', ' ') || case when r.expires_on < current_date then ' has expired' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end, r.reference, '/fleet/vehicles', true);
      perform send_telegram(r.company_id, 'fleet', '📄 ' || r.reg_no || ': ' || replace(r.kind, '_', ' ') || case when r.expires_on < current_date then ' has EXPIRED' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end);
      update vehicle_documents set reminded_for = current_date where id = r.id; n := n + 1;
    end if;
  end loop;
  for r in select d.*, e.full_name, e.user_id from drivers d join employees e on e.id = d.employee_id
            where d.active and d.licence_expiry is not null and d.licence_expiry <= current_date + 30 and (d.reminded_for is null or d.reminded_for < d.licence_expiry - 30 or (d.licence_expiry < current_date and d.reminded_for < d.licence_expiry)) loop
    perform notify_users(r.company_id, transport_users(r.company_id) || array[r.user_id], 'driver_licence', r.full_name || '''s driving licence ' || case when r.licence_expiry < current_date then 'has expired' else 'expires ' || to_char(r.licence_expiry, 'DD Mon YYYY') end, null, '/fleet/drivers', true);
    update drivers set reminded_for = current_date where id = r.id; n := n + 1;
  end loop;
  for r in select l.* from software_licences l where l.expires_on is not null and l.expires_on <= current_date + 30 and (l.reminded_on is null or (l.expires_on < current_date and l.reminded_on < l.expires_on)) loop
    perform notify(r.company_id, array['store'], null, 'licence_expiry', 'Licence ' || r.name || case when r.expires_on < current_date then ' has expired' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end, null, '/assets/licences', true);
    update software_licences set reminded_on = current_date where id = r.id; n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_fleet_reminders() from public, anon, authenticated;

create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- New companies get a Head office location.
create or replace function public.company_seed_assets() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform set_config('sika.seed', 'on', true);
  insert into asset_locations (company_id, name, kind) values (new.id, 'Head office', 'head_office') on conflict do nothing;
  perform set_config('sika.seed', 'off', true);
  return null;
end $$;
create trigger companies_seed_assets after insert on public.companies for each row execute function public.company_seed_assets();

-- ---------------------------------------------------------------- 11. Security rules
do $$ declare t text; begin
  foreach t in array array['company_telegram','asset_locations','asset_transfers','asset_items','asset_item_stock','asset_item_moves','asset_item_checkouts',
                           'software_licences','licence_seats','vehicles','vehicle_documents','drivers','vehicle_requests','vehicle_trips','vehicle_fuel','vehicle_services','waybills','waybill_lines'] loop
    execute format('alter table public.%I enable row level security', t);
    if t <> 'company_telegram' then execute format('create policy "members read" on public.%I for select using (is_member(company_id))', t); end if;
  end loop;
end $$;
create policy "owners manage telegram" on public.company_telegram for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));
create policy "store edits asset details" on public.assets for update using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "locations write" on public.asset_locations for all using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "items write" on public.asset_items for all using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "licences write" on public.software_licences for all using (asset_manager(company_id)) with check (asset_manager(company_id));
create policy "seats write" on public.licence_seats for all using (asset_manager(company_id)) with check (is_member(company_id));
create policy "fleet write vehicles" on public.vehicles for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "fleet write documents" on public.vehicle_documents for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "fleet write drivers" on public.drivers for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "fleet write services" on public.vehicle_services for all using (is_transport(company_id)) with check (is_transport(company_id));
create policy "anyone requests a vehicle" on public.vehicle_requests for insert with check (is_member(company_id));
create policy "requests update" on public.vehicle_requests for update using (is_member(company_id));
create policy "trips insert" on public.vehicle_trips for insert with check (is_member(company_id));
create policy "trips edit" on public.vehicle_trips for update using (is_transport(company_id));
create policy "fuel insert" on public.vehicle_fuel for insert with check (true);
create policy "fuel delete" on public.vehicle_fuel for delete using (is_transport(company_id));
create policy "waybills insert" on public.waybills for insert with check (is_member(company_id));
create policy "waybills edit" on public.waybills for update using (is_member(company_id));
create policy "waybills delete drafts" on public.waybills for delete using (status = 'draft' and is_transport(company_id));
create policy "waybill lines" on public.waybill_lines for all using (is_member(company_id)) with check (true);

do $$ declare t text; begin
  foreach t in array array['asset_locations','asset_transfers','asset_items','asset_item_moves','software_licences','licence_seats','vehicles','vehicle_documents','drivers','vehicle_fuel','vehicle_services','waybills'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
  end loop;
end $$;
revoke execute on function public.transport_users(uuid) from public, anon, authenticated;
$sql318$;
    raise notice 'v3.1 installed';
  else
    raise notice 'v3.1 was already installed; skipped';
  end if;
end $v318$;

-- Part 2: v3.1.1 (fleet reminders)
-- Asnys ERP v3.1.1 — Fleet reminders reach admins as well as transport officers
--   * Roadworthy, insurance, road use, permits and statutory inspections: reminders 30 days before, 7 days before,
--     and on expiry, then every 7 days while it stays expired. Sent to transport officers, the storekeeper,
--     owners and admins (and the vehicle's driver when it has expired).
--   * New document kind: statutory inspection (crane, lifting gear, pressure vessel, fire extinguishers on the vehicle).
--   * Each company can choose how many days ahead the first reminder goes (default 30).
--   * Drivers' licences and medicals are reminded the same way.
-- Run after 0018. Safe to run more than once.

alter table public.vehicle_documents drop constraint if exists vehicle_documents_kind_check;
alter table public.vehicle_documents add constraint vehicle_documents_kind_check
  check (kind in ('roadworthy','insurance','road_use','registration','permit','tracker','inspection','fire_extinguisher','other'));
alter table public.companies add column if not exists fleet_reminder_days int not null default 30 check (fleet_reminder_days between 1 and 120);
alter table public.drivers add column if not exists medical_reminded_for date;

-- Who hears about fleet papers: transport officers, the storekeeper, owners and admins.
create or replace function public.fleet_alert_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or role in ('store','owner','admin'));
$$;
revoke execute on function public.fleet_alert_users(uuid) from public, anon, authenticated;

-- One reminder per stage: first warning, final week, expiry, then weekly while expired.
create or replace function public.fleet_reminder_due(p_expires date, p_last date, p_lead int) returns boolean
language sql immutable as $$
  select p_expires is not null and p_expires <= current_date + p_lead and coalesce(p_last, '1900-01-01') < current_date and (
       p_last is null
    or p_last < p_expires - p_lead
    or (p_expires - current_date <= 7 and p_last < p_expires - 7)
    or (p_expires <= current_date and p_last < p_expires)
    or (p_expires < current_date and p_last <= current_date - 7));
$$;

create or replace function public.run_fleet_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; v_title text; v_kind text;
begin
  for r in select d.*, v.reg_no, v.driver_id as v_driver, c.fleet_reminder_days lead
             from vehicle_documents d join vehicles v on v.id = d.vehicle_id join companies c on c.id = d.company_id
            where v.status <> 'disposed' and d.expires_on is not null
              and not exists (select 1 from vehicle_documents d2 where d2.vehicle_id = d.vehicle_id and d2.kind = d.kind and d2.expires_on > d.expires_on)
              and fleet_reminder_due(d.expires_on, d.reminded_for, c.fleet_reminder_days) loop
    v_kind := case r.kind when 'roadworthy' then 'Roadworthy certificate' when 'insurance' then 'Insurance' when 'road_use' then 'Road use fee'
                          when 'inspection' then 'Statutory inspection' when 'fire_extinguisher' then 'Fire extinguisher service' else initcap(replace(r.kind, '_', ' ')) end;
    v_title := r.reg_no || ': ' || v_kind || case when r.expires_on < current_date then ' EXPIRED on ' || to_char(r.expires_on, 'DD Mon YYYY')
                                                  when r.expires_on = current_date then ' expires TODAY'
                                                  else ' due ' || to_char(r.expires_on, 'DD Mon YYYY') || ' (' || (r.expires_on - current_date) || ' days)' end;
    perform notify_users(r.company_id, fleet_alert_users(r.company_id)
      || case when r.expires_on <= current_date then array[(select user_id from employees where id = r.v_driver)] else '{}'::uuid[] end,
      'fleet_document', v_title, coalesce('Ref ' || r.reference, '') || case when r.expires_on < current_date then ' — do not use the vehicle on the road until renewed.' else '' end,
      '/fleet/vehicles/' || r.vehicle_id, true);
    perform send_telegram(r.company_id, 'fleet', case when r.expires_on <= current_date then '🚫 ' else '📄 ' end || v_title);
    update vehicle_documents set reminded_for = current_date where id = r.id; n := n + 1;
  end loop;

  for r in select d.*, e.full_name, e.user_id, c.fleet_reminder_days lead from drivers d join employees e on e.id = d.employee_id join companies c on c.id = d.company_id
            where d.active and fleet_reminder_due(d.licence_expiry, d.reminded_for, c.fleet_reminder_days) loop
    perform notify_users(r.company_id, fleet_alert_users(r.company_id) || array[r.user_id], 'driver_licence',
      r.full_name || '''s driving licence ' || case when r.licence_expiry < current_date then 'EXPIRED on ' || to_char(r.licence_expiry, 'DD Mon YYYY') else 'expires ' || to_char(r.licence_expiry, 'DD Mon YYYY') end,
      'Renew at DVLA.', '/fleet/drivers', true);
    perform send_telegram(r.company_id, 'fleet', '🪪 ' || r.full_name || '''s driving licence ' || case when r.licence_expiry < current_date then 'has EXPIRED' else 'expires ' || to_char(r.licence_expiry, 'DD Mon YYYY') end);
    update drivers set reminded_for = current_date where id = r.id; n := n + 1;
  end loop;

  for r in select d.*, e.full_name, e.user_id, c.fleet_reminder_days lead from drivers d join employees e on e.id = d.employee_id join companies c on c.id = d.company_id
            where d.active and fleet_reminder_due(d.medical_expiry, d.medical_reminded_for, c.fleet_reminder_days) loop
    perform notify_users(r.company_id, fleet_alert_users(r.company_id) || array[r.user_id], 'driver_licence',
      r.full_name || '''s driver medical ' || case when r.medical_expiry < current_date then 'has expired' else 'is due ' || to_char(r.medical_expiry, 'DD Mon YYYY') end, null, '/fleet/drivers', true);
    update drivers set medical_reminded_for = current_date where id = r.id; n := n + 1;
  end loop;

  for r in select l.* from software_licences l where l.expires_on is not null and l.expires_on <= current_date + 30 and (l.reminded_on is null or (l.expires_on < current_date and l.reminded_on < l.expires_on)) loop
    perform notify(r.company_id, array['store'], null, 'licence_expiry', 'Licence ' || r.name || case when r.expires_on < current_date then ' has expired' else ' expires ' || to_char(r.expires_on, 'DD Mon YYYY') end, null, '/assets/licences', true);
    update software_licences set reminded_on = current_date where id = r.id; n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_fleet_reminders() from public, anon, authenticated;

-- A renewed or corrected expiry date starts the reminders afresh.
create or replace function public.vehicle_document_reset() returns trigger
language plpgsql as $$
begin
  if new.expires_on is distinct from old.expires_on then new.reminded_for := null; end if;
  return new;
end $$;
drop trigger if exists vehicle_documents_reset on public.vehicle_documents;
create trigger vehicle_documents_reset before update on public.vehicle_documents for each row execute function public.vehicle_document_reset();

-- Owners or admins choose how far ahead the first reminder goes.
create or replace function public.set_fleet_reminder_days(cid uuid, p_days int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  if p_days not between 1 and 120 then raise exception 'Choose between 1 and 120 days'; end if;
  update companies set fleet_reminder_days = p_days where id = cid;
end $$;


-- Part 3: v3.2
-- Asnys ERP v3.2 — Approvals reach people on Telegram and by email; HR creates logins with temporary passwords
--   1. Every approval in the system raises a notification to the people who must decide, and tells the requester
--      the outcome. Flows that had no notification now have one: the approval chain (bills, payroll, purchase orders,
--      purchase requests and expense claims above the limits), site purchase requests, expense claims, timesheets,
--      training requests, document reviews and stock requests from sites.
--   2. Each person can connect their own Telegram (a private chat with the company's bot). Notifications go to
--      them personally, not to a group. Everyone chooses: all notifications, approvals only, or none.
--   3. Approval emails through Brevo's API (an API key and a verified sender address; no SMTP needed).
--   4. HR and admins can create logins with a temporary password and reset passwords (with the updated
--      invite-member function). People must choose their own password at first sign-in.
-- Telegram and email need the pg_net extension (Database → Extensions → pg_net). Without it, everything else
-- works and the in-app notifications are unchanged.
-- Run after 0019.

-- ---------------------------------------------------------------- 0. Sending through pg_net (skipped quietly when it is off)
create or replace function public.http_post_safe(p_url text, p_body jsonb, p_headers jsonb default '{"Content-Type":"application/json"}') returns bigint
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if to_regnamespace('net') is null then return null; end if;
  begin
    execute 'select net.http_post(url := $1, body := $2, headers := $3)' into v using p_url, p_body, p_headers;
  exception when others then return null;
  end;
  return v;
end $$;
revoke execute on function public.http_post_safe(text, jsonb, jsonb) from public, anon, authenticated;

-- ---------------------------------------------------------------- 1. Company settings
alter table public.company_telegram add column if not exists bot_username text;
alter table public.company_telegram add column if not exists personal boolean not null default true;   -- private messages to people who connect
alter table public.company_telegram add column if not exists app_url text not null default 'https://asnys-erp.pages.dev';
alter table public.company_telegram add column if not exists last_update_id bigint;
-- The group chat is now optional: "enabled" switches the group on; private messages only need the bot token.

create table if not exists public.company_email (
  company_id uuid primary key references public.companies(id) on delete cascade,
  provider text not null default 'brevo' check (provider in ('brevo')),
  api_key text,
  from_email text,
  from_name text,
  enabled boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.company_email enable row level security;
drop policy if exists "owners manage email" on public.company_email;
create policy "owners manage email" on public.company_email for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));

-- ---------------------------------------------------------------- 2. Each person's channels
create table if not exists public.user_channels (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null,
  telegram_chat_id text,
  telegram_username text,
  telegram_linked_at timestamptz,
  telegram_code text,
  telegram_code_at timestamptz,
  telegram_poll_id bigint,
  telegram_poll_at timestamptz,
  telegram_level text not null default 'all' check (telegram_level in ('all','approvals','off')),
  email_level text not null default 'approvals' check (email_level in ('all','approvals','off')),
  updated_at timestamptz not null default now(),
  primary key (company_id, user_id)
);
alter table public.user_channels enable row level security;
drop policy if exists "own channels" on public.user_channels;
create policy "own channels" on public.user_channels for select using (user_id = auth.uid() or has_role(company_id, array['owner','admin']));

create table if not exists public.message_log (
  id bigserial primary key,
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid,
  channel text not null check (channel in ('telegram','email')),
  notification_id uuid,
  title text,
  request_id bigint,
  status text not null default 'queued' check (status in ('queued','skipped')),
  note text,
  created_at timestamptz not null default now()
);
create index if not exists message_log_company on public.message_log (company_id, created_at desc);
alter table public.message_log enable row level security;
drop policy if exists "admins read log" on public.message_log;
create policy "admins read log" on public.message_log for select using (has_role(company_id, array['owner','admin']) or user_id = auth.uid());

-- My settings (and whether the company has Telegram and email set up), for the Notifications page.
create or replace function public.my_channels(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email;
begin
  perform require_member(cid);
  select * into uc from user_channels where company_id = cid and user_id = auth.uid();
  select * into t from company_telegram where company_id = cid;
  select * into e from company_email where company_id = cid;
  return jsonb_build_object(
    'telegram_ready', t.bot_token is not null and t.personal and t.bot_username is not null,
    'bot_username', t.bot_username,
    'email_ready', coalesce(e.enabled, false) and e.api_key is not null and e.from_email is not null,
    'pg_net', to_regnamespace('net') is not null,
    'telegram_linked', uc.telegram_chat_id is not null,
    'telegram_username', uc.telegram_username,
    'telegram_linked_at', uc.telegram_linked_at,
    'telegram_level', coalesce(uc.telegram_level, 'all'),
    'email_level', coalesce(uc.email_level, 'approvals'),
    'email', (select coalesce(m.email, u.email) from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid()));
end $$;

create or replace function public.set_my_channels(cid uuid, p_telegram_level text, p_email_level text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform require_member(cid);
  if p_telegram_level not in ('all','approvals','off') or p_email_level not in ('all','approvals','off') then raise exception 'Choose all, approvals or off'; end if;
  insert into user_channels (company_id, user_id, telegram_level, email_level) values (cid, auth.uid(), p_telegram_level, p_email_level)
  on conflict (company_id, user_id) do update set telegram_level = excluded.telegram_level, email_level = excluded.email_level, updated_at = now();
end $$;

-- ---------------------------------------------------------------- 3. Which notifications are approvals
-- Requests that wait for someone's decision, and the decisions that go back to the person who asked.
create or replace function public.is_approval_kind(p_kind text) returns boolean
language sql immutable as $$
  select p_kind = any(array[
      'approval_needed','approval_decided','request_submitted','request_decided','expense_submitted','expense_decided',
      'time_submitted','time_decided','training_request','training_decided','doc_review','doc_reviewed','stock_request',
      'leave_request','leave_decided','hr_profile_change','hr_profile_decided','asset_requested','asset_request_decided',
      'asset_transfer','vehicle_request','spend_request','spend_request_done','budget.submitted','budget.decided',
      'progress.submitted','retirement_submitted','retirement_returned','variation_proposed','variation_decided',
      'tender.review','project.registered','hse_permit','hse_action_done','hse_investigate','petty_count_difference'])
    or p_kind like 'spend_request\_%' or p_kind like 'asset_transfer\_%' or p_kind like 'hse_permit\_%';
$$;

-- ---------------------------------------------------------------- 4. Delivery: every new notification goes to Telegram and email as each person chose
create or replace function public.tg_escape(t text) returns text language sql immutable as $$
  select replace(replace(replace(coalesce(t, ''), '&', '&amp;'), '<', '&lt;'), '>', '&gt;');
$$;

create or replace function public.deliver_notification() returns trigger
language plpgsql security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email; v_appr boolean; v_url text; v_email text; v_req bigint; v_text text;
begin
  begin
    select * into t from company_telegram where company_id = new.company_id;
    select * into e from company_email where company_id = new.company_id;
    if t.company_id is null and e.company_id is null then return null; end if;
    select * into uc from user_channels where company_id = new.company_id and user_id = new.user_id;
    v_appr := is_approval_kind(new.kind);
    v_url := rtrim(coalesce(t.app_url, 'https://asnys-erp.pages.dev'), '/') || coalesce(new.path, '/notifications');

    -- Telegram, privately
    if t.bot_token is not null and t.personal and uc.telegram_chat_id is not null
       and (uc.telegram_level = 'all' or (uc.telegram_level = 'approvals' and v_appr)) then
      v_text := case when v_appr then '🔔 ' else '' end || '<b>' || tg_escape(new.title) || '</b>'
             || coalesce(E'\n' || tg_escape(new.body), '') || E'\n\n<a href="' || tg_escape(v_url) || '">' || case when v_appr then 'Open and decide' else 'Open in Asnys' end || '</a>';
      v_req := http_post_safe('https://api.telegram.org/bot' || t.bot_token || '/sendMessage',
        jsonb_build_object('chat_id', uc.telegram_chat_id, 'text', left(v_text, 4000), 'parse_mode', 'HTML', 'disable_web_page_preview', true));
      insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
      values (new.company_id, new.user_id, 'telegram', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' end);
    end if;

    -- Email through Brevo
    if coalesce(e.enabled, false) and e.api_key is not null and e.from_email is not null
       and (coalesce(uc.email_level, 'approvals') = 'all' or (coalesce(uc.email_level, 'approvals') = 'approvals' and v_appr)) then
      select coalesce(m.email, u.email) into v_email from memberships m left join auth.users u on u.id = m.user_id where m.company_id = new.company_id and m.user_id = new.user_id;
      if v_email is not null then
        v_req := http_post_safe('https://api.brevo.com/v3/smtp/email',
          jsonb_build_object(
            'sender', jsonb_build_object('email', e.from_email, 'name', coalesce(e.from_name, (select name from companies where id = new.company_id))),
            'to', jsonb_build_array(jsonb_build_object('email', v_email)),
            'subject', left(case when v_appr then '[Action] ' else '' end || new.title, 200),
            'htmlContent', '<div style="font-family:Arial,sans-serif;font-size:15px;color:#17231e">'
              || '<p style="margin:0 0 8px"><b>' || tg_escape(new.title) || '</b></p>'
              || coalesce('<p style="margin:0 0 16px;white-space:pre-wrap">' || tg_escape(new.body) || '</p>', '')
              || '<p><a href="' || tg_escape(v_url) || '" style="background:#1d6b55;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;display:inline-block">'
              || case when v_appr then 'Open and decide' else 'Open in Asnys ERP' end || '</a></p>'
              || '<p style="color:#5b6b63;font-size:12px">Sent by Asnys ERP for ' || tg_escape((select name from companies where id = new.company_id))
              || '. Change what you receive under Notifications → Settings.</p></div>',
            'textContent', new.title || coalesce(E'\n' || new.body, '') || E'\n\n' || v_url),
          jsonb_build_object('api-key', e.api_key, 'Content-Type', 'application/json', 'accept', 'application/json'));
        insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
        values (new.company_id, new.user_id, 'email', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' else v_email end);
      end if;
    end if;
  exception when others then
    null;   -- sending must never stop the work that raised the notification
  end;
  return null;
end $$;
drop trigger if exists notifications_deliver on public.notifications;
create trigger notifications_deliver after insert on public.notifications for each row execute function public.deliver_notification();

-- ---------------------------------------------------------------- 5. Connecting a person's Telegram
-- The app opens t.me/<bot>?start=<code>; the person presses Start; the app then asks the database to look for it.
create or replace function public.telegram_link_start(cid uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare t company_telegram; v_code text := substr(md5(gen_random_uuid()::text || clock_timestamp()::text), 1, 12);
begin
  perform require_member(cid);
  select * into t from company_telegram where company_id = cid;
  if t.bot_token is null or t.bot_username is null then raise exception 'Telegram is not set up for this company yet. Ask an owner or admin to add the bot under Settings → Telegram & email.'; end if;
  insert into user_channels (company_id, user_id, telegram_code, telegram_code_at) values (cid, auth.uid(), v_code, now())
  on conflict (company_id, user_id) do update set telegram_code = v_code, telegram_code_at = now(), telegram_poll_id = null, updated_at = now();
  return jsonb_build_object('code', v_code, 'url', 'https://t.me/' || ltrim(t.bot_username, '@') || '?start=' || v_code, 'bot_username', ltrim(t.bot_username, '@'));
end $$;

-- Reads Telegram's reply to an earlier getUpdates, links anyone in this company who pressed Start with their code,
-- then asks again. Returns linked, pending or expired.
create or replace function public.telegram_link_check(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare uc user_channels; t company_telegram; v_content text; v_json jsonb; u jsonb; v_text text; v_code text; v_max bigint; v_chat text; r record; v_req bigint;
begin
  perform require_member(cid);
  select * into uc from user_channels where company_id = cid and user_id = auth.uid();
  if uc.telegram_chat_id is not null then return 'linked'; end if;
  if uc.telegram_code is null then raise exception 'Press Connect Telegram first'; end if;
  if uc.telegram_code_at < now() - interval '30 minutes' then return 'expired'; end if;
  select * into t from company_telegram where company_id = cid;
  if t.bot_token is null then raise exception 'Telegram is not set up for this company'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;

  if uc.telegram_poll_id is not null then
    begin
      execute 'select content from net._http_response where id = $1' into v_content using uc.telegram_poll_id;
    exception when others then v_content := null;
    end;
    if v_content is null and uc.telegram_poll_at > now() - interval '15 seconds' then return 'pending'; end if;
    update user_channels set telegram_poll_id = null where company_id = cid and user_id = auth.uid();
    if v_content is not null then
      begin v_json := v_content::jsonb; exception when others then v_json := null; end;
      v_max := t.last_update_id;
      for u in select * from jsonb_array_elements(coalesce(v_json->'result', '[]'::jsonb)) loop
        v_max := greatest(coalesce(v_max, 0), (u->>'update_id')::bigint);
        v_text := u->'message'->>'text';
        if v_text like '/start %' then
          v_code := trim(split_part(v_text, ' ', 2));
          v_chat := u->'message'->'chat'->>'id';
          for r in update user_channels set telegram_chat_id = v_chat, telegram_username = u->'message'->'from'->>'username', telegram_linked_at = now(),
                     telegram_code = null, updated_at = now()
                    where company_id = cid and telegram_code = v_code and telegram_chat_id is null returning user_id loop
            perform http_post_safe('https://api.telegram.org/bot' || t.bot_token || '/sendMessage',
              jsonb_build_object('chat_id', v_chat, 'text', '✅ Connected to Asnys ERP for ' || (select name from companies where id = cid)
                || '. You will get your approvals and notifications here. Change what you receive in Asnys under Notifications → Settings.'));
          end loop;
        end if;
      end loop;
      if v_max is distinct from t.last_update_id then update company_telegram set last_update_id = v_max where company_id = cid; end if;
      if exists (select 1 from user_channels where company_id = cid and user_id = auth.uid() and telegram_chat_id is not null) then return 'linked'; end if;
    end if;
  end if;

  execute 'select net.http_get(url := $1)' into v_req
    using 'https://api.telegram.org/bot' || t.bot_token || '/getUpdates?timeout=0&offset=' || coalesce((select last_update_id from company_telegram where company_id = cid) + 1, 0);
  update user_channels set telegram_poll_id = v_req, telegram_poll_at = now() where company_id = cid and user_id = auth.uid();
  return 'pending';
end $$;

create or replace function public.telegram_unlink(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform require_member(cid);
  update user_channels set telegram_chat_id = null, telegram_username = null, telegram_linked_at = null, telegram_code = null, updated_at = now()
   where company_id = cid and user_id = auth.uid();
end $$;

-- Sends me a test on each channel I have.
create or replace function public.test_my_channels(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
begin
  perform require_member(cid);
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  insert into notifications (company_id, user_id, kind, title, body, path)
  values (cid, auth.uid(), 'approval_needed', 'Test: this is how an approval looks', 'Nothing to do; this is a test from Notifications → Settings.', '/notifications');
  return 'sent';
end $$;

-- Owners and admins: how many people have connected.
create or replace function public.channel_overview(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  return jsonb_build_object(
    'members', (select count(*) from memberships where company_id = cid),
    'telegram_linked', (select count(*) from user_channels where company_id = cid and telegram_chat_id is not null),
    'email_off', (select count(*) from user_channels where company_id = cid and email_level = 'off'),
    'last_24h', (select coalesce(jsonb_object_agg(channel, n), '{}') from (select channel, count(*) n from message_log where company_id = cid and created_at > now() - interval '1 day' group by channel) x),
    'people', coalesce((select jsonb_agg(jsonb_build_object('email', coalesce(m.email, u.email), 'role', m.role, 'telegram', c.telegram_chat_id is not null,
                 'telegram_level', coalesce(c.telegram_level, 'all'), 'email_level', coalesce(c.email_level, 'approvals')) order by coalesce(m.email, u.email))
               from memberships m left join auth.users u on u.id = m.user_id left join user_channels c on c.company_id = m.company_id and c.user_id = m.user_id
              where m.company_id = cid), '[]'));
end $$;

-- ---------------------------------------------------------------- 6. Approval notifications for the flows that had none
-- 6a. The approval chain (bills, payroll, purchase orders, purchase requests and expense claims above the limits).
alter table public.approval_steps add column if not exists notified_at timestamptz;

create or replace function public.step_approvers(s approval_steps) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct u), '{}') from (
    select s.approver_user u where s.approver_user is not null
    union select m.user_id from memberships m where m.company_id = s.company_id and s.approver_role is not null and m.role = s.approver_role
    union select m.user_id from memberships m where m.company_id = s.company_id and m.role = 'owner'
      and not exists (select 1 from memberships x where x.company_id = s.company_id and ((s.approver_role is not null and x.role = s.approver_role) or x.user_id = s.approver_user))
  ) x where u is not null and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = u);
$$;

create or replace function public.approval_step_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare cur approval_steps; d record; v_left int; v_rej boolean; v_amt text;
begin
  if new.doc_type = 'spend_request' then return null; end if;   -- spend requests already notify themselves
  select * into d from doc_info(new.doc_type, new.doc_id);
  v_amt := case when new.amount is not null then ' (GH₵ ' || to_char(new.amount, 'FM999,999,999,990.00') || ')' else '' end;
  -- The step now waiting, if nobody has been told about it yet.
  select * into cur from approval_steps where doc_type = new.doc_type and doc_id = new.doc_id and status = 'pending' order by step_no limit 1;
  if found and cur.notified_at is null then
    update approval_steps set notified_at = now() where id = cur.id;
    perform notify_users(cur.company_id, step_approvers(cur), 'approval_needed',
      'Approval needed: ' || coalesce(d.label, replace(new.doc_type, '_', ' ')) || v_amt,
      'Step ' || cur.step_no || ' of ' || (select count(*) from approval_steps where doc_type = new.doc_type and doc_id = new.doc_id) || ': ' || cur.label
        || coalesce(' · asked by ' || (select email from memberships where company_id = cur.company_id and user_id = cur.requested_by), ''),
      '/approvals-inbox', false);
  end if;
  -- The outcome, back to whoever asked.
  if tg_op = 'UPDATE' and new.status is distinct from old.status and new.status in ('approved','rejected') then
    select count(*) filter (where status = 'pending'), bool_or(status = 'rejected') into v_left, v_rej from approval_steps where doc_type = new.doc_type and doc_id = new.doc_id;
    if new.status = 'rejected' or (v_left = 0 and not coalesce(v_rej, false)) then
      perform notify_users(new.company_id, array[new.requested_by], 'approval_decided',
        coalesce(d.label, replace(new.doc_type, '_', ' ')) || case when new.status = 'rejected' then ' was rejected' else ' is fully approved' end,
        case when new.status = 'rejected' then coalesce('Reason: ' || new.note, null) end, coalesce(d.path, '/approvals-inbox'), false);
    end if;
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists approval_steps_notice on public.approval_steps;
create trigger approval_steps_notice after insert or update on public.approval_steps for each row execute function public.approval_step_notice();

-- Project managers of a project, or Finance when there is none.
create or replace function public.project_deciders(cid uuid, pid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct u), '{}') from (
    select p.manager_id u from projects p where p.id = pid and p.manager_id is not null
    union select m.user_id from memberships m where m.company_id = cid and m.role = 'accountant'
      and (pid is null or not exists (select 1 from projects p where p.id = pid and p.manager_id is not null))
  ) x where u is not null;
$$;
revoke execute on function public.project_deciders(uuid, uuid) from public, anon, authenticated;
revoke execute on function public.step_approvers(approval_steps) from public, anon, authenticated;

-- 6b. Site purchase requests (first approval by the project manager).
create or replace function public.project_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare p projects;
begin
  select * into p from projects where id = new.project_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    perform notify_users(new.company_id, project_deciders(new.company_id, new.project_id), 'request_submitted',
      coalesce(new.number, 'Purchase request') || ' needs approval: ' || coalesce(new.description, new.kind),
      concat_ws(' · ', p.number || ' ' || p.name, new.qty || ' × GH₵ ' || to_char(coalesce(new.est_unit_cost, 0), 'FM999,999,990.00'), new.requested_email), '/approvals', false);
  elsif tg_op = 'UPDATE' and new.status in ('approved','rejected') and old.status is distinct from new.status then
    perform notify_users(new.company_id, array[new.requested_by], 'request_decided',
      coalesce(new.number, 'Your request') || ' was ' || new.status, case when new.status = 'rejected' then 'Reason: ' || new.reject_reason end, '/my', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists project_requests_notice on public.project_requests;
create trigger project_requests_notice after insert or update of status on public.project_requests for each row execute function public.project_request_notice();

-- 6c. Expense claims.
create or replace function public.expense_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_who text;
begin
  select full_name into v_who from employees where id = new.employee_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    perform notify_users(new.company_id, project_deciders(new.company_id, new.project_id), 'expense_submitted',
      'Expense claim to approve: ' || coalesce(v_who, 'staff') || ', GH₵ ' || to_char(coalesce(new.amount_home, new.amount, 0), 'FM999,999,990.00'),
      left(coalesce(new.description, ''), 300), '/approvals', false);
  elsif tg_op = 'UPDATE' and new.status in ('approved','rejected') and old.status is distinct from new.status then
    perform notify_users(new.company_id, array[new.submitted_by, (select user_id from employees where id = new.employee_id)], 'expense_decided',
      'Your expense claim of GH₵ ' || to_char(coalesce(new.amount_home, new.amount, 0), 'FM999,999,990.00') || ' was ' || new.status,
      case when new.status = 'rejected' then 'Reason: ' || new.reject_reason end, '/my', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists expense_claims_notice on public.expense_claims;
create trigger expense_claims_notice after insert or update of status on public.expense_claims for each row execute function public.expense_notice();

-- 6d. Timesheets: one message per person, project and day, however many lines were submitted.
create or replace function public.timesheet_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare p projects; v_who text; v_user uuid;
begin
  select * into p from projects where id = new.project_id;
  select full_name, user_id into v_who, v_user from employees where id = new.employee_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    if exists (select 1 from notifications n where n.company_id = p.company_id and n.kind = 'time_submitted' and n.read_at is null
                 and n.created_at > now() - interval '12 hours' and n.title = 'Time to approve: ' || coalesce(v_who, 'staff') || ' on ' || coalesce(p.number, p.name)) then
      return null;
    end if;
    perform notify_users(p.company_id, project_deciders(p.company_id, p.id), 'time_submitted',
      'Time to approve: ' || coalesce(v_who, 'staff') || ' on ' || coalesce(p.number, p.name), p.name, '/approvals', false);
  elsif tg_op = 'UPDATE' and new.status = 'rejected' and old.status = 'submitted' then
    perform notify_users(p.company_id, array[v_user, new.submitted_by], 'time_decided', 'Time rejected on ' || coalesce(p.number, p.name), 'Ask the project manager why, correct it and submit again.', '/my', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists timesheets_notice on public.timesheets;
create trigger timesheets_notice after insert or update of status on public.timesheets for each row execute function public.timesheet_notice();

-- 6e. Training requests (HR decides).
create or replace function public.training_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'submitted' and tg_op = 'INSERT' then
    perform notify_users(new.company_id, (select coalesce(array_agg(user_id), '{}') from memberships where company_id = new.company_id and role = 'hr'), 'training_request',
      coalesce(new.number, 'Training request') || ' to decide: ' || (select full_name from employees where id = new.employee_id), new.requested_email, '/training', false);
  elsif tg_op = 'UPDATE' and new.status in ('approved','rejected') and old.status is distinct from new.status then
    perform notify_users(new.company_id, array[new.requested_by, (select user_id from employees where id = new.employee_id)], 'training_decided',
      coalesce(new.number, 'Training request') || ' was ' || new.status, new.decision_note, '/training', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists training_requests_notice on public.training_requests;
create trigger training_requests_notice after insert or update of status on public.training_requests for each row execute function public.training_request_notice();

-- 6f. Document revisions sent for review (project manager), and the result back to whoever uploaded it.
create or replace function public.doc_review_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare d doc_register; p projects;
begin
  select * into d from doc_register where id = new.doc_id;
  select * into p from projects where id = d.project_id;
  if new.status = 'in_review' and old.status is distinct from 'in_review' then
    perform notify_users(d.company_id, project_deciders(d.company_id, d.project_id), 'doc_review',
      'Document to review: ' || coalesce(d.number, '') || ' rev ' || coalesce(new.rev, '') || ' ' || coalesce(d.title, ''), coalesce(p.number || ' ' || p.name, ''),
      '/projects/' || d.project_id, false);
  elsif old.status = 'in_review' and new.status in ('approved','approved_comments','rejected','ready') then
    perform notify_users(d.company_id, array[new.uploaded_by], 'doc_reviewed',
      coalesce(d.number, 'Document') || ' rev ' || coalesce(new.rev, '') || ': ' || replace(new.status, '_', ' '), new.review_note, '/projects/' || d.project_id, false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists doc_revisions_notice on public.doc_revisions;
create trigger doc_revisions_notice after update of status on public.doc_revisions for each row execute function public.doc_review_notice();

-- 6g. Stock requests from sites (the storekeeper dispatches).
create or replace function public.stock_request_notice() returns trigger
language plpgsql security definer set search_path = public as $$
declare p projects;
begin
  select * into p from projects where id = new.project_id;
  if new.status = 'submitted' and (tg_op = 'INSERT' or old.status is distinct from 'submitted') then
    perform notify_users(new.company_id, (select coalesce(array_agg(user_id), '{}') from memberships where company_id = new.company_id and role = 'store'), 'stock_request',
      coalesce(new.number, 'Stock request') || ' from ' || coalesce(p.number || ' ' || p.name, 'a site') || ' to dispatch',
      concat_ws(' · ', new.requested_email, 'needed by ' || to_char(new.needed_by, 'DD Mon')), '/inventory/requests', false);
  elsif tg_op = 'UPDATE' and new.status = 'dispatched' and old.status is distinct from 'dispatched' then
    perform notify_users(new.company_id, array[new.requested_by], 'stock_request', coalesce(new.number, 'Your stock request') || ' has been dispatched', new.dispatch_note, '/inventory/requests', false);
  end if;
  return null;
exception when others then return null;
end $$;
drop trigger if exists stock_requests_notice on public.stock_requests;
create trigger stock_requests_notice after insert or update of status on public.stock_requests for each row execute function public.stock_request_notice();

-- ---------------------------------------------------------------- 7. Logins with a temporary password (used by the invite-member function)
-- Invitations to give a password to: their login, if one exists, and whether it has ever signed in.
create or replace function public.invites_for_password(cid uuid, p_ids uuid[])
returns table (id uuid, email text, role text, company_name text, user_id uuid, signed_in boolean)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform require_member(cid, array['owner','admin','hr']);
  return query
    select i.id, i.email, i.role, c.name, u.id, u.last_sign_in_at is not null
      from member_invites i join companies c on c.id = i.company_id left join auth.users u on lower(u.email) = lower(i.email)
     where i.company_id = cid and i.id = any(p_ids) and i.status in ('pending','sent','failed') and can_invite(cid, i.role);
end $$;

-- Whether the caller may set a new password for this member. Owners and admins: anyone but the owner;
-- HR: staff only. Nobody resets their own this way. Logged.
create or replace function public.password_reset_target(cid uuid, p_user uuid) returns text
language plpgsql security definer set search_path = public as $$
declare m memberships; v_email text;
begin
  perform require_member(cid, array['owner','admin','hr']);
  select * into m from memberships where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
  if p_user = auth.uid() then raise exception 'Change your own password from your account menu'; end if;
  if m.role = 'owner' then raise exception 'The owner''s password cannot be reset by others'; end if;
  if not has_role(cid, array['owner','admin']) and m.role <> 'staff' then raise exception 'HR can reset passwords for staff only. Ask an admin.'; end if;
  select email into v_email from auth.users where id = p_user;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (cid, 'password.reset', 'memberships', p_user, jsonb_build_object('email', v_email));
  return v_email;
end $$;

-- The app shows Set new password only where it is allowed.
create or replace function public.can_reset_password(cid uuid, p_role text, p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select p_user is distinct from auth.uid() and p_role <> 'owner'
     and (has_role(cid, array['owner','admin']) or (p_role = 'staff' and has_role(cid, array['hr'])));
$$;


-- ---------------------------------------------------------------- 8. Activity log for the whole system
-- Secrets never go into the log.
create or replace function public.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
declare o jsonb; n jsonb; d_old jsonb := '{}'; d_new jsonb := '{}'; k text; cid uuid; rid uuid;
  ignore text[] := array['stock_qty','cost','score','sales_ready','updated_at','last_depreciated','accumulated_depreciation','percent_complete',
                         'telegram_poll_id','telegram_poll_at','reminded_for','reminded_on','notified_at'];
  secret text[] := array['bot_token','api_key','product_key','password','telegram_code','token','secret'];
begin
  if tg_op <> 'INSERT' then o := to_jsonb(old); end if;
  if tg_op <> 'DELETE' then n := to_jsonb(new); end if;
  cid := coalesce((n->>'company_id')::uuid, (o->>'company_id')::uuid, case when tg_table_name = 'companies' then coalesce((n->>'id')::uuid, (o->>'id')::uuid) end);
  begin rid := coalesce((n->>'id')::uuid, (o->>'id')::uuid); exception when others then rid := null; end;
  if tg_op = 'UPDATE' then
    for k in select jsonb_object_keys(n) loop
      if k <> all(ignore) and (o->k) is distinct from (n->k) then
        d_old := d_old || jsonb_build_object(k, o->k); d_new := d_new || jsonb_build_object(k, n->k);
      end if;
    end loop;
    if d_new = '{}'::jsonb then return null; end if;
    -- keep a name or number so the line says which record changed
    foreach k in array array['number','name','full_name','title','reg_no','tag','email','description'] loop
      if (to_jsonb(new)) ? k and not d_new ? k then d_new := d_new || jsonb_build_object('_label', to_jsonb(new)->k); exit; end if;
    end loop;
    o := d_old; n := d_new;
  end if;
  foreach k in array secret loop   -- a changed secret shows as changed, never its value
    if o ? k then o := o || jsonb_build_object(k, case when o->>k is null then null else '••••' end); end if;
    if n ? k then n := n || jsonb_build_object(k, case when n->>k is null then null else '••••' end); end if;
  end loop;
  insert into audit_log (company_id, action, table_name, row_id, old_data, new_data)
  values (cid, tg_table_name || '.' || lower(tg_op), tg_table_name, rid, o, n);
  return null;
end $$;

-- Every business table is logged, not only the money ones.
do $$ declare t text; begin
  for t in select c.table_name from information_schema.columns c join information_schema.tables x on x.table_schema = c.table_schema and x.table_name = c.table_name
            where c.table_schema = 'public' and c.column_name = 'company_id' and x.table_type = 'BASE TABLE'
              and c.table_name not in ('audit_log','notifications','message_log','user_channels','company_telegram','company_email','announcement_reads',
                                       'payment_reminders','journal_lines','asset_item_stock','esg_entries_cache')
              and not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || c.table_name)::regclass and p.proname = 'audit_row') loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', left(t, 50) || '_audit', t);
  end loop;
end $$;
-- Settings tables: logged, with their secrets hidden by audit_row.
do $$ declare t text; begin
  foreach t in array array['company_telegram','company_email'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- Sign-ins: recorded once per real sign-in (from the login time Supabase keeps).
alter table public.memberships add column if not exists last_sign_in_logged timestamptz;
create or replace function public.record_sign_in() returns int
language plpgsql security definer set search_path = public as $$
declare v_at timestamptz; v_email text; m record; n int := 0;
begin
  if auth.uid() is null then return 0; end if;
  select last_sign_in_at, email into v_at, v_email from auth.users where id = auth.uid();
  if v_at is null then return 0; end if;
  for m in select company_id from memberships where user_id = auth.uid() and (last_sign_in_logged is null or last_sign_in_logged < v_at) loop
    insert into audit_log (company_id, action, table_name, row_id, detail) values (m.company_id, 'user.signed_in', 'sign_in', auth.uid(), jsonb_build_object('email', v_email, 'at', v_at));
    update memberships set last_sign_in_logged = v_at where company_id = m.company_id and user_id = auth.uid();
    n := n + 1;
  end loop;
  return n;
end $$;

-- What has been logged, by area, for the filter list.
create or replace function public.audit_areas(cid uuid, p_from date, p_to date) returns table (table_name text, n bigint)
language sql stable security definer set search_path = public as $$
  select l.table_name, count(*) from audit_log l
   where l.company_id = cid and has_role(cid, array['owner','admin','accountant']) and l.created_at >= p_from and l.created_at < p_to + 1 and l.table_name is not null
   group by l.table_name order by 2 desc;
$$;

-- The trail, with an action filter (created, changed, deleted, sign-in, other).
create or replace function public.activity_log(cid uuid, p_from date, p_to date, p_table text default null, p_user text default null,
  p_search text default null, p_kind text default null, p_limit int default 100, p_offset int default 0)
returns table (id bigint, created_at timestamptz, user_email text, action text, table_name text, row_id uuid, old_data jsonb, new_data jsonb, detail jsonb, total bigint)
language sql stable security definer set search_path = public as $$
  select l.id, l.created_at, l.user_email, l.action, l.table_name, l.row_id, l.old_data, l.new_data, l.detail, count(*) over()
    from audit_log l
   where l.company_id = cid and has_role(cid, array['owner','admin','accountant'])
     and l.created_at >= p_from and l.created_at < p_to + 1
     and (p_table is null or l.table_name = p_table)
     and (p_user is null or l.user_email ilike '%' || p_user || '%')
     and (p_kind is null or (p_kind = 'insert' and l.action like '%.insert') or (p_kind = 'update' and l.action like '%.update')
          or (p_kind = 'delete' and l.action like '%.delete') or (p_kind = 'sign_in' and l.action = 'user.signed_in')
          or (p_kind = 'other' and l.action not like '%.insert' and l.action not like '%.update' and l.action not like '%.delete' and l.action <> 'user.signed_in'))
     and (p_search is null or l.action ilike '%' || p_search || '%' or coalesce(l.new_data::text,'') ilike '%' || p_search || '%'
          or coalesce(l.old_data::text,'') ilike '%' || p_search || '%' or coalesce(l.detail::text,'') ilike '%' || p_search || '%')
   order by l.created_at desc, l.id desc
   limit least(p_limit, 1000) offset p_offset;
$$;


-- ---------------------------------------------------------------- 9. Void entries made in error
-- Anything that has not been posted to the books can be voided with a reason. It stays on record (marked Voided,
-- with who, when and why) and drops out of totals, approvals and reminders. Posted money entries are corrected by
-- reversal instead: invoices with a credit note, bank and cash entries with Void, journals with Reverse.
create table if not exists public.void_rules (
  table_name text primary key,
  label text not null,
  from_status text[] not null,
  roles text[] not null,           -- who may void besides the person who entered it (owners and admins always can)
  creator_col text                 -- the column holding who entered it; that person may void their own
);
insert into public.void_rules (table_name, label, from_status, roles, creator_col) values
  ('tenders',              'Tender',              '{registered,preparing,review,submitted,no_bid,lost}', '{sales,accountant}', null),
  ('sales_quotes',         'Quote',               '{draft,sent,declined}',            '{sales,accountant}', null),
  ('purchase_orders',      'Purchase order',      '{draft,approved,sent}',            '{accountant,store}', 'created_by'),
  ('project_requests',     'Purchase request',    '{draft,submitted,approved}',       '{accountant,project_manager}', 'requested_by'),
  ('expense_claims',       'Expense claim',       '{submitted}',                      '{accountant}', 'submitted_by'),
  ('leave_requests',       'Leave request',       '{pending,approved}',               '{hr}', 'employee_id'),
  ('timesheets',           'Timesheet line',      '{submitted}',                      '{accountant,project_manager}', 'submitted_by'),
  ('stock_requests',       'Stock request',       '{draft,submitted}',                '{store,accountant}', 'requested_by'),
  ('asset_requests',       'Asset request',       '{pending,approved}',               '{store,accountant}', 'requested_by'),
  ('training_requests',    'Training request',    '{submitted,approved}',             '{hr}', 'requested_by'),
  ('contract_variations',  'Variation',           '{proposed}',                       '{accountant,project_manager,sales}', 'created_by'),
  ('vehicle_requests',     'Vehicle request',     '{pending,approved}',               '{store,accountant}', 'requested_by'),
  ('vehicle_trips',        'Trip',                '{planned}',                        '{store,accountant}', 'created_by'),
  ('hse_permits',          'Permit',              '{requested}',                      '{}', 'requested_by'),
  ('employee_change_requests','Profile change',   '{pending}',                        '{hr}', 'employee_id'),
  ('contracts',            'Contract',            '{draft}',                          '{accountant,sales}', 'created_by'),
  ('risk_assessments',     'Risk assessment',     '{draft}',                          '{project_manager}', 'assessed_by'),
  ('hse_inspections',      'Inspection',          '{draft}',                          '{}', null),
  ('hse_sessions',         'Toolbox talk / induction', '{draft}',                     '{}', 'created_by'),
  ('leads',                'Lead',                '{new,contacted,qualified,unqualified}', '{sales}', null)
on conflict (table_name) do update set label = excluded.label, from_status = excluded.from_status, roles = excluded.roles, creator_col = excluded.creator_col;
delete from public.void_rules where table_name in ('progress_reports','petty_vouchers','waybills');
alter table public.void_rules enable row level security;
drop policy if exists "read void rules" on public.void_rules;
create policy "read void rules" on public.void_rules for select using (true);

-- 'voided' becomes a valid status, and the reason is kept on the entry.
do $$ declare r record; c record; v_def text; begin
  for r in select table_name from void_rules where to_regclass('public.' || table_name) is not null loop
    execute format('alter table public.%I add column if not exists void_reason text', r.table_name);
    execute format('alter table public.%I add column if not exists voided_at timestamptz', r.table_name);
    execute format('alter table public.%I add column if not exists voided_by uuid', r.table_name);
    for c in select con.conname, pg_get_constraintdef(con.oid) def from pg_constraint con join pg_attribute a on a.attrelid = con.conrelid and a.attnum = any(con.conkey)
              where con.conrelid = ('public.' || r.table_name)::regclass and con.contype = 'c' and a.attname = 'status' loop
      if c.def not like '%''voided''%' then
        v_def := regexp_replace(c.def, '\](\)+)$', ', ''voided''::text]\1');
        if v_def = c.def then raise exception 'Could not add voided to %', r.table_name; end if;
        execute format('alter table public.%I drop constraint %I', r.table_name, c.conname);
        execute format('alter table public.%I add constraint %I %s', r.table_name, c.conname, v_def);
      end if;
    end loop;
  end loop;
end $$;

-- The person who entered it (an employee column means that employee's login).
create or replace function public.entry_owner(p_col text, p_table text, p_id uuid) returns uuid
language plpgsql stable security definer set search_path = public as $$
declare v uuid;
begin
  if p_col is null then return null; end if;
  execute format('select %I from public.%I where id = $1', p_col, p_table) into v using p_id;
  if p_col = 'employee_id' then select user_id into v from employees where id = v; end if;
  return v;
end $$;
revoke execute on function public.entry_owner(text, text, uuid) from public, anon, authenticated;

create or replace function public.void_entry(p_table text, p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid; f text;
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be voided here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  if not (has_role(v_cid, array['owner','admin']) or has_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid())) then
    raise exception 'You cannot void this %. Ask an admin.', lower(vr.label);
  end if;
  if v_status = 'voided' then raise exception 'Already voided'; end if;
  if not (v_status = any(vr.from_status)) then
    raise exception 'A % that is % cannot be voided. %', lower(vr.label), replace(v_status, '_', ' '),
      case when p_table = 'purchase_orders' then 'Goods have been received against it; close it instead.'
           when p_table = 'expense_claims' then 'It has been posted; reverse it with a journal.'
           when p_table = 'tenders' then 'An awarded tender has a project; cancel the project instead.'
           else 'It has already gone through.' end;
  end if;
  if p_table = 'timesheets' and exists (select 1 from timesheets where id = p_id and invoice_id is not null) then raise exception 'This time has been invoiced'; end if;
  -- Let the update through the usual "use the buttons" guards; the void itself is the controlled action.
  foreach f in array array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle'] loop
    perform set_config(f, 'on', true);
  end loop;
  execute format('update public.%I set status = ''voided'', void_reason = $2, voided_at = now(), voided_by = auth.uid() where id = $1', p_table) using p_id, trim(p_reason);
  foreach f in array array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle'] loop
    perform set_config(f, 'off', true);
  end loop;
  -- Nothing waits for approval on a voided entry.
  update approval_steps set status = 'skipped' where doc_id = p_id and status = 'pending';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.voided', p_table, p_id, jsonb_build_object('what', vr.label, 'was', v_status, 'reason', trim(p_reason)));
end $$;

-- Who may void a given entry (for showing the button).
create or replace function public.can_void(p_table text, p_id uuid) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid;
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then return false; end if;
  execute format('select company_id, status from public.%I where id = $1', p_table) into v_cid, v_status using p_id;
  if v_cid is null or not (v_status = any(vr.from_status)) then return false; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  return has_role(v_cid, array['owner','admin']) or has_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid());
end $$;

-- Manual journals posted in error: reverse them (a mirror entry dated when you choose). The original stays.
alter table public.journal_entries add column if not exists reversed_by_entry uuid;
create or replace function public.reverse_journal(p_entry uuid, p_date date, p_reason text) returns uuid
language plpgsql security definer set search_path = public as $$
declare e journal_entries; v uuid;
begin
  select * into e from journal_entries where id = p_entry for update;
  if not found then raise exception 'Journal not found'; end if;
  perform require_member(e.company_id, array['owner','admin','accountant']);
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being reversed'; end if;
  if e.reversed_by_entry is not null then raise exception 'This journal has already been reversed'; end if;
  if coalesce(e.source_type, 'manual') not in ('manual','journal','opening') then
    raise exception 'This journal was posted by a % — correct it there (credit note, void, or the document''s own reversal).', replace(e.source_type, '_', ' ');
  end if;
  v := post_journal(e.company_id, p_date, 'Reversal of ' || e.entry_no || ': ' || trim(p_reason),
    (select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit, 'project_id', l.project_id,
                                         'branch_id', l.branch_id, 'cost_centre_id', l.cost_centre_id, 'description', 'Reversal'))
       from journal_lines l where l.entry_id = e.id), 'reversal', e.id);
  update journal_entries set reversed_by_entry = v where id = e.id;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (e.company_id, 'journal.reversed', 'journal_entries', e.id, jsonb_build_object('entry', e.entry_no, 'reason', trim(p_reason)));
  return v;
end $$;



-- ======================================== Part B: v3.3 Microsoft 365 email
-- Asnys ERP v3.3 — Send email through the company's own Microsoft 365 (no Brevo)
-- Emails go out from a real mailbox (e.g. notifications@gulfaco.com) through Microsoft Graph, using an app
-- registered in the company's Microsoft 365 (Azure). The Microsoft keys stay in Supabase's secret store and the
-- send-mail function; the database only knows the function's address and a shared secret.
-- Brevo stays available as an alternative. Run after 0020. Safe to run twice.

alter table public.company_email drop constraint if exists company_email_provider_check;
alter table public.company_email add constraint company_email_provider_check check (provider in ('brevo','microsoft'));
alter table public.company_email add column if not exists function_url text;     -- https://<project>.supabase.co/functions/v1/send-mail
-- The shared secret lives in its own table that nobody can read from the app (RLS on, no policies).
create table if not exists public.company_email_secret (
  company_id uuid primary key references public.companies(id) on delete cascade,
  secret text not null default (md5(gen_random_uuid()::text || clock_timestamp()::text) || md5(gen_random_uuid()::text))
);
alter table public.company_email_secret enable row level security;
create or replace function public.company_email_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into company_email_secret (company_id) values (new.company_id) on conflict do nothing;
  return null;
end $$;
drop trigger if exists company_email_defaults on public.company_email;
create trigger company_email_defaults after insert or update on public.company_email for each row execute function public.company_email_defaults();
insert into public.company_email_secret (company_id) select company_id from public.company_email on conflict do nothing;

-- One email, by whichever service the company chose.
create or replace function public.send_company_email(cid uuid, p_to text, p_subject text, p_html text, p_text text) returns bigint
language plpgsql security definer set search_path = public as $$
declare e company_email;
begin
  select * into e from company_email where company_id = cid;
  if not found or not e.enabled or e.from_email is null or p_to is null then return null; end if;
  if e.provider = 'microsoft' then
    if e.function_url is null then return null; end if;
    return http_post_safe(e.function_url,
      jsonb_build_object('company_id', cid, 'to', p_to, 'subject', left(p_subject, 250), 'html', p_html, 'text', p_text),
      jsonb_build_object('Content-Type', 'application/json', 'x-asnys-secret', (select secret from company_email_secret where company_id = cid)));
  end if;
  if e.api_key is null then return null; end if;
  return http_post_safe('https://api.brevo.com/v3/smtp/email',
    jsonb_build_object('sender', jsonb_build_object('email', e.from_email, 'name', coalesce(e.from_name, (select name from companies where id = cid))),
      'to', jsonb_build_array(jsonb_build_object('email', p_to)), 'subject', left(p_subject, 200), 'htmlContent', p_html, 'textContent', p_text),
    jsonb_build_object('api-key', e.api_key, 'Content-Type', 'application/json', 'accept', 'application/json'));
end $$;
revoke execute on function public.send_company_email(uuid, text, text, text, text) from public, anon, authenticated;

-- Delivery now uses either service.
create or replace function public.deliver_notification() returns trigger
language plpgsql security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email; v_appr boolean; v_url text; v_email text; v_req bigint; v_text text; v_ready boolean;
begin
  begin
    select * into t from company_telegram where company_id = new.company_id;
    select * into e from company_email where company_id = new.company_id;
    if t.company_id is null and e.company_id is null then return null; end if;
    select * into uc from user_channels where company_id = new.company_id and user_id = new.user_id;
    v_appr := is_approval_kind(new.kind);
    v_url := rtrim(coalesce(t.app_url, 'https://asnys-erp.pages.dev'), '/') || coalesce(new.path, '/notifications');

    if t.bot_token is not null and t.personal and uc.telegram_chat_id is not null
       and (uc.telegram_level = 'all' or (uc.telegram_level = 'approvals' and v_appr)) then
      v_text := case when v_appr then '🔔 ' else '' end || '<b>' || tg_escape(new.title) || '</b>'
             || coalesce(E'\n' || tg_escape(new.body), '') || E'\n\n<a href="' || tg_escape(v_url) || '">' || case when v_appr then 'Open and decide' else 'Open in Asnys' end || '</a>';
      v_req := http_post_safe('https://api.telegram.org/bot' || t.bot_token || '/sendMessage',
        jsonb_build_object('chat_id', uc.telegram_chat_id, 'text', left(v_text, 4000), 'parse_mode', 'HTML', 'disable_web_page_preview', true));
      insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
      values (new.company_id, new.user_id, 'telegram', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' end);
    end if;

    v_ready := coalesce(e.enabled, false) and e.from_email is not null and ((e.provider = 'microsoft' and e.function_url is not null) or (e.provider = 'brevo' and e.api_key is not null));
    if v_ready and (coalesce(uc.email_level, 'approvals') = 'all' or (coalesce(uc.email_level, 'approvals') = 'approvals' and v_appr)) then
      select coalesce(m.email, u.email) into v_email from memberships m left join auth.users u on u.id = m.user_id where m.company_id = new.company_id and m.user_id = new.user_id;
      if v_email is not null then
        v_req := send_company_email(new.company_id, v_email, case when v_appr then '[Action] ' else '' end || new.title,
          '<div style="font-family:Arial,sans-serif;font-size:15px;color:#17231e">'
            || '<p style="margin:0 0 8px"><b>' || tg_escape(new.title) || '</b></p>'
            || coalesce('<p style="margin:0 0 16px;white-space:pre-wrap">' || tg_escape(new.body) || '</p>', '')
            || '<p><a href="' || tg_escape(v_url) || '" style="background:#1d6b55;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;display:inline-block">'
            || case when v_appr then 'Open and decide' else 'Open in Asnys ERP' end || '</a></p>'
            || '<p style="color:#5b6b63;font-size:12px">Sent by Asnys ERP for ' || tg_escape((select name from companies where id = new.company_id))
            || '. Change what you receive under Notifications → How you are notified.</p></div>',
          new.title || coalesce(E'\n' || new.body, '') || E'\n\n' || v_url);
        insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
        values (new.company_id, new.user_id, 'email', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' else v_email end);
      end if;
    end if;
  exception when others then
    null;
  end;
  return null;
end $$;

-- Used only by the send-mail function (with the service key) to check a request really came from this database.
create or replace function public.email_hook_config(cid uuid, p_secret text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('from_email', e.from_email, 'from_name', coalesce(e.from_name, c.name))
    from company_email e join companies c on c.id = e.company_id join company_email_secret x on x.company_id = e.company_id
   where e.company_id = cid and e.provider = 'microsoft' and e.enabled and x.secret = p_secret;
$$;
revoke execute on function public.email_hook_config(uuid, text) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then grant execute on function public.email_hook_config(uuid, text) to service_role; end if;
end $$;

-- Owners: send a test email to themselves now, and see how recent emails went.
create or replace function public.test_company_email(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_to text; v bigint; e company_email;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can test email'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  select * into e from company_email where company_id = cid;
  if not found or not e.enabled then raise exception 'Tick Send emails and save first'; end if;
  select coalesce(m.email, u.email) into v_to from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid();
  v := send_company_email(cid, v_to, 'Asnys ERP test email', '<p>This is a test from Asnys ERP. Email is working for ' || tg_escape((select name from companies where id = cid)) || '.</p>', 'This is a test from Asnys ERP.');
  if v is null then raise exception 'Not sent: check the settings above'; end if;
  insert into message_log (company_id, user_id, channel, title, request_id, status, note) values (cid, auth.uid(), 'email', 'Test email', v, 'queued', v_to);
  return v_to;
end $$;

create or replace function public.recent_email_results(cid uuid) returns table (sent_at timestamptz, to_email text, title text, status_code int, error text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  if to_regnamespace('net') is null then return; end if;
  return query execute
    'select l.created_at, l.note, l.title, r.status_code, left(coalesce(r.error_msg, case when r.status_code >= 300 then r.content end), 300)
       from message_log l left join net._http_response r on r.id = l.request_id
      where l.company_id = $1 and l.channel = ''email'' order by l.id desc limit 15' using cid;
end $$;

-- Each person's settings page counts Microsoft 365 as set up too.
create or replace function public.my_channels(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email;
begin
  perform require_member(cid);
  select * into uc from user_channels where company_id = cid and user_id = auth.uid();
  select * into t from company_telegram where company_id = cid;
  select * into e from company_email where company_id = cid;
  return jsonb_build_object(
    'telegram_ready', t.bot_token is not null and t.personal and t.bot_username is not null,
    'bot_username', t.bot_username,
    'email_ready', coalesce(e.enabled, false) and e.from_email is not null and ((e.provider = 'microsoft' and e.function_url is not null) or (e.provider = 'brevo' and e.api_key is not null)),
    'pg_net', to_regnamespace('net') is not null,
    'telegram_linked', uc.telegram_chat_id is not null,
    'telegram_username', uc.telegram_username,
    'telegram_linked_at', uc.telegram_linked_at,
    'telegram_level', coalesce(uc.telegram_level, 'all'),
    'email_level', coalesce(uc.email_level, 'approvals'),
    'email', (select coalesce(m.email, u.email) from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid()));
end $$;

-- ======================================== Part C: v3.4
-- Asnys ERP v3.4 — Gulfaco's requests: numbering, customers and tax, stricter invoices, payment milestones,
-- SR/ADR/MRO requests with several items and attachments, stock for sale or for use, subcontractors,
-- company logo, backups to OneDrive, Microsoft 365 certificate, password reset by email, 2-step sign-in.
-- Run after 0021. Safe to run twice.

-- ---------------------------------------------------------------- 1. Document numbering: a company code in front (GUF-INV-00001), and set your own
alter table public.companies add column if not exists doc_prefix text check (doc_prefix ~ '^[A-Z0-9]{1,6}$');
create table if not exists public.number_formats (
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  prefix text not null check (prefix ~ '^[A-Z0-9/-]{1,12}$'),
  primary key (company_id, key)
);
alter table public.number_formats enable row level security;
drop policy if exists "members read formats" on public.number_formats;
create policy "members read formats" on public.number_formats for select using (is_member(company_id));

create or replace function public.next_number(cid uuid, p_key text, p_prefix text)
returns text language plpgsql security definer set search_path = public as $$
declare v int; v_code text; v_pre text;
begin
  insert into number_sequences (company_id, key, next_value) values (cid, p_key, 2)
  on conflict (company_id, key) do update set next_value = number_sequences.next_value + 1
  returning next_value - 1 into v;
  select doc_prefix into v_code from companies where id = cid;
  select prefix into v_pre from number_formats where company_id = cid and key = p_key;
  v_pre := coalesce(v_pre || '-', p_prefix);
  return case when v_code is not null then v_code || '-' else '' end || v_pre || lpad(v::text, 5, '0');
end $$;
revoke execute on function public.next_number(uuid, text, text) from public, anon, authenticated;

-- Settings: every sequence, its prefix and the next number; owners and Finance can change them.
create or replace function public.number_settings(cid uuid) returns table (key text, prefix text, next_value int, example text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare v_code text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  select doc_prefix into v_code from companies where id = cid;
  return query
    select s.key, coalesce(f.prefix, s.key), s.next_value,
           case when v_code is not null then v_code || '-' else '' end || coalesce(f.prefix, s.key) || '-' || lpad(s.next_value::text, 5, '0')
      from number_sequences s left join number_formats f on f.company_id = s.company_id and f.key = s.key
     where s.company_id = cid order by s.key;
end $$;

create or replace function public.set_numbering(cid uuid, p_code text, p_key text default null, p_prefix text default null, p_next int default null) returns void
language plpgsql security definer set search_path = public as $$
declare v_used int;
begin
  if not has_role(cid, array['owner','admin','accountant']) then raise exception 'Only an owner, admin or Finance can change numbering'; end if;
  update companies set doc_prefix = nullif(upper(trim(p_code)), '') where id = cid;
  if p_key is not null then
    if nullif(trim(p_prefix), '') is not null then
      insert into number_formats (company_id, key, prefix) values (cid, p_key, upper(trim(p_prefix)))
      on conflict (company_id, key) do update set prefix = excluded.prefix;
    end if;
    if p_next is not null then
      select next_value into v_used from number_sequences where company_id = cid and key = p_key;
      if p_next < 1 then raise exception 'The next number must be 1 or more'; end if;
      insert into number_sequences (company_id, key, next_value) values (cid, p_key, p_next)
      on conflict (company_id, key) do update set next_value = excluded.next_value;
    end if;
  end if;
  insert into audit_log (company_id, action, table_name, detail) values (cid, 'numbering.changed', 'number_sequences', jsonb_build_object('code', p_code, 'key', p_key, 'prefix', p_prefix, 'next', p_next));
end $$;

-- Gulfaco's request codes: SR service request, ADR procurement request, MRO material request.
insert into public.number_formats (company_id, key, prefix)
select id, k, p from public.companies, (values ('ADR','ADR'),('SR','SR'),('MRO','MRO')) v(k, p) on conflict do nothing;

-- ---------------------------------------------------------------- 2. Customers and suppliers: contacts, TIN, tax position
alter table public.customers add column if not exists contact_name text;
alter table public.customers add column if not exists contact_phone text;
alter table public.customers add column if not exists contact_email text;
alter table public.customers add column if not exists tax_status text not null default 'standard'
  check (tax_status in ('standard','exempt','zero_rated','diplomatic','free_zone'));
alter table public.customers add column if not exists exemption_ref text;
alter table public.customers add column if not exists exemption_expiry date;
alter table public.customers add column if not exists wht_agent boolean not null default false;
alter table public.customers add column if not exists wht_rate numeric(5,2) check (wht_rate between 0 and 30);
alter table public.customers add column if not exists vat_wht_agent boolean not null default false;
alter table public.customers add column if not exists tax_note text;

alter table public.suppliers add column if not exists contact_phone text;
alter table public.suppliers add column if not exists contact_email text;
alter table public.suppliers add column if not exists vat_registered boolean not null default true;
alter table public.suppliers add column if not exists wht_rate numeric(5,2) check (wht_rate between 0 and 30);
alter table public.suppliers add column if not exists tax_note text;

alter table public.companies add column if not exists strict_invoices boolean not null default false;
alter table public.companies add column if not exists wht_default_rate numeric(5,2) not null default 7.5;
update public.companies set strict_invoices = true where not strict_invoices and created_at < now() - interval '1 minute';

-- Withholding tax credit (what customers deduct and pay to GRA on Gulfaco's behalf).
create or replace function public.seed_accounts_v34(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into accounts (company_id, code, name, type, system_key) values
  (cid, '1285', 'Withholding tax credit (deducted by customers)', 'asset', 'wht_receivable')
  on conflict do nothing;
$$;
select public.seed_accounts_v34(id) from public.companies;
revoke execute on function public.seed_accounts_v34(uuid) from public, anon, authenticated;

-- ---------------------------------------------------------------- 3. Invoices tied to something, with a reference, VAT on or off
alter table public.invoices add column if not exists quote_id uuid references public.sales_quotes(id) on delete set null;
alter table public.invoices add column if not exists contract_id uuid references public.contracts(id) on delete set null;
alter table public.invoices add column if not exists milestone_id uuid references public.project_milestones(id) on delete set null;
alter table public.invoices add column if not exists customer_po text;
alter table public.invoices add column if not exists reference text;
alter table public.invoices add column if not exists charge_vat boolean not null default true;
alter table public.invoices add column if not exists wht_rate numeric(5,2);
alter table public.invoices add column if not exists wht_amount numeric(14,2) not null default 0;

-- VAT off: every line is untaxed.
create or replace function public.invoice_vat_lines() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_table_name = 'invoices' then
    if new.charge_vat is distinct from old.charge_vat and new.status = 'draft' then
      update invoice_lines l set taxable = case when new.charge_vat then coalesce((select taxable from products p where p.id = l.product_id), true) else false end where l.invoice_id = new.id;
    end if;
    return new;
  end if;
  if not coalesce((select charge_vat from invoices where id = new.invoice_id), true) then new.taxable := false; end if;
  return new;
end $$;
drop trigger if exists invoices_vat_lines on public.invoices;
create trigger invoices_vat_lines after update of charge_vat on public.invoices for each row execute function public.invoice_vat_lines();
drop trigger if exists invoice_lines_vat on public.invoice_lines;
create trigger invoice_lines_vat before insert or update on public.invoice_lines for each row execute function public.invoice_vat_lines();

-- New invoices take the customer's tax position: exempt or zero-rated → no VAT; withholding agent → expected WHT.
create or replace function public.invoice_customer_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers;
begin
  select * into c from customers where id = new.customer_id;
  if found then
    if c.tax_status in ('exempt','zero_rated','diplomatic','free_zone') and (c.exemption_expiry is null or c.exemption_expiry >= coalesce(new.invoice_date, current_date)) then new.charge_vat := false; end if;
    if c.wht_agent and new.wht_rate is null then new.wht_rate := coalesce(c.wht_rate, (select wht_default_rate from companies where id = new.company_id)); end if;
  end if;
  return new;
end $$;
drop trigger if exists invoices_customer_defaults on public.invoices;
create trigger invoices_customer_defaults before insert on public.invoices for each row execute function public.invoice_customer_defaults();

-- With strict invoices on (Settings), an invoice can only be posted when it is tied to a quote, contract, project or the
-- customer's PO, has a reference, and the customer has a TIN.
create or replace function public.invoice_post_rules() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers; v_strict boolean;
begin
  if old.status = 'draft' and new.status <> 'draft' then
    select strict_invoices into v_strict from companies where id = new.company_id;
    if v_strict then
      select * into c from customers where id = new.customer_id;
      if coalesce(trim(c.tin), '') = '' then raise exception 'Add % TIN to the customer record before posting (Sales → Customers)', c.name || '''s'; end if;
      if coalesce(trim(new.reference), '') = '' then raise exception 'Enter the invoice reference before posting'; end if;
      if new.quote_id is null and new.contract_id is null and new.project_id is null and coalesce(trim(new.customer_po), '') = '' then
        raise exception 'Tie the invoice to a quotation, contract, project or the customer''s PO number before posting';
      end if;
    end if;
    if new.wht_rate is not null then new.wht_amount := round(new.subtotal * new.wht_rate / 100, 2); end if;
  end if;
  return new;
end $$;
drop trigger if exists invoices_post_rules on public.invoices;
create trigger invoices_post_rules before update of status on public.invoices for each row execute function public.invoice_post_rules();

-- A quote converted to an invoice stays linked, with its number as the reference.
do $$ begin
  if to_regprocedure('public.convert_quote_v22(uuid)') is null then alter function public.convert_quote(uuid) rename to convert_quote_v22; end if;
end $$;
create or replace function public.convert_quote(p_quote uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid; q sales_quotes;
begin
  v := convert_quote_v22(p_quote);
  select * into q from sales_quotes where id = p_quote;
  update invoices set quote_id = p_quote, reference = coalesce(reference, q.number) where id = v;
  return v;
end $$;
revoke execute on function public.convert_quote_v22(uuid) from public, anon, authenticated;

-- Receiving a payment when the customer withheld tax: the cash is what reached the bank; the withheld part becomes a tax credit.
create or replace function public.record_payment_wht(p_invoice uuid, p_cash numeric, p_wht numeric, p_date date, p_method text,
  p_reference text default null, p_rate numeric default null, p_certificate text default null) returns void
language plpgsql security definer set search_path = public as $$
declare inv invoices; v_rate numeric; g numeric; v_je uuid;
begin
  select * into inv from invoices where id = p_invoice;
  if not found then raise exception 'Invoice not found'; end if;
  if coalesce(p_wht, 0) < 0 then raise exception 'Withholding tax cannot be negative'; end if;
  perform record_payment(p_invoice, round(coalesce(p_cash, 0) + coalesce(p_wht, 0), 2), p_date, p_method, p_reference, p_rate);
  if coalesce(p_wht, 0) > 0 then
    v_rate := case when inv.currency = 'GHS' then 1 else coalesce(nullif(p_rate, 0), inv.exchange_rate) end;
    g := round(p_wht * v_rate, 2);
    v_je := post_journal(inv.company_id, p_date, 'Withholding tax deducted by customer on ' || inv.number || coalesce(' (certificate ' || p_certificate || ')', ''),
      jsonb_build_array(jl(acct(inv.company_id, 'wht_receivable'), g, 0), jl(acct(inv.company_id, p_method), 0, g)), 'wht', inv.id);
  end if;
end $$;

-- ---------------------------------------------------------------- 4. Payment milestones as a percentage of the contract, due when work reaches a stage
alter table public.project_milestones add column if not exists kind text not null default 'progress'
  check (kind in ('advance','progress','completion','retention','other'));
alter table public.project_milestones add column if not exists pct numeric(6,2) check (pct > 0 and pct <= 100);
alter table public.project_milestones add column if not exists trigger_pct int check (trigger_pct between 0 and 100);
alter table public.project_milestones add column if not exists terms_days int check (terms_days between 0 and 365);

create or replace function public.milestone_amount() returns trigger
language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if new.pct is not null and new.status <> 'invoiced' then
    select contract_value into v from projects where id = new.project_id;
    if coalesce(v, 0) > 0 then new.amount := round(v * new.pct / 100, 2); end if;
  end if;
  if new.status = 'planned' and new.trigger_pct = 0 then new.status := 'ready'; end if;
  return new;
end $$;
drop trigger if exists project_milestones_amount on public.project_milestones;
create trigger project_milestones_amount before insert or update on public.project_milestones for each row execute function public.milestone_amount();

-- A change of contract value re-prices the milestones not yet invoiced.
create or replace function public.project_value_milestones() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.contract_value is distinct from old.contract_value then
    update project_milestones set pct = pct where project_id = new.id and pct is not null and status <> 'invoiced';
  end if;
  return null;
end $$;
drop trigger if exists projects_value_milestones on public.projects;
create trigger projects_value_milestones after update of contract_value on public.projects for each row execute function public.project_value_milestones();

-- How far the work is: the manager's figure, else the tasks (weighted by estimated hours).
create or replace function public.project_pct(p_project uuid) returns int
language sql stable security definer set search_path = public as $$
  select coalesce(p.percent_complete_override,
    (select case when sum(coalesce(estimated_hours,0)) > 0
                 then round(sum(coalesce(estimated_hours,0) * coalesce(percent_complete, case status when 'done' then 100 when 'doing' then 50 else 0 end) / 100.0) / sum(coalesce(estimated_hours,0)) * 100)::int
                 when count(*) > 0 then round(count(*) filter (where status = 'done')::numeric / count(*) * 100)::int else 0 end
       from tasks where project_id = p.id))
  from projects p where p.id = p_project;
$$;

-- Milestones whose stage of work has been reached become ready to invoice, and the project manager and Finance are told.
create or replace function public.check_milestones(p_project uuid default null) returns int
language plpgsql security definer set search_path = public as $$
declare r record; v_pct int; n int := 0;
begin
  if p_project is not null and auth.uid() is not null and not is_member((select company_id from projects where id = p_project)) then raise exception 'Not your project'; end if;
  for r in select m.*, p.company_id cid, p.number pnum, p.name pname, p.manager_id from project_milestones m join projects p on p.id = m.project_id
            where m.status = 'planned' and m.trigger_pct is not null and (p_project is null or m.project_id = p_project) loop
    v_pct := project_pct(r.project_id);
    if coalesce(v_pct, 0) >= r.trigger_pct then
      update project_milestones set status = 'ready' where id = r.id;
      perform notify(r.cid, array['accountant'], array[r.manager_id], 'milestone.ready',
        'Ready to invoice: ' || r.name || ' (' || coalesce(r.pct || '% of contract', 'GH₵ ' || r.amount) || ')',
        coalesce(r.pnum || ' ', '') || r.pname || ' is ' || v_pct || '% complete', '/projects/' || r.project_id, true);
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

-- Invoicing a milestone: due date from its payment terms; linked and referenced.
do $$ begin
  if to_regprocedure('public.invoice_milestone_v22(uuid)') is null then alter function public.invoice_milestone(uuid) rename to invoice_milestone_v22; end if;
end $$;
create or replace function public.invoice_milestone(p_milestone uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid; m project_milestones; p projects;
begin
  select * into m from project_milestones where id = p_milestone;
  select * into p from projects where id = m.project_id;
  v := invoice_milestone_v22(p_milestone);
  update invoices set milestone_id = m.id, reference = coalesce(reference, coalesce(p.number || ' ', '') || m.name),
    due_date = case when m.terms_days is not null then invoice_date + m.terms_days else coalesce(m.due_date, due_date) end,
    customer_po = coalesce(customer_po, p.client_po)
   where id = v;
  update invoice_lines set description = 'Milestone: ' || m.name || coalesce(' (' || m.pct || '% of contract sum)', '') where invoice_id = v;
  return v;
end $$;
revoke execute on function public.invoice_milestone_v22(uuid) from public, anon, authenticated;
alter table public.projects add column if not exists client_po text;

-- ---------------------------------------------------------------- 5. Stock for sale, for use in the work, or both; each item's home store
alter table public.products add column if not exists use_for text not null default 'both' check (use_for in ('sale','internal','both'));
alter table public.products add column if not exists home_warehouse_id uuid references public.warehouses(id) on delete set null;

-- ---------------------------------------------------------------- 6. Requests: SR (services), ADR (purchases), MRO (materials from store); several items; attachments
alter table public.project_requests drop constraint if exists project_requests_kind_check;
alter table public.project_requests add constraint project_requests_kind_check check (kind in ('material','subcontract','equipment','other','service'));
alter table public.project_requests add column if not exists group_no text;
alter table public.project_requests add column if not exists line_no int;
create index if not exists project_requests_group on public.project_requests (company_id, group_no);

create or replace function public.project_request_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.company_id := (select company_id from projects where id = new.project_id);
    if new.number is null then
      new.number := case when new.kind in ('service','subcontract') then next_number(new.company_id, 'SR', 'SR-') else next_number(new.company_id, 'ADR', 'ADR-') end;
    end if;
    new.requested_by := coalesce(auth.uid(), new.requested_by);
    new.requested_email := (select email from auth.users where id = new.requested_by);
    if new.status not in ('draft','submitted') then raise exception 'New requests start as draft or submitted'; end if;
  elsif new.status is distinct from old.status and new.status in ('approved','rejected','billed','ordered')
        and coalesce(current_setting('sika.requests', true), '') <> 'on' then
    raise exception 'Use Approve or Reject to decide a request';
  end if;
  if tg_op = 'UPDATE' and old.status in ('approved','billed','ordered') and coalesce(current_setting('sika.requests', true), '') <> 'on'
     and (new.qty, new.est_unit_cost, new.project_id) is distinct from (old.qty, old.est_unit_cost, old.project_id) then
    raise exception 'An approved request cannot be changed. Cancel it and raise a new one.';
  end if;
  return new;
end $$;

-- One request with several items: one number (ADR-00012 or SR-00004) and a line for each item (ADR-00012/1, /2…).
-- p_lines: [{"description","qty","unit","est_unit_cost","product_id","supplier_id","notes"}]
create or replace function public.raise_project_request(p_project uuid, p_kind text, p_lines jsonb, p_needed_by date default null,
  p_notes text default null, p_submit boolean default true) returns text
language plpgsql security definer set search_path = public as $$
declare cid uuid; v_no text; l jsonb; i int := 0; n int;
begin
  select company_id into cid from projects where id = p_project;
  if cid is null then raise exception 'Choose the project'; end if;
  perform require_member(cid);
  n := jsonb_array_length(coalesce(p_lines, '[]'::jsonb));
  if n = 0 then raise exception 'Add at least one item'; end if;
  v_no := case when p_kind in ('service','subcontract') then next_number(cid, 'SR', 'SR-') else next_number(cid, 'ADR', 'ADR-') end;
  for l in select * from jsonb_array_elements(p_lines) loop
    i := i + 1;
    if coalesce(trim(l->>'description'), '') = '' then raise exception 'Item % has no description', i; end if;
    if coalesce((l->>'qty')::numeric, 0) <= 0 then raise exception 'Item % needs a quantity', i; end if;
    insert into project_requests (company_id, project_id, kind, description, product_id, account_id, task_id, qty, unit, est_unit_cost, supplier_id, needed_by, status, notes, number, group_no, line_no)
    values (cid, p_project, p_kind, trim(l->>'description'), nullif(l->>'product_id', '')::uuid, nullif(l->>'account_id', '')::uuid, nullif(l->>'task_id', '')::uuid, (l->>'qty')::numeric, nullif(l->>'unit', ''),
            coalesce(nullif(l->>'est_unit_cost', '')::numeric, 0), nullif(l->>'supplier_id', '')::uuid, p_needed_by,
            case when p_submit then 'submitted' else 'draft' end, concat_ws(E'\n', p_notes, nullif(l->>'notes', '')),
            case when n > 1 then v_no || '/' || i else v_no end, v_no, i);
  end loop;
  return v_no;
end $$;

-- Material requests from the store are numbered MRO.
create or replace function public.stock_request_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.company_id := (select company_id from projects where id = new.project_id);
    new.number := coalesce(new.number, next_number(new.company_id, 'MRO', 'MRO-'));
    new.requested_by := coalesce(auth.uid(), new.requested_by);
    new.requested_email := (select email from auth.users where id = new.requested_by);
    if new.status not in ('draft','submitted') then raise exception 'A new stock request starts as a draft'; end if;
    if (select project_id from warehouses where id = new.to_warehouse_id) is distinct from new.project_id then
      raise exception 'Deliver the request to this project''s site store';
    end if;
  elsif new.status is distinct from old.status and coalesce(current_setting('sika.posting', true), '') <> 'on'
        and not (old.status = 'draft' and new.status in ('submitted','cancelled')) and not (old.status = 'submitted' and new.status = 'cancelled') then
    raise exception 'Use Send or Receive to move a stock request on';
  end if;
  return new;
end $$;

-- Attachments (PDF, Excel, photos) for requests and other records.
create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  parent_type text not null,          -- 'request' (by request number), 'invoice', 'customer', ...
  parent_key text not null,
  name text not null,
  storage_path text not null,
  size_bytes bigint,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists attachments_parent on public.attachments (company_id, parent_type, parent_key);
alter table public.attachments enable row level security;
drop policy if exists "members read attachments" on public.attachments;
create policy "members read attachments" on public.attachments for select using (is_member(company_id));
drop policy if exists "members add attachments" on public.attachments;
create policy "members add attachments" on public.attachments for insert with check (is_member(company_id) and uploaded_by = auth.uid());
drop policy if exists "remove own attachments" on public.attachments;
create policy "remove own attachments" on public.attachments for delete using (uploaded_by = auth.uid() or has_role(company_id, array['owner','admin']));

-- ---------------------------------------------------------------- 7. Subcontractors in HR (site records, inductions, timesheets; not on payroll)
alter table public.employees drop constraint if exists employees_employment_type_check;
alter table public.employees add constraint employees_employment_type_check
  check (employment_type in ('permanent','fixed_term','casual','contract','intern','national_service','consultant','subcontractor'));
alter table public.employees add column if not exists subcontractor_supplier_id uuid references public.suppliers(id) on delete set null;
alter table public.employees add column if not exists subcontractor_company text;
alter table public.employees add column if not exists id_type text;
alter table public.employees add column if not exists id_number text;
alter table public.employees add column if not exists trade text;

do $$ begin
  if to_regprocedure('public.calc_run_v30(uuid)') is null then alter function public.calc_run(uuid) rename to calc_run_v30; end if;
end $$;
create or replace function public.calc_run(p_run uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform calc_run_v30(p_run);
  -- Subcontractors are paid through their company's bills, never through payroll.
  delete from payslips where run_id = p_run and employee_id in (select id from employees where employment_type = 'subcontractor');
end $$;
revoke execute on function public.calc_run_v30(uuid) from public, anon, authenticated;
revoke execute on function public.calc_run(uuid) from public, anon, authenticated;

-- ---------------------------------------------------------------- 8. Company logo on documents and in the app
alter table public.companies add column if not exists logo_data text check (logo_data is null or (logo_data like 'data:image/%' and length(logo_data) < 400000));

-- ---------------------------------------------------------------- 9. Backups to the company's OneDrive (Microsoft 365), daily
create table if not exists public.company_backup (
  company_id uuid primary key references public.companies(id) on delete cascade,
  enabled boolean not null default false,
  onedrive_user text,                 -- the Microsoft 365 account whose OneDrive holds the backups
  folder text not null default 'Asnys ERP backups',
  keep_days int not null default 90 check (keep_days between 7 and 3650),
  function_url text,
  last_run_at timestamptz,
  last_status text,
  last_file text,
  last_size bigint,
  updated_at timestamptz not null default now()
);
alter table public.company_backup enable row level security;
drop policy if exists "owners manage backup" on public.company_backup;
create policy "owners manage backup" on public.company_backup for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));
insert into public.company_email_secret (company_id) select company_id from public.company_backup on conflict do nothing;
create or replace function public.company_backup_secret() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into company_email_secret (company_id) values (new.company_id) on conflict do nothing;
  return null;
end $$;
drop trigger if exists company_backup_secret on public.company_backup;
create trigger company_backup_secret after insert or update on public.company_backup for each row execute function public.company_backup_secret();

-- The tables that belong to a company (everything with a company_id), for the backup function.
create or replace function public.backup_tables() returns text[]
language sql stable security definer set search_path = public as $$
  select array_agg(c.table_name::text order by c.table_name) from information_schema.columns c join information_schema.tables t on t.table_schema = c.table_schema and t.table_name = c.table_name
   where c.table_schema = 'public' and c.column_name = 'company_id' and t.table_type = 'BASE TABLE'
     and c.table_name not in ('company_email','company_email_secret','company_telegram','message_log','notifications','user_channels');
$$;
create or replace function public.backup_hook_config(cid uuid, p_secret text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('onedrive_user', b.onedrive_user, 'folder', b.folder, 'keep_days', b.keep_days, 'company', c.name, 'code', coalesce(c.doc_prefix, ''), 'tables', backup_tables())
    from company_backup b join companies c on c.id = b.company_id join company_email_secret x on x.company_id = b.company_id
   where b.company_id = cid and b.enabled and x.secret = p_secret;
$$;
create or replace function public.backup_done(cid uuid, p_secret text, p_status text, p_file text, p_size bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from company_email_secret where company_id = cid and secret = p_secret) then raise exception 'Not allowed'; end if;
  update company_backup set last_run_at = now(), last_status = left(p_status, 500), last_file = p_file, last_size = p_size where company_id = cid;
  if p_status <> 'ok' then
    perform notify(cid, array[]::text[], null, 'backup_failed', 'Backup to OneDrive failed', left(p_status, 300), '/settings/security', true);
  end if;
end $$;
do $$ begin
  revoke execute on function public.backup_hook_config(uuid, text) from public, anon, authenticated;
  revoke execute on function public.backup_done(uuid, text, text, text, bigint) from public, anon, authenticated;
  revoke execute on function public.backup_tables() from public, anon, authenticated;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.backup_hook_config(uuid, text) to service_role;
    grant execute on function public.backup_done(uuid, text, text, text, bigint) to service_role;
    grant execute on function public.backup_tables() to service_role;
  end if;
end $$;

create or replace function public.start_backup(cid uuid) returns bigint
language plpgsql security definer set search_path = public as $$
declare b company_backup;
begin
  select * into b from company_backup where company_id = cid;
  if not found or not b.enabled or b.function_url is null or b.onedrive_user is null then return null; end if;
  return http_post_safe(b.function_url, jsonb_build_object('action', 'backup', 'company_id', cid),
    jsonb_build_object('Content-Type', 'application/json', 'x-asnys-secret', (select secret from company_email_secret where company_id = cid)));
end $$;
revoke execute on function public.start_backup(uuid) from public, anon, authenticated;

-- Owners can also download a backup to their own computer from the app (the same tables).
create or replace function public.my_backup_tables(cid uuid) returns text[]
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can download a backup'; end if;
  return backup_tables();
end $$;

create or replace function public.backup_now(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can start a backup'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  v := start_backup(cid);
  if v is null then raise exception 'Tick Back up to OneDrive, enter the OneDrive account and save first'; end if;
  return 'started';
end $$;

-- ---------------------------------------------------------------- 10. Microsoft 365 sign-in by certificate (10 years) and its expiry reminder
alter table public.company_email add column if not exists cert_thumbprint text;
alter table public.company_email add column if not exists cert_expires date;
alter table public.company_email add column if not exists secret_expires date;
alter table public.company_email add column if not exists reminded_on date;
-- The v3.3 send-mail function is replaced by asnys-m365 (email, backups and password reset in one).
update public.company_email set function_url = replace(function_url, '/functions/v1/send-mail', '/functions/v1/asnys-m365') where function_url like '%/functions/v1/send-mail';

create or replace function public.run_integration_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; v_date date; v_what text;
begin
  for r in select * from company_email where provider = 'microsoft' and enabled loop
    v_date := least(coalesce(r.cert_expires, '9999-12-31'), coalesce(r.secret_expires, '9999-12-31'));
    v_what := case when v_date = r.cert_expires then 'certificate' else 'client secret' end;
    if v_date <= current_date + 30 and (r.reminded_on is null or r.reminded_on < current_date - 7) then
      perform notify(r.company_id, array[]::text[], null, 'integration_expiry', 'Microsoft 365 ' || v_what || case when v_date < current_date then ' has EXPIRED' else ' expires ' || to_char(v_date, 'DD Mon YYYY') end,
        'Emails, invitations and OneDrive backups stop when it expires. Renew it under Settings → Telegram & email.', '/settings/messaging', true);
      update company_email set reminded_on = current_date where company_id = r.company_id; n := n + 1;
    end if;
  end loop;
  -- Daily backups to OneDrive
  for r in select company_id from company_backup where enabled and (last_run_at is null or last_run_at < now() - interval '20 hours') loop
    perform start_backup(r.company_id); n := n + 1;
  end loop;
  -- Payment milestones whose stage of work has been reached
  n := n + coalesce(check_milestones(null), 0);
  return n;
end $$;
revoke execute on function public.run_integration_reminders() from public, anon, authenticated;

create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_integration_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 11. "Forgot password" by the company's Microsoft 365 email
create table if not exists public.password_reset_log (
  id bigserial primary key,
  email text not null,
  requested_at timestamptz not null default now(),
  sent boolean not null default false
);
alter table public.password_reset_log enable row level security;
-- Called by the asnys-m365 function (service key): may this email have a reset link now, and from which company's mailbox?
create or replace function public.reset_target(p_email text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_user uuid; v_cid uuid; v_recent int;
begin
  select count(*) into v_recent from password_reset_log where lower(email) = lower(p_email) and requested_at > now() - interval '1 hour';
  insert into password_reset_log (email) values (lower(p_email));
  if v_recent >= 3 then return null; end if;
  select id into v_user from auth.users where lower(email) = lower(p_email);
  if v_user is null then return null; end if;
  select m.company_id into v_cid from memberships m join company_email e on e.company_id = m.company_id
   where m.user_id = v_user and e.provider = 'microsoft' and e.enabled order by m.created_at limit 1;
  if v_cid is null then return null; end if;
  update password_reset_log set sent = true where id = currval(pg_get_serial_sequence('public.password_reset_log', 'id'));
  return jsonb_build_object('company_id', v_cid, 'company', (select name from companies where id = v_cid),
    'from_email', (select from_email from company_email where company_id = v_cid), 'from_name', (select coalesce(from_name, (select name from companies where id = v_cid)) from company_email where company_id = v_cid),
    'app_url', coalesce((select app_url from company_telegram where company_id = v_cid), 'https://asnys-erp.pages.dev'));
end $$;
-- For invitations sent by invite-member: the company's Microsoft 365 sender, if it has one.
create or replace function public.m365_sender(cid uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('from_email', e.from_email, 'from_name', coalesce(e.from_name, c.name), 'company', c.name)
    from company_email e join companies c on c.id = e.company_id where e.company_id = cid and e.provider = 'microsoft' and e.enabled and e.from_email is not null;
$$;
do $$ begin
  revoke execute on function public.reset_target(text) from public, anon, authenticated;
  revoke execute on function public.m365_sender(uuid) from public, anon, authenticated;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.reset_target(text) to service_role;
    grant execute on function public.m365_sender(uuid) to service_role;
  end if;
end $$;

-- ---------------------------------------------------------------- 12. 2-step sign-in (authenticator app): who must use it, and who has it
alter table public.companies add column if not exists mfa_roles text[] not null default '{}';
create or replace function public.my_mfa_required() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships m join companies c on c.id = m.company_id where m.user_id = auth.uid() and m.role = any(c.mfa_roles));
$$;
create or replace function public.security_overview(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_mfa boolean := to_regclass('auth.mfa_factors') is not null; v jsonb;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  if v_mfa then
    execute 'select coalesce(jsonb_agg(jsonb_build_object(''email'', coalesce(m.email, u.email), ''role'', m.role, ''last_sign_in_at'', u.last_sign_in_at,
               ''mfa'', exists (select 1 from auth.mfa_factors f where f.user_id = m.user_id and f.status = ''verified'')) order by m.role, coalesce(m.email, u.email)), ''[]'')
               from memberships m left join auth.users u on u.id = m.user_id where m.company_id = $1' into v using cid;
  else
    select coalesce(jsonb_agg(jsonb_build_object('email', coalesce(m.email, u.email), 'role', m.role, 'last_sign_in_at', u.last_sign_in_at, 'mfa', false)), '[]')
      into v from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid;
  end if;
  return jsonb_build_object('people', v, 'mfa_roles', (select mfa_roles from companies where id = cid),
    'backup', (select to_jsonb(b) - 'function_url' from company_backup b where company_id = cid),
    'cert_expires', (select cert_expires from company_email where company_id = cid),
    'secret_expires', (select secret_expires from company_email where company_id = cid),
    'failed_resets_24h', (select count(*) from password_reset_log where requested_at > now() - interval '1 day' and not sent));
end $$;
create or replace function public.set_mfa_roles(cid uuid, p_roles text[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  update companies set mfa_roles = coalesce(p_roles, '{}') where id = cid;
  insert into audit_log (company_id, action, table_name, detail) values (cid, 'security.mfa_roles', 'companies', jsonb_build_object('roles', p_roles));
end $$;

-- ---------------------------------------------------------------- 12b. Custom roles: tick the modules and pages, and whether they may approve and void
-- A person keeps one main role and can hold any number of custom roles; they get everything those roles allow combined.
-- What a custom role may do in the database is expressed as the built-in roles it "acts as" (worked out by the app from
-- the pages ticked); owner and admin can never be granted this way.
create table if not exists public.custom_roles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null check (length(trim(name)) between 2 and 60),
  description text,
  pages text[] not null default '{}',           -- app pages (paths) this role can open
  grants text[] not null default '{}' check (grants <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  approve text[] not null default '{}' check (approve <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  void_grants text[] not null default '{}' check (void_grants <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  created_at timestamptz not null default now(),
  unique (company_id, name)
);
alter table public.custom_roles enable row level security;
drop policy if exists "members read custom roles" on public.custom_roles;
create policy "members read custom roles" on public.custom_roles for select using (is_member(company_id));
drop policy if exists "admins manage custom roles" on public.custom_roles;
create policy "admins manage custom roles" on public.custom_roles for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));

alter table public.memberships add column if not exists custom_role_ids uuid[] not null default '{}';
alter table public.memberships add column if not exists extra_roles text[] not null default '{}';
alter table public.memberships add column if not exists approve_roles text[] not null default '{}';
alter table public.memberships add column if not exists void_roles text[] not null default '{}';
alter table public.memberships add column if not exists allowed_pages text[];      -- null: the main role decides

-- The combined rights are always worked out here from the roles held, so nobody can write them directly.
create or replace function public.membership_custom_sync() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.extra_roles
    from custom_roles r left join lateral unnest(r.grants) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.approve_roles
    from custom_roles r left join lateral unnest(r.approve) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.void_roles
    from custom_roles r left join lateral unnest(r.void_grants) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  if cardinality(new.custom_role_ids) = 0 then new.allowed_pages := null;
  else select coalesce(array_agg(distinct pg) filter (where pg is not null), '{}') into new.allowed_pages
         from custom_roles r left join lateral unnest(r.pages) pg on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  end if;
  return new;
end $$;
drop trigger if exists memberships_custom_sync on public.memberships;
create trigger memberships_custom_sync before insert or update on public.memberships for each row execute function public.membership_custom_sync();

create or replace function public.custom_role_changed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update memberships set custom_role_ids = case when tg_op = 'DELETE' then array_remove(custom_role_ids, old.id) else custom_role_ids end
   where company_id = coalesce(new.company_id, old.company_id) and coalesce(new.id, old.id) = any(custom_role_ids);
  return null;
end $$;
drop trigger if exists custom_roles_changed on public.custom_roles;
create trigger custom_roles_changed after update or delete on public.custom_roles for each row execute function public.custom_role_changed();

-- A role check now also counts the custom roles a person holds.
create or replace function public.has_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or extra_roles && roles));
$$;
-- Approving a step of an approval chain needs the main role, or a custom role with "Can approve" ticked.
create or replace function public.has_approve_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or approve_roles && roles));
$$;
-- Voiding needs the main role, or a custom role with "Can void" ticked.
create or replace function public.has_void_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or void_roles && roles));
$$;

create or replace function public.can_approve_step(s approval_steps) returns boolean
language sql stable security definer set search_path = public as $$
  select s.status = 'pending'
     and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'pending' and o.step_no < s.step_no)
     and (has_role(s.company_id, array['owner'])
          or ((s.approver_user = auth.uid() or (s.approver_role is not null and has_approve_role(s.company_id, array[s.approver_role])))
              and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = auth.uid())));
$$;

create or replace function public.step_approvers(s approval_steps) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct u), '{}') from (
    select s.approver_user u where s.approver_user is not null
    union select m.user_id from memberships m where m.company_id = s.company_id and s.approver_role is not null and (m.role = s.approver_role or s.approver_role = any(m.approve_roles))
    union select m.user_id from memberships m where m.company_id = s.company_id and m.role = 'owner'
      and not exists (select 1 from memberships x where x.company_id = s.company_id and ((s.approver_role is not null and (x.role = s.approver_role or s.approver_role = any(x.approve_roles))) or x.user_id = s.approver_user))
  ) x where u is not null and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = u);
$$;

create or replace function public.can_void(p_table text, p_id uuid) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid;
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then return false; end if;
  execute format('select company_id, status from public.%I where id = $1', p_table) into v_cid, v_status using p_id;
  if v_cid is null or not (v_status = any(vr.from_status)) then return false; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  return has_role(v_cid, array['owner','admin']) or has_void_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid());
end $$;

-- Notices sent "to Finance", "to HR" etc. also reach people holding that right through a custom role.
create or replace function public.notify(cid uuid, p_roles text[], p_users uuid[], p_kind text, p_title text, p_body text default null, p_path text default null, p_include_self boolean default false)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into notifications (company_id, user_id, kind, title, body, path)
  select distinct cid, u, p_kind, p_title, p_body, p_path from (
    select m.user_id u from memberships m where m.company_id = cid and (m.role = any(p_roles) or m.extra_roles && p_roles or m.role in ('owner','admin'))
    union select unnest(coalesce(p_users, '{}'::uuid[]))) x
  where u is not null and (p_include_self or u is distinct from auth.uid());
  get diagnostics n = row_count;
  return n;
end $$;

-- Transport officers and HSE officers can also come from a custom role.
create or replace function public.is_hse(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (hse or 'hse' = any(extra_roles) or role in ('owner','admin')));
$$;
create or replace function public.hse_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (hse or 'hse' = any(extra_roles));
$$;
create or replace function public.is_transport(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (transport or 'transport' = any(extra_roles) or role in ('owner','admin','accountant','store')));
$$;
create or replace function public.transport_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or 'transport' = any(extra_roles) or role = 'store');
$$;
create or replace function public.fleet_alert_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or 'transport' = any(extra_roles) or role in ('store','owner','admin'));
$$;
revoke execute on function public.fleet_alert_users(uuid) from public, anon, authenticated;

-- Owners and admins give or take away custom roles.
create or replace function public.set_member_custom_roles(cid uuid, p_user uuid, p_roles uuid[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can give custom roles'; end if;
  if exists (select 1 from unnest(coalesce(p_roles, '{}')) r where not exists (select 1 from custom_roles c where c.id = r and c.company_id = cid)) then
    raise exception 'Unknown role';
  end if;
  update memberships set custom_role_ids = coalesce(p_roles, '{}') where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (cid, 'member.custom_roles', 'memberships', p_user, jsonb_build_object('roles', (select coalesce(jsonb_agg(name), '[]') from custom_roles where id = any(p_roles))));
end $$;

-- ---------------------------------------------------------------- 12c. Several bank accounts; each invoice says which one to pay into
create table if not exists public.company_banks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  bank_name text not null,
  branch text,
  account_name text,
  account_no text not null,
  swift text,
  currency text not null default 'GHS',
  is_default boolean not null default false,
  active boolean not null default true,
  sort int not null default 0,
  created_at timestamptz not null default now()
);
create unique index if not exists company_banks_one_default on public.company_banks (company_id) where is_default;
alter table public.company_banks enable row level security;
drop policy if exists "members read banks" on public.company_banks;
create policy "members read banks" on public.company_banks for select using (is_member(company_id));
drop policy if exists "finance manages banks" on public.company_banks;
create policy "finance manages banks" on public.company_banks for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));
alter table public.invoices add column if not exists bank_id uuid references public.company_banks(id) on delete set null;
alter table public.sales_quotes add column if not exists bank_id uuid references public.company_banks(id) on delete set null;

-- A new invoice pays into the account in its currency, else the default account.
create or replace function public.invoice_bank_default() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.bank_id is null then
    select id into new.bank_id from company_banks where company_id = new.company_id and active
     order by (currency = coalesce(new.currency, 'GHS')) desc, is_default desc, sort limit 1;
  end if;
  return new;
end $$;
drop trigger if exists invoices_bank_default on public.invoices;
create trigger invoices_bank_default before insert on public.invoices for each row execute function public.invoice_bank_default();

-- ---------------------------------------------------------------- 13. Voiding: also lets material requests through their store guard
create or replace function public.void_entry(p_table text, p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid; f text;
  flags text[] := array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle','sika.posting'];
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be voided here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  if not (has_role(v_cid, array['owner','admin']) or has_void_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid())) then
    raise exception 'You cannot void this %. Ask an admin.', lower(vr.label);
  end if;
  if v_status = 'voided' then raise exception 'Already voided'; end if;
  if not (v_status = any(vr.from_status)) then
    raise exception 'A % that is % cannot be voided. %', lower(vr.label), replace(v_status, '_', ' '),
      case when p_table = 'purchase_orders' then 'Goods have been received against it; close it instead.'
           when p_table = 'expense_claims' then 'It has been posted; reverse it with a journal.'
           when p_table = 'tenders' then 'An awarded tender has a project; cancel the project instead.'
           else 'It has already gone through.' end;
  end if;
  if p_table = 'timesheets' and exists (select 1 from timesheets where id = p_id and invoice_id is not null) then raise exception 'This time has been invoiced'; end if;
  foreach f in array flags loop perform set_config(f, 'on', true); end loop;
  execute format('update public.%I set status = ''voided'', void_reason = $2, voided_at = now(), voided_by = auth.uid() where id = $1', p_table) using p_id, trim(p_reason);
  foreach f in array flags loop perform set_config(f, 'off', true); end loop;
  update approval_steps set status = 'skipped' where doc_id = p_id and status = 'pending';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.voided', p_table, p_id, jsonb_build_object('what', vr.label, 'was', v_status, 'reason', trim(p_reason)));
end $$;

-- ---------------------------------------------------------------- 13a. Restore (un-void): owners and admins, with a reason; back to the status it had
create or replace function public.unvoid_entry(p_table text, p_id uuid, p_reason text) returns text
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_was text; f text;
  flags text[] := array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle','sika.posting'];
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be restored here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being restored'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  if not has_role(v_cid, array['owner','admin']) then raise exception 'Only an owner or admin can restore a voided entry'; end if;
  if v_status <> 'voided' then raise exception 'This % is not voided', lower(vr.label); end if;
  select detail->>'was' into v_was from audit_log where company_id = v_cid and action = 'entry.voided' and table_name = p_table and row_id = p_id order by id desc limit 1;
  if v_was is null then raise exception 'The status before voiding is not on record, so it cannot be restored'; end if;
  foreach f in array flags loop perform set_config(f, 'on', true); end loop;
  execute format('update public.%I set status = $2, void_reason = null, voided_at = null, voided_by = null where id = $1', p_table) using p_id, v_was;
  foreach f in array flags loop perform set_config(f, 'off', true); end loop;
  update approval_steps set status = 'pending' where doc_id = p_id and status = 'skipped';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.restored', p_table, p_id, jsonb_build_object('what', vr.label, 'back_to', v_was, 'reason', trim(p_reason)));
  return v_was;
end $$;

-- ---------------------------------------------------------------- 13b. Numbered entries are never deleted: void them instead
-- Once a document has a number it stays in the system for the audit trail. Drafts without a number can still be deleted,
-- and deleting a whole company (cascade) is not blocked.
create or replace function public.keep_numbered() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if pg_trigger_depth() = 1 and coalesce(to_jsonb(old)->>'number', '') <> '' and coalesce(current_setting('asnys.purge', true), '') <> 'on' then
    raise exception '% is numbered, so it cannot be deleted. Use Void instead: it stays in the records marked voided, with the reason.', to_jsonb(old)->>'number';
  end if;
  return old;
end $$;
do $$ declare t text; begin
  for t in select v.table_name from void_rules v
             where exists (select 1 from information_schema.columns c where c.table_schema = 'public' and c.table_name = v.table_name and c.column_name = 'number') loop
    execute format('drop trigger if exists %I on public.%I', t || '_keep_numbered', t);
    execute format('create trigger %I before delete on public.%I for each row execute function public.keep_numbered()', t || '_keep_numbered', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- 14. New companies
create or replace function public.company_seed_v34() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform seed_accounts_v34(new.id);
  insert into number_formats (company_id, key, prefix) values (new.id, 'ADR', 'ADR'), (new.id, 'SR', 'SR'), (new.id, 'MRO', 'MRO') on conflict do nothing;
  return null;
end $$;
drop trigger if exists companies_seed_v34 on public.companies;
create trigger companies_seed_v34 after insert on public.companies for each row execute function public.company_seed_v34();

-- Audit the new settings tables too.
do $$ declare t text; begin
  foreach t in array array['number_formats','attachments','company_backup','custom_roles','company_banks'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- Progress changes make milestones ready straight away.
create or replace function public.progress_milestones() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform check_milestones(case when tg_table_name = 'tasks' then (to_jsonb(new)->>'project_id')::uuid else new.id end);
  return null;
end $$;
drop trigger if exists tasks_progress_milestones on public.tasks;
create trigger tasks_progress_milestones after update of status, percent_complete on public.tasks for each row execute function public.progress_milestones();
drop trigger if exists projects_progress_milestones on public.projects;
create trigger projects_progress_milestones after update of percent_complete_override on public.projects for each row execute function public.progress_milestones();

-- ======================================== Part C2: v3.5 QuickBooks-style sales and accounting
-- Asnys ERP v3.5 — QuickBooks-style sales and accounting
--   1. Receive payment: one receipt split over several invoices, into the bank account you choose; anything extra is kept
--      as the customer's credit (customer deposits) and applied to later invoices.
--   2. Sales receipt: a cash sale in one step (invoice + payment), without the strict-invoice checks.
--   3. Pay bills: several supplier bills paid together from one account, with withholding tax deducted.
--   4. Bank feed: statement lines imported from the bank's CSV, rules that suggest the account, matched or posted.
--   5. Reports: cash flow, sales by customer, sales by product, profit by project and by customer.
-- Run after 0022. Safe to run twice.

-- ---------------------------------------------------------------- 0. Accounts
create or replace function public.seed_accounts_v35(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  -- 2500 has existed since v1.1 without a key; give it one so receipts can use it.
  if not exists (select 1 from accounts where company_id = cid and system_key = 'customer_deposits') then
    if exists (select 1 from accounts where company_id = cid and code = '2500' and system_key is null) then
      update accounts set system_key = 'customer_deposits' where company_id = cid and code = '2500';
    else
      insert into accounts (company_id, code, name, type, system_key)
      values (cid, case when exists (select 1 from accounts where company_id = cid and code = '2500') then '2510' else '2500' end, 'Customer deposits and credits', 'liability', 'customer_deposits')
      on conflict do nothing;
    end if;
  end if;
  if not exists (select 1 from accounts where company_id = cid and system_key = 'wht_payable') then
    insert into accounts (company_id, code, name, type, system_key)
    values (cid, case when exists (select 1 from accounts where company_id = cid and code = '2270') then '2275' else '2270' end, 'Withholding tax payable (deducted from suppliers)', 'liability', 'wht_payable')
    on conflict do nothing;
  end if;
end $$;
select public.seed_accounts_v35(id) from public.companies;

-- Which payment method a cash, MoMo or bank account counts as.
create or replace function public.method_of(p_account uuid) returns text
language sql stable security definer set search_path = public as $$
  select case when system_key = 'cash' or name ilike '%cash%' then 'cash' when system_key = 'momo' or name ilike '%momo%' or name ilike '%mobile money%' then 'momo' else 'bank' end
    from accounts where id = p_account;
$$;

alter table public.payments add column if not exists account_id uuid references public.accounts(id);
alter table public.payments add column if not exists receipt_id uuid;
alter table public.bill_payments add column if not exists account_id uuid references public.accounts(id);
alter table public.bill_payments add column if not exists batch_id uuid;
alter table public.bill_payments add column if not exists wht_amount numeric(14,2) not null default 0;

-- ---------------------------------------------------------------- 1. Receive payment over several invoices, with customer credit
create table if not exists public.customer_receipts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  customer_id uuid not null references public.customers(id),
  receipt_date date not null,
  account_id uuid not null references public.accounts(id),
  currency text not null default 'GHS',
  exchange_rate numeric(14,6) not null default 1,
  amount numeric(14,2) not null check (amount > 0),
  unapplied numeric(14,2) not null default 0 check (unapplied >= 0),
  reference text,
  memo text,
  status text not null default 'posted' check (status in ('posted','voided')),
  journal_entry_id uuid references public.journal_entries(id),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists customer_receipts_customer on public.customer_receipts (company_id, customer_id);
alter table public.customer_receipts enable row level security;
drop policy if exists "finance and sales read receipts" on public.customer_receipts;
create policy "finance and sales read receipts" on public.customer_receipts for select using (has_role(company_id, array['owner','admin','accountant','sales']));

-- p_allocs: [{"invoice_id": "...", "amount": 1000}] in the receipt's currency. Every invoice must be this customer's and in that currency.
create or replace function public.receive_payment(cid uuid, p_customer uuid, p_date date, p_account uuid, p_amount numeric,
  p_allocs jsonb default '[]', p_reference text default null, p_memo text default null, p_currency text default 'GHS', p_rate numeric default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_no text; a jsonb; inv invoices; v_alloc numeric; v_wht numeric; v_total numeric := 0; v_rate numeric; v_lines jsonb := '[]'; v_je uuid;
  g_bank numeric; g_ar numeric; g_wht numeric; g_sum_ar numeric := 0; g_sum_wht numeric := 0; v_left numeric; v_method text; v_cust customers;
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  select * into v_cust from customers where id = p_customer and company_id = cid;
  if not found then raise exception 'Choose the customer'; end if;
  perform paying_account(cid, p_account);
  if round(coalesce(p_amount, 0), 2) <= 0 then raise exception 'Enter the amount received'; end if;
  v_rate := case when coalesce(p_currency, 'GHS') = 'GHS' then 1 else nullif(p_rate, 0) end;
  if v_rate is null then raise exception 'Type in the exchange rate for %', p_currency; end if;
  v_method := method_of(p_account);
  select coalesce(sum(round((x->>'amount')::numeric, 2)), 0) into v_total from jsonb_array_elements(coalesce(p_allocs, '[]')) x where coalesce((x->>'amount')::numeric, 0) > 0;
  if v_total > round(p_amount, 2) then raise exception 'You applied % to invoices but received only %', v_total, round(p_amount, 2); end if;

  v_no := next_number(cid, 'RCP', 'RCP-');
  insert into customer_receipts (company_id, number, customer_id, receipt_date, account_id, currency, exchange_rate, amount, unapplied, reference, memo)
  values (cid, v_no, p_customer, p_date, p_account, coalesce(p_currency, 'GHS'), v_rate, round(p_amount, 2), round(p_amount, 2) - v_total, p_reference, p_memo)
  returning id into v_id;

  g_bank := round(p_amount * v_rate, 2);
  for a in select * from jsonb_array_elements(coalesce(p_allocs, '[]')) loop
    v_alloc := round(coalesce((a->>'amount')::numeric, 0), 2);
    v_wht := round(coalesce((a->>'wht')::numeric, 0), 2);     -- withholding tax the customer deducted (paid to GRA for us)
    continue when v_alloc + v_wht <= 0;
    if v_alloc < 0 or v_wht < 0 then raise exception 'Amounts cannot be negative'; end if;
    select * into inv from invoices where id = (a->>'invoice_id')::uuid and company_id = cid for update;
    if not found or inv.customer_id <> p_customer then raise exception 'An invoice is not this customer''s'; end if;
    if inv.status not in ('posted') then raise exception '% is not open for payment', coalesce(inv.number, 'A draft invoice'); end if;
    if inv.currency <> coalesce(p_currency, 'GHS') then raise exception '% is in %; receive it in that currency', inv.number, inv.currency; end if;
    v_left := inv.total - inv.amount_paid - inv.amount_credited;
    if v_alloc + v_wht > v_left then raise exception '% has only % left to pay', inv.number, v_left; end if;
    g_ar := round((v_alloc + v_wht) * inv.exchange_rate, 2);
    g_wht := round(v_wht * v_rate, 2);
    g_sum_ar := g_sum_ar + g_ar; g_sum_wht := g_sum_wht + g_wht;
    insert into payments (company_id, invoice_id, payment_date, amount, method, reference, exchange_rate, account_id, receipt_id)
    values (cid, inv.id, p_date, v_alloc + v_wht, v_method, coalesce(p_reference, v_no) || case when v_wht > 0 then ' (incl. WHT ' || v_wht || ')' else '' end, v_rate, p_account, v_id);
    update invoices set amount_paid = amount_paid + v_alloc + v_wht,
      status = case when amount_paid + amount_credited + v_alloc + v_wht >= total then 'paid' else 'posted' end where id = inv.id;
    v_lines := v_lines || jl(acct(cid, 'ar'), 0, g_ar);
    if g_wht > 0 then v_lines := v_lines || jl(acct(cid, 'wht_receivable'), g_wht, 0); end if;
  end loop;
  -- Bank in full; receivables at each invoice's own rate; the extra waits as the customer's credit; rounding/rate difference to FX.
  v_lines := v_lines || jl(p_account, g_bank, 0);
  if round(p_amount, 2) - v_total > 0 then v_lines := v_lines || jl(acct(cid, 'customer_deposits'), 0, round((round(p_amount, 2) - v_total) * v_rate, 2)); end if;
  declare d numeric;
  begin
    d := g_bank + g_sum_wht - g_sum_ar - case when round(p_amount, 2) - v_total > 0 then round((round(p_amount, 2) - v_total) * v_rate, 2) else 0 end;
    if d <> 0 then v_lines := v_lines || jl(acct(cid, 'fx'), greatest(-d, 0), greatest(d, 0)); end if;
  end;
  v_je := post_journal(cid, p_date, 'Payment received from ' || v_cust.name || ' (' || v_no || ')' || coalesce(' — ' || p_reference, ''), v_lines, 'receipt', v_id);
  update customer_receipts set journal_entry_id = v_je where id = v_id;
  return v_id;
end $$;

-- Use a customer's unapplied credit against an invoice (same currency).
create or replace function public.apply_customer_credit(p_receipt uuid, p_invoice uuid, p_amount numeric, p_date date default current_date)
returns void language plpgsql security definer set search_path = public as $$
declare r customer_receipts; inv invoices; v numeric; g_dep numeric; g_ar numeric; v_je uuid;
begin
  select * into r from customer_receipts where id = p_receipt for update;
  if not found or r.status <> 'posted' then raise exception 'Receipt not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant','sales']);
  select * into inv from invoices where id = p_invoice for update;
  if not found or inv.customer_id <> r.customer_id or inv.status <> 'posted' then raise exception 'Choose an open invoice of the same customer'; end if;
  if inv.currency <> r.currency then raise exception 'The credit is in % but the invoice is in %', r.currency, inv.currency; end if;
  v := round(least(coalesce(p_amount, 0), r.unapplied, inv.total - inv.amount_paid - inv.amount_credited), 2);
  if v <= 0 then raise exception 'Nothing to apply'; end if;
  g_dep := round(v * r.exchange_rate, 2); g_ar := round(v * inv.exchange_rate, 2);
  v_je := post_journal(r.company_id, greatest(p_date, r.receipt_date), 'Customer credit ' || r.number || ' applied to ' || inv.number,
    jsonb_build_array(jl(acct(r.company_id, 'customer_deposits'), g_dep, 0), jl(acct(r.company_id, 'ar'), 0, g_ar),
      jl(acct(r.company_id, 'fx'), greatest(g_ar - g_dep, 0), greatest(g_dep - g_ar, 0))), 'receipt', r.id);
  insert into payments (company_id, invoice_id, payment_date, amount, method, reference, exchange_rate, account_id, receipt_id, journal_entry_id)
  values (r.company_id, inv.id, greatest(p_date, r.receipt_date), v, method_of(r.account_id), 'Credit ' || r.number, r.exchange_rate, r.account_id, r.id, v_je);
  update invoices set amount_paid = amount_paid + v, status = case when amount_paid + amount_credited + v >= total then 'paid' else 'posted' end where id = inv.id;
  update customer_receipts set unapplied = unapplied - v where id = r.id;
end $$;

-- A receipt entered in error: reverse its journal, take the amounts off the invoices; it stays on record as voided.
create or replace function public.void_customer_receipt(p_receipt uuid, p_reason text, p_date date default current_date)
returns void language plpgsql security definer set search_path = public as $$
declare r customer_receipts; p record; v_lines jsonb;
begin
  select * into r from customer_receipts where id = p_receipt for update;
  if not found then raise exception 'Receipt not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant']);
  if r.status = 'voided' then raise exception 'Already voided'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  if exists (select 1 from payments where receipt_id = r.id and reference like 'Credit %') then raise exception 'Part of this credit has been applied to invoices. Reverse those first with a credit note or journal.'; end if;
  for p in select * from payments where receipt_id = r.id loop
    update invoices set amount_paid = amount_paid - p.amount, status = 'posted' where id = p.invoice_id;
  end loop;
  delete from payments where receipt_id = r.id;
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit, 'project_id', l.project_id)) into v_lines
    from journal_lines l where l.entry_id = r.journal_entry_id;
  perform post_journal(r.company_id, greatest(p_date, r.receipt_date), 'Void of receipt ' || r.number || ': ' || trim(p_reason), v_lines, 'receipt', r.id);
  update customer_receipts set status = 'voided', unapplied = 0 where id = r.id;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (r.company_id, 'entry.voided', 'customer_receipts', r.id, jsonb_build_object('what', 'Receipt', 'number', r.number, 'reason', trim(p_reason)));
end $$;

-- Open items for the Receive payment screen.
create or replace function public.customer_open_items(cid uuid, p_customer uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  return jsonb_build_object(
    'invoices', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'number', i.number, 'invoice_date', i.invoice_date, 'due_date', i.due_date, 'currency', i.currency,
        'total', i.total, 'open', i.total - i.amount_paid - i.amount_credited, 'reference', i.reference, 'customer_po', i.customer_po, 'wht_amount', i.wht_amount) order by i.due_date nulls last, i.invoice_date)
      from invoices i where i.company_id = cid and i.customer_id = p_customer and i.status = 'posted' and i.total - i.amount_paid - i.amount_credited > 0), '[]'),
    'credits', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'number', r.number, 'receipt_date', r.receipt_date, 'currency', r.currency, 'unapplied', r.unapplied) order by r.receipt_date)
      from customer_receipts r where r.company_id = cid and r.customer_id = p_customer and r.status = 'posted' and r.unapplied > 0), '[]'));
end $$;

-- ---------------------------------------------------------------- 2. Sales receipt (cash sale): invoice and payment in one step
alter table public.invoices add column if not exists cash_sale boolean not null default false;
create or replace function public.invoice_post_rules() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers; v_strict boolean;
begin
  if old.status = 'draft' and new.status <> 'draft' then
    select strict_invoices into v_strict from companies where id = new.company_id;
    if v_strict and not new.cash_sale then
      select * into c from customers where id = new.customer_id;
      if coalesce(trim(c.tin), '') = '' then raise exception 'Add % TIN to the customer record before posting (Sales → Customers)', c.name || '''s'; end if;
      if coalesce(trim(new.reference), '') = '' then raise exception 'Enter the invoice reference before posting'; end if;
      if new.quote_id is null and new.contract_id is null and new.project_id is null and coalesce(trim(new.customer_po), '') = '' then
        raise exception 'Tie the invoice to a quotation, contract, project or the customer''s PO number before posting';
      end if;
    end if;
    if new.wht_rate is not null then new.wht_amount := round(new.subtotal * new.wht_rate / 100, 2); end if;
  end if;
  return new;
end $$;

create or replace function public.complete_sales_receipt(p_invoice uuid, p_account uuid, p_reference text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare inv invoices; v uuid;
begin
  select * into inv from invoices where id = p_invoice;
  if not found then raise exception 'Invoice not found'; end if;
  perform require_member(inv.company_id, array['owner','admin','accountant','sales']);
  update invoices set cash_sale = true, due_date = coalesce(due_date, invoice_date) where id = p_invoice and status = 'draft';
  if inv.status = 'draft' then perform post_invoice(p_invoice); end if;
  select * into inv from invoices where id = p_invoice;
  v := receive_payment(inv.company_id, inv.customer_id, inv.invoice_date, p_account, inv.total - inv.amount_paid - inv.amount_credited,
    jsonb_build_array(jsonb_build_object('invoice_id', inv.id, 'amount', inv.total - inv.amount_paid - inv.amount_credited)), p_reference, 'Sales receipt ' || inv.number, inv.currency, inv.exchange_rate);
  return v;
end $$;

-- ---------------------------------------------------------------- 3. Pay several bills at once, from the account you choose, with WHT deducted
create table if not exists public.bill_payment_batches (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  pay_date date not null,
  account_id uuid not null references public.accounts(id),
  reference text,
  total_paid numeric(14,2) not null default 0,
  total_wht numeric(14,2) not null default 0,
  bills int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
alter table public.bill_payment_batches enable row level security;
drop policy if exists "finance reads bill batches" on public.bill_payment_batches;
create policy "finance reads bill batches" on public.bill_payment_batches for select using (has_role(company_id, array['owner','admin','accountant']));

-- p_items: [{"bill_id": "...", "amount": 1000, "wht": 75, "rate": 15.2}] in each bill's currency; amount is what is paid out,
-- wht what is kept back for GRA. Both together come off the bill.
create or replace function public.pay_bills(cid uuid, p_date date, p_account uuid, p_items jsonb, p_reference text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_batch uuid; v_no text; x jsonb; b bills; v_pay numeric; v_wht numeric; v_rate numeric; g_bank numeric; g_ap numeric; g_wht numeric;
  v_je uuid; v_id uuid; n int := 0; t_pay numeric := 0; t_wht numeric := 0; v_method text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  perform paying_account(cid, p_account);
  v_method := method_of(p_account);
  v_no := next_number(cid, 'BPB', 'BPB-');
  insert into bill_payment_batches (company_id, number, pay_date, account_id, reference) values (cid, v_no, p_date, p_account, p_reference) returning id into v_batch;
  for x in select * from jsonb_array_elements(coalesce(p_items, '[]')) loop
    v_pay := round(coalesce((x->>'amount')::numeric, 0), 2); v_wht := round(coalesce((x->>'wht')::numeric, 0), 2);
    continue when v_pay + v_wht <= 0;
    if v_pay < 0 or v_wht < 0 then raise exception 'Amounts cannot be negative'; end if;
    select * into b from bills where id = (x->>'bill_id')::uuid and company_id = cid for update;
    if not found then raise exception 'Bill not found'; end if;
    if b.status <> 'posted' then raise exception '% is not open for payment', coalesce(b.number, 'A draft bill'); end if;
    if v_pay + v_wht > b.total - b.amount_paid then raise exception '% has only % left to pay', b.number, b.total - b.amount_paid; end if;
    v_rate := case when b.currency = 'GHS' then 1 else coalesce(nullif((x->>'rate')::numeric, 0), b.exchange_rate) end;
    g_bank := round(v_pay * v_rate, 2); g_wht := round(v_wht * v_rate, 2); g_ap := round((v_pay + v_wht) * b.exchange_rate, 2);
    insert into bill_payments (company_id, bill_id, payment_date, amount, method, reference, exchange_rate, account_id, batch_id, wht_amount)
    values (cid, b.id, p_date, v_pay + v_wht, v_method, coalesce(p_reference, v_no), v_rate, p_account, v_batch, v_wht) returning id into v_id;
    v_je := post_journal(cid, p_date, 'Payment to supplier for ' || b.number || ' (' || v_no || ')' || case when v_wht > 0 then ', WHT withheld' else '' end,
      jsonb_build_array(jl(acct(cid, 'ap'), g_ap, 0), jl(p_account, 0, g_bank),
        case when g_wht > 0 then jl(acct(cid, 'wht_payable'), 0, g_wht) else jl(p_account, 0, 0) end,
        jl(acct(cid, 'fx'), greatest(g_bank + g_wht - g_ap, 0), greatest(g_ap - g_bank - g_wht, 0))), 'bill_payment', v_id);
    update bill_payments set journal_entry_id = v_je where id = v_id;
    update bills set amount_paid = amount_paid + v_pay + v_wht, status = case when amount_paid + v_pay + v_wht >= total then 'paid' else 'posted' end where id = b.id;
    n := n + 1; t_pay := t_pay + g_bank; t_wht := t_wht + g_wht;
  end loop;
  if n = 0 then raise exception 'Tick at least one bill and enter what to pay'; end if;
  update bill_payment_batches set total_paid = t_pay, total_wht = t_wht, bills = n where id = v_batch;
  return v_batch;
end $$;

-- ---------------------------------------------------------------- 4. Bank feed: imported statement lines and rules
create table if not exists public.bank_rules (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  contains text not null,                      -- words in the bank's description, e.g. "ECG" or "SALARY"
  direction text not null default 'any' check (direction in ('in','out','any')),
  counter_account_id uuid not null references public.accounts(id),
  payee text,
  project_id uuid references public.projects(id) on delete set null,
  priority int not null default 100,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.bank_rules enable row level security;
drop policy if exists "finance manages rules" on public.bank_rules;
create policy "finance manages rules" on public.bank_rules for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

create table if not exists public.bank_feed_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id),
  txn_date date not null,
  description text not null,
  reference text,
  amount numeric(14,2) not null check (amount <> 0),   -- positive = money in, negative = money out
  fingerprint text not null,
  status text not null default 'new' check (status in ('new','done','ignored')),
  done_as text,                                        -- what it became: payment, bill payment, money in/out, matched
  done_ref text,
  batch text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  unique (company_id, account_id, fingerprint)
);
create index if not exists bank_feed_open on public.bank_feed_lines (company_id, account_id, status, txn_date);
alter table public.bank_feed_lines enable row level security;
drop policy if exists "finance manages feed" on public.bank_feed_lines;
create policy "finance manages feed" on public.bank_feed_lines for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

-- Upload: lines already imported (same date, amount, description and reference) are skipped.
create or replace function public.import_bank_lines(cid uuid, p_account uuid, p_lines jsonb, p_batch text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare x jsonb; n_new int := 0; n_dup int := 0; v_fp text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  perform paying_account(cid, p_account);
  for x in select * from jsonb_array_elements(coalesce(p_lines, '[]')) loop
    continue when coalesce((x->>'amount')::numeric, 0) = 0 or nullif(x->>'date', '') is null;
    v_fp := md5((x->>'date') || '|' || round((x->>'amount')::numeric, 2)::text || '|' || lower(trim(coalesce(x->>'description', ''))) || '|' || lower(trim(coalesce(x->>'reference', ''))));
    insert into bank_feed_lines (company_id, account_id, txn_date, description, reference, amount, fingerprint, batch)
    values (cid, p_account, (x->>'date')::date, left(coalesce(nullif(trim(x->>'description'), ''), '(no description)'), 400), nullif(trim(x->>'reference'), ''),
            round((x->>'amount')::numeric, 2), v_fp, p_batch)
    on conflict (company_id, account_id, fingerprint) do nothing;
    if found then n_new := n_new + 1; else n_dup := n_dup + 1; end if;
  end loop;
  return jsonb_build_object('added', n_new, 'skipped', n_dup);
end $$;

-- What each open line could be: an existing entry in the books with the same amount within 5 days, an open invoice or
-- bill of that amount (or whose number is in the description), or a rule.
create or replace function public.bank_feed_suggestions(cid uuid, p_account uuid)
returns table (line_id uuid, kind text, target_id uuid, label text, amount numeric, counter_account_id uuid, payee text, project_id uuid)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with open as (select * from bank_feed_lines f where f.company_id = cid and f.account_id = p_account and f.status = 'new'),
  booked as (   -- entries already in the books on this account and not yet matched to a line
    select je.id, je.entry_date, je.memo, sum(l.debit - l.credit) amt
      from journal_entries je join journal_lines l on l.entry_id = je.id
     where je.company_id = cid and l.account_id = p_account and l.reconciliation_id is null
       and not exists (select 1 from bank_feed_lines f where f.company_id = cid and f.done_ref = je.id::text)
     group by je.id, je.entry_date, je.memo)
  select o.id, 'match', b.id, 'Already in the books: ' || b.memo, b.amt, null::uuid, null::text, null::uuid
    from open o join booked b on b.amt = o.amount and abs(b.entry_date - o.txn_date) <= 5
  union all
  select o.id, 'invoice', i.id, 'Payment of ' || i.number || ' — ' || c.name, i.total - i.amount_paid - i.amount_credited, null, c.name, i.project_id
    from open o join invoices i on i.company_id = cid and i.status = 'posted' and i.currency = 'GHS'
    join customers c on c.id = i.customer_id
   where o.amount > 0 and (i.total - i.amount_paid - i.amount_credited = o.amount or (i.number is not null and o.description || ' ' || coalesce(o.reference, '') ilike '%' || i.number || '%')
        or (i.total - i.amount_paid - i.amount_credited - coalesce(i.wht_amount, 0) = o.amount and coalesce(i.wht_amount, 0) > 0))
  union all
  select o.id, 'bill', b.id, 'Pay ' || b.number || ' — ' || s.name, b.total - b.amount_paid, null, s.name, null
    from open o join bills b on b.company_id = cid and b.status = 'posted' and b.currency = 'GHS'
    join suppliers s on s.id = b.supplier_id
   where o.amount < 0 and (b.total - b.amount_paid = -o.amount or (b.number is not null and o.description ilike '%' || b.number || '%')
        or (b.supplier_ref is not null and length(b.supplier_ref) >= 3 and o.description || ' ' || coalesce(o.reference, '') ilike '%' || b.supplier_ref || '%'))
  union all
  select distinct on (o.id) o.id, 'rule', r.id, r.name || ' → ' || a.code || ' ' || a.name, abs(o.amount), r.counter_account_id, r.payee, r.project_id
    from open o join bank_rules r on r.company_id = cid and r.active and o.description || ' ' || coalesce(o.reference, '') ilike '%' || r.contains || '%'
         and (r.direction = 'any' or (r.direction = 'in' and o.amount > 0) or (r.direction = 'out' and o.amount < 0))
    join accounts a on a.id = r.counter_account_id
   order by 1, 2;
end $$;

-- Close a line: matched to an entry already in the books, or after the app posted it (payment, bill payment, money in/out).
create or replace function public.bank_line_done(p_line uuid, p_as text, p_ref text default null) returns void
language plpgsql security definer set search_path = public as $$
declare f bank_feed_lines;
begin
  select * into f from bank_feed_lines where id = p_line for update;
  if not found then raise exception 'Line not found'; end if;
  perform require_member(f.company_id, array['owner','admin','accountant']);
  update bank_feed_lines set status = case when p_as = 'ignored' then 'ignored' when p_as = 'reopen' then 'new' else 'done' end,
    done_as = case when p_as in ('ignored','reopen') then null else p_as end, done_ref = case when p_as in ('ignored','reopen') then null else p_ref end where id = p_line;
end $$;

-- ---------------------------------------------------------------- 5. Reports
-- Cash flow (direct): every movement on cash, MoMo and bank accounts, sorted by what was on the other side.
create or replace function public.cash_flow(cid uuid, p_from date, p_to date)
returns table (section text, line text, amount numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with banks as (select id from accounts where company_id = cid and is_bank),
  ent as (select distinct l.entry_id from journal_lines l join journal_entries e on e.id = l.entry_id
           where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date between p_from and p_to),
  other as (select a.*, l.credit - l.debit amt from journal_lines l join accounts a on a.id = l.account_id
             where l.entry_id in (select entry_id from ent) and l.account_id not in (select id from banks)),
  classed as (
    select case
             when o.system_key in ('fa_cost','fa_accdep','disposal') or (o.type = 'asset' and o.system_key is null and o.code between '1500' and '1999') then '2 Investing'
             when o.type = 'equity' or o.code = '2400' or (o.type = 'liability' and o.system_key is null and o.name ilike '%loan%') then '3 Financing'
             else '1 Operating' end sec,
           case
             when o.system_key = 'ar' then 'Received from customers'
             when o.system_key = 'customer_deposits' then 'Customer deposits'
             when o.system_key in ('ap','grni') then 'Paid to suppliers'
             when o.system_key in ('net_pay','salaries','paye','ssnit1','tier2','payroll_deductions','employer_ssnit') then 'Salaries, PAYE and pensions'
             when o.system_key in ('vat_out','nhil_out','getf_out','vat_in','nhil_in','getf_in','wht_payable','wht_receivable') then 'VAT, levies and withholding tax'
             when o.system_key in ('staff_advances','staff_loans','reimburse') then 'Staff advances, loans and claims'
             when o.type = 'income' then 'Other income received'
             when o.type = 'expense' then o.code || ' ' || o.name
             else o.code || ' ' || o.name end ln,
           o.amt from other o)
  select c.sec, c.ln, round(sum(c.amt), 2) from classed c group by c.sec, c.ln having round(sum(c.amt), 2) <> 0
  union all
  select '0 Opening', 'Cash and bank at ' || to_char(p_from, 'DD Mon YYYY'), round(coalesce(sum(l.debit - l.credit), 0), 2)
    from journal_lines l join journal_entries e on e.id = l.entry_id where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date < p_from
  union all
  select '9 Closing', 'Cash and bank at ' || to_char(p_to, 'DD Mon YYYY'), round(coalesce(sum(l.debit - l.credit), 0), 2)
    from journal_lines l join journal_entries e on e.id = l.entry_id where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date <= p_to
  order by 1, 3;
end $$;

-- Sales by customer or by product/service, in GH₵, net of credit notes.
create or replace function public.sales_by(cid uuid, p_from date, p_to date, p_by text default 'customer')
returns table (name text, docs bigint, qty numeric, net numeric, tax numeric, total numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  if p_by = 'product' then
    return query
    select coalesce(p.name, '(services and other lines)'), count(distinct i.id), sum(l.qty), round(sum(l.qty * l.unit_price * i.exchange_rate), 2), 0::numeric, round(sum(l.qty * l.unit_price * i.exchange_rate), 2)
      from invoices i join invoice_lines l on l.invoice_id = i.id left join products p on p.id = l.product_id
     where i.company_id = cid and i.status in ('posted','paid') and i.invoice_date between p_from and p_to
     group by coalesce(p.name, '(services and other lines)') order by 4 desc;
  else
    return query
    with s as (
      select i.customer_id, count(*) n, sum(i.subtotal * i.exchange_rate) sub, sum((i.total - i.subtotal) * i.exchange_rate) tx
        from invoices i where i.company_id = cid and i.status in ('posted','paid') and i.invoice_date between p_from and p_to group by i.customer_id),
    cr as (
      select n.customer_id, sum(n.subtotal * coalesce(n.exchange_rate, 1)) sub, sum((n.total - n.subtotal) * coalesce(n.exchange_rate, 1)) tx
        from credit_notes n where n.company_id = cid and n.status = 'posted' and n.credit_date between p_from and p_to group by n.customer_id)
    select c.name, coalesce(s.n, 0), null::numeric, round(coalesce(s.sub, 0) - coalesce(cr.sub, 0), 2), round(coalesce(s.tx, 0) - coalesce(cr.tx, 0), 2),
           round(coalesce(s.sub, 0) + coalesce(s.tx, 0) - coalesce(cr.sub, 0) - coalesce(cr.tx, 0), 2)
      from customers c left join s on s.customer_id = c.id left join cr on cr.customer_id = c.id
     where c.company_id = cid and (s.customer_id is not null or cr.customer_id is not null)
     order by 4 desc;
  end if;
end $$;

-- Profit by project (from the ledger lines tagged to each project) or by customer (their projects plus invoices without a project).
create or replace function public.profit_by(cid uuid, p_from date, p_to date, p_by text default 'project')
returns table (name text, detail text, income numeric, costs numeric, profit numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  if p_by = 'customer' then
    return query
    with pl as (
      select pr.customer_id, sum(case when a.type = 'income' then l.credit - l.debit else 0 end) inc, sum(case when a.type = 'expense' then l.debit - l.credit else 0 end) cst
        from journal_lines l join journal_entries e on e.id = l.entry_id join accounts a on a.id = l.account_id join projects pr on pr.id = l.project_id
       where l.company_id = cid and e.entry_date between p_from and p_to group by pr.customer_id),
    loose as (   -- invoices with no project: their income only
      select i.customer_id, sum(i.subtotal * i.exchange_rate) inc from invoices i
       where i.company_id = cid and i.project_id is null and i.status in ('posted','paid') and i.invoice_date between p_from and p_to group by i.customer_id)
    select coalesce(c.name, '(no customer)'), (select count(*) from projects x where x.customer_id = c.id and not x.is_template)::text || ' project(s)',
           round(coalesce(pl.inc, 0) + coalesce(loose.inc, 0), 2), round(coalesce(pl.cst, 0), 2), round(coalesce(pl.inc, 0) + coalesce(loose.inc, 0) - coalesce(pl.cst, 0), 2)
      from pl full join loose on loose.customer_id = pl.customer_id left join customers c on c.id = coalesce(pl.customer_id, loose.customer_id)
     order by 5 desc;
  else
    return query
    select coalesce(p.number || ' ', '') || p.name, coalesce(c.name, 'Internal'),
           round(sum(case when a.type = 'income' then l.credit - l.debit else 0 end), 2), round(sum(case when a.type = 'expense' then l.debit - l.credit else 0 end), 2),
           round(sum(case when a.type = 'income' then l.credit - l.debit when a.type = 'expense' then l.credit - l.debit else 0 end), 2)
      from journal_lines l join journal_entries e on e.id = l.entry_id join accounts a on a.id = l.account_id join projects p on p.id = l.project_id
      left join customers c on c.id = p.customer_id
     where l.company_id = cid and e.entry_date between p_from and p_to and a.type in ('income','expense')
     group by p.id, p.number, p.name, c.name order by 5 desc;
  end if;
end $$;

-- ---------------------------------------------------------------- 6. New companies, numbering names, audit, voiding rules
create or replace function public.company_seed_v35() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform seed_accounts_v35(new.id); return null; end $$;
drop trigger if exists companies_seed_v35 on public.companies;
create trigger companies_seed_v35 after insert on public.companies for each row execute function public.company_seed_v35();

do $$ declare t text; begin
  foreach t in array array['customer_receipts','bill_payment_batches','bank_rules'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- ======================================== Part C3: v3.6 Bank of Ghana rates and month-end revaluation
-- Asnys ERP v3.6 — Bank of Ghana exchange rates, filled in automatically, and month-end revaluation
--   1. Every working day the BoG interbank rates (buying, mid, selling) are fetched by the asnys-m365 edge function
--      (from a rates service that republishes the BoG table, with the BoG web page as the backup) and kept as history.
--   2. Each company's currency list takes the BoG mid-rate; new documents and payments fill in the BoG mid-rate for
--      their date (staff can still change it).
--   3. Month-end revaluation restates unpaid foreign-currency invoices and bills at the month-end BoG rate; the
--      unrealised gain or loss is posted and reversed on the first day of the next month.
-- The books stay in cedis. Run after 0023. Safe to run twice.

-- ---------------------------------------------------------------- 1. Rate history (the same BoG rates for every company)
create table if not exists public.fx_rates (
  rate_date date not null,
  code text not null check (code ~ '^[A-Z]{3}$'),
  buying numeric(14,6),
  mid numeric(14,6) not null check (mid > 0),
  selling numeric(14,6),
  source text not null default 'BoG',
  fetched_at timestamptz not null default now(),
  primary key (rate_date, code)
);
alter table public.fx_rates enable row level security;
drop policy if exists "signed in read rates" on public.fx_rates;
create policy "signed in read rates" on public.fx_rates for select using (auth.uid() is not null);

-- One row of settings for the daily fetch. The shared secret is only readable by the database and the edge function.
create table if not exists public.fx_settings (
  id int primary key default 1 check (id = 1),
  enabled boolean not null default true,
  function_url text,
  secret text not null default (md5(gen_random_uuid()::text || clock_timestamp()::text) || md5(gen_random_uuid()::text)),
  last_run_at timestamptz,
  last_status text,
  last_rate_date date,
  last_alert date
);
insert into public.fx_settings (id) values (1) on conflict do nothing;
alter table public.fx_settings enable row level security;   -- no policies: reached only through the functions below

alter table public.currencies add column if not exists rate_date date;
alter table public.currencies add column if not exists rate_source text;
alter table public.currencies add column if not exists auto_rate boolean not null default true;

-- The rate for a currency on a day: the latest BoG mid-rate on or before that day (weekends and holidays use Friday's).
create or replace function public.fx_rate(cid uuid, p_code text, p_date date default current_date)
returns jsonb language sql stable security definer set search_path = public as $$
  select case when p_code = 'GHS' then jsonb_build_object('rate', 1, 'rate_date', p_date, 'source', 'GHS')
         else (select jsonb_build_object('rate', r.mid, 'buying', r.buying, 'selling', r.selling, 'rate_date', r.rate_date, 'source', r.source)
                 from fx_rates r where r.code = upper(p_code) and r.rate_date <= coalesce(p_date, current_date)
                order by r.rate_date desc limit 1) end
   where is_member(cid);
$$;

-- Settings screen: the last fetch and today's table.
create or replace function public.fx_status(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s fx_settings;
begin
  perform require_member(cid);
  select * into s from fx_settings where id = 1;
  return jsonb_build_object('enabled', s.enabled, 'function_url_set', s.function_url is not null, 'last_run_at', s.last_run_at, 'last_status', s.last_status,
    'last_rate_date', s.last_rate_date, 'pg_net', to_regnamespace('net') is not null,
    'latest', coalesce((select jsonb_agg(jsonb_build_object('code', r.code, 'buying', r.buying, 'mid', r.mid, 'selling', r.selling, 'rate_date', r.rate_date, 'source', r.source) order by r.code)
                 from fx_rates r where r.rate_date = (select max(rate_date) from fx_rates)), '[]'));
end $$;

-- Owners point the daily fetch at their asnys-m365 function (any company owner of this installation may set it).
create or replace function public.fx_configure(cid uuid, p_function_url text, p_enabled boolean default true) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  if p_function_url !~ '^https://.+/functions/v1/asnys-m365$' then raise exception 'The address should end in /functions/v1/asnys-m365'; end if;
  update fx_settings set function_url = p_function_url, enabled = p_enabled where id = 1;
end $$;

-- Ask the edge function to fetch today's table.
create or replace function public.start_fx_fetch() returns bigint
language plpgsql security definer set search_path = public as $$
declare s fx_settings; v_url text;
begin
  select * into s from fx_settings where id = 1;
  if not s.enabled then return null; end if;
  v_url := coalesce(s.function_url, (select function_url from company_email where function_url like '%/functions/v1/asnys-m365' limit 1));
  if v_url is null then return null; end if;
  update fx_settings set last_run_at = now(), last_status = 'started' where id = 1;
  return http_post_safe(v_url, jsonb_build_object('action', 'fx'), jsonb_build_object('Content-Type', 'application/json', 'x-asnys-fx', s.secret));
end $$;
revoke execute on function public.start_fx_fetch() from public, anon, authenticated;

create or replace function public.fx_fetch_now(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if not has_role(cid, array['owner','admin','accountant']) then raise exception 'Only Finance can fetch rates'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  v := start_fx_fetch();
  if v is null then raise exception 'Set the asnys-m365 function address under Foreign currencies first'; end if;
  return 'started';
end $$;

-- Used only by the edge function (service key + the shared secret): save the table and update every company's rates.
create or replace function public.fx_save(p_secret text, p_rows jsonb, p_source text, p_status text default 'ok') returns int
language plpgsql security definer set search_path = public as $$
declare x jsonb; n int := 0; v_date date; c record;
begin
  if not exists (select 1 from fx_settings where id = 1 and secret = p_secret) then raise exception 'Not allowed'; end if;
  for x in select * from jsonb_array_elements(coalesce(p_rows, '[]')) loop
    continue when coalesce((x->>'mid')::numeric, 0) <= 0 or coalesce(x->>'code', '') !~ '^[A-Z]{3}$' or (x->>'code') = 'GHS';
    insert into fx_rates (rate_date, code, buying, mid, selling, source)
    values ((x->>'date')::date, x->>'code', nullif(x->>'buying', '')::numeric, (x->>'mid')::numeric, nullif(x->>'selling', '')::numeric, coalesce(p_source, 'BoG'))
    on conflict (rate_date, code) do update set buying = excluded.buying, mid = excluded.mid, selling = excluded.selling, source = excluded.source, fetched_at = now();
    n := n + 1; v_date := greatest(v_date, (x->>'date')::date);
  end loop;
  update fx_settings set last_status = case when n > 0 then 'ok' else coalesce(p_status, 'no rates found') end,
    last_rate_date = coalesce(v_date, last_rate_date), last_run_at = now() where id = 1;
  if n > 0 then
    update currencies cu set rate = r.mid, rate_date = r.rate_date, rate_source = r.source, updated_at = now()
      from (select distinct on (code) code, mid, rate_date, source from fx_rates order by code, rate_date desc) r
     where cu.code = r.code and cu.auto_rate;
  elsif (select coalesce(last_alert, '1900-01-01') < current_date from fx_settings where id = 1) then
    -- Tell Finance once a day that the rates could not be fetched; the last rates stay in use.
    update fx_settings set last_alert = current_date where id = 1;
    for c in select distinct company_id from currencies loop
      perform notify(c.company_id, array['accountant'], null, 'fx_failed', 'Bank of Ghana rates could not be fetched today',
        'The last rates stay in use. Check the rate on each foreign-currency document, or type it in. ' || coalesce(p_status, ''), '/settings', true);
    end loop;
  end if;
  return n;
end $$;
revoke execute on function public.fx_save(text, jsonb, text, text) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then grant execute on function public.fx_save(text, jsonb, text, text) to service_role; end if;
end $$;

-- Daily at 15:00 and 17:00 Ghana time (UTC) on working days, if pg_cron is on.
do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    begin perform cron.unschedule('asnys-bog-rates'); exception when others then null; end;
    perform cron.schedule('asnys-bog-rates', '0 15,17 * * 1-5', 'select public.start_fx_fetch()');
  end if;
exception when others then null;
end $$;

-- ---------------------------------------------------------------- 2. Month-end revaluation of unpaid foreign-currency invoices and bills
create table if not exists public.fx_revaluations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  reval_date date not null,
  ar_change numeric(14,2) not null default 0,     -- + = receivables worth more in cedis (gain)
  ap_change numeric(14,2) not null default 0,     -- + = payables cost more in cedis (loss)
  detail jsonb not null default '[]',
  journal_entry_id uuid references public.journal_entries(id),
  reversal_entry_id uuid references public.journal_entries(id),
  status text not null default 'posted' check (status in ('posted','undone')),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create unique index if not exists fx_revaluations_one_per_date on public.fx_revaluations (company_id, reval_date) where status = 'posted';
alter table public.fx_revaluations enable row level security;
drop policy if exists "finance reads revaluations" on public.fx_revaluations;
create policy "finance reads revaluations" on public.fx_revaluations for select using (has_role(company_id, array['owner','admin','accountant']));

-- What revaluing at a date would do (nothing is posted).
create or replace function public.fx_revalue_preview(cid uuid, p_date date)
returns table (kind text, doc_id uuid, number text, party text, currency text, open_amount numeric, booked_rate numeric, new_rate numeric, change numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with r as (select distinct on (code) code, mid from fx_rates where rate_date <= p_date order by code, rate_date desc)
  select 'invoice', i.id, i.number, c.name, i.currency, round(i.total - i.amount_paid - i.amount_credited, 2), i.exchange_rate, r.mid,
         round((i.total - i.amount_paid - i.amount_credited) * (r.mid - i.exchange_rate), 2)
    from invoices i join customers c on c.id = i.customer_id join r on r.code = i.currency
   where i.company_id = cid and i.currency <> 'GHS' and i.status = 'posted' and i.invoice_date <= p_date and i.total - i.amount_paid - i.amount_credited > 0
  union all
  select 'bill', b.id, b.number, s.name, b.currency, round(b.total - b.amount_paid, 2), b.exchange_rate, r.mid,
         round((b.total - b.amount_paid) * (r.mid - b.exchange_rate), 2)
    from bills b join suppliers s on s.id = b.supplier_id join r on r.code = b.currency
   where b.company_id = cid and b.currency <> 'GHS' and b.status = 'posted' and b.bill_date <= p_date and b.total - b.amount_paid > 0
  order by 1, 3;
end $$;

-- Post it: one entry at the date, reversed the next day, so payments later still clear at each document's own rate.
create or replace function public.fx_revalue(cid uuid, p_date date) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_ar numeric; v_ap numeric; v_det jsonb; v_lines jsonb := '[]'; v_je uuid; v_rev uuid; v_id uuid; v_net numeric;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  if exists (select 1 from fx_revaluations where company_id = cid and reval_date = p_date and status = 'posted') then raise exception 'Already revalued at %. Undo that one first.', p_date; end if;
  select coalesce(sum(change) filter (where kind = 'invoice'), 0), coalesce(sum(change) filter (where kind = 'bill'), 0), coalesce(jsonb_agg(to_jsonb(p)), '[]')
    into v_ar, v_ap, v_det from fx_revalue_preview(cid, p_date) p;
  if v_ar = 0 and v_ap = 0 then raise exception 'Nothing to revalue: no unpaid foreign-currency invoices or bills, or no BoG rate on or before %', p_date; end if;
  -- Receivables up = gain; payables up = loss.
  if v_ar <> 0 then v_lines := v_lines || jl(acct(cid, 'ar'), greatest(v_ar, 0), greatest(-v_ar, 0)); end if;
  if v_ap <> 0 then v_lines := v_lines || jl(acct(cid, 'ap'), greatest(-v_ap, 0), greatest(v_ap, 0)); end if;
  v_net := v_ar - v_ap;
  if v_net <> 0 then v_lines := v_lines || jl(acct(cid, 'fx'), greatest(-v_net, 0), greatest(v_net, 0)); end if;
  insert into fx_revaluations (company_id, reval_date, ar_change, ap_change, detail) values (cid, p_date, v_ar, v_ap, v_det) returning id into v_id;
  v_je := post_journal(cid, p_date, 'Unrealised exchange gain/loss: foreign-currency invoices and bills restated at the BoG rate of ' || to_char(p_date, 'DD Mon YYYY'), v_lines, 'fx_reval', v_id);
  select jsonb_agg(jsonb_build_object('account_id', l->>'account_id', 'debit', l->>'credit', 'credit', l->>'debit')) into v_lines from jsonb_array_elements(v_lines) l;
  v_rev := post_journal(cid, p_date + 1, 'Reversal of the ' || to_char(p_date, 'DD Mon YYYY') || ' exchange revaluation', v_lines, 'fx_reval', v_id);
  update fx_revaluations set journal_entry_id = v_je, reversal_entry_id = v_rev where id = v_id;
  return v_id;
end $$;

create or replace function public.fx_revalue_undo(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r fx_revaluations; v_lines jsonb;
begin
  select * into r from fx_revaluations where id = p_id for update;
  if not found or r.status <> 'posted' then raise exception 'Revaluation not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant']);
  -- Cancel both entries with mirror entries (dated as the originals; the books must not be locked over those dates).
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit)) into v_lines from journal_lines l where l.entry_id = r.journal_entry_id;
  perform post_journal(r.company_id, r.reval_date, 'Undo exchange revaluation of ' || to_char(r.reval_date, 'DD Mon YYYY'), v_lines, 'fx_reval', r.id);
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit)) into v_lines from journal_lines l where l.entry_id = r.reversal_entry_id;
  perform post_journal(r.company_id, r.reval_date + 1, 'Undo reversal of exchange revaluation of ' || to_char(r.reval_date, 'DD Mon YYYY'), v_lines, 'fx_reval', r.id);
  update fx_revaluations set status = 'undone' where id = r.id;
end $$;

do $$ declare t text; begin
  foreach t in array array['fx_revaluations'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- ======================================== Part C4: v3.7 supplier onboarding, contracts, policies
-- Asnys ERP v3.7 — Gulfaco's notes of 18 Nov 2026
--   1. Supplier / subcontractor onboarding: type, Ghana Card, full bank and MoMo details, what they supply, documents
--      (business registration, incorporation, VAT, ISO, HSE and quality policies, tax exemption, BoG / foreign exchange,
--      others) with expiry, a requirements list per type, and approval by Finance.
--   2. Contracts: type (goods, works, services…), client sector, currency from the list; a draft contract can be started
--      from a tender before award; contract drafts kept as numbered versions; one contract or tender with several projects.
--   3. A purchase order's project can be changed (before goods are received or billed).
--   4. Policies: document / reference number generated from the company's numbering procedure; HSE policies and HR & Admin
--      compliance policies kept apart; "Other" with what it is.
-- Run after 0024. Safe to run twice.

-- ---------------------------------------------------------------- 1. Supplier onboarding
alter table public.suppliers add column if not exists supplier_type text not null default 'vendor';
alter table public.suppliers drop constraint if exists suppliers_supplier_type_check;
alter table public.suppliers add constraint suppliers_supplier_type_check check (supplier_type in ('vendor','subcontractor','both'));
alter table public.suppliers add column if not exists ghana_card text;
alter table public.suppliers add column if not exists products_services text;          -- what they supply or do
alter table public.suppliers add column if not exists bank_branch text;
alter table public.suppliers add column if not exists bank_account_name text;
alter table public.suppliers add column if not exists bank_swift text;
alter table public.suppliers add column if not exists bank_address text;
alter table public.suppliers add column if not exists momo_name text;
alter table public.suppliers add column if not exists momo_network text;
alter table public.suppliers drop constraint if exists suppliers_momo_network_check;
alter table public.suppliers add constraint suppliers_momo_network_check check (momo_network is null or momo_network in ('mtn','telecel','airteltigo','other'));
-- Suppliers already in use before onboarding existed count as approved (only the first time this runs).
do $$ begin
  if not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'suppliers' and column_name = 'onboarding_status') then
    alter table public.suppliers add column onboarding_status text not null default 'pending';
    update public.suppliers set onboarding_status = 'approved';
  end if;
end $$;
alter table public.suppliers drop constraint if exists suppliers_onboarding_status_check;
alter table public.suppliers add constraint suppliers_onboarding_status_check check (onboarding_status in ('pending','approved','rejected','suspended'));
alter table public.suppliers add column if not exists onboarded_at timestamptz;
alter table public.suppliers add column if not exists onboarded_by uuid;
alter table public.suppliers add column if not exists onboarding_note text;

create table if not exists public.supplier_documents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_id uuid not null references public.suppliers(id) on delete cascade,
  doc_type text not null check (doc_type in ('business_registration','incorporation','vat_certificate','tax_clearance','iso_certificate','hse_policy',
                                             'quality_policy','tax_exemption','bog_fx','ssnit','insurance','other')),
  doc_label text,                    -- for "other": what it is
  ref_no text,
  issued_on date,
  expires_on date,
  name text,
  storage_path text,
  status text not null default 'submitted' check (status in ('submitted','verified','rejected')),
  verified_by uuid,
  verified_at timestamptz,
  note text,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists supplier_documents_supplier on public.supplier_documents (supplier_id);
alter table public.supplier_documents enable row level security;
drop policy if exists "members read supplier docs" on public.supplier_documents;
create policy "members read supplier docs" on public.supplier_documents for select using (is_member(company_id));
drop policy if exists "buyers add supplier docs" on public.supplier_documents;
create policy "buyers add supplier docs" on public.supplier_documents for insert with check (has_role(company_id, array['owner','admin','accountant','store','project_manager']));
drop policy if exists "finance edits supplier docs" on public.supplier_documents;
create policy "finance edits supplier docs" on public.supplier_documents for update using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));
drop policy if exists "finance removes supplier docs" on public.supplier_documents;
create policy "finance removes supplier docs" on public.supplier_documents for delete using (has_role(company_id, array['owner','admin','accountant']) or (uploaded_by = auth.uid() and status = 'submitted'));

-- Which documents each kind of supplier must give (Settings → Supplier onboarding).
create table if not exists public.onboarding_requirements (
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_type text not null check (supplier_type in ('vendor','subcontractor')),
  doc_type text not null,
  required boolean not null default true,
  primary key (company_id, supplier_type, doc_type)
);
alter table public.onboarding_requirements enable row level security;
drop policy if exists "members read requirements" on public.onboarding_requirements;
create policy "members read requirements" on public.onboarding_requirements for select using (is_member(company_id));
drop policy if exists "finance sets requirements" on public.onboarding_requirements;
create policy "finance sets requirements" on public.onboarding_requirements for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

create or replace function public.seed_onboarding(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into onboarding_requirements (company_id, supplier_type, doc_type, required)
  select cid, t, d, r from (values
    ('vendor','business_registration',true),('vendor','incorporation',true),('vendor','vat_certificate',true),('vendor','iso_certificate',false),
    ('vendor','hse_policy',false),('vendor','quality_policy',false),('vendor','tax_exemption',false),('vendor','bog_fx',false),
    ('subcontractor','business_registration',true),('subcontractor','incorporation',true),('subcontractor','vat_certificate',false),('subcontractor','iso_certificate',false),
    ('subcontractor','hse_policy',true),('subcontractor','quality_policy',true),('subcontractor','tax_exemption',false),('subcontractor','bog_fx',false)) v(t, d, r)
  on conflict do nothing;
$$;
select public.seed_onboarding(id) from public.companies;

-- What is still missing for a supplier (required documents not uploaded, or rejected or expired).
create or replace function public.supplier_missing_docs(p_supplier uuid) returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(r.doc_type order by r.doc_type), '{}')
    from suppliers s join onboarding_requirements r on r.company_id = s.company_id and r.required
         and (r.supplier_type = s.supplier_type or (s.supplier_type = 'both'))
   where s.id = p_supplier
     and not exists (select 1 from supplier_documents d where d.supplier_id = s.id and d.doc_type = r.doc_type
                      and d.status <> 'rejected' and (d.expires_on is null or d.expires_on >= current_date));
$$;

create or replace function public.decide_supplier(p_supplier uuid, p_status text, p_note text default null, p_override boolean default false) returns void
language plpgsql security definer set search_path = public as $$
declare s suppliers; v_missing text[];
begin
  select * into s from suppliers where id = p_supplier for update;
  if not found then raise exception 'Supplier not found'; end if;
  if not has_role(s.company_id, array['owner','admin','accountant']) then raise exception 'Only Finance or an admin approves suppliers'; end if;
  if p_status not in ('approved','rejected','suspended','pending') then raise exception 'Unknown status'; end if;
  if p_status = 'approved' then
    v_missing := supplier_missing_docs(p_supplier);
    if cardinality(v_missing) > 0 and not p_override then
      raise exception 'Still missing: %. Upload them, or approve anyway with a note.', replace(array_to_string(v_missing, ', '), '_', ' ');
    end if;
    if cardinality(v_missing) > 0 and coalesce(trim(p_note), '') = '' then raise exception 'Say why it is approved without every document'; end if;
  end if;
  if p_status in ('rejected','suspended') and coalesce(trim(p_note), '') = '' then raise exception 'Give the reason'; end if;
  update suppliers set onboarding_status = p_status, onboarded_at = now(), onboarded_by = auth.uid(), onboarding_note = p_note where id = p_supplier;
  update supplier_documents set status = 'verified', verified_by = auth.uid(), verified_at = now() where supplier_id = p_supplier and status = 'submitted' and p_status = 'approved';
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (s.company_id, 'supplier.' || p_status, 'suppliers', s.id, jsonb_build_object('supplier', s.name, 'note', p_note, 'missing', v_missing));
end $$;

-- Reminders: supplier documents that expire within 30 days (once a week per document).
alter table public.supplier_documents add column if not exists reminded_on date;
create or replace function public.run_supplier_doc_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare d record; n int := 0;
begin
  for d in select sd.*, s.name supplier from supplier_documents sd join suppliers s on s.id = sd.supplier_id
            where sd.expires_on is not null and sd.expires_on <= current_date + 30 and sd.status <> 'rejected' and s.onboarding_status = 'approved'
              and (sd.reminded_on is null or sd.reminded_on < current_date - 7) loop
    perform notify(d.company_id, array['accountant','store'], null, 'supplier_doc_expiry',
      d.supplier || ': ' || replace(d.doc_type, '_', ' ') || case when d.expires_on < current_date then ' has expired' else ' expires ' || to_char(d.expires_on, 'DD Mon YYYY') end,
      'Ask the supplier for the renewed document and upload it on their page.', '/suppliers/' || d.supplier_id, true);
    update supplier_documents set reminded_on = current_date where id = d.id;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_supplier_doc_reminders() from public, anon, authenticated;
create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_integration_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_supplier_doc_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 2. Contracts: type, sector, drafts, several projects
alter table public.contracts add column if not exists contract_type text;
alter table public.contracts drop constraint if exists contracts_contract_type_check;
alter table public.contracts add constraint contracts_contract_type_check check (contract_type is null or contract_type in ('goods','works','services','goods_works','consultancy','other'));
alter table public.contracts add column if not exists sector text;
alter table public.contracts drop constraint if exists contracts_sector_check;
alter table public.contracts add constraint contracts_sector_check check (sector is null or sector in ('oil_gas','power_energy','mining','manufacturing','construction','government','telecom','other'));
alter table public.tenders add column if not exists contract_type text;
alter table public.tenders add column if not exists sector text;
alter table public.customers add column if not exists sector text;

alter table public.contract_files drop constraint if exists contract_files_kind_check;
alter table public.contract_files add constraint contract_files_kind_check check (kind in ('draft','signed_contract','variation','security','correspondence','other'));
alter table public.contract_files add column if not exists version int;
alter table public.contract_files add column if not exists note text;
-- Drafts are numbered Draft 1, 2, 3… per contract.
create or replace function public.contract_file_version() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.kind = 'draft' and new.version is null then
    select coalesce(max(version), 0) + 1 into new.version from contract_files where contract_id = new.contract_id and kind = 'draft';
  end if;
  return new;
end $$;
drop trigger if exists contract_files_version on public.contract_files;
create trigger contract_files_version before insert on public.contract_files for each row execute function public.contract_file_version();

-- A tender's contract can be started as a draft before award; on award the draft becomes the active contract.
create or replace function public.contract_from_tender(p_tender uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders; v uuid; pj uuid; c contracts;
begin
  select * into t from tenders where id = p_tender;
  if not found then raise exception 'Tender not found'; end if;
  pj := coalesce(t.project_id, (select id from projects where tender_id = t.id order by created_at limit 1));
  select * into c from contracts where tender_id = p_tender;
  if found then
    if t.status = 'awarded' and c.status = 'draft' then
      update contracts set status = 'active', value = coalesce(t.awarded_value, value), their_ref = coalesce(t.contract_ref, their_ref),
             signed_on = coalesce(t.contract_signed_on, signed_on), project_id = coalesce(project_id, pj),
             payment_terms_days = coalesce((to_jsonb(t)->>'payment_terms_days')::int, payment_terms_days),
             advance_pct = coalesce((to_jsonb(t)->>'advance_pct')::numeric, advance_pct), retention_pct = coalesce((to_jsonb(t)->>'retention_pct')::numeric, retention_pct)
       where id = c.id;
    end if;
    return c.id;
  end if;
  insert into contracts (company_id, title, kind, customer_id, counterparty, their_ref, project_id, tender_id, value, currency, signed_on, start_date, status,
                         payment_terms_days, advance_pct, retention_pct, owner_id, description, contract_type, sector)
  values (t.company_id, t.title, 'client', t.customer_id, t.client_name, t.contract_ref, pj, t.id,
          coalesce(t.awarded_value, t.submitted_value, t.est_value, 0), t.currency, t.contract_signed_on,
          coalesce((select start_date from projects where id = pj), t.contract_signed_on),
          case when t.status = 'awarded' then 'active' else 'draft' end,
          (to_jsonb(t)->>'payment_terms_days')::int, (to_jsonb(t)->>'advance_pct')::numeric, (to_jsonb(t)->>'retention_pct')::numeric,
          coalesce(t.bd_owner_id, auth.uid()),
          case when t.status = 'awarded' then 'Awarded on ' || t.number || coalesce(' (' || replace(t.award_type, '_', ' ') || ')', '') else 'Draft from ' || t.number end,
          t.contract_type, t.sector)
  returning id into v;
  return v;
end $$;

-- From the tender page: start (or open) the contract.
create or replace function public.start_contract_from_tender(p_tender uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders;
begin
  select * into t from tenders where id = p_tender;
  if not found then raise exception 'Tender not found'; end if;
  if not has_role(t.company_id, array['owner','admin','accountant','sales','project_manager']) then raise exception 'Your role cannot start contracts'; end if;
  if t.status in ('lost','no_bid','cancelled','voided') then raise exception 'This tender is %; it cannot have a contract', t.status; end if;
  return contract_from_tender(p_tender);
end $$;

-- Several projects under one contract or tender.
alter table public.projects add column if not exists contract_id uuid references public.contracts(id) on delete set null;
update public.projects p set contract_id = c.id from public.contracts c where c.project_id = p.id and p.contract_id is null;
update public.projects p set contract_id = c.id from public.contracts c where c.tender_id is not null and p.tender_id = c.tender_id and p.contract_id is null;

drop function if exists public.register_project_from_tender(uuid, text, uuid, uuid, date, date, text, uuid);
create or replace function public.register_project_from_tender(p_tender uuid, p_name text, p_cost_centre uuid, p_manager uuid, p_start date, p_end date,
  p_billing text default 'fixed_price', p_branch uuid default null, p_value numeric default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders; v uuid; v_value numeric; v_contract uuid;
begin
  select * into t from tenders where id = p_tender for update;
  if not found then raise exception 'Tender not found'; end if;
  if not has_role(t.company_id, array['owner','admin','accountant']) then raise exception 'Only Finance registers projects'; end if;
  if t.status <> 'awarded' then raise exception 'Only an awarded tender becomes a project'; end if;
  -- The first project takes the whole award unless a share is given; further projects take the share given.
  v_value := coalesce(p_value, case when t.project_id is null then t.awarded_value else 0 end);
  v_contract := (select id from contracts where tender_id = t.id);
  insert into projects (company_id, name, customer_id, status, start_date, end_date, manager_id, billing_type, contract_value, currency, location, description, hourly_rate, tender_id, contract_ref, contract_id)
  values (t.company_id, coalesce(nullif(trim(p_name), ''), t.title), t.customer_id, 'planned', p_start, p_end, p_manager, p_billing, v_value, 'GHS', t.location,
          'From ' || t.number || ' (' || replace(coalesce(t.award_type, 'award'), '_', ' ') || ' ' || coalesce(t.contract_ref, '') || ')', 0, t.id, t.contract_ref, v_contract)
  returning id into v;
  if t.project_id is null then
    perform set_config('sika.cycle','on', true);
    update tenders set project_id = v where id = p_tender;
    perform set_config('sika.cycle','off', true);
  end if;
  perform register_project(v, p_cost_centre, p_branch, t.contract_ref, v_value);
  return v;
end $$;

create or replace function public.link_project_contract(p_project uuid, p_contract uuid) returns void
language plpgsql security definer set search_path = public as $$
declare p projects; c contracts;
begin
  select * into p from projects where id = p_project;
  if not found then raise exception 'Project not found'; end if;
  if not has_role(p.company_id, array['owner','admin','accountant','project_manager']) then raise exception 'Your role cannot link projects to contracts'; end if;
  if p_contract is not null then
    select * into c from contracts where id = p_contract and company_id = p.company_id;
    if not found then raise exception 'Contract not found'; end if;
  end if;
  update projects set contract_id = p_contract where id = p_project;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (p.company_id, 'project.contract', 'projects', p.id, jsonb_build_object('contract', c.number));
end $$;

-- ---------------------------------------------------------------- 3. Move a purchase order to another project
create or replace function public.set_po_project(p_po uuid, p_project uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare po purchase_orders; v_old uuid;
begin
  select * into po from purchase_orders where id = p_po for update;
  if not found then raise exception 'Purchase order not found'; end if;
  if not has_role(po.company_id, array['owner','admin','accountant','store']) then raise exception 'Only Finance or the storekeeper can change the project of an order'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why the project is changing'; end if;
  if po.status in ('cancelled','closed') then raise exception 'This order is %', po.status; end if;
  if exists (select 1 from po_lines where po_id = p_po and (received_qty > 0 or billed_qty > 0)) then
    raise exception 'Goods have been received or billed on this order; their cost is already on the old project. Raise a new order for the other project instead.';
  end if;
  if p_project is not null and not exists (select 1 from projects where id = p_project and company_id = po.company_id and not is_template) then raise exception 'Project not found'; end if;
  v_old := po.project_id;
  perform set_config('sika.po', 'on', true);
  update purchase_orders set project_id = p_project where id = p_po;
  update po_lines set project_id = p_project where po_id = p_po and (project_id is not distinct from v_old or project_id is null);
  perform set_config('sika.po', 'off', true);
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (po.company_id, 'po.project_changed', 'purchase_orders', po.id, jsonb_build_object('number', po.number, 'from', (select number from projects where id = v_old),
          'to', (select number from projects where id = p_project), 'reason', trim(p_reason)));
end $$;

-- ---------------------------------------------------------------- 4. Policies: numbers from the numbering procedure; HSE vs HR & Admin
alter table public.hse_policies add column if not exists doc_number text;
alter table public.hse_policies add column if not exists area_other text;          -- when the area is "other": what it is
alter table public.hse_policies add column if not exists scope text not null default 'hse';
alter table public.hse_policies drop constraint if exists hse_policies_scope_check;
alter table public.hse_policies add constraint hse_policies_scope_check check (scope in ('hse','hr_admin'));
update public.hse_policies set scope = 'hr_admin' where scope = 'hse' and area in ('legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it');
alter table public.hse_policies drop constraint if exists hse_policies_area_check;
alter table public.hse_policies add constraint hse_policies_area_check
  check (area in ('safety','environment','quality','security','emergency','legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it','compliance','other'));

-- The numbering procedure: e.g. "{CO}-{AREA}-POL-{SEQ}" → GUF-HSE-POL-001. Tokens: {CO} company code, {AREA} area code,
-- {YYYY} year, {SEQ} running number (3 digits).
alter table public.companies add column if not exists policy_numbering text not null default '{CO}-{AREA}-POL-{SEQ}';
alter table public.companies add column if not exists policy_numbering_note text;

create or replace function public.policy_area_code(p_area text) returns text
language sql immutable as $$
  select case p_area when 'safety' then 'HSE' when 'environment' then 'ENV' when 'quality' then 'QA' when 'security' then 'SEC' when 'emergency' then 'ERP'
    when 'legal' then 'LEG' when 'tax_finance' then 'FIN' when 'labour' then 'HRA' when 'hr' then 'HR' when 'admin' then 'ADM' when 'it' then 'IT'
    when 'data_protection' then 'DPP' when 'anti_bribery' then 'ABC' when 'compliance' then 'CMP' else 'GEN' end;
$$;

create or replace function public.next_policy_number(cid uuid, p_area text) returns text
language plpgsql security definer set search_path = public as $$
declare f text; v int; code text := policy_area_code(p_area);
begin
  if not (is_hse(cid) or has_role(cid, array['owner','admin','hr'])) then raise exception 'Only HSE, HR or an admin numbers policies'; end if;
  select policy_numbering into f from companies where id = cid;
  insert into number_sequences (company_id, key, next_value) values (cid, 'POL-' || code, 2)
  on conflict (company_id, key) do update set next_value = number_sequences.next_value + 1
  returning next_value - 1 into v;
  return replace(replace(replace(replace(coalesce(f, '{CO}-{AREA}-POL-{SEQ}'),
    '{CO}', coalesce((select doc_prefix from companies where id = cid), 'CO')), '{AREA}', code), '{YYYY}', to_char(current_date, 'YYYY')), '{SEQ}', lpad(v::text, 3, '0'));
end $$;

create or replace function public.set_policy_numbering(cid uuid, p_format text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hse(cid) or has_role(cid, array['owner','admin','hr'])) then raise exception 'Only HSE, HR or an admin can change this'; end if;
  if position('{SEQ}' in coalesce(p_format, '')) = 0 then raise exception 'The format must contain {SEQ} (the running number)'; end if;
  update companies set policy_numbering = trim(p_format), policy_numbering_note = nullif(trim(p_note), '') where id = cid;
end $$;

-- ---------------------------------------------------------------- 5. New companies and audit
create or replace function public.company_seed_v37() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform seed_onboarding(new.id); return null; end $$;
drop trigger if exists companies_seed_v37 on public.companies;
create trigger companies_seed_v37 after insert on public.companies for each row execute function public.company_seed_v37();

do $$ declare t text; begin
  foreach t in array array['supplier_documents'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- ======================================== Part C5: v3.8 own contract types and sectors, what not to do, policy reference numbers
-- Asnys ERP v3.8 — Gulfaco's notes of 24 Nov 2026
--   1. "Who does what": each duty also says what NOT to do.
--   2. Your own contract types and client sectors (added from the drop-down), on top of the standard ones.
--   3. Supplier documents: "BoG exemption letter" (label only; uses the existing document type).
-- Run after 0025. Safe to run twice.

alter table public.cycle_responsibilities add column if not exists dont text;   -- what not to do

-- Lists the company extends itself: contract types and client sectors.
create table if not exists public.lookup_values (
  company_id uuid not null references public.companies(id) on delete cascade,
  list text not null check (list in ('contract_type','sector')),
  code text not null check (code ~ '^[a-z0-9_]{2,40}$'),
  label text not null check (length(trim(label)) between 2 and 60),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  primary key (company_id, list, code)
);
alter table public.lookup_values enable row level security;
drop policy if exists "members read lookups" on public.lookup_values;
create policy "members read lookups" on public.lookup_values for select using (is_member(company_id));
drop policy if exists "staff add lookups" on public.lookup_values;
create policy "staff add lookups" on public.lookup_values for insert with check (has_role(company_id, array['owner','admin','accountant','sales','project_manager']));
drop policy if exists "admins remove lookups" on public.lookup_values;
create policy "admins remove lookups" on public.lookup_values for delete using (has_role(company_id, array['owner','admin']));

-- Contract types and sectors are no longer limited to the fixed list.
alter table public.contracts drop constraint if exists contracts_contract_type_check;
alter table public.contracts drop constraint if exists contracts_sector_check;

-- Policies: a reference number as well as the document number.
alter table public.hse_policies add column if not exists reference_no text;

-- HR & Admin policy areas: "HR and administration" and "Compliance" replace labour/HR, administration,
-- legal and corporate, data protection and anti-bribery (existing policies move across; nothing is lost).
update public.hse_policies set area = 'hr' where scope = 'hr_admin' and area in ('labour','admin');
update public.hse_policies set area = 'compliance' where scope = 'hr_admin' and area in ('legal','data_protection','anti_bribery');

-- ======================================== Part D: Gulfaco's logo and company code (only if not set yet)
update public.companies set logo_data = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALEAAACKCAYAAADllKurAABCTUlEQVR42u29eZBdxZXn/8nMe+/bai+V9g0JJBZtCIlFLJIMZjNgY+P22G63Pc1MuP1zh3/+dUzP9MxEdMfMxPwxdkd4ZtzTHrfd3d6NG2MEiH0TmwRISAIhCUmohLbSUnvVW++9mef3x3v3UaUFxGIbwzsRL0qqeu/e+zK/efIs33NSiQgNeXey7/igHO0bJI4svp/CWou1DhQIoACnAAQEFIJC0AIGofonRzbwmTl1Em3tzaoxqu9cvMYQvDvZ3V+UB594joceWcfA4AipIIMSH2cVAohSaBxWQGmHEqm9HAYwTkAJyjnacik+dfO1fPHzNzQGtgHi374cLIeSSgds6T7Ig5t2UcrMYs++1ynmy+R8Q4DBGIPFoQHR4MSCOJRSaKGqicWgBTxR7Cr0obNbWX7FZTJvRltdG+dHjktTy8SGdm6A+P2VIOWz43Afax5/jp6hmHRuCpPObufAG4dwzgdlEK3AxVgijFFoLFYsKI0DEIW2BhHAQSbIsW1PD/c8vInbv3SNdKSqlkZTy0Rl4wExXkcDyG8hujEE70xiYN0zL/HSlp3E+BRjS+uECbR3TcQZTaQUkYNYFLEYQqtw+GACnNI4NA6FU1V72SJ4qRRD+Tw/v+NfeHXnAYYrbzoq1jXGvAHi91GOC7Jhyz6ee+FVglwHQbYVP52mWCnR2tkOvk/FOSoIog0YH6cMVoEoA8qraWoDSiFaIUZRsZbmtk6O9w3yzz+5k0K5/KbmDxpauAHi90mGBNl/NM8Dj6ynp7eISXWivSZKsaMUheiUT7qliVgbQoFY6ar2xRBbD+s8RDxEaQRd08oKqxQODxNkaeuaxtPPvcgjj7/IcEQjbNQA8fsnw85J72iJZzZuZdtrBzCpCZQinxifchThZVJYDa2dHaRbmrFGEStqGlgjokE8RPmIpEB8nPIRfAQPvBRxbEBlCdId/MM//YKdu4/QX7ANIDdA/P6I05rD/aM8uX4jgyXAbyPTNJFSBMavArkUhqSbs7RMaAZPEzpLbB1ONEp5aOWhxUPjoZSPEh9FgFIBYUVhXQrrUjid5VDPCD/6yV3E1jQGvwHi90eODoWse34rB44M4+cmEJEiEo/YaUQbrHU45yhHFbKtTWRbclgsfspDKYWNIpSAWMBplBh0NVoM1MBMGusCwlDT1j6VZ57bzAMPP9MY/AaI37v0VJCnNu7g4adeJDLNKD+HI6BcsYCHxBpPeRgMTgRRiubWZrSnyY8MYZQjnfLQYvGMwkMwolCi8ZRGo/G9AE8HeCZDLteB7zdRKMbcfc+jPLNxrwAMD4UN06IB4ndjCyOHjw9x/yNPc/DIKM5vJtIBUS2tDAolCuUUSoQorFAo5mlra2H6tEmIxGTSmlzGx8VFPFdB2QouLmGjAnFUwtkyLq5QKRVxcYTSHrEFrQO6u9/grrseYGAwlta2oBGlaID4nUuh4nhk3Va6Dw6Sa5uBpQlUgAVECziLsqCsQjvAVbN0nlE05TI0N6cpFYbJD/ViXEigY1JeTMaPyQaOtO8IjCXtC6k0GGOBiNhFtLW1kMtm2bp5C488sq4xGQ0QvzvZum0/9z70OCZow89OIHIBpdgCMSIRShxKNNoK2oLBEPgBoyMjRJUyUydNxCMm7Ttacoa4PICyo3gU8VQZjwLaFTAUSXkVjC7jbIGwMow2McaDgcE+HnhgLVs372qYEzTSzu9I9h3Ly11r7qVYtrhcQOwCrPJwWhBiPBFEFEoMRjRKCaU4BGNQ1pHyPJrSPoPaMTLQi8llUGJxsUKsAqVRohABFzkqEmG0wjPg+ZbYxRgV4geaTZs2cddddzLnrP9XWhpMtwaIz1QeefxZdu5+nXR2GkWdIbIa5QcYQqRqUKDFoIQqGLGkUymi2BJoDXGFsFRi7qzJMKmZsDSCwhJHIXEUYcWilYcx1Ws4JzgboxT4xlApF7CuQktzFt81sWP7dja+uImrr1vdmJwGiN9eNrx6SB58chMF14zoFkIVEDuL0RZchBaHthotGkRhNYjWKCc0Bx7h6HE8KdNsKnzh1mu5YM4kCvkCIjHWWuI4RpyglK6CWAkiQhTHWGfxUISVEsZZMoGHiiIkrjB18qTG5DRA/Payt78gdz34FAf7K4S0kwo6KEeCSWnEFjAS4YtGOxARHFJNHSvwbISJSrSaGFUaYMWF57Jy6WzOmdwwARqO3e9IekMnTz23hQ2bXiVWGVLZVkqVCE8ZjII4CrGRRazgHLgEyNZhbYhnLMWRPnwd09Ga5obrVjUA3ADx71Z27HqDBx5dT99QTKZlAngpSqUKEse4coivPIz2sGicUlWSO6AlxjiL50JaMx5hoZ/VV1zM9CkTGoPaAPHvTg4VnTz0xEZ2dR8l1TwFCVqpVBQaD18bolIZTxRGByg8tArQ2kNr8JSQkhAdjaLjUebPmcr111xGxm8o4QaIf8syXBqux143vbyb517YCaYNCVoZzQtRDNlMlrQXYJwgoUPH1WFTNU1slBBIRCAVdJjHs3luvnYl07pSTMyoBoobjt1vWVT167/wxoDcefcTDI0KXqaLQpzGag/jVaMPEoWkPR/nhDhyoDXOgFExSipoW0bbEr4tsvrypVxy4ezGFtfQxL8baU3n1LGKlXVPb+TFTTvxgg6syyCkQKfQxkfiGFupEBiDURosaFFgIyQuERBiXBFVGWH+rMncfN0qZuUC1Vat2H9PYhkWJ8ONTF1DE7+1bH5lH0+u2wS6Cd9rIoxrxZ4iOGvxFGitEVtNTnhaY4zChmWQEkrK6HCU5jTc/PGVnDW1/dSAdENircNaRSbdfkYAN7QqGgZJQxO/ZTTi6Ijce/86jhzLk8tOwDkfXWP6arFosShnQQkg1eycdWAjcGXSJiLM9yGVIZacP5ulC+bQlT497EQ4YwA3pKGJ31b6Q+SZZ7ey/vltWNVBJtVMYbREqinAcxaUQ6kIUXGtgU+1yiKKQlJKkfUcnhQIvJAJTRk+vvJS5k7KnBagpcjiLKSC9+HZHZLQQT1VncR2Pro6+yML4pdf3cujj28gDAOyTW04WyWuG+cQFYKq/TQOK6bGHhZ8ozESkjERYX6YlnTMx668jIuXnv2W92tKdY4D2ZHBSN544zCFQpnRQoVUJlvtSaEUSlGPQaOqZftOKyIRis5SjCNCsViJiUp5soHH+efMkfNmTWaSRg2FsbQFnmqA+EMsx0Yqct/ax3h972FyuelUQoPR0JRrIozKKA3aCE5HOFctrUdpxAlpzyMuD1OKBnHlYSZO7eTqlZfQkdZnBJqBkpOOjFaPPbaB7//DjyiWYiJnqMSA1ihdC99h6mE85XtIYLCeJvQUsVFEHhhPkfOEFI4LLziXT16ziuUL58iMjxCAP5IgHhjJy4OPPMWGDRsxZgLOeSh8UB42jkGiKi9COURJre1f1dFDoBKWyAaK0uAQUzvTXHf1lSyac+atpjoyWm3ecVyeXPcCQ8MhXqoFP53FxYDx0EqjlEGrKohFK5ynsIGHSnmYjI9Oe/gZH2NAx2W0hOw8eBTv6Q005XLk5k+Rjo+QefGRA/Gh46OsfXA9wyPQObGToRFLOhvgEIrFAumsj5MYzxgiG9YSG6BVjFIhtjxIW1MKZSosnHcuN3x85Un3iKIh8f22U4JoX09RfvyTNTy9fhuz5ywhVmkGR4sEGQ+URTQobVB4oA3KeGAU1lPYAEIPIm1wBDin8bxm2rMBheFjbN53hHNeP8ic2ZOwRkuX99EA8kcKxMeKVh5/Zhu79w7T1DybclGTCjxsXMApg5cOiJyiEkd0tjYxMlxBo/A9hZYQ7Yr4QZl830FmT8px6w0foytrTgKKtYLvn/oZHnxgHRte3EZL5xwGCilivxkyrURSxlHCqbhmF2vQAaI8RHvExhEbRRwYrB8QmyzWSxMFaQYKA0yZMIdC/hiPb93J1KmTWLloViPE9mGU7Tv38atf3UfKb0eRBlVVVaIcUOX0CgrP+BSLRQI/RTaTwYZlonIeX0WkPUtUGubqq1awaMHcU94nfZow2gOPbZFHHtsAOoufaiaVa0WpgHyxgtMeVvtY7WG1wRoPqwOsThErH6v8amWJ8hDlAR7WGfKhQ+fayFsPr7WLw0MF7nvyGQ4NFOnn5C5ClXhQGiD+QzUjBvJyz5pHGOzL43tZxFVTyggoR7V3sBNwjnQQEEcRyjkkjnBRiG/AaEcxP8RFSxZz9aorac+eOcNn/5Ehuff+dezadwgv3YwVRaVSQbmIdGCqjbiVqvZs0x7OeNVebqbajFBMgNJ+lXyEQQNKWTwDuWyWQrlMZHykqZXdR/p4ctN2jubjkx8kUg1N/Icqjz/6PE+v28ikrlnEca21lKuBeEy3fC2gXDWxoZ3FloukjCOtLcXhftpyKW771M3Mn31qm7dSOXWa+MFHXmLr9n1kWiaDzmKtIQ4ruLhCUzao2cMKpTWiA0SnsCaFeCnEq/4fHaB0zVauZQ4D31R7sKQCRgXMhCnoiVN4ctsOnt7+OvvC8UcBpDJtqgHiP0DZ+up++c1dD+PCNFHoI5GPtl41hSbUsnHVl+AolUsYJ3gKDJasD3FpBFce5aoVy1l4wentzVSq9SSQPPzkHrln7TrKUYpUbiL5kiNIZcik0hBXcDZEAQoN2kO0j+iqFnYmIDYBzqv93wsQz0MbhfIUsUQUoxLZjk4qqTR9Vqg0T+CoMzy2+VVe7D5Cj/twNyf80IO459io3HPPE+zb10smO4GwotAqVf3qopH66Rq1jtcAYjFKMDYkRYyKSsTFQZYumMctN1zFtPYzj8Nu3zkk99z3ON1v9GFSnRTLilh8RPk4Zwk8sGEJXUtwgEaUQYyHMxqnNVYrYqOJPYM1Bms01lc4rXDGEmpHxdOE6RzDKkU/HlFrF/sLIU9s3c5rx4dOaR83QPwHIpu3vMYjjz5HkGqjWBSyuQ6sVJUw43gNVS2sxJLyDFpZ4rAEtkRcHsJXIauvupQl8ya8eRzB6JAAhOUhKZf6TwmSp5/dzOate/BTbQgpyhUhlW0hiiLy+TyBXy19qsJX1RoOVm+hlMOZGPEcGHCeJtaKWGsqWmONwqQDTCogXyoRKg2t7YyaDHm/CemcxMs9x3jl0BFGgWPWSQPEf2CyYeNu+e7/+SeM14TWTbS0TqRUDGtWhCDiEEf1JbX/E2NtBaMsnhdjqKCiApdfvITLl18w7vpNzVX7Mki3qXSm82Qz4ok98pt7HqYS+6SynUTO4PtZojDCWksmkyKKQ8Q6JHLoWGFEQ1gtd4IKNsrjGYv2pRovNoqKOCKjIOVhAasElc0QG5+yU0SpDAUvxYDzyXtZHt24jVf2H6PoFANOGtGJD6LkC0MnTcxw2crah9ZxtL9EoaKJnUclspTCCsoDS4TDVimX4qpVy8Q4QtCWQmmYdFoRFoeZOqmNP/5Xn+Sc2S1nbEa8fmBE/s/3f8Lx4RCrMjjxUOLVzRWlLKIcVgkioKwGq3DlCBXH+IRkdERTxtKcdSip9m3TxhDkcig/RSmOQVe1uBJB1bKLqIBIB4w4n3LQTH+oWLNuI3t7B3Fa0RdWpAHiD5g05cZ73APlWDa8+BrPbthGGKVB59B+FuUFxCrGSym0JygNSmvQGpSq/tAOa8toFePCIpHNs/LK5SxfMu2MAdw/GMsv/+VRdu87gp9uxQQ5KpEFEZTENZpnld7ppHq+h3O62pjQCYFyBFLBi4fRlX7C0R7SlGgKqhyPKLLEVlDGq/avsA7PWry4+tIxYH1EZzDZDkoqw96j/Ty3eTtHRgp4QYpGxu4DKsNRJK2+r/bsPcTP77ib/kFLOtMFOofTfhW4xhFJpaaJFTgPUQpb7QgIRKRSEKAZGOhhyXmzuf7jV72j53h2w6vcfc9DNLVNJrQ+aIPWCu0sSjnQDoXGCVhjqo24qfYsDpTDM2DLw0TFYbycRzrTSqh8QiJC6yOxwngB6XQGF5eq18ZDoRDRuNq1xMYUrcU3OYJmxebtO5nRnqbrsqWgTUMTfxCl1ffVvt5hefjRZ3jq2ZdANaG8ZiqxohzFVGyI9oUwLuJU9CbJR1U9K1EO0TGxVChX8jS3pPlXn/s0557TecZaeMf2o/LzX95FMRSszhCKTxSDpw0Ki5YIIzEQ45TgROGkGlrTaDwl+DYkKvQTxKMsnjeVz1y/iqktaSiOknbQEmQI8NBWkfPSNOmAJuXRIooWEZqtIiseHU0TEOuTae4EP00smi2vvML+gwcbmviDJkOlfmmrOVYvbt7O+udfIp1pxUmKMDSEsSUmpBTHBGlLVAlx4kBSiKSq52poh9UhypTxJaIpcHzsY1dw+ZULzjycd2hI7rv/IbZs3UbbtPMpOEWQbSIsRcQuJpAYQ1xNceMhorEanBiMUzglaCsIJTwXcv45M/jM9VcyadZUXtm+i72jg3hBJ74HI5UKYSVCpwwiMb4SrAKUJlI+sfYI0ykqhTLHR0sMjx6ly+XZe/wYhw/NZ2jmdGlTHw7K5ocCxG1jIgOVMGLChAksWPwxStFEMG2gNeW4RKU8QnOLT1gZRSuFSAqn0tVGKFpwKkRTRsdlWrLCF7748WrF8xnKI4+t5667Hqa1dQouBmtjonCUjJ9GRREmOcXOOQTBKBBR1aNzEYyAlgJaCrSkYfmS+Vx20TzWbztKf+8gxdECQXqUUiHCiiGdzVIYKmGweKqaP3coYuURKwNeQEvaJz9yjLYMUArpbG1hzuxZfFgA/KFksc2ePpWjR3p48ZX9xE1nE3vtBKkc2Jg4LOFTQeIy2jdEyhDrVBXEOIxUCFyMhGWaU5r8wCB/9f99gbYJVfvRhUPV4+jMyanb5zftlXvue5ZKpZWM3wyRoVWBI8LE1cB01SauHlLuqxgjMc6ViUURhZZ0JoC4gC0d56Kli/nkLTdy+FjEo49vY9+BPO2d0yiLwwsHmdnSSaE4gtI+YrxqHFk7rAKveiAvWQ90foisi/GH+vGjEVasvpJZk6Y2zIkPssw9ayZXr7ySb3/vFwTBJGICDh49RnNzO9pZtC3iEWNSHpFyhKZWA4TDl4iUjdEWCoNDrM/388BD0/nj21ZJe1opHbSpwvARybW2jbvnkeODsuaeNXTv24fnd+LiCs5VucgWQUQjUj3XuVq5IaAtoqthNi/lI8SU8jFGKqQyIV/68mdBKV7ecYANG1+mYgN8q1Ha0pIOyGhFZGPAr51OKoiSmpNjUSKkLfiuQrsnSL7IJRcuYOUly2n3jGqA+AMs09pS6hM3fEwefmoTO4+P0NLaRdyawfM9lKs6Q752xBLV6tg01QhrVRuLqnIYPD9DX/9hfnP3Qyy9YC6XXzgTgFzrlJMAsH79BrZv20xzM6QzithG1QS29qoOo3WIE4zSaKWqIEbAOFCOiisQpBSpdIq0n+OWz3yczqkT6enr40c/+wXl2GdC11RC5RGHFTytKRUjbCwY782MuVKgTFXrG2ex5QppqVApDTK5LcvVKy/n/EkfvhNKP5Sk+EXnTFJfu/2L8lff+gf6Du2hc9p8hgsVYmuQyJIKqgSaKlw1ohQ6SRYoS+Ri2tu6iD3H7tf3c899j3LOWV+UiW1pBVAqDEsm9ybRZ/bMqfz5/3M7mUw75UgRxhaHoHwfpRVSLZ5G19IRiZWtNYgSYhehjcYpDz+TYtGyeRzuC/nHX9zH3kM9TJ65GM8PGM2XsSJIVE3QpDI5YmvBA0VN01tXNY1chOcqiB3FuAKrLruEC8+dTqOy4w9Irlt9IS9uW8n//fHduNJEAtOC8gKK1pJJZbBRWCNQSK3JNdVjasVDKU2pIng6QzrbwcOPrmfe3Dn8my9Wu7SPBTDARUuXvK/abV8ZeeaFrTz27ItMnzOfUqgojRaIrSKdzRGLxjqD8VJENg9O0FrX+EuCJsKTMoGUsIU+zjvvLK5ddRFd/oezN9yHkjsxOjQqbRmlPn/zx7nq4gWM9h8iLg8hLsShiKxCtI9SPp7y8PAwqnrSJ8rHD7IUizGh1eSaJzE4ErPmvkdZv+nAbz1dezxEdr8xyC9+8wBtE2cSSqpKikeRy2RJeSm0qiZICqViVcVTbfTiuRjfRQQuInBlKA0yvTPL1SsWMn1CM4OVuEEA+kOR5rZqY+tl509QX/vKrXRkBIlGkbhEc1OO2DlcjRBPLVGXmKlOqhRNrQOy2Q4KJUdr+zRe29PD3fc+SU9fdBIQ4vC990sr1zp0Hh8o8rNfrmGkpChLlmLFI4yrNXdKKUrFIjYW0kEKF1VT2EYcRizGxfguJnAVUnERPxrliovO48qLz8c4aE95DU38hyiXLDmH1SsuJM73oeM8cVgg8D3EuapvVesCr8ShURitiazDBGnCSDB+DtFZMtkuHnrkaZ57cSfHhsdzc72gVUl85kCO7cnvTWeqJsojjz3P7r09KNNOHGUQVa0FdE4RhRFKqpa1tRFGg7IxxoW4Up60jgniAqYyjBfluWDOVK5ZsZTZKV+16g9v5fOHHsST2tLqtpuvZvH8GUhlEM8Vicv5KgkHMOLwRKqEnBpL0ZjqqUbgIypF7AKcpAklxa/uXMvho0MnAzOyZ+6ImNZTAuqx51+TJ5/eSOzSeF4rYewTBM21M6CrO4emevCjEosHiI0JFDSlDF5UxIuLNHsxTSbi6suXM3NiJ41q5w+Dk7divvr0jSsJ4hG8OI/nShiJUMSoWhZNY1EqRojBxmBdrebDABnEZPFTbbyw6VXWrH2UgUjGaVM/895CV4d6I/n1Pc+y/1A/YegRhYZM0IYLNcrpamSjVkKVZP20C9FRhI4jVFhCKiP4UqTY38OyBXNZeckiZmQ//O3qPzKFojdds5wVS+YR2Dw5P8YjwqvRIqsng9oqQQdL7MpYG+FiV2WYaR/tZfGCFrx0G/eufZR1z2ynv8j75ig99cI2Nr+6h2xrF9Z6RBVLU6aJcrFUtddrxau1PAlejc6ZDXyMjZEwT0qFxMV+zprSzi3Xr2JOc0o1+k58iOTsqW3qa//6j5jY7GHzg3gSoiSmejhzBCquaeYYr1aer5VAjdpoRROLIZNrZzgf8oMf/JiDh3vfl2d78uVj8uv7NyCpZsqx4PsB2XSOcr5EoAx6jLmjRdXbC/gKfMBWiuQChS0NEagSX/ijm1gwbwaN5ikfQvn4ZWerlZcuxifCuBiNRddYZapmUqAsgVZ4RmFMtUOlc0JsNZGt8ng7Oify2u693Lv2AfpH31uVxLaDQ7Jm7eO8srsbP9fCaKGM5/mkfJ9KoUTGD1C2yrdQohBXyy46B7ElLJWJwwq4kDgqcNnFi1ixfMFHqtXrRwLE8ZgDZr7w2U8wd2YnnhTxJcIThxFB10Js2gkiMeIsIhapRS087eHpFEZlMSZHNtvJPfc+wmOPrx93L+HMohRDsciAFXlx8y6efXELJt3MwFCJyZNnYJ0wMjhIUyaFjcpoZcG5Wll/9bgFT8A4h1GWtmyK4nA/58yayqdu+DhTUh+tY5s+EiD2Mm9GA2ZNa+FrX7kZXTxMOhpEVwqkMUhFk1ZNeJJCxKFUXM186RiDw0fjSYpAtzE6aMimp1EpZfj5T9fyevfxOnAVrWcEIKcUr+0d4Rf/cj+FikeQbkdUjlLJw8YeRiuEAkgeXBlfg44drhTixUJap9BxiLEjpBhhUrPh5tVXcNW5s1XjuIMPuUxo9tQlS+bw6RuvQkXD+BKinSUbpCGEjEkTGK8asagdeWDEVVtdOY9KSchluhCXw9NtHO4Z4q5fP/aOnmGoLDIyavnZL+6ldzDEqQyCj6dzlMsKcdUQn3Nl0BFgEevwtEfK83BxTFwp4xET6DKl0aNceP7ZrFh6PjTO7PhoyIxJLepzn/sUUya3USoOoKg6eTYqE0chyiVdIBLDMkntWayLMUbhrENrHyuG+x54lIcf3nzGtnFbWqn1z23jkUfXkUplSXkBWBBXM2twiNSiEU4DhjgS4siiEXAVonAEpULC0ggtTRkuv+xizp760TwP5CN78MysmZ3cfPO1pFOCi/O4qEBTNoWthEgs6Fr6GVFJgzZQllTaZzQ/DEaj/RSZXBuFouPHP7uL7jd6BWBoJP+WgN5zsCS//vV9ZNJN2BgCPwtOoRyIWHDVWJo4BaLxdQrPBETlCrEtEwSOwA9x8TBGh1z7sStZsnAOjdOTPmLS2aTUzTddyerVF5MfPYoxISkP0r6HFjDOjBmeqiYWZbGujDbgeR6iDcbPkMp2sGvvEdY+uKGqaVuaTqsRj/RG8pOf/Jo9uw/Q0txFpWQRUaha6AyxIHH19HOncLHGVhQZL42qMdR8PySOB6iUe1m6cB7XX7OCWW0Z1QDxR1DOmpRSn7z5Kro6M0g8Sinfj0dEiiqotNQSviK1ymhLqVKiqaUJUWBFU4kUsQQ0tU7l0cc28OQzr72lFn7++c3cd++jtLVOolJ2BCaNRLVwtbhaVs5VnUvARkK5UCEqR9VUswopl3oJS31MmpDm+muvYsaUDhrn2H2EZcmSmdxy09WEpUG0K6JtGeVsLcFAnXPssIiK8QJDbGPCOMIPUjgCTKqNMA44cHiQn/38Xt7oqZoTQ4WRcYDe8NJe+fmv7kVUFq0zKElhdBrlDDiNdgrtqrQ65RyI4GufVJCmUipiXETKi4iKfbQ0Oa5YsYhLl8yjQ3+0j2z8yIO4K5NSn/nUKhYvmIumiHJFtIR4LibQCrBEcQXf1xhjMEZTicNa8xMFOgCdIZIATBMvb9/Luqe2cqC3KG25N9te9Q0X5e41D7F9ezedE6ZRLisQj7Bs8ZT3ZiZOLMrFKLFgBY0QeAbfCCnfUhw9jpEC0yc388kbVjM17avGiaIN4fzZHeoLf3QLTRlBuTwpbXFxBU2M72kCr1bt7GpRA0CpGoiVT+w0ysuSa+lCec38809/TU/PaP36wxVk2/YDbNq0HeM1E1sfGxs8FaBFo8WgpVoipWudOTW2+lMJtlLAxdWDH40U8Chyyw0fY9aUCY3Ja4D4TbntpsVqxcUX4OIhoIBnIsRVAEcqkyKOIkQEYwxKmeo5c2JwSiPa4MSAyRCk2+g5NsRdax7hjWNVgtDx433ceefDHD9eoLm5i0oIUawIvAxap3BxrUrZubpdjHNocRCX0a5MoMqoeAhtR1h9+TJuWn05XdpTjZlrgHicfOHz1zF9SjOV4gCBb0n5iqhSII5ChCrPuFphoWv9g6s91BQGjKEcOZxOMXvuQh59/AWeWLeFN446uffezTz+xEaU10K2qQPrNFobnFO4yOFcFbhaJVq4WuypsNiohFYl2lo0w/37mdzVxJ9+6bNMTKcbAG6A+GRZuvAsdeunVuOZCpXyMH7gECKcs3jGR0SjRWMwaHT9xM9qHzeF8gMifIaGQ1pbp7H2/mf41a82cM/d6/C8drJNEyhVwFkw2qdcroBzmJr/WG30Xf2pa/RQz4sRV6CQP0o6FfH5P/oEF8yc0gBwA8Snl5tuuppLLlmM2DJRVCKV8vB8H2MM1goiploipKpANrXzmEGBMTjtoYIskfXpOTTMQw89Rzn0yTV1AWny+XL1rGYFsbMEXlDLDtoaU63KqBOpZgg9IxgdMTx4hBuuW8V1H7u8MUkNEJ9e8vlhmdzVov70Tz9NW3uGfH4A39fVPm3O4RkfrU0NtFXt63T16FrRCu37RM7hp3OEVmP8ZkbzFmOaEFLYWFUXge8TW4vWiiCVIgxDamcukORWNIIWC3GZKMwzf95MPnHDajpzuYYWboD49NLUVGWgXbR4urrl5ssRO4yL8rioBDiM52ENRAZCHyJfiHywRlUPhFEaMR7FclQFsgPRAcVSrd2U03iej0m6ACmqjVM8IYzKCIJ24FuDH3nocowqFwjsMLfesIpz58xoTFIDxGcun7plFUsWzSE/fIzAA6UER0ysLJHviHwh9hXWaJypdhGKrcMLApTWlCohYWyJrMX4Pg4HumpDixO0VjgsFVtClEV7EEZlXByRNj4mtAQuQlVGuHjhXFZcdD5t2WxDCzdAfOYyZ2aH+qPPfpq29iwiZXyvyjFWymIUiWtHwrAwCJ5SaCfYOMZZW6ucrraNrZ36iCiH01Jr7u0QDZWoQiaTwsYhsS2BlPGDCsoVmNiZ47bbbmHunJkNADdA/M5lxeUXcOMN11Ao9KN1iO9ZfC14KHylCTD4aHyplv4bJxA7JIqRKEaLwyipHnGARZTF1Q+cAasUToHne5TLBdIBGB2SLxxDVJ5YRli5+mKuunJxA8ANEPMumW5G3XTzpcyYPoHBgYOILeIphxEwTqGSw2Kk2tBPnMPFrlYTVzvVSDGmxVD1eAVHleFZbUJUTWdH5RKecfheBIwyPHSABYtmcf0NVzUmogHi9ybTpk/ik59cSSqIicJhFDEmoRhDrSNPlfMQRxYXA1I9VpHkjFKlcMlR0rWXqx3XJRhs7Ej7PmJDICTXpGlqUXzmM9dywXmTG1q4AeL3Jr6JuOHjF3H11RfjmQglFXBRFaSiq900ReGk2tI1iqXarNDzEWWwtW6bUmMDi+i6FY0YtBiUU3iq+orDMmFlmJtu+RiXXrqwMQENEPO+nMg0c0KLuuUTq5nc1UxYGiWT8oniCrGN8QKfShQSSwxaYWvxY1G6ajbUmgEICpSqcS4UXu2lUQTGI65UcFEIcUzXhFZu/sS1tOUa3IgGiN+jFEq9dT7w4oVzuOLyZRTzfVTKIxjj8D2F1o4wKlEs57E1dnsUV4jiClYsThzWxThna9UaFqwFWz05VMfVtgFNmYByocCkrk7+zb/+11xw9tQGgBsgfu9i9Js4avdRV6+6mIuXXUB++AhtTYZ0Kqa3bz+ZDASBoCjheSGeF2L8uHo2tInxTIynLUbHeCrCUyG+hHhSwqeExMNUykPEYZ55Z89hxaULGoNPo1P8+7PC1fjhWXbuRPWZm6+Wwwd+RO+x3TS3TyDtlUkZDRIiYvFqVdIJrRKqFSKSdKWnem6H0VUOsUGhVJliqY8li87hlpuupasjaGjhBojfHwmCk4/6WnnZeby2czm/+NUaCgN5Ul7AcF8P1jo846F8vwbgWpTCCYKgFGhVJdcrrRBxiCicCIX8IKm0cNPNq/jY6tkNADdA/Ft29JqNunb1xbJn51Z27d1XbQyrY3KtzcRRjIvK6CRI7FS10lSqYbXa8XI453A2Jo4tEkVoVeHqa67m0oYZ8a5EiUhjFN6FHD50TPr6h4hslckGGuMZfFVtwwrV00Kr/9BYJdUz7aoormriOMbFMc6WmDlrCjNnzGho4QaIfzcyOjggze0dDcA1QNyQhjRCbA1pSAPEDWmAuCENaYC4IQ1pgLghDWmAuCENEDekIQ0QN6QhDRA3pCENEDekAeKGNKQB4oY0pAHihjRA3BiChvBhr+wYGBiQjo5Tc2ePHDkiURRhra02iBZBKUUqlSKTyXC6z32QZWhoSNra2tRv6zPDw8PS2tra4CLze+ITv/HGG7Jt2zYOHTrEG2+8wf79++np6WFgYIBCoYCIkMlkmDhxIjNnzmT27NmcddZZzJgxg6lTpzJ9+nQ+SBM4MDAgd955J4cPH6alpaV67IBSdHV1ceutt76jZ927d6/s2bOH/v5+wjCkXC5z4gLXWhOGIXPnzuW2225rAPl3WWP38ssvy2OPPcYTTzzBli1bGBoaolwuc7oF8Nprr6GUwvM8MpkMzc3NzJo1ixUrVnDjjTfKueeey5Qpv/+W/YODg/zyl7/kqaeeIpVKEccxxhgWLFjAggULWLZs2dteY/PmzfKb3/yGZ599lj179jAyMkIURcRxXF8UqtaUW2uN1prrr7+eZcuWyezZjaLQ3zqI9+7dKz/96U9Zs2YNu3btolwuV/vr1sCbTApUix+T3yWTFkURURQxOjrK4cOH2bRpE2vWrOG8887js5/9rNxyyy2/V82stSaKIoC6KRTHMceOHcPWWrO+laxZs0b+9//+3zz//POUSqXTb3dK1Y5LsERRRKlUIpfLNdD32wbxPffcI3/3d3/Hc889RxRFpFIpfN9/8yw39Sb2ku1y7LZpjMH3feI4HqexDx48yOuvv04QBFx++eW0trb+3r58svCSfyffqa2tjebm5rf87MaNG+W73/0uTz75JJ7n4Xle3XRItG8yHtbacYvCOUccxw30/TZBfOedd8rf//3fs27dOowxpFIpKpUK6XSaSqWCtbYO5rFaLQgCrLXEcXySJsvlcvW/TZs2jWXLljFnzpzf63bqnMMYg9Yaay2pVArnHGEYvnmOxmnk7rvv5plnnsH3fbTW9bEQEXK5HC0tLTQ1NZFKpep/t9ailOLss8/+QJhTH1oQP/roo/I3f/M37NmzB2MMIkIURQRBQKVSIYoimpqaaG9vJ5vN0tLSwsSJE+nq6kJrzfDwMEeOHOH48eMMDw9TLBYplUoUi0Wy2SyVSoXzzjuPL33pS/z+m6MEhGFY18iVSqU6KDWtejrZs2ePrFu3rm6OJAtaRLjlllv43Oc+x/Tp05k8eTK+79fBmwC9qampgbzfFog3bNgg3/3ud3n99dcxxhDHMVprfN+nVCrR0tLCpZdeyqJFi1i2bBnnnnsuEydOJJPJ1CdIKYW1lsHBQbq7u9myZQuvvPIKO3fuZNeuXYgIK1asYNq0ab93TTQWWIkWBQjDsG7rnyZKw549ewjDEN/365+56qqr+NrXvsZ1113X0LK/LxDfc889PPLII0RRVAdvYj7MnTuXr3zlK3z5y19m+vTpbztJHR0dzJ07l49//OMAvPLKK3LHHXewadMmLrnkkg/8wLyVJj569CjFYnHcTqW1ZuXKlQ0A/z5BfMcdd8jdd99NGIbjnDaAxYsX8+/+3b/ji1/84rueoEWLFqlFixZx8OBBmfEB73TT3NyMMea0f89ms+RyOcIwxFpbX/Dt7e3v+7McOXJEEhu9XC4ThiHGGIIgwPd9UqkUnucxder72wr22LFjMjAwQLFYrC/SIAhoamoim82+L/c7cOCAlMtlyuUyo6Oj+L5ff+VyOc466yx1xiDu7++X++67j927d9c9a8/zqFQqzJ8/n7/4i794TwAeK28H4A0bNshYJ6hcLtPe3s5FF110xvc/fPiw7Nq1qx41cM4RRRHTpk1j3rx5b3udKIrGLeTNmzfL0NAQQRCQyWR47bXXiOO4Hlf2PI84jtmxYwePPfaYtLS01E2MMAzJZDJ1uzuOYyZPnsz8+fPV6cKax48f59ChQ7z66qvs2bOHoaEhKpUKxWKxbuokk51Op+ns7GTp0qWyfPlyLrjgAiZMmPCu5urVV1+Vffv2sWnTJt544w0OHTrE6Ogo1tq6g+95Hm1tbZx33nmybNkyZs+ezYQJE5g588xOd3rjjTdk586dbN68mS1bttDT00M+n6dUKtUXZXNzM9OmTeOCCy6Q888/n+XLl78lbrzawLFz506UUnVPOo5j2tra+MpXvsKXvvSl34nm3LRpk/yX//Jf2L9/fz06ICJceeWV/PVf/7XMnTv3jJ5jzZo1/N3f/V09ipI4a7fddhvf+MY3ZOLEiW95nbHhr8OHD8v3v/99HnvsMbTWtLS0MDQ0RD6fx/O8+vudc6xdu5YXXnih7uwl/oExBuccWmsqlQo333wz//k//2eZNGnSuOdYu3at/PCHP6wnTYrFIgMDA2c0dg888ACzZ89m6dKl3HrrrXLzzTef8Zzt2LFD7r//fh588EG6u7vp7++vZ2BPJw8//DATJ06ko6ODZcuWcfvtt8sll1xy2nvu3LlT1q9fz0MPPcSmTZvo7e2lWCy+5T2CIKCrq4tFixZxzTXXyHXXXccFF1ygTgniQ4cOcejQoXF/EBEWLlzItdde+zvbxsvlMjt27ODgwYPjfn/WWWedUfIBqtyE0dFRXn/99ZNisT09PW/psI11+Mbe78iRI3R3d9dDicnC8H2/nixJbOVjx46ddmKSz/b29p7SXHniiSdYu3YtItVjeIMgeNvnTK45OjrKyy+/zMsvv8y2bdvo6emRr371q28L5IceeqiesBkZGcFai+d5dac3+XcyHlrr+qI9duwY+/fvZ2BggNWrV5/W13nqqafku9/9Lk899RSDg4N1Eyx5/iTJpLXG87y6Eg3DkMOHD9PT08PGjRt56qmn+LM/+zO54YYb1Ekgfu211xgcHBw3KEopFi5cyNKlS39n9ms2m60nGcZGDhKz4EyktbVVaa0lGZzkOkopstnsGW21Sbw4mbSxkRelFEEQEMdx3VYUkToox05Q8vskBJeMrYic9By7du2S7u7u+meS6FBiqoxdPGMXYjqdplgsAtSzgtu3b+fb3/42s2fPlrdyNH/wgx/I97//fbZu3VoHb5KFTe6VhA6TmHqyo4w1t+bPn3/aFP3TTz8t3/zmN9m+fXt9wY8dq+Q6yXglplzyXZK56+vrY+3atXR3d3Po0CH5t//236pxVMyenp766kp+plIpZsyY8TsPeSUTdGLo650QlZxz4zKLYxl2w8PDb3uhSqUyLnWeTOhY8yCXy5FOp+shtrEJoOR9iS2e/DvZGcZq77G7RE9PT/0aURQhIvi+X4/LT5o0ia6uLlpbW+vZ02KxiNaaVCpVn/w4jtm3bx8//elP2bdv3ym/7/333y9/+7d/y5YtWzDGjFvwYRjWv0eyIySx7cQWj6KIcrnMpEmTuOmmmzjnnHNUshMm93jhhRfkf/yP/1FfJMk9Eps+GdNcLlfXwMl7kgWcKLVkAW3fvp0f/OAH/PSnP63fxzt8+LAcOXLkJO3X2trK/Pnzzxg4jz/+uOTz+fqXHasJE3rmWJAMDAwwb948zj///A9cpCLZRgGKxSJBEJBOp3HO4Xkexhjy+Xx9rBLNmewaCZkoSbknE5D8PZvNcvz48XG2eaVSoa+vj0wmw+LFi5k/fz5z585l1qxZTJkyhXQ6TRAEOOcolUqMjIwwMDDAfffdx/r16+nt7a0DIYoijDE8/PDDfOYzn+Gss84a9/2OHz8uP/7xj+sJrQSoyQJqb2/niiuuYMWKFUyYMKGeBxgZGaG7u5vjx4/T09PDli1bWLRo0TiTM+HC9Pb2yve+9z0efPDB+mJIoj4jIyMEQcCFF17I3LlzmTFjBul0ur7YBwcH2b17N9u3b2d4eHicEhERNm/ezPe+9z0WLlwoS5YsUd7w8DCHDx8eZ7MlqdOZM2ee0aQfPHhQfvKTn3DvvffWt82x269SiiiKKBQKddMglUrxzW9+k/PPP/8DGSNOAHruueeqL3/5y7J69eo6H2TTpk3ceeedDA8Pj3v/ddddx6pVq2hqaqoP/FiAJOM7e/ZsTnQuW1tb+bM/+zPOOeccli1bxpmGIT/xiU/ID37wA/7pn/6J/fv316MxAPl8nh07dnDrrbeO+8wjjzzCunXryGQy9Z0iMYOWLl3Kn//5n7NixYrTRlBq9r88++yztLS0nPJ9a9eu5e6770Yphe/7iEjdWVywYAGf//zn+dznPnda6kF3d7c8/vjjrFmzhocffhjnXB3ocRyzdetW7rjjDpYsWYJXKBQoFArj7L9ErScq/0zMgCNHjjA0NHTa9yQcA+cc5XKZUqlUv+8HLnhe02iJfOpTnxo30JlMRtasWTPO3lVKcfnll/Pv//2/f1c7y2WXXaYuu+yyd/y5SZMmqT/5kz+RvXv38qMf/ahuPydckBMd9sOHD8vPf/5zent76ynxVCpFuVzmqquu4j/8h/9wRgmbyZMnq9tuu+20YbS1a9cyMjJSt20zmQxaa5YtW8Zf/uVfctlll9HV1XXa+8yZM0e1tbXJrFmzsNbyzDPP1Ock2Y2ee+45Xn/9dfGy2SydnZ3jHIYEaL29vWc0kMYYktjoWKdmLBASgz2xicbSOD9oks1mx5k/p5JSqVS3vRPg/76YaTNnzlRnn322NDU1USwW6/ZnYtuOld27d7Nly5b6vCX8j66uLm6//fZ3lXE8sVplZGSkfo8ET6Ojo5x77rl8/etf55Zbbjmje3R0dKhrr70W3/dlYGCAjRs3EgRBfawPHjzItm3b8Nrb25k6dWrdFkwmpVgscuzYMc6Ul1sul0+iN574nmRVJp7uqcJmJ2YLfx+Sz+ffMqSXkP3DMKxHKKIoelvm2zuV7u5uGRgYoL+/n2KxWKcAJD5GLdrC9OnT61t1kgpPxvFESunBgwfHzVViRlx++eVceuml7+o5T+SEb926tR7t8n2fcrlc18KXX375O77+6tWr1dVXXy1btmwZh6/+/n527NiBFwRB/YsmE+J5HsVikaNHj56xI3TJJZfUY4pJLDHxZA8cOMCLL744ztE5kZOcXCdhko0Fue/77wjcY0NAbxXlSCINYxdPEqN8K606Ntow1vx6PxZgd3e3PP/886xbt47u7m56e3sZGRmp01sTpzPRookS2rFjB4VC4aSw4onx6H379lEul+u02WSrrzmS74sGeeWVV+oLOrFlgyDgoosu4t1SDpYsWcKECRM4evRofX7L5TIHDx7EmzBhgpo+fbpkMhnK5XId6cYYXnrppZO86NPZR1/96ldlrPZK6JtxHPPAAw/Q3d190qI4cdIT8yIxNZLrjd223w077a0W39g4ZfK7JOT0Vp8b+0xJ1OK9gHj37t3ywx/+kK1bt9Ld3c2+ffvGmSpJKv5E2bdvH1u2bKmH48ZmKZMQHCeUZCXvSfIBlUrlfTXthoaG6iHCsYGC9xKybW9vr5t4CS24HooDOOecc2hvb+fIkSP1iQ3DkBdeeIEdO3YwceLEt63SfSugp1IpOZOMWxK1OBGwJ1ZGnAk4/5DkjTfekB//+Mf88z//M319fYnzWNdmyZafhP2SkJ6IUC6X67HhZAzHJhROHMuxmjpZrMn1eR+LDcZW+FQqlfrr3YoxZlwpWXL9IAiqIJ47dy6zZ8+mp6eHIAgwxlAqlThy5Ai//OUvOe+8807K878TyeVyb8kKO1W50IlVIx8EW/m3JXfddRf/63/9LwqFQp0dl5gqs2bNYt68eXR2dtLR0UE6na4D1VpbLzjYtGkTr7766jgPPp1OnzTu06ZNqyuKsankoaEh+vv7pbOz8z0PdFdXV90eTohkxWKR/fv3vxczq76ok58JUa2uia+88ko2bdpUX0We51EqlVizZg0XX3wxt99++7t+gLHVE28H4rFgTezihC32ThMWfwjS3d0t69evp1Ao1EN2iWa8/vrr+frXv87ChQvf1pb81re+Jd/5znfo7e2t2+tJYe9YmTt3Lp7nEQQBpVKpnojYsmUL+/btq0eq3oucd955dfAmGrNcLvPCCy+wf/9+mTVr1jtaKH19ffLcc88xPDw8Ls0vItWKIoC2tjZ1zTXXsHDhwnpFbuKgDQ4O8rd/+7d873vfk/eyFZwJCNPpNE1NTeNK3GshnDOOlPyhmRO9vb3s37+/7oSVSiVEhCVLlvCXf/mX3HjjjepMnCHP8+oEnsSnSDTVCf4Lzc3NdW2WjPGOHTtYv379+/KdFixYwIwZM+pp9yTfsGnTJp5++ul3fL0NGzawcePGujmRmEDNzc1ccMEFb7axWrZsGbfccgu5XG4cqwiqBKFvf/vb/PVf/7Vs27ZNzoR/wJucADlw4MBblrQn0tTURFtbG0EQjAPi/v37eeKJJ95RdOIPRZKWBlCldGYyGXzfp7Ozk1WrVql3Ui84NqGUjN+JPI1Zs2axbNmyujOa7JDDw8PceeedPPTQQ+9ZA8ydO5elS5fWo0pJWLCvr49//Md/5I477jije9R47vKd73yHffv2nWTnn3/++SxatOjNyo62tjZ1ww03yMaNG1m7dm3dAQjDkFQqxYEDB/jWt77F448/zuLFi7n00ktl3rx5tLa21gcjccCGh4d5/fXX2bVrF/v27ePVV19leHi4vgWcLiTV1NR0Uqrb8zx6e3v59a9/TXt7u9x000281XY0NDQk+Xz+pAhIQl4fe8/EGUocnRPT5Wdqv7+X+HZCNk/GJSkJ27NnD08//bRcddVV6kxT5cl3HEsgOjFUOHXqVPXHf/zH8tJLL3HkyJF6zDmOY9avX89//+//nf3798uyZctOW4jQ29srW7ZsYfv27cyaNYtPf/rT6oRIgrr++uvlySefrHM6kh3+qaee4vjx47z00ktyzTXXsGzZMk60wwcHB2X37t2sXbuWhx56iM2bN9cXXWKmtLa2smrVKs4++2w1bq9Zvny5+uY3vymDg4Ns2bKl7vkmoPM8j/Xr17N+/Xr+5V/+hUmTJtVBnNjQSUq5v7+f/v7+cY1WxnqVnueRTqfHDU5bW5u64oor5N577+XIkSP1vhW+7/Pyyy/z3/7bf+OBBx5g0aJFMnXqVNLpdD2m29fXx8DAAAMDA+zYsQMRqYMjCSmN5UScGIpLnmtsRvHtvO+x0YATr32m0tHRwdSpU9m2bVvddnTOcejQIf7mb/6Gz372s3LRRRfR2tpKR0dHPQrU398viZYdGRnh8OHD9VjyWFPiVJzklStXcsUVV/DrX/96XNq8ubmZ9evX8+qrrzJ//nwWLFggCQHJ8zyOHz/OgQMHOHz4MAcOHGDnzp0sX76cc845RxYuXDgOiNdeey0vvvgiv/jFLyiXy/W51Frz+uuv853vfIff/OY3XHDBBZx99tnS0dFRJxkdOHCAXbt2sWfPHorFIplMhlKpVNfo6XSalStX8oUvfOHUJftXX321MsbI//yf/7OukZuamigUCoRhWE/5JSA91TZ+Ki2VOItjm4mcimuxfPlyLr74YtasWVMnRidAOXbsGA888AAPP/xwPYCeTNZYDkiiFRMPf6yGHdv4LzFbxtInT8xcns7+TOy8sU7GO3U+AebPn68uvPBCSUguyXOGYcjTTz/NSy+9RFdXVx3sLS0tAtUCgmKxyOjoKM45Dhw4QD6fryeaEpPwxDgxQGdnp/qP//E/ytDQEA8++GCd9ZZk8oaGhnjhhRd44YUX8H2flpaWesV7QnpK2h289NJL/OY3v2HhwoXj7jFlyhT1F3/xF3L48GHuueee+hwmc2Otpbu7m+7u7jrXO0lgjN09PM8jDENyuVydM3HxxRfzp3/6p3Xi0SmZ5qtWrVLGGOns7OS+++6jv7+/zuA6UXONBcuJoE002tjkQMLm6ujoOGX/hXnz5qlbb71VXn75Zfbt2zeOPJ1kqZIA/VgCUbItJvHEJKIxNhVcLpfHxbvHhu6am5vHFWK+nSYeS9x2zr3jrOJYufHGG3nppZd45plnsNaSTqfrvIfR0VFGR0frk30680VECIKgniRKxuN01SELFixQ3/jGN0REeOyxx8ZVuCdjl5glY5XV2JrFIAgoFArcd999fOpTn5LFixersVyKuXPnqq997WtSqVR49tlnyefz9d3zxAKDsXOZPMfYYoRSqYQxhssuu4z/9J/+EzfeeKN62zZWV155pZo9e7YsXbqUO+64g82bN9eds1PFcBOgjg3Kj03faq1Jp9NMnjyZlStX8olPfIKrrrqqbgO1t7fXH+pP/uRPVKlUkh/96Eds3LjxpAUzNquYELStteOC6Sdm7RLtOfZ3Y58vqVwG6k1i3sr+HBvBSUyVMAzfVWvYK6+8Un3jG9+QgYEBtmzZUr93EAQn9Yo70V5PFtTYgoZktxubgT2VXHfddWrSpEkyffp07rjjjnplc/J9xpokieJIzLuxXJEDBw7wyiuvsHjx4pO4FNddd52aOnWq3HHHHdx55510d3djrSWbzdb5IMncJOOfUHfH7kydnZ3cdNNN3H777VxxxRXqjBsKzpgxQ33961/nmmuukfvvv7+ePh4dHaVYLI7jDpzo8Bhjkh7FdZLKihUrWL16NZdeeulJjsCJ9/7qV7+qzj//fPnhD3/Ihg0b6OvrY3R0tB5EH8uDPRGovu/Xs1HJNjxt2jSWL18+DpzlcplMJkM6na6bOwlpPdlaT2dOJHHWxFlMSEHvVi699FL+6q/+iieffJJnnnmGgwcP1kEzNo18qqhE4uwk0YlsNovnebS2tjJnzpy3zLYuWbJE/df/+l/lwgsv5O677+bgwYMcOnSoHtsfu9CTBZSMmed5LF68mHPPPZe2trbTfreFCxeqGTNmyNKlS/nZz37Giy++yOjo6DiH71QRps7OzqSymi984QusWrWq3v5rbN/sd9Sf+MCBA/LKK69w6NAhDhw4wNGjRxkZGanHNhPgtrS00NHRwZQpUzjrrLOYOXMms2bN4t1kg44fPy6HDh1i69atvPbaa/T19TEyMkKhUKhrhcTDb21tZeLEiTQ3N5NKpZg3bx6TJ0+mvb2d1tbWk/irR48elfvvv5+BgYH6duqco6OjgxtvvPG0Zehbt26V++67r66xkmdYsWLFOwqLnS6stHXrVrZv387Bgwfp6+tjaGiIQqFQbwumtSaXy9XHOjGjJk+eTFtbGzNmzKCjo4Pm5mbOOeecUza7OVXz9N27d8trr73G9u3b6enpoa+vr67NE+XR3NxMe3s7HR0dzJo1i4ULFzJz5sxTKqJTyf79+2Xjxo1s3ryZgYEBent7675R4vjlcjkmT57M2Wefzdlnn80ll1zylske9X4lBk40CX7b1xwYGKj3p3g7gtIfugwPD0tSRJBo3Gw2W08rv1PzhXfYBT/J/L0X6gFvUxmU+E6pVOotyfKnkv8f8snqm/HTJLoAAAAASUVORK5CYII=' where name ilike 'gulfaco%' and logo_data is null;
update public.companies set doc_prefix = 'GUF' where name ilike 'gulfaco%' and doc_prefix is null;

select 'Asnys ERP v3.8 database update finished' as result;
