import { useEffect, useState } from 'react';

/** Chrome/Edge/Samsung Internet on Android (and desktop) offer installing through this event; keep it from the very first moment. */
let deferred: any = null;
const listeners = new Set<() => void>();
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e: any) => { e.preventDefault(); deferred = e; listeners.forEach(f => f()); });
  window.addEventListener('appinstalled', () => { deferred = null; listeners.forEach(f => f()); });
}
const KEY = 'asnys.install.snooze';
const snoozed = () => { try { return Number(localStorage.getItem(KEY) || 0) > Date.now(); } catch { return false; } };
const snooze = (days: number) => { try { localStorage.setItem(KEY, String(Date.now() + days * 864e5)); } catch { /* private mode */ } };
const standalone = () => window.matchMedia?.('(display-mode: standalone)').matches || (navigator as any).standalone === true;
const isIos = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const isPhone = () => /android|iphone|ipad|ipod|mobile/i.test(navigator.userAgent) || isIos();

/** A few seconds into the app on a phone: "Install Asnys on your phone". One tap installs it (Android); iPhone shows the two taps needed. */
export function InstallPrompt() {
  const [show, setShow] = useState<'android' | 'ios' | null>(null);
  const [, tick] = useState(0);
  useEffect(() => {
    const f = () => tick(x => x + 1);
    listeners.add(f);
    const t = setTimeout(() => {
      if (standalone() || snoozed() || !isPhone()) return;
      if (deferred) setShow('android');
      else if (isIos()) setShow('ios');
    }, 8000);
    return () => { listeners.delete(f); clearTimeout(t); };
  }, []);
  if (!show || standalone()) return null;
  if (show === 'android' && !deferred) return null;
  const later = () => { snooze(7); setShow(null); };
  const install = async () => {
    try { deferred.prompt(); const r = await deferred.userChoice; if (r?.outcome !== 'accepted') snooze(7); } catch { /* already used */ }
    deferred = null; setShow(null);
  };
  return <div className="install-pop" role="dialog" aria-label="Install the Asnys app">
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <img src="/icon-192.png" alt="" />
      <div><b>Install Asnys on your phone</b><br /><span className="muted" style={{ fontSize: 13 }}>Opens like an app from your home screen, full screen, with your approvals one tap away.</span></div>
    </div>
    {show === 'ios' && <ol style={{ margin: 0, paddingLeft: 20, fontSize: 14 }}>
      <li>Tap the <b>Share</b> button <span aria-hidden="true">(the square with an arrow ↑)</span> at the bottom of Safari.</li>
      <li>Scroll and tap <b>Add to Home Screen</b>, then <b>Add</b>.</li>
    </ol>}
    <div className="actions" style={{ justifyContent: 'flex-end' }}>
      <button className="btn ghost" type="button" onClick={later}>Not now</button>
      {show === 'android' ? <button className="btn primary" type="button" onClick={install}>Install the app</button>
        : <button className="btn primary" type="button" onClick={() => { snooze(60); setShow(null); }}>Done</button>}
    </div>
  </div>;
}

/** For a menu: install now if the browser allows it. */
export function canInstall() { return !!deferred && !standalone(); }
export async function installNow() { if (!deferred) return false; deferred.prompt(); const r = await deferred.userChoice; deferred = null; return r?.outcome === 'accepted'; }
