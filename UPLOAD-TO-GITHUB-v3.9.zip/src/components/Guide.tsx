import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { q, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { Guide, GUIDES } from '../lib/guides';
import { ConfirmButton, Field, FormModal, useAction, useLoad } from './ui';

const SEEN = 'asnys.guide.seen';
const seenSet = (): Set<string> => { try { return new Set(JSON.parse(localStorage.getItem(SEEN) || '[]')); } catch { return new Set(); } };
const markSeen = (p: string) => { try { const s = seenSet(); s.add(p); localStorage.setItem(SEEN, JSON.stringify([...s])); } catch { /* storage unavailable */ } };
const lines = (t?: string | null) => (t || '').split('\n').map(x => x.trim()).filter(Boolean);

/** At the top of every page: what the page is for, who works on it, what to do and what not to do. Open the first time, then folded. */
export function PageGuide() {
  const { cid, can } = useSession();
  const { pathname } = useLocation();
  const path = pathname.replace(/\/$/, '') || '/';
  const act = useAction();
  const [edit, setEdit] = useState<any | null>(null);
  const { data: own, reload } = useLoad(() => q<any[]>(supabase.from('page_guides').select('*').eq('company_id', cid) as any).catch(() => [] as any[]), [cid]);
  const base = GUIDES[path];
  const o = (own || []).find(x => x.path === path);
  const [, force] = useState(0);
  const firstTime = useMemo(() => !seenSet().has(path), [path]);
  useEffect(() => { if (GUIDES[path]) markSeen(path); }, [path]);   // open on the first visit only
  if (!base && !o) return null;
  const guide: Guide = o ? { what: o.what || base?.what || '', who: o.who || base?.who || '', do: o.dos != null ? lines(o.dos) : base?.do || [], dont: o.donts != null ? lines(o.donts) : base?.dont || [] } : base!;
  return <>
    <details className="guide" key={path} open={firstTime} onToggle={e => { if (!(e.target as HTMLDetailsElement).open) { markSeen(path); force(x => x + 1); } }}>
      <summary><span aria-hidden="true">ℹ️</span><span><b>What this page is for:</b> <span className="muted">{guide.what}</span></span></summary>
      <div className="guide-body">
        <div><h4>Who works here</h4><p>{guide.who}</p></div>
        {guide.do.length > 0 && <div><h4>What to do</h4><ul>{guide.do.map((d, i) => <li key={i}><span style={{ color: 'var(--good)' }}>✓</span><span>{d}</span></li>)}</ul></div>}
        {guide.dont.length > 0 && <div><h4>What not to do</h4><ul>{guide.dont.map((d, i) => <li key={i}><span style={{ color: 'var(--bad)' }}>✗</span><span>{d}</span></li>)}</ul></div>}
        <div style={{ gridColumn: '1 / -1', display: 'flex', gap: 8, justifyContent: 'flex-end', alignItems: 'center' }}>
          {o && <span className="muted" style={{ fontSize: 12 }}>Written for your company</span>}
          {can('admin') && <button className="btn small ghost" type="button" onClick={() => setEdit({ what: guide.what, who: guide.who, dos: guide.do.join('\n'), donts: guide.dont.join('\n') })}>Edit this guide</button>}
          <button className="btn small ghost" type="button" onClick={e => { const d = (e.target as HTMLElement).closest('details'); if (d) d.open = false; markSeen(path); }}>Fold away</button>
        </div>
      </div>
    </details>
    {edit && <FormModal title="Edit the page guide" busy={act.busy} onClose={() => setEdit(null)} onSave={() => act.run(async () => {
      await q(supabase.from('page_guides').upsert({ company_id: cid, path, what: edit.what || null, who: edit.who || null, dos: edit.dos, donts: edit.donts, updated_at: new Date().toISOString() }) as any);
      setEdit(null); reload(); }, 'Guide saved for everyone')}
      danger={o && <ConfirmButton className="btn danger" label="Back to the standard guide" confirm="Remove your company's version?" onConfirm={() => act.run(async () => {
        await q(supabase.from('page_guides').delete().eq('company_id', cid).eq('path', path) as any); setEdit(null); reload(); })} />}>
      <Field label="What this page is for" id="pg-what" value={edit.what} onChange={v => setEdit({ ...edit, what: v })} required />
      <Field label="Who works here" id="pg-who" value={edit.who} onChange={v => setEdit({ ...edit, who: v })} />
      <Field label="What to do (one per line)" id="pg-do" type="textarea" value={edit.dos} onChange={v => setEdit({ ...edit, dos: v })} />
      <Field label="What not to do (one per line)" id="pg-dont" type="textarea" value={edit.donts} onChange={v => setEdit({ ...edit, donts: v })} />
      <p className="muted" style={{ margin: 0, fontSize: 13 }}>Everyone in the company sees this on the page.</p>
    </FormModal>}
  </>;
}
