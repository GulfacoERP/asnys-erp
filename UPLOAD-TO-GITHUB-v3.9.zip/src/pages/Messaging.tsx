import { makeCertificate } from '../lib/cert';
import { useEffect, useRef, useState } from 'react';
import { q, rpc, supabase, supabaseUrl } from '../lib/supabase';
import { useSession } from '../lib/session';
import { ConfirmButton, Field, Loading, PageHead, Panel, Select, useAction, useLoad, useToast } from '../components/ui';
import { FleetReminderPanel } from './AssetMore';

const LEVELS: [string, string][] = [['all', 'Everything'], ['approvals', 'Approvals only (requests to decide, and decisions on mine)'], ['off', 'Nothing']];

// ---------------------------------------------------------------- Each person: Telegram and email
export function MyChannelsPanel() {
  const { cid } = useSession();
  const act = useAction();
  const toast = useToast();
  const [waiting, setWaiting] = useState(false);
  const timer = useRef<number | null>(null);
  const { data, error, reload } = useLoad(() => rpc<any>('my_channels', { cid }), [cid]);
  useEffect(() => () => { if (timer.current) window.clearTimeout(timer.current); }, []);
  if (error) return null;   // older database
  if (!data) return <Panel title="How you are notified"><Loading loading /></Panel>;

  const poll = (tries: number) => {
    timer.current = window.setTimeout(async () => {
      try {
        const s = await rpc<string>('telegram_link_check', { cid });
        if (s === 'linked') { setWaiting(false); toast('Telegram connected. You will get your notifications there.'); reload(); return; }
        if (s === 'expired' || tries <= 0) { setWaiting(false); toast('Not connected yet. Open Telegram, press Start in the chat with the bot, then press Check again.', true); return; }
        poll(tries - 1);
      } catch (e: any) { setWaiting(false); toast(e.message, true); }
    }, 3000);
  };
  const connect = () => act.run(async () => {
    const r = await rpc<any>('telegram_link_start', { cid });
    window.open(r.url, '_blank', 'noopener');
    setWaiting(true); await rpc('telegram_link_check', { cid }).catch(() => null); poll(30);
  });
  const save = (tg: string, em: string) => act.run(async () => { await rpc('set_my_channels', { cid, p_telegram_level: tg, p_email_level: em }); reload(); }, 'Saved');

  return <Panel title="How you are notified" pad>
    <p className="muted" style={{ marginTop: 0 }}>Everything always appears here under the bell. You can also get it on your phone.</p>
    <div className="grid-form">
      <div>
        <div className="label">Telegram (private chat)</div>
        {!data.telegram_ready ? <p className="muted" style={{ margin: '4px 0' }}>Not set up for the company yet. An owner or admin adds the bot under Settings → Telegram & email.</p>
          : data.telegram_linked ? <p style={{ margin: '4px 0' }}><span className="pill good">Connected</span> {data.telegram_username ? '@' + data.telegram_username : ''}{' '}
              <ConfirmButton className="btn small ghost" label="Disconnect" confirm="Stop Telegram messages to this account?" onConfirm={() => act.run(async () => { await rpc('telegram_unlink', { cid }); reload(); }, 'Disconnected')} /></p>
          : <div style={{ margin: '4px 0' }}>
              <button className="btn primary" type="button" disabled={act.busy || waiting} onClick={connect}>{waiting ? 'Waiting for Telegram…' : 'Connect Telegram'}</button>
              {waiting && <button className="btn" type="button" style={{ marginLeft: 6 }} onClick={() => { if (timer.current) window.clearTimeout(timer.current); poll(10); }}>Check again</button>}
              <p className="muted" style={{ fontSize: 13, margin: '6px 0 0' }}>Telegram opens the chat with @{data.bot_username}. Press <b>Start</b>, then come back here; it connects within a few seconds. On a computer without Telegram, open this page on your phone.</p>
            </div>}
        {data.telegram_linked && <Select label="Send to Telegram" id="mc-tg" value={data.telegram_level} onChange={v => save(v, data.email_level)} options={LEVELS} />}
      </div>
      <div>
        <div className="label">Email</div>
        {!data.email_ready ? <p className="muted" style={{ margin: '4px 0' }}>Not set up for the company yet.</p>
          : <><p style={{ margin: '4px 0' }}>To <b>{data.email}</b></p>
            <Select label="Send by email" id="mc-em" value={data.email_level} onChange={v => save(data.telegram_level, v)} options={LEVELS} /></>}
      </div>
    </div>
    {(data.telegram_linked || data.email_ready) && data.pg_net && <div className="actions" style={{ marginTop: 10 }}>
      <button className="btn" type="button" disabled={act.busy} onClick={() => act.run(async () => { await rpc('test_my_channels', { cid }); }, 'Test sent. It should arrive within a minute.')}>Send me a test</button></div>}
  </Panel>;
}

// ---------------------------------------------------------------- Owners and admins: the company bot and email sender
export function MessagingSettingsPage() {
  const { cid, can } = useSession();
  const act = useAction();
  const [tg, setTg] = useState<any | null>(null);
  const [em, setEm] = useState<any | null>(null);
  const { data, error, loading, reload } = useLoad(async () => {
    const [t, e, ov, mail] = await Promise.all([
      q<any>(supabase.from('company_telegram').select('*').eq('company_id', cid).maybeSingle() as any).catch(() => null),
      q<any>(supabase.from('company_email').select('*').eq('company_id', cid).maybeSingle() as any).then((r: any) => r && { ...r, api_key: r.api_key || '' }).catch(() => null),
      rpc<any>('channel_overview', { cid }).catch(() => null),
      rpc<any[]>('recent_email_results', { cid }).catch(() => [] as any[]),
    ]);
    return { t, e, ov, mail };
  }, [cid]);
  if (!can()) return <><PageHead title="Telegram & email" /><Panel pad><p className="muted" style={{ margin: 0 }}>Only an owner or admin can set these up. Your own choices are under Notifications.</p></Panel><MyChannelsPanel /></>;
  const t = tg || { bot_token: data?.t?.bot_token || '', bot_username: data?.t?.bot_username || '', personal: data?.t?.personal ?? true, app_url: data?.t?.app_url || window.location.origin,
    chat_id: data?.t?.chat_id || '', enabled: data?.t?.enabled ?? false, events: data?.t?.events || ['transfer', 'request', 'decision', 'low_stock', 'fleet'] };
  const e = em || { provider: data?.e?.provider || 'microsoft', api_key: data?.e?.api_key || '', from_email: data?.e?.from_email || '', from_name: data?.e?.from_name || '', enabled: data?.e?.enabled ?? false,
    function_url: data?.e?.function_url || (supabaseUrl ? supabaseUrl + '/functions/v1/asnys-m365' : '') };
  const saveTg = () => act.run(async () => {
    if (t.bot_token && !/^\d+:[\w-]{20,}$/.test(t.bot_token.trim())) throw new Error('That does not look like a bot token. It looks like 7123456789:AAH… and comes from @BotFather.');
    await q(supabase.from('company_telegram').upsert({ company_id: cid, bot_token: t.bot_token.trim() || null, bot_username: t.bot_username.trim().replace(/^@/, '') || null, personal: t.personal,
      app_url: t.app_url.trim().replace(/\/$/, '') || window.location.origin, chat_id: t.chat_id.trim() || null, enabled: t.enabled, events: t.events, updated_at: new Date().toISOString() }) as any);
    setTg(null); reload();
  }, 'Saved');
  const saveEm = () => act.run(async () => {
    if (e.enabled && !/^\S+@\S+\.\S+$/.test(e.from_email.trim())) throw new Error('Enter the mailbox the emails come from.');
    if (e.enabled && e.provider === 'brevo' && !e.api_key.trim()) throw new Error('Enter the Brevo API key.');
    if (e.enabled && e.provider === 'microsoft' && !/^https:\/\/.+\/functions\/v1\/(asnys-m365|send-mail)$/.test(e.function_url.trim())) throw new Error('The function address should end in /functions/v1/asnys-m365.');
    await q(supabase.from('company_email').upsert({ company_id: cid, provider: e.provider, api_key: e.provider === 'brevo' ? e.api_key.trim() || null : null, from_email: e.from_email.trim() || null,
      from_name: e.from_name.trim() || null, function_url: e.provider === 'microsoft' ? e.function_url.trim() : null, enabled: e.enabled, updated_at: new Date().toISOString() }) as any);
    setEm(null); reload();
  }, 'Saved');
  const ov = data?.ov;
  return <>
    <PageHead title="Telegram & email" sub="Approvals and notifications go to each person privately on Telegram and by email, as well as in the app." />
    <Loading error={error} loading={loading && !data} />
    {data && <>
      <Panel title="1. Telegram bot" pad>
        <ol className="muted" style={{ marginTop: 0, paddingLeft: 18 }}>
          <li>In Telegram, open <b>@BotFather</b>, send <code>/newbot</code>, give it a name (e.g. Gulfaco Asnys) and a username ending in <code>bot</code>.</li>
          <li>Copy the token BotFather gives you and the bot's username into the boxes below, and save.</li>
          <li>In Supabase, turn on the <b>pg_net</b> extension (Database → Extensions).</li>
          <li>Each person then opens <b>Notifications</b> in Asnys and presses <b>Connect Telegram</b>.</li>
        </ol>
        <div className="grid-form">
          <Field label="Bot token" id="ms-tok" value={t.bot_token} onChange={v => setTg({ ...t, bot_token: v })} placeholder="7123456789:AAH…" />
          <Field label="Bot username" id="ms-user" value={t.bot_username} onChange={v => setTg({ ...t, bot_username: v })} placeholder="gulfaco_asnys_bot" />
          <Field label="App address (for links in messages)" id="ms-url" value={t.app_url} onChange={v => setTg({ ...t, app_url: v })} />
        </div>
        <label className="check"><input type="checkbox" checked={t.personal} onChange={x => setTg({ ...t, personal: x.target.checked })} /> Send private messages to people who connect</label>
        <details style={{ marginTop: 8 }}><summary className="muted" style={{ cursor: 'pointer' }}>Also post some alerts to a group (optional)</summary>
          <div className="grid-form" style={{ marginTop: 8 }}><Field label="Group chat id" id="ms-chat" value={t.chat_id} onChange={v => setTg({ ...t, chat_id: v })} placeholder="-1001234567890" /></div>
          <label className="check"><input type="checkbox" checked={t.enabled} onChange={x => setTg({ ...t, enabled: x.target.checked })} /> Post transfers, requests, low stock and fleet alerts to the group too</label>
        </details>
        <div className="actions" style={{ marginTop: 10 }}><button className="btn primary" type="button" disabled={act.busy || !tg} onClick={saveTg}>Save</button></div>
      </Panel>
      <Panel title="2. Email" pad>
        <Select label="Send emails through" id="ms-prov" value={e.provider} onChange={v => setEm({ ...e, provider: v })} options={[['microsoft', 'Our Microsoft 365 (from a Gulfaco mailbox)'], ['brevo', 'Brevo']]} />
        {e.provider === 'microsoft' ? <>
          <ol className="muted" style={{ paddingLeft: 18 }}>
            <li><b>Microsoft 365:</b> pick the mailbox emails come from, e.g. <code>notifications@gulfaco.com</code> (a shared mailbox is free).</li>
            <li><b>Azure portal</b> (portal.azure.com, as a Microsoft 365 admin) → <b>App registrations → New registration</b>, name it Asnys ERP, Register. Copy the <b>Application (client) ID</b> and <b>Directory (tenant) ID</b>.</li>
            <li>In it: <b>API permissions → Add a permission → Microsoft Graph → Application permissions</b> → tick <b>Mail.Send</b> (and <b>Files.ReadWrite.All</b> for OneDrive backups) → Add, then <b>Grant admin consent</b>.</li>
            <li>Press <b>Create 10-year certificate</b> below. Upload the downloaded <code>.cer</code> file in Azure under <b>Certificates &amp; secrets → Certificates → Upload certificate</b>.</li>
            <li><b>Supabase → Edge Functions → Secrets</b>: add <code>MS_TENANT_ID</code>, <code>MS_CLIENT_ID</code>, <code>MS_CERT_THUMBPRINT</code> and <code>MS_CERT_KEY</code> (the private key shown below — paste it only there).</li>
            <li><b>Supabase → Edge Functions</b>: deploy the <code>asnys-m365</code> function from the update, and switch <b>Verify JWT off</b> in its settings.</li>
            <li>Recommended: ask the Microsoft 365 admin to limit the app to the notifications mailbox (an <i>application access policy</i>).</li>
            <li>Fill in below, tick Send emails, save, then press <b>Send me a test email</b>.</li>
          </ol>
          <div className="grid-form">
            <Field label="Send from (mailbox)" id="ms-from" value={e.from_email} onChange={v => setEm({ ...e, from_email: v })} placeholder="notifications@gulfaco.com" />
            <Field label="Sender name" id="ms-name" value={e.from_name} onChange={v => setEm({ ...e, from_name: v })} placeholder="Gulfaco Limited" />
            <Field label="asnys-m365 function address" id="ms-fn" value={e.function_url} onChange={v => setEm({ ...e, function_url: v })} />
          </div>
          <CertificateBox cid={cid} e={data?.e} onDone={reload} />
        </> : <>
          <ol className="muted" style={{ paddingLeft: 18 }}>
            <li>In Brevo: <b>Settings → Senders, domains → Senders → Add a sender</b> and confirm it with the code Brevo emails to it.</li>
            <li><b>SMTP & API → API keys → Generate a new API key</b>, copy it.</li>
          </ol>
          <div className="grid-form">
            <Field label="Brevo API key" id="ms-key" type="password" value={e.api_key} onChange={v => setEm({ ...e, api_key: v })} placeholder="xkeysib-…" />
            <Field label="Sender address" id="ms-from" value={e.from_email} onChange={v => setEm({ ...e, from_email: v })} placeholder="no-reply@gulfaco.com" />
            <Field label="Sender name" id="ms-name" value={e.from_name} onChange={v => setEm({ ...e, from_name: v })} placeholder="Gulfaco Limited" />
          </div>
        </>}
        <label className="check"><input type="checkbox" checked={e.enabled} onChange={x => setEm({ ...e, enabled: x.target.checked })} /> <b>Send emails</b> (approvals by default; each person can change it)</label>
        <div className="actions" style={{ marginTop: 10 }}>
          <button className="btn primary" type="button" disabled={act.busy || !em} onClick={saveEm}>Save</button>
          {data.e?.enabled && !em && <button className="btn" type="button" disabled={act.busy} onClick={() => act.run(async () => { const to = await rpc<string>('test_company_email', { cid }); setTimeout(() => reload(), 6000); return void to; }, 'Test email sent. Check your inbox (and Junk) in a minute; the result appears below.')}>Send me a test email</button>}
        </div>
        {data.mail && data.mail.length > 0 && <div className="scroll" style={{ marginTop: 10 }}><table>
          <thead><tr><th>Sent</th><th>To</th><th>Subject</th><th>Result</th></tr></thead>
          <tbody>{data.mail.map((m: any, i: number) => <tr key={i}><td className="num" style={{ fontSize: 13 }}>{String(m.sent_at).slice(0, 16).replace('T', ' ')}</td><td style={{ fontSize: 13 }}>{m.to_email}</td>
            <td style={{ fontSize: 13 }}>{m.title}</td>
            <td style={{ fontSize: 13 }}>{m.status_code == null ? <span className="muted">waiting</span> : m.status_code < 300 ? <span className="pill good">Sent</span> : <><span className="pill bad">Failed {m.status_code}</span> <span className="muted">{m.error}</span></>}</td></tr>)}</tbody></table></div>}
      </Panel>
      {ov && <Panel title={`Who is connected: ${ov.telegram_linked} of ${ov.members} on Telegram`}>
        <div className="scroll"><table><thead><tr><th>Person</th><th>Role</th><th>Telegram</th><th>Email</th></tr></thead>
          <tbody>{ov.people.map((p: any) => <tr key={p.email}><td>{p.email}</td><td style={{ textTransform: 'capitalize' }}>{String(p.role).replace('_', ' ')}</td>
            <td>{p.telegram ? <span className="pill good">{p.telegram_level === 'all' ? 'Everything' : p.telegram_level === 'approvals' ? 'Approvals' : 'Off'}</span> : <span className="muted">Not connected</span>}</td>
            <td>{p.email_level === 'all' ? 'Everything' : p.email_level === 'approvals' ? 'Approvals' : 'Off'}</td></tr>)}</tbody></table></div>
        <p className="muted body" style={{ margin: 0, fontSize: 13 }}>Sent in the last 24 hours: {Object.entries(ov.last_24h || {}).map(([k, n]) => `${n} by ${k}`).join(', ') || 'none'}. Ask people to open Notifications and press Connect Telegram.</p>
      </Panel>}
      <FleetReminderPanel />
      <MyChannelsPanel />
    </>}
  </>;
}

/** Makes the Microsoft 365 sign-in certificate in the browser: the public part for Azure, the private key for Supabase only. */
function CertificateBox({ cid, e, onDone }: { cid: string; e: any; onDone: () => void }) {
  const { company } = useSession();
  const act = useAction();
  const [made, setMade] = useState<{ key: string; thumb: string; expires: string } | null>(null);
  const [secretExp, setSecretExp] = useState<string>(e?.secret_expires || '');
  const record = async (patch: any) => {
    const { data: row } = await supabase.from('company_email').select('company_id').eq('company_id', cid).maybeSingle();
    if (row) await q(supabase.from('company_email').update(patch).eq('company_id', cid) as any);
    else await q(supabase.from('company_email').insert({ company_id: cid, provider: 'microsoft', enabled: false, ...patch }) as any);
  };
  const create = () => act.run(async () => {
    const c = await makeCertificate(`${company?.name || 'Company'} Asnys ERP`, 10);
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([c.certificateDer as BlobPart], { type: 'application/pkix-cert' }));
    a.download = 'asnys-erp-microsoft365.cer'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    await record({ cert_thumbprint: c.thumbprint, cert_expires: c.expires });
    setMade({ key: c.privateKeyPem, thumb: c.thumbprint, expires: c.expires }); onDone();
  }, 'Certificate made — upload the .cer to Azure');
  return <div style={{ border: '1px solid var(--line)', borderRadius: 10, padding: 12, marginTop: 12 }}>
    <b>Microsoft 365 key</b>
    <p className="muted" style={{ margin: '4px 0 8px', fontSize: 13 }}>
      {e?.cert_expires ? <>Certificate <code>{(e.cert_thumbprint || '').slice(0, 12)}…</code> valid until <b>{e.cert_expires}</b>. You are reminded 30 days before it expires.</> : 'No certificate recorded yet. A certificate lasts 10 years; a client secret lasts at most 2.'}</p>
    {!made ? <button className="btn" type="button" disabled={act.busy} onClick={create}>{e?.cert_expires ? 'Make a new certificate' : 'Create 10-year certificate'}</button> : <>
      <p style={{ margin: '0 0 6px', fontSize: 13 }}><span className="pill warn">Shown once</span> Copy these into <b>Supabase → Edge Functions → Secrets</b> now. The private key is not saved anywhere else; if you lose it, make a new certificate.</p>
      <div className="grid-form">
        <div className="field"><label>MS_CERT_THUMBPRINT</label><input readOnly value={made.thumb} onFocus={x => x.target.select()} /></div>
        <div className="field"><label>Valid until</label><input readOnly value={made.expires} /></div>
      </div>
      <div className="field"><label>MS_CERT_KEY (private key — paste only into Supabase secrets)</label>
        <textarea readOnly value={made.key} rows={6} style={{ fontFamily: 'monospace', fontSize: 11 }} onFocus={x => x.target.select()} /></div>
      <div className="actions"><button className="btn small" type="button" onClick={() => navigator.clipboard?.writeText(made.key)}>Copy private key</button>
        <button className="btn small ghost" type="button" onClick={() => setMade(null)}>I have saved it — hide</button></div></>}
    <details style={{ marginTop: 8 }}><summary className="muted" style={{ cursor: 'pointer', fontSize: 13 }}>Using a client secret instead?</summary>
      <div className="filters" style={{ marginTop: 6 }}>
        <Field label="Client secret expires on" id="ms-secexp" type="date" value={secretExp} onChange={setSecretExp} />
        <button className="btn small" type="button" style={{ marginBottom: 2 }} disabled={act.busy} onClick={() => act.run(async () => { await record({ secret_expires: secretExp || null }); onDone(); }, 'Saved — you will be reminded 30 days before')}>Save date</button>
      </div>
      <p className="muted" style={{ fontSize: 12, margin: 0 }}>Put it in Supabase secrets as <code>MS_CLIENT_SECRET</code>. If both are set, the certificate is used.</p>
    </details>
  </div>;
}
