import { useState } from 'react';
import { q, rpc, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { MODULES, ModuleIcon } from '../lib/modules';
import { ConfirmButton, Empty, Field, FormModal, Loading, PageHead, Panel, useAction, useLoad } from '../components/ui';

/** The built-in right each module's pages need in the database. */
const MODULE_RIGHT: Record<string, string | null> = {
  sales: 'sales', accounts: 'accountant', crm: 'sales', hr: 'hr', inventory: 'store', projects: 'project_manager', contracts: 'project_manager',
  assets: 'store', fleet: 'transport', purchasing: 'store', service: null, settings: null, hse: 'hse', mywork: null,
};
const RIGHT_NAMES: Record<string, string> = { accountant: 'Accountant', sales: 'Sales', hr: 'HR', project_manager: 'Project manager', store: 'Storekeeper', transport: 'Transport officer', hse: 'HSE officer' };
const GRANTABLE = Object.keys(RIGHT_NAMES);

/** The rights a set of ticked pages needs. */
function rightsFor(pages: string[]) {
  const out = new Set<string>();
  for (const m of MODULES) for (const p of m.pages) {
    if (!pages.includes(p.to)) continue;
    const def = MODULE_RIGHT[m.id];
    const r = p.roles?.length ? (p.roles.includes(def as any) ? def : p.roles.find(x => GRANTABLE.includes(x))) : def;
    if (r && GRANTABLE.includes(r)) out.add(r);
  }
  return [...out];
}

export function RolesPage() {
  const { cid, can } = useSession();
  const act = useAction();
  const [edit, setEdit] = useState<any | null>(null);
  const { data, error, loading, reload } = useLoad(async () => ({
    roles: await q<any[]>(supabase.from('custom_roles').select('*').eq('company_id', cid).order('name') as any),
    team: await q<any[]>(supabase.from('memberships').select('user_id,email,role,custom_role_ids').eq('company_id', cid).order('email') as any),
  }), [cid]);
  if (!can('owner')) return <><PageHead title="Roles" /><Empty>Only an owner or admin can set up roles.</Empty></>;
  if (!data) return <Loading error={error && 'Run the v3.4 database update first. ' + error} loading={loading} />;

  const save = () => act.run(async () => {
    const pages: string[] = edit.pages;
    if (!pages.length) throw new Error('Tick at least one page.');
    const grants = rightsFor(pages);
    const mods = MODULES.filter(m => m.pages.some(p => pages.includes(p.to)));
    const approve = rightsFor(mods.filter(m => edit.approve.includes(m.id)).flatMap(m => m.pages.filter(p => pages.includes(p.to)).map(p => p.to)));
    const voids = rightsFor(mods.filter(m => edit.void.includes(m.id)).flatMap(m => m.pages.filter(p => pages.includes(p.to)).map(p => p.to)));
    const row = { name: edit.name.trim(), description: edit.description || null, pages, grants, approve, void_grants: voids };
    if (edit.id) await q(supabase.from('custom_roles').update(row).eq('id', edit.id) as any);
    else await q(supabase.from('custom_roles').insert({ ...row, company_id: cid }) as any);
    setEdit(null); reload();
  }, 'Role saved');
  const toggleMember = (m: any, roleId: string, on: boolean) => act.run(async () => {
    const ids = new Set<string>(m.custom_role_ids || []); on ? ids.add(roleId) : ids.delete(roleId);
    await rpc('set_member_custom_roles', { cid, p_user: m.user_id, p_roles: [...ids] }); reload();
  }, on ? 'Role given' : 'Role removed');
  const open = (r?: any) => {
    const approve: string[] = [], vd: string[] = [];
    if (r) for (const m of MODULES) { const r0 = MODULE_RIGHT[m.id]; if (r0 && r.approve.includes(r0)) approve.push(m.id); if (r0 && r.void_grants.includes(r0)) vd.push(m.id); }
    setEdit(r ? { ...r, description: r.description || '', approve, void: vd } : { name: '', description: '', pages: [], approve: [], void: [] });
  };
  const people = data.team.filter(m => !['owner', 'admin'].includes(m.role));

  return <>
    <PageHead title="Roles" sub="Make your own roles: tick the modules and pages they open, and whether they can approve and void there.">
      <button className="btn primary" type="button" onClick={() => open()}>New role</button>
    </PageHead>
    <Panel title="Your roles">
      {data.roles.length ? <div className="scroll"><table>
        <thead><tr><th>Role</th><th>Opens</th><th>Same rights as</th><th>Approves as</th><th>Voids as</th><th className="r">People</th><th></th></tr></thead>
        <tbody>{data.roles.map(r => { const mods = MODULES.filter(m => m.pages.some(p => r.pages.includes(p.to)));
          return <tr key={r.id}><td><b>{r.name}</b>{r.description && <><br /><span className="muted" style={{ fontSize: 12 }}>{r.description}</span></>}</td>
            <td className="wrap-cell">{mods.map(m => <span key={m.id} className="pill" style={{ marginRight: 4 }}>{m.name} ({m.pages.filter(p => r.pages.includes(p.to)).length})</span>)}</td>
            <td>{r.grants.map((g: string) => RIGHT_NAMES[g]).join(', ') || <span className="muted">View and use own work only</span>}</td>
            <td>{r.approve.map((g: string) => RIGHT_NAMES[g]).join(', ') || <span className="muted">No</span>}</td>
            <td>{r.void_grants.map((g: string) => RIGHT_NAMES[g]).join(', ') || <span className="muted">No</span>}</td>
            <td className="r num">{data.team.filter(m => (m.custom_role_ids || []).includes(r.id)).length}</td>
            <td className="r"><button className="btn small" type="button" onClick={() => open(r)}>Edit</button></td></tr>; })}</tbody>
      </table></div> : <Empty>No custom roles yet. Example: “Stores &amp; Fleet officer” with Inventory and Fleet ticked, allowed to approve but not void.</Empty>}
    </Panel>
    {data.roles.length > 0 && <Panel title="Who has which role">
      {people.length ? <div className="scroll"><table>
        <thead><tr><th>Person</th><th>Main role</th>{data.roles.map(r => <th key={r.id} style={{ textAlign: 'center' }}>{r.name}</th>)}</tr></thead>
        <tbody>{people.map(m => <tr key={m.user_id}><td>{m.email}</td><td>{m.role.replace('_', ' ')}</td>
          {data.roles.map(r => <td key={r.id} style={{ textAlign: 'center' }}><input type="checkbox" aria-label={`${m.email} has ${r.name}`} disabled={act.busy}
            checked={(m.custom_role_ids || []).includes(r.id)} onChange={e => toggleMember(m, r.id, e.target.checked)} /></td>)}</tr>)}</tbody>
      </table></div> : <Empty>Invite people under Settings &amp; team first.</Empty>}
      <div className="body muted" style={{ fontSize: 13 }}>A person keeps their main role and gets everything their custom roles add. Someone whose main role is <b>Staff</b> sees only the pages ticked in their roles, plus My work. Owners and admins always see everything. Changes apply the next time the person opens the app.</div>
    </Panel>}
    {edit && <FormModal title={edit.id ? `Edit ${edit.name}` : 'New role'} wide busy={act.busy} onClose={() => setEdit(null)} onSave={save}
      danger={edit.id && <ConfirmButton className="btn danger" label="Delete role" confirm="Delete this role? People who have it lose what it gave them." onConfirm={() => act.run(async () => { await q(supabase.from('custom_roles').delete().eq('id', edit.id) as any); setEdit(null); reload(); }, 'Role deleted')} />}>
      <div className="grid-form">
        <Field label="Role name" id="rl-name" value={edit.name} onChange={v => setEdit({ ...edit, name: v })} placeholder="e.g. Stores & Fleet officer" required />
        <Field label="What it is for (optional)" id="rl-desc" value={edit.description} onChange={v => setEdit({ ...edit, description: v })} />
      </div>
      <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
        {MODULES.filter(m => m.id !== 'mywork').map(m => {
          const pages = m.pages.filter(p => !(p.roles?.length === 1 && p.roles[0] === 'owner'));
          const on = pages.filter(p => edit.pages.includes(p.to));
          const all = on.length === pages.length;
          const setPages = (list: string[]) => setEdit({ ...edit, pages: list });
          const right = MODULE_RIGHT[m.id];
          return <div key={m.id} style={{ border: '1px solid var(--line)', borderRadius: 10, padding: 10, background: on.length ? 'var(--accent-soft, rgba(29,107,85,.06))' : undefined }}>
            <label className="check" style={{ fontWeight: 600 }}><input type="checkbox" checked={all} ref={el => { if (el) el.indeterminate = on.length > 0 && !all; }}
              onChange={e => setPages(e.target.checked ? [...new Set([...edit.pages, ...pages.map(p => p.to)])] : edit.pages.filter((x: string) => !pages.some(p => p.to === x)))} />
              <span style={{ color: m.hue, display: 'inline-flex' }}><ModuleIcon id={m.id} size={18} /></span> {m.name}</label>
            <div style={{ display: 'grid', gap: 2, margin: '6px 0 0 24px', fontSize: 13 }}>
              {pages.map(p => <label key={p.to} className="check"><input type="checkbox" checked={edit.pages.includes(p.to)}
                onChange={e => setPages(e.target.checked ? [...edit.pages, p.to] : edit.pages.filter((x: string) => x !== p.to))} /> {p.label}</label>)}
            </div>
            {on.length > 0 && right && <div style={{ display: 'flex', gap: 12, margin: '8px 0 0 24px', fontSize: 13 }}>
              <label className="check"><input type="checkbox" checked={edit.approve.includes(m.id)} onChange={e => setEdit({ ...edit, approve: e.target.checked ? [...edit.approve, m.id] : edit.approve.filter((x: string) => x !== m.id) })} /> Can approve</label>
              <label className="check"><input type="checkbox" checked={edit.void.includes(m.id)} onChange={e => setEdit({ ...edit, void: e.target.checked ? [...edit.void, m.id] : edit.void.filter((x: string) => x !== m.id) })} /> Can void</label>
            </div>}
          </div>;
        })}
      </div>
      <p className="muted" style={{ margin: 0, fontSize: 13 }}>
        This role will have the same rights as: <b>{rightsFor(edit.pages).map(g => RIGHT_NAMES[g]).join(', ') || 'Staff (own work only)'}</b>. My work (payslips, leave, expenses, requests) is always included.
        “Can approve” lets them approve the steps in Approval rules set for that right; “Can void” lets them void entries made in error in that module.</p>
    </FormModal>}
  </>;
}
