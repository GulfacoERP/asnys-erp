import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { q, rpc, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { cedis, money, r2, today } from '../lib/format';
import { readSheet, toIsoDate, toNum } from '../lib/sheet';
import { bogRate, useBogFill } from '../components/docs';
import { ConfirmButton, Empty, Field, FormModal, Loading, PageHead, Panel, Select, useAction, useLoad } from '../components/ui';

/** Cash, MoMo and bank accounts to receive into or pay from. */
export function useBankAccounts(cid: string) {
  return useLoad(() => q<any[]>(supabase.from('accounts').select('id,code,name,system_key').eq('company_id', cid).eq('is_bank', true).eq('active', true).order('code') as any), [cid]);
}
const bankOpts = (banks: any[] | null | undefined) => (banks || []).map(b => [b.id, `${b.code} ${b.name}`] as [string, string]);

// ---------------------------------------------------------------- Receive payment (one receipt over several invoices)
export function ReceivePaymentPage() {
  const { cid } = useSession();
  const act = useAction();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const { data: banks } = useBankAccounts(cid);
  const { data: customers } = useLoad(() => q<any[]>(supabase.from('customers').select('id,name').eq('company_id', cid).order('name') as any), [cid]);
  const [f, setF] = useState({ customer: params.get('customer') || '', date: today(), account: '', amount: '', reference: '', memo: '', currency: 'GHS', rate: '' });
  const [alloc, setAlloc] = useState<Record<string, string>>({});
  const [whts, setWhts] = useState<Record<string, string>>({});
  const { data: open, reload } = useLoad(() => f.customer ? rpc<any>('customer_open_items', { cid, p_customer: f.customer }) : Promise.resolve(null), [cid, f.customer]);
  const { data: recent, reload: reloadRecent } = useLoad(() => q<any[]>(supabase.from('customer_receipts').select('*, customer:customers(name)').eq('company_id', cid).order('created_at', { ascending: false }).limit(25) as any).catch(() => [] as any[]), [cid]);
  const [voiding, setVoiding] = useState<any | null>(null);
  useEffect(() => { if (banks?.length && !f.account) setF(x => ({ ...x, account: (banks.find(b => b.system_key === 'bank') || banks[0]).id })); }, [banks]);
  useEffect(() => { setAlloc({}); setWhts({}); }, [f.customer, f.currency]);
  const bogHint = useBogFill(f.currency, f.date, f.rate, r => setF(x => ({ ...x, rate: r })));
  const invs: any[] = (open?.invoices || []).filter((i: any) => i.currency === f.currency);
  const credits: any[] = open?.credits || [];
  const applied = Object.values(alloc).reduce((s, v) => s + (Number(v) || 0), 0);
  const amount = Number(f.amount) || 0;
  const autoFill = (total: number) => {
    let left = total; const next: Record<string, string> = {};
    for (const i of invs) { if (left <= 0) break; const a = Math.min(left, Number(i.open)); next[i.id] = String(r2(a)); left = r2(left - a); }
    setAlloc(next);
  };
  const save = () => act.run(async () => {
    if (!f.customer) throw new Error('Choose the customer.');
    if (!(amount > 0)) throw new Error('Enter the amount received.');
    if (applied > amount + 0.001) throw new Error('You applied more than you received.');
    if (f.currency !== 'GHS' && !(Number(f.rate) > 0)) throw new Error('Type in the exchange rate on the day received.');
    await rpc('receive_payment', { cid, p_customer: f.customer, p_date: f.date, p_account: f.account, p_amount: amount,
      p_allocs: [...new Set([...Object.keys(alloc), ...Object.keys(whts)])].map(invoice_id => ({ invoice_id, amount: Number(alloc[invoice_id]) || 0, wht: Number(whts[invoice_id]) || 0 })).filter(x => x.amount + x.wht > 0),
      p_reference: f.reference || null, p_memo: f.memo || null, p_currency: f.currency, p_rate: f.currency === 'GHS' ? null : Number(f.rate) });
    setF({ ...f, amount: '', reference: '', memo: '' }); setAlloc({}); reload(); reloadRecent();
  }, amount > applied ? `Payment recorded; ${cedis(amount - applied)} kept as the customer's credit` : 'Payment recorded');

  return <>
    <PageHead title="Receive payment" sub="One cheque, transfer or MoMo payment can pay several invoices. Anything extra is kept as the customer's credit for later invoices.">
      <Link className="btn" to="/sales-receipt">Sales receipt</Link>
    </PageHead>
    <Panel pad>
      <div className="grid-form">
        <Select label="Customer" id="rp-c" value={f.customer} onChange={v => setF({ ...f, customer: v })} options={[['', 'Choose…'], ...(customers || []).map(c => [c.id, c.name] as [string, string])]} />
        <Field label="Date received" id="rp-d" type="date" value={f.date} onChange={v => setF({ ...f, date: v })} required />
        <Select label="Deposit to" id="rp-a" value={f.account} onChange={v => setF({ ...f, account: v })} options={bankOpts(banks)} />
        <Field label={`Amount received (${f.currency})`} id="rp-amt" type="number" step="0.01" min="0" value={f.amount} onChange={v => { setF({ ...f, amount: v }); autoFill(Number(v) || 0); }} required />
        <Field label="Reference (cheque, transfer or MoMo ID)" id="rp-ref" value={f.reference} onChange={v => setF({ ...f, reference: v })} />
        <Select label="Currency" id="rp-cur" value={f.currency} onChange={v => setF({ ...f, currency: v })} options={[...new Set(['GHS', ...(open?.invoices || []).map((i: any) => i.currency)])].map(c => [c, c] as [string, string])} />
        {f.currency !== 'GHS' && <div><Field label={`Rate on the day (GH₵ per ${f.currency})`} id="rp-rate" type="number" step="0.000001" min="0" value={f.rate} onChange={v => setF({ ...f, rate: v })} required /><span className="muted" style={{ fontSize: 12 }}>{bogHint}</span></div>}
      </div>
    </Panel>
    {f.customer && !open && <Loading loading />}
    {f.customer && open && <Panel title="Outstanding invoices" actions={invs.length > 0 && <button className="btn small" type="button" onClick={() => { const t = invs.reduce((s, i) => s + Number(i.open), 0); setF({ ...f, amount: String(r2(t)) }); autoFill(t); }}>Pay all</button>}>
      {invs.length ? <div className="scroll"><table>
        <thead><tr><th style={{ width: 28 }}></th><th>Invoice</th><th>Reference / PO</th><th>Due</th><th className="r">Open ({f.currency})</th><th className="r">Payment</th><th className="r">WHT deducted</th></tr></thead>
        <tbody>{invs.map(i => { const on = Number(alloc[i.id]) > 0; return <tr key={i.id}>
          <td><input type="checkbox" aria-label={`Pay ${i.number}`} checked={on} onChange={e => { const w = Number(i.wht_amount) > 0 && Number(i.open) >= Number(i.wht_amount) ? Number(i.wht_amount) : 0;
            setAlloc({ ...alloc, [i.id]: e.target.checked ? String(r2(Number(i.open) - w)) : '' }); setWhts({ ...whts, [i.id]: e.target.checked && w ? String(w) : '' }); }} /></td>
          <td className="num">{i.number}<br /><span className="muted" style={{ fontSize: 12 }}>{i.invoice_date}</span></td>
          <td style={{ fontSize: 13 }}>{[i.reference, i.customer_po].filter(Boolean).join(' · ')}{Number(i.wht_amount) > 0 && <><br /><span className="muted">WHT expected {money(i.wht_amount)}</span></>}</td>
          <td className="num" style={{ color: i.due_date && i.due_date < today() ? 'var(--bad)' : undefined }}>{i.due_date || ''}</td>
          <td className="r num">{money(i.open)}</td>
          <td className="r"><input aria-label={`Amount for ${i.number}`} type="number" step="0.01" min="0" max={i.open} value={alloc[i.id] || ''} onChange={e => setAlloc({ ...alloc, [i.id]: e.target.value })} style={{ width: 120, textAlign: 'right' }} /></td>
          <td className="r"><input aria-label={`WHT for ${i.number}`} type="number" step="0.01" min="0" value={whts[i.id] || ''} onChange={e => setWhts({ ...whts, [i.id]: e.target.value })} style={{ width: 100, textAlign: 'right' }} placeholder="0" /></td></tr>; })}</tbody>
      </table></div> : <Empty>No open invoices in {f.currency} for this customer. A payment saved now is kept as their credit (a deposit) and can be applied later.</Empty>}
      <div className="totals"><span className="muted">Amount received</span><span className="num">{money(amount)}</span>
        <span className="muted">Applied to invoices</span><span className="num">{money(applied)}</span>
        <span className="grand">{amount - applied >= 0 ? 'Kept as credit' : 'Over-applied'}</span><span className="grand num" style={{ color: amount - applied < 0 ? 'var(--bad)' : undefined }}>{money(amount - applied)}</span></div>
      <div className="body"><Field label="Memo (optional)" id="rp-memo" value={f.memo} onChange={v => setF({ ...f, memo: v })} /></div>
      <div className="body actions" style={{ justifyContent: 'flex-end', borderTop: '1px solid var(--line)' }}>
        <button className="btn primary" type="button" disabled={act.busy} onClick={save}>Save payment</button></div>
    </Panel>}
    {f.customer && credits.length > 0 && <Panel title="Unused credit">
      <div className="scroll"><table><thead><tr><th>Receipt</th><th>Date</th><th className="r">Credit left</th><th></th></tr></thead>
        <tbody>{credits.map(c => <CreditRow key={c.id} c={c} invs={(open?.invoices || []).filter((i: any) => i.currency === c.currency)} onDone={() => { reload(); reloadRecent(); }} />)}</tbody></table></div>
    </Panel>}
    <Panel title="Recent payments received">
      {recent && recent.length ? <div className="scroll"><table>
        <thead><tr><th>Receipt</th><th>Date</th><th>Customer</th><th>Reference</th><th className="r">Amount</th><th className="r">Credit left</th><th></th></tr></thead>
        <tbody>{recent.map(r => <tr key={r.id} style={r.status === 'voided' ? { opacity: .55 } : undefined}><td className="num">{r.number}</td><td className="num">{r.receipt_date}</td><td>{r.customer?.name}</td><td>{r.reference}</td>
          <td className="r num">{r.currency !== 'GHS' ? r.currency + ' ' : ''}{money(r.amount)}</td><td className="r num">{Number(r.unapplied) ? money(r.unapplied) : ''}</td>
          <td className="r">{r.status === 'voided' ? <span className="pill bad">Voided</span> : <button className="btn small ghost" type="button" onClick={() => setVoiding({ r, reason: '' })}>Void</button>}</td></tr>)}</tbody>
      </table></div> : <Empty>No payments recorded here yet.</Empty>}
    </Panel>
    {voiding && <FormModal title={`Void ${voiding.r.number}`} submit="Void" busy={act.busy} onClose={() => setVoiding(null)}
      onSave={() => act.run(async () => { await rpc('void_customer_receipt', { p_receipt: voiding.r.id, p_reason: voiding.reason }); setVoiding(null); reload(); reloadRecent(); }, 'Voided: the invoices are open again and a reversing entry was posted')}>
      <p style={{ margin: 0 }}>The invoices it paid become unpaid again, and a reversing journal is posted. The receipt stays on record, marked voided.</p>
      <Field label="Why?" id="vr-why" value={voiding.reason} onChange={v => setVoiding({ ...voiding, reason: v })} required />
    </FormModal>}
    <p className="muted" style={{ fontSize: 13 }}>WHT deducted is booked to 1285 Withholding tax credit; keep the customer's WHT certificate. <button className="btn ghost small" type="button" onClick={() => nav('/invoices')}>Invoices</button></p>
  </>;
}

function CreditRow({ c, invs, onDone }: { c: any; invs: any[]; onDone: () => void }) {
  const act = useAction();
  const [inv, setInv] = useState('');
  return <tr><td className="num">{c.number}</td><td className="num">{c.receipt_date}</td><td className="r num">{c.currency !== 'GHS' ? c.currency + ' ' : ''}{money(c.unapplied)}</td>
    <td className="r"><span className="actions" style={{ justifyContent: 'flex-end' }}>
      <select aria-label="Invoice to apply the credit to" value={inv} onChange={e => setInv(e.target.value)}><option value="">Apply to…</option>{invs.map(i => <option key={i.id} value={i.id}>{i.number} ({money(i.open)})</option>)}</select>
      <button className="btn small" type="button" disabled={!inv || act.busy} onClick={() => act.run(async () => { await rpc('apply_customer_credit', { p_receipt: c.id, p_invoice: inv, p_amount: Number(c.unapplied) }); setInv(''); onDone(); }, 'Credit applied')}>Apply</button></span></td></tr>;
}

// ---------------------------------------------------------------- Pay bills (several at once)
export function PayBillsPage() {
  const { cid, company } = useSession();
  const act = useAction();
  const { data: banks } = useBankAccounts(cid);
  const [f, setF] = useState({ date: today(), account: '', reference: '', supplier: '', due: '' });
  const [pick, setPick] = useState<Record<string, { pay: string; wht: string; rate: string }>>({});
  const { data, reload } = useLoad(async () => ({
    bills: await q<any[]>(supabase.from('bills').select('id,number,bill_date,due_date,total,amount_paid,currency,exchange_rate,supplier_ref,supplier:suppliers(id,name,wht_rate)').eq('company_id', cid).eq('status', 'posted').order('due_date', { ascending: true, nullsFirst: false }) as any),
    batches: await q<any[]>(supabase.from('bill_payment_batches').select('*').eq('company_id', cid).order('created_at', { ascending: false }).limit(15) as any).catch(() => [] as any[]),
  }), [cid]);
  useEffect(() => { if (banks?.length && !f.account) setF(x => ({ ...x, account: (banks.find(b => b.system_key === 'bank') || banks[0]).id })); }, [banks]);
  if (!data) return <Loading loading />;
  const list = data.bills.filter(b => (!f.supplier || b.supplier?.id === f.supplier) && (!f.due || (b.due_date || b.bill_date) <= f.due));
  const suppliers = [...new Map(data.bills.map(b => [b.supplier?.id, b.supplier])).values()].filter(Boolean) as any[];
  const open = (b: any) => r2(Number(b.total) - Number(b.amount_paid));
  const toggle = (b: any, on: boolean) => {
    const next = { ...pick };
    if (on) { const wr = Number(b.supplier?.wht_rate || 0); const wht = wr ? r2(open(b) * wr / 100) : 0; next[b.id] = { pay: String(r2(open(b) - wht)), wht: wht ? String(wht) : '', rate: '' };
      if (b.currency !== 'GHS') bogRate(cid, b.currency, f.date).then(x => x && setPick(pk => pk[b.id] && !pk[b.id].rate ? { ...pk, [b.id]: { ...pk[b.id], rate: String(x.rate) } } : pk)); }
    else delete next[b.id];
    setPick(next);
  };
  const chosen = Object.entries(pick);
  const total = chosen.reduce((s, [id, p]) => { const b = data.bills.find(x => x.id === id); return s + (Number(p.pay) || 0) * (b?.currency === 'GHS' ? 1 : Number(p.rate) || Number(b?.exchange_rate) || 1); }, 0);
  const save = () => act.run(async () => {
    if (!chosen.length) throw new Error('Tick the bills to pay.');
    for (const [id, p] of chosen) { const b = data.bills.find(x => x.id === id)!; if (b.currency !== 'GHS' && !(Number(p.rate) > 0)) throw new Error(`Type in today's rate for ${b.number} (${b.currency}).`); }
    await rpc('pay_bills', { cid, p_date: f.date, p_account: f.account, p_reference: f.reference || null,
      p_items: chosen.map(([bill_id, p]) => ({ bill_id, amount: Number(p.pay) || 0, wht: Number(p.wht) || 0, rate: Number(p.rate) || null })) });
    setPick({}); reload();
  }, `${chosen.length} bill${chosen.length === 1 ? '' : 's'} paid`);

  return <>
    <PageHead title="Pay bills" sub="Tick the supplier bills to pay now, from one bank, cash or MoMo account. Withholding tax is kept back where the supplier has a WHT rate." />
    <Panel pad><div className="grid-form">
      <Field label="Payment date" id="pb-d" type="date" value={f.date} onChange={v => setF({ ...f, date: v })} required />
      <Select label="Pay from" id="pb-a" value={f.account} onChange={v => setF({ ...f, account: v })} options={bankOpts(banks)} />
      <Field label="Reference (cheque no. or transfer)" id="pb-r" value={f.reference} onChange={v => setF({ ...f, reference: v })} />
      <Select label="Supplier" id="pb-s" value={f.supplier} onChange={v => setF({ ...f, supplier: v })} options={[['', 'All suppliers'], ...suppliers.map(s => [s.id, s.name] as [string, string])]} />
      <Field label="Due on or before" id="pb-due" type="date" value={f.due} onChange={v => setF({ ...f, due: v })} />
    </div></Panel>
    <Panel title={`Unpaid bills (${list.length})`}>
      {list.length ? <div className="scroll"><table>
        <thead><tr><th style={{ width: 28 }}></th><th>Bill</th><th>Supplier</th><th>Due</th><th className="r">Open</th><th className="r">Pay now</th><th className="r">WHT kept back</th></tr></thead>
        <tbody>{list.map(b => { const p = pick[b.id]; return <tr key={b.id}>
          <td><input type="checkbox" aria-label={`Pay ${b.number}`} checked={!!p} onChange={e => toggle(b, e.target.checked)} /></td>
          <td className="num"><Link to={'/bills/' + b.id}>{b.number}</Link>{b.supplier_ref && <><br /><span className="muted" style={{ fontSize: 12 }}>{b.supplier_ref}</span></>}</td>
          <td>{b.supplier?.name}</td>
          <td className="num" style={{ color: (b.due_date || b.bill_date) < today() ? 'var(--bad)' : undefined }}>{b.due_date || b.bill_date}</td>
          <td className="r num">{b.currency !== 'GHS' ? b.currency + ' ' : ''}{money(open(b))}</td>
          <td className="r">{p && <input aria-label="Amount to pay" type="number" step="0.01" min="0" value={p.pay} onChange={e => setPick({ ...pick, [b.id]: { ...p, pay: e.target.value } })} style={{ width: 110, textAlign: 'right' }} />}
            {p && b.currency !== 'GHS' && <input aria-label="Rate" type="number" step="0.000001" min="0" placeholder={`rate (${b.exchange_rate})`} value={p.rate} onChange={e => setPick({ ...pick, [b.id]: { ...p, rate: e.target.value } })} style={{ width: 110, textAlign: 'right', marginTop: 4 }} />}</td>
          <td className="r">{p && <input aria-label="Withholding tax" type="number" step="0.01" min="0" value={p.wht} onChange={e => setPick({ ...pick, [b.id]: { ...p, wht: e.target.value } })} style={{ width: 100, textAlign: 'right' }} />}</td></tr>; })}</tbody>
      </table></div> : <Empty>No unpaid bills{f.supplier || f.due ? ' match' : ''}.</Empty>}
      <div className="body actions" style={{ justifyContent: 'space-between', borderTop: '1px solid var(--line)' }}>
        <span><b>{chosen.length}</b> bill{chosen.length === 1 ? '' : 's'} · paying out <b className="num">{cedis(total)}</b></span>
        <button className="btn primary" type="button" disabled={act.busy || !chosen.length} onClick={save}>Pay selected bills</button></div>
    </Panel>
    {data.batches.length > 0 && <Panel title="Recent bill payments"><div className="scroll"><table>
      <thead><tr><th>Batch</th><th>Date</th><th>Reference</th><th className="r">Bills</th><th className="r">Paid out (GH₵)</th><th className="r">WHT kept (GH₵)</th></tr></thead>
      <tbody>{data.batches.map(x => <tr key={x.id}><td className="num">{x.number}</td><td className="num">{x.pay_date}</td><td>{x.reference}</td><td className="r num">{x.bills}</td><td className="r num">{money(x.total_paid)}</td><td className="r num">{Number(x.total_wht) ? money(x.total_wht) : ''}</td></tr>)}</tbody>
    </table></div><div className="body muted" style={{ fontSize: 13 }}>WHT kept back sits in 2270 Withholding tax payable until you pay it to GRA (Bank &amp; cash → Money out → 2270), by the 15th of the next month. Give each supplier their WHT credit certificate. {company?.name}</div></Panel>}
  </>;
}

// ---------------------------------------------------------------- Bank feed: import the bank's statement, match or post each line
const COLS = { date: ['date', 'transactiondate', 'txndate', 'valuedate', 'postingdate', 'bookingdate'], desc: ['description', 'narration', 'details', 'particulars', 'memo', 'transactiondetails', 'remarks'],
  ref: ['reference', 'ref', 'chequeno', 'refno', 'transactionid', 'docno'], amount: ['amount', 'transactionamount'], debit: ['debit', 'withdrawal', 'withdrawals', 'moneyout', 'paidout', 'dr', 'debitamount'],
  credit: ['credit', 'deposit', 'deposits', 'moneyin', 'paidin', 'cr', 'creditamount'] };
const n = (s: string) => s.toLowerCase().replace(/[^a-z]/g, '');

export function BankFeedPage() {
  const { cid } = useSession();
  const act = useAction();
  const { data: banks } = useBankAccounts(cid);
  const [acc, setAcc] = useState('');
  const [show, setShow] = useState<'new' | 'done' | 'ignored'>('new');
  const [post, setPost] = useState<any | null>(null);
  const [rule, setRule] = useState<any | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (banks?.length && !acc) setAcc((banks.find(b => b.system_key === 'bank') || banks[0]).id); }, [banks]);
  const { data, error, loading, reload } = useLoad(async () => {
    if (!acc) return null;
    const [lines, sug, accounts, rules] = await Promise.all([
      q<any[]>(supabase.from('bank_feed_lines').select('*').eq('company_id', cid).eq('account_id', acc).eq('status', show).order('txn_date', { ascending: false }).limit(300) as any),
      show === 'new' ? rpc<any[]>('bank_feed_suggestions', { cid, p_account: acc }) : Promise.resolve([] as any[]),
      q<any[]>(supabase.from('accounts').select('id,code,name,type,is_bank,system_key').eq('company_id', cid).eq('active', true).order('code') as any),
      q<any[]>(supabase.from('bank_rules').select('*').eq('company_id', cid).order('priority') as any),
    ]);
    return { lines, sug, accounts, rules };
  }, [cid, acc, show]);

  const upload = (file: File) => act.run(async () => {
    const grid = await readSheet(file);
    let hr = 0; const score = (r: string[]) => r.map(n).filter(h => Object.values(COLS).some(a => a.includes(h))).length;
    for (let i = 1; i < Math.min(grid.length, 20); i++) if (score(grid[i]) > score(grid[hr])) hr = i;
    const h = grid[hr].map(n);
    const col = (k: keyof typeof COLS) => h.findIndex(x => COLS[k].includes(x));
    const [cd, cs, cr, ca, cdr, ccr] = [col('date'), col('desc'), col('ref'), col('amount'), col('debit'), col('credit')];
    if (cd < 0 || (ca < 0 && cdr < 0 && ccr < 0)) throw new Error('Could not find the Date and Amount (or Debit/Credit) columns. Export the statement as CSV or Excel with headings.');
    const lines = grid.slice(hr + 1).map(r => {
      const amt = ca >= 0 ? toNum(r[ca]) : (toNum(r[ccr] || '0') || 0) - (toNum(r[cdr] || '0') || 0);
      return { date: toIsoDate(r[cd] || ''), description: cs >= 0 ? r[cs] : '', reference: cr >= 0 ? r[cr] : '', amount: Number.isNaN(amt) ? 0 : amt };
    }).filter(l => l.date && l.amount);
    if (!lines.length) throw new Error('No transactions found under the headings.');
    const res = await rpc<any>('import_bank_lines', { cid, p_account: acc, p_lines: lines, p_batch: file.name });
    setShow('new'); reload();
    return res;
  }, 'Statement imported — duplicates were skipped');

  const done = (line: any, as: string, ref?: string) => rpc('bank_line_done', { p_line: line.id, p_as: as, p_ref: ref || null });
  const actOn = (line: any, s: any) => act.run(async () => {
    if (s.kind === 'match') await done(line, 'matched', s.target_id);
    else if (s.kind === 'invoice') {
      const inv = await q<any>(supabase.from('invoices').select('customer_id,currency,wht_amount').eq('id', s.target_id).single() as any);
      const open = Number(s.amount), w = Number(inv.wht_amount) || 0;
      const wht = w > 0 && Math.abs(open - w - line.amount) < 0.01 ? w : 0;   // the customer paid the invoice less their withholding tax
      const id = await rpc<string>('receive_payment', { cid, p_customer: inv.customer_id, p_date: line.txn_date, p_account: acc, p_amount: line.amount,
        p_allocs: [{ invoice_id: s.target_id, amount: Math.min(line.amount, open - wht), wht }], p_reference: line.reference || line.description.slice(0, 60) });
      await done(line, 'payment received', id);
    } else if (s.kind === 'bill') {
      const id = await rpc<string>('pay_bills', { cid, p_date: line.txn_date, p_account: acc, p_reference: line.reference || line.description.slice(0, 60), p_items: [{ bill_id: s.target_id, amount: Math.min(-line.amount, Number(s.amount)) }] });
      await done(line, 'bill paid', id);
    } else if (s.kind === 'rule') {
      const id = await rpc<string>('post_cash_transaction', { cid, p_kind: line.amount > 0 ? 'receive' : 'spend', p_date: line.txn_date, p_account: acc, p_counter: s.counter_account_id,
        p_amount: Math.abs(line.amount), p_description: line.description.slice(0, 200), p_payee: s.payee || null, p_reference: line.reference || null, p_project: s.project_id || null });
      await done(line, line.amount > 0 ? 'money in' : 'money out', id);
    }
    reload();
  }, 'Done');

  const accounts = data?.accounts || [];
  const counterOpts = (out: boolean) => accounts.filter(a => !a.is_bank && !['ar', 'ap', 'inventory', 'vat_in', 'nhil_in', 'getf_in', 'vat_out', 'nhil_out', 'getf_out'].includes(a.system_key) && (out ? a.type !== 'income' : a.type !== 'expense')).map(a => [a.id, `${a.code} ${a.name}`] as [string, string]);
  const transfers = accounts.filter(a => a.is_bank && a.id !== acc);

  return <>
    <PageHead title="Bank feed" sub="Import your bank or MoMo statement. Each line is matched to what is already in the books, to an open invoice or bill, or posted with a rule — like QuickBooks' For review.">
      <button className="btn" type="button" onClick={() => setRule({ name: '', contains: '', direction: 'out', counter_account_id: '', payee: '', priority: '100', active: true })}>Add rule</button>
      <button className="btn primary" type="button" disabled={!acc || act.busy} onClick={() => fileRef.current?.click()}>Import statement</button>
      <input ref={fileRef} type="file" accept=".csv,.xlsx" style={{ display: 'none' }} onChange={e => { const fl = e.target.files?.[0]; e.target.value = ''; if (fl) upload(fl); }} />
    </PageHead>
    <div className="filters">
      <Select label="Account" id="bf-acc" value={acc} onChange={setAcc} options={bankOpts(banks)} />
      <Select label="Show" id="bf-show" value={show} onChange={v => setShow(v as any)} options={[['new', 'For review'], ['done', 'Done'], ['ignored', 'Ignored']]} />
    </div>
    <Loading error={error} loading={loading && !data} />
    {data && <Panel>
      {data.lines.length ? <div className="scroll"><table>
        <thead><tr><th>Date</th><th>Description</th><th className="r">Money in</th><th className="r">Money out</th><th>{show === 'new' ? 'Suggested' : 'Became'}</th><th></th></tr></thead>
        <tbody>{data.lines.map(l => { const s = data.sug.filter(x => x.line_id === l.id); const best = s[0];
          return <tr key={l.id}>
            <td className="num">{l.txn_date}</td>
            <td className="wrap-cell" style={{ fontSize: 13 }}>{l.description}{l.reference && <span className="muted"> · {l.reference}</span>}</td>
            <td className="r num">{l.amount > 0 ? money(l.amount) : ''}</td><td className="r num">{l.amount < 0 ? money(-l.amount) : ''}</td>
            <td style={{ fontSize: 13 }}>{show === 'new' ? (best ? <span><span className={'pill ' + (best.kind === 'match' ? 'good' : best.kind === 'rule' ? '' : 'warn')}>{({ match: 'Match', invoice: 'Receive', bill: 'Pay', rule: 'Rule' } as any)[best.kind]}</span> {best.label}{s.length > 1 && <span className="muted"> (+{s.length - 1} more)</span>}</span> : <span className="muted">No match — add it</span>) : <>{l.done_as}</>}</td>
            <td className="r"><span className="actions" style={{ justifyContent: 'flex-end' }}>
              {show === 'new' && best && <button className="btn small primary" type="button" disabled={act.busy} onClick={() => actOn(l, best)}>{({ match: 'Match', invoice: 'Receive', bill: 'Pay', rule: 'Post' } as any)[best.kind]}</button>}
              {show === 'new' && s.length > 1 && <select aria-label="Other suggestions" value="" onChange={e => { const x = s[Number(e.target.value)]; if (x) actOn(l, x); }}><option value="">Other…</option>{s.slice(1).map((x, i) => <option key={i} value={i + 1}>{x.label}</option>)}</select>}
              {show === 'new' && <button className="btn small" type="button" onClick={() => setPost({ line: l, counter: '', transfer: '', description: l.description, payee: '', saveRule: false, contains: '' })}>Add</button>}
              {show === 'new' && <button className="btn small ghost" type="button" disabled={act.busy} onClick={() => act.run(async () => { await done(l, 'ignored'); reload(); }, 'Ignored')}>Ignore</button>}
              {show !== 'new' && <button className="btn small ghost" type="button" disabled={act.busy} onClick={() => act.run(async () => { await done(l, 'reopen'); reload(); }, 'Back in For review')}>Undo</button>}
            </span></td></tr>; })}</tbody>
      </table></div> : <Empty>{show === 'new' ? 'Nothing to review. Import a statement (CSV or Excel from your bank or MoMo) to start.' : 'Nothing here.'}</Empty>}
      <div className="body muted" style={{ fontSize: 13 }}><b>Match</b> = it is already in the books (an invoice payment, bill payment, money in/out or payroll); nothing new is posted. <b>Receive</b> / <b>Pay</b> = records the payment of that invoice or bill. <b>Post</b> = money in/out to the rule's account. Undo only reopens the line; to undo a posting, void it where it was posted.</div>
    </Panel>}
    {data && data.rules.length > 0 && <Panel title="Rules">
      <div className="scroll"><table><thead><tr><th>Rule</th><th>When the description has</th><th>Direction</th><th>Post to</th><th></th></tr></thead>
        <tbody>{data.rules.map(r => <tr key={r.id} style={r.active ? undefined : { opacity: .5 }}><td>{r.name}</td><td><code>{r.contains}</code></td><td>{({ in: 'Money in', out: 'Money out', any: 'Either' } as any)[r.direction]}</td>
          <td>{accounts.find(a => a.id === r.counter_account_id)?.code} {accounts.find(a => a.id === r.counter_account_id)?.name}</td>
          <td className="r"><button className="btn small ghost" type="button" onClick={() => setRule({ ...r, payee: r.payee || '', priority: String(r.priority) })}>Edit</button></td></tr>)}</tbody></table></div>
    </Panel>}
    {post && <FormModal title={post.line.amount > 0 ? 'Add as money in' : 'Add as money out'} busy={act.busy} onClose={() => setPost(null)}
      onSave={() => act.run(async () => {
        const l = post.line; let id: string;
        if (post.transfer) {
          id = await rpc<string>('post_cash_transaction', { cid, p_kind: 'transfer', p_date: l.txn_date, p_account: l.amount < 0 ? acc : post.transfer, p_counter: l.amount < 0 ? post.transfer : acc,
            p_amount: Math.abs(l.amount), p_description: post.description || 'Transfer', p_reference: l.reference || null });
        } else {
          if (!post.counter) throw new Error('Choose the account.');
          id = await rpc<string>('post_cash_transaction', { cid, p_kind: l.amount > 0 ? 'receive' : 'spend', p_date: l.txn_date, p_account: acc, p_counter: post.counter, p_amount: Math.abs(l.amount),
            p_description: post.description || l.description, p_payee: post.payee || null, p_reference: l.reference || null });
          if (post.saveRule && post.contains.trim()) await q(supabase.from('bank_rules').insert({ company_id: cid, name: post.payee || post.contains.trim(), contains: post.contains.trim(), direction: l.amount > 0 ? 'in' : 'out', counter_account_id: post.counter, payee: post.payee || null }) as any);
        }
        await done(l, post.transfer ? 'transfer' : l.amount > 0 ? 'money in' : 'money out', id); setPost(null); reload();
      }, 'Posted')}>
      <p style={{ margin: 0 }}><b className="num">{post.line.txn_date}</b> · {post.line.description} · <b className="num">{money(Math.abs(post.line.amount))}</b></p>
      <div className="grid-form">
        <Select label={post.line.amount > 0 ? 'Income or other account' : 'Expense or other account'} id="bp-c" value={post.counter} onChange={v => setPost({ ...post, counter: v, transfer: '' })} options={[['', 'Choose…'], ...counterOpts(post.line.amount < 0)]} />
        {transfers.length > 0 && <Select label={post.line.amount > 0 ? 'Or a transfer from' : 'Or a transfer to'} id="bp-t" value={post.transfer} onChange={v => setPost({ ...post, transfer: v, counter: '' })} options={[['', '—'], ...bankOpts(transfers)]} />}
        <Field label="Payee" id="bp-p" value={post.payee} onChange={v => setPost({ ...post, payee: v })} />
        <Field label="Description" id="bp-d" value={post.description} onChange={v => setPost({ ...post, description: v })} />
      </div>
      {!post.transfer && <><label className="check"><input type="checkbox" checked={post.saveRule} onChange={e => setPost({ ...post, saveRule: e.target.checked, contains: post.contains || post.line.description.split(/\s+/).slice(0, 2).join(' ') })} /> Make a rule for lines like this next time</label>
        {post.saveRule && <Field label="When the description contains" id="bp-k" value={post.contains} onChange={v => setPost({ ...post, contains: v })} />}</>}
      <p className="muted" style={{ margin: 0, fontSize: 13 }}>A customer payment or supplier payment should be taken as Receive or Pay instead, so the invoice or bill is closed. Use Sales → Receive payment if it covers several invoices, then Match it here.</p>
    </FormModal>}
    {rule && <FormModal title={rule.id ? 'Edit rule' : 'Add rule'} busy={act.busy} onClose={() => setRule(null)}
      danger={rule.id && <ConfirmButton className="btn danger" label="Delete" confirm="Delete this rule?" onConfirm={() => act.run(async () => { await q(supabase.from('bank_rules').delete().eq('id', rule.id) as any); setRule(null); reload(); })} />}
      onSave={() => act.run(async () => {
        if (!rule.contains.trim() || !rule.counter_account_id) throw new Error('Enter the words to look for and the account.');
        const row = { name: rule.name.trim() || rule.contains.trim(), contains: rule.contains.trim(), direction: rule.direction, counter_account_id: rule.counter_account_id, payee: rule.payee || null, priority: Number(rule.priority) || 100, active: rule.active };
        if (rule.id) await q(supabase.from('bank_rules').update(row).eq('id', rule.id) as any); else await q(supabase.from('bank_rules').insert({ ...row, company_id: cid }) as any);
        setRule(null); reload();
      }, 'Rule saved')}>
      <div className="grid-form">
        <Field label="Name" id="br-n" value={rule.name} onChange={v => setRule({ ...rule, name: v })} placeholder="e.g. ECG prepaid" />
        <Field label="When the description contains" id="br-c" value={rule.contains} onChange={v => setRule({ ...rule, contains: v })} placeholder="ECG" required />
        <Select label="For" id="br-d" value={rule.direction} onChange={v => setRule({ ...rule, direction: v })} options={[['out', 'Money out'], ['in', 'Money in'], ['any', 'Either']]} />
        <Select label="Post to account" id="br-a" value={rule.counter_account_id} onChange={v => setRule({ ...rule, counter_account_id: v })} options={[['', 'Choose…'], ...counterOpts(rule.direction !== 'in')]} />
        <Field label="Payee" id="br-p" value={rule.payee} onChange={v => setRule({ ...rule, payee: v })} />
        <Field label="Priority (lower first)" id="br-pr" type="number" value={rule.priority} onChange={v => setRule({ ...rule, priority: v })} />
      </div>
      <label className="check"><input type="checkbox" checked={rule.active} onChange={e => setRule({ ...rule, active: e.target.checked })} /> Active</label>
    </FormModal>}
  </>;
}

// ---------------------------------------------------------------- "+ New" menu, like QuickBooks
const NEW_ITEMS: { group: string; items: [string, string, string[]?][] }[] = [
  { group: 'Customers', items: [['Invoice', '/invoices/new', ['sales', 'accountant']], ['Receive payment', '/receive-payment', ['sales', 'accountant']], ['Sales receipt', '/sales-receipt', ['sales', 'accountant']], ['Quote (estimate)', '/quotes/new'], ['Credit note', '/credit-notes/new', ['sales', 'accountant']], ['Customer', '/customers?new=1']] },
  { group: 'Suppliers', items: [['Bill', '/bills/new', ['accountant']], ['Pay bills', '/pay-bills', ['accountant']], ['Purchase order', '/purchase-orders/new', ['accountant', 'store', 'project_manager']], ['Supplier', '/suppliers?new=1']] },
  { group: 'Money', items: [['Expense (money out)', '/bank-cash?new=spend', ['accountant']], ['Deposit (money in)', '/bank-cash?new=receive', ['accountant']], ['Transfer', '/bank-cash?new=transfer', ['accountant']], ['Bank feed', '/bank-feed', ['accountant']], ['Journal entry', '/journal', ['accountant']]] },
  { group: 'Other', items: [['Product or service', '/inventory', ['accountant', 'store']], ['Request (SR / ADR)', '/projects'], ['Time & expenses', '/my'], ['Leave request', '/leave']] },
];
export function NewMenu() {
  const { can } = useSession();
  const ref = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    const close = (e: Event) => { const d = ref.current; if (d?.open && (e instanceof KeyboardEvent ? e.key === 'Escape' : !d.contains(e.target as Node))) d.open = false; };
    document.addEventListener('click', close); document.addEventListener('keydown', close);
    return () => { document.removeEventListener('click', close); document.removeEventListener('keydown', close); };
  }, []);
  const groups = NEW_ITEMS.map(g => ({ ...g, items: g.items.filter(([, , r]) => !r || can(...(r as any))) })).filter(g => g.items.length);
  return <details ref={ref} className="new-menu" style={{ position: 'relative' }}>
    <summary className="btn primary small" style={{ listStyle: 'none', cursor: 'pointer' }} aria-label="Create new">+ New</summary>
    <div role="menu" style={{ position: 'absolute', right: 0, top: 'calc(100% + 6px)', zIndex: 50, background: 'var(--panel, #fff)', border: '1px solid var(--line)', borderRadius: 12, boxShadow: '0 12px 32px rgba(0,0,0,.14)', padding: 14,
      display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 14, width: 'min(640px, calc(100vw - 32px))' }}>
      {groups.map(g => <div key={g.group}><div className="label" style={{ marginBottom: 6 }}>{g.group}</div>
        {g.items.map(([label, to]) => <Link key={to} to={to} role="menuitem" onClick={() => { if (ref.current) ref.current.open = false; }} style={{ display: 'block', padding: '5px 0', fontSize: 14 }}>{label}</Link>)}</div>)}
    </div>
  </details>;
}

