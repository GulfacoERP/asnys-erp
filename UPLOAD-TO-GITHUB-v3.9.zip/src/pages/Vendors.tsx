import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { q, rpc, supabase } from '../lib/supabase';
import { useSession } from '../lib/session';
import { longDate } from '../lib/format';
import { Empty, Loading, PageHead, Panel, useAction, useLoad } from '../components/ui';
import { DOC_TYPES, ONB, SUPPLIER_TYPES } from './V37';

/** The buying steps, in order. Shown on the Vendor onboarding page so everyone sees where a vendor stands. */
const STEPS: [string, string, string][] = [
  ['1', 'Register the vendor', 'Details, TIN, Ghana Card, bank and MoMo, and the documents (registration, VAT, ISO, HSE and quality policies, BoG exemption letter…).'],
  ['2', 'Finance checks and approves', 'Finance verifies each document and approves the vendor. Missing documents are listed in red.'],
  ['3', 'Raise a purchase order', 'Only approved vendors. The PO tells the vendor exactly what we buy and what it will cost; it goes through approval.'],
  ['4', 'Receive and bill', 'Stores record what arrived against the PO; the vendor\'s invoice is entered as a bill and matched to the PO.'],
  ['5', 'Pay', 'Finance pays the bill by bank or MoMo, keeping back withholding tax.'],
];

export function VendorOnboardingPage() {
  const { cid, can } = useSession();
  const nav = useNavigate();
  const act = useAction();
  const [view, setView] = useState<'waiting' | 'approved' | 'stopped' | 'all'>('waiting');
  const { data, error, loading } = useLoad(() => rpc<any[]>('vendor_onboarding_list', { cid }), [cid]);
  const { data: co, reload: reloadCo } = useLoad(() => q<any>(supabase.from('companies').select('po_needs_approved_supplier').eq('id', cid).single() as any).catch(() => null), [cid]);
  const rows = (data || []).filter(s => view === 'all' ? true : view === 'waiting' ? s.onboarding_status === 'pending' : view === 'approved' ? s.onboarding_status === 'approved' : ['rejected', 'suspended'].includes(s.onboarding_status));
  const n = (st: string[]) => (data || []).filter(s => st.includes(s.onboarding_status)).length;
  const buyer = can('accountant', 'store', 'project_manager');
  const docName = (t: string) => DOC_TYPES.find(d => d[0] === t)?.[1] || t.replace(/_/g, ' ');
  return <>
    <PageHead title="Vendor onboarding" sub="Every vendor and subcontractor is onboarded here before we buy from them. Once Finance approves them, raise a purchase order.">
      {buyer && <button className="btn primary" type="button" onClick={() => nav('/suppliers?new=1')}>Onboard a new vendor</button>}
    </PageHead>
    <div className="steps-row">{STEPS.map(([no, t, d]) => <div key={no} className="step-box"><b><span className="step-no">{no}</span> {t}</b><span>{d}</span></div>)}</div>
    <div className="filters">
      <div className="actions" style={{ alignSelf: 'end' }}>{([['waiting', `Waiting for approval (${n(['pending'])})`], ['approved', `Approved (${n(['approved'])})`], ['stopped', `Rejected or suspended (${n(['rejected', 'suspended'])})`], ['all', 'All']] as const).map(([k, l]) =>
        <button key={k} type="button" className={'btn small' + (view === k ? ' primary' : '')} onClick={() => setView(k)}>{l}</button>)}</div>
    </div>
    <Loading error={error} loading={loading && !data} />
    {data && <Panel>{rows.length ? <div className="scroll"><table>
      <thead><tr><th>Vendor</th><th>Supplies</th><th>Documents</th><th>Status</th><th></th></tr></thead>
      <tbody>{rows.map(s => { const st = ONB[s.onboarding_status] || [s.onboarding_status, ''];
        return <tr key={s.id}>
          <td><Link to={'/suppliers/' + s.id} style={{ fontWeight: 600 }}>{s.name}</Link><br /><span className="muted" style={{ fontSize: 12 }}>{SUPPLIER_TYPES.find(t => t[0] === s.supplier_type)?.[1] || 'Vendor'}{s.tin ? ' · TIN ' + s.tin : ' · no TIN'}{s.contact_name && <><br />{s.contact_name}{s.contact_phone ? ' · ' + s.contact_phone : ''}</>}</span></td>
          <td className="wrap-cell" style={{ maxWidth: 220, fontSize: 13 }}>{s.products_services || <span className="muted">—</span>}</td>
          <td className="wrap-cell" style={{ fontSize: 13, maxWidth: 240 }}>{s.docs} attached{s.missing?.length ? <><br /><span style={{ color: 'var(--bad)' }}>Missing: {s.missing.map(docName).join(', ')}</span></> : <><br /><span style={{ color: 'var(--good)' }}>All required in</span></>}</td>
          <td><span className={'pill ' + st[1]}>{st[0]}</span>{s.onboarded_at && <><br /><span className="muted" style={{ fontSize: 12 }}>{longDate(s.onboarded_at.slice(0, 10))}</span></>}</td>
          <td className="r" style={{ whiteSpace: 'nowrap' }}>
            {s.onboarding_status === 'approved' ? buyer && <Link className="btn small primary" to={`/purchase-orders/new?supplier=${s.id}`}>Raise purchase order</Link>
              : <Link className="btn small" to={'/suppliers/' + s.id}>{can('accountant') ? 'Check and approve' : 'Add documents'}</Link>}
            {s.open_pos > 0 && <><br /><span className="muted" style={{ fontSize: 12 }}>{s.open_pos} open PO{s.open_pos > 1 ? 's' : ''}</span></>}
          </td></tr>; })}</tbody>
    </table></div> : <Empty>{view === 'waiting' ? 'No vendor is waiting for approval.' : 'Nothing here.'} Press "Onboard a new vendor" to register one with its documents.</Empty>}</Panel>}
    {co && can('admin') && <Panel pad>
      <label className="check"><input type="checkbox" checked={!!co.po_needs_approved_supplier} disabled={act.busy} onChange={e => act.run(async () => {
        await q(supabase.from('companies').update({ po_needs_approved_supplier: e.target.checked }).eq('id', cid) as any); reloadCo(); }, 'Saved')} />
        Purchase orders can only be approved for vendors Finance has approved (recommended)</label>
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 13 }}>A draft order can still be prepared for a vendor who is waiting, so nothing is held up; it cannot be approved and sent until onboarding is approved. Which documents are required is set under <Link to="/supplier-onboarding">Onboarding rules</Link>.</p>
    </Panel>}
  </>;
}
