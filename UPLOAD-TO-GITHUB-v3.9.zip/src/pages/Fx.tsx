import { useState } from 'react';
import { q, rpc, supabase, supabaseUrl } from '../lib/supabase';
import { useSession } from '../lib/session';
import { longDate, money, today } from '../lib/format';
import { ConfirmButton, Empty, Field, Panel, useAction, useLoad } from '../components/ui';

/** Foreign currencies with the Bank of Ghana rate fetched every working day. The books stay in cedis. */
export function FxCurrenciesPanel() {
  const { cid, can } = useSession();
  const act = useAction();
  const [add, setAdd] = useState({ code: '', name: '' });
  const [url, setUrl] = useState<string | null>(null);
  const { data, reload } = useLoad(async () => ({
    list: await q<any[]>(supabase.from('currencies').select('*').eq('company_id', cid).order('code') as any),
    st: await rpc<any>('fx_status', { cid }).catch(() => null),
  }), [cid]);
  if (!data) return null;
  const st = data.st;
  const latest: any[] = st?.latest || [];
  const fn = url ?? `${supabaseUrl}/functions/v1/asnys-m365`;
  return <Panel title="Foreign currencies and Bank of Ghana rates">
    <div className="body muted" style={{ fontSize: 13 }}>
      All books and reports are kept in GH₵. Each working day at about 15:00 the Bank of Ghana interbank rates are fetched; the <b>mid-rate</b> for the document's date is filled in on invoices, bills, quotes, credit notes and payments, and can still be changed on each document.
      {st && <> Last fetch: <b>{st.last_run_at ? st.last_run_at.slice(0, 16).replace('T', ' ') : 'never'}</b>{st.last_status && st.last_status !== 'ok' && st.last_status !== 'started' ? <span style={{ color: 'var(--bad)' }}> · {st.last_status}</span> : ''}{st.last_rate_date && <> · rates of <b>{longDate(st.last_rate_date)}</b></>}.</>}
      {st === null && <> Run the v3.6 database update to fetch BoG rates.</>}
    </div>
    {data.list.length > 0 && <div className="scroll"><table>
      <thead><tr><th>Currency</th><th className="r">BoG buying</th><th className="r">BoG mid (used)</th><th className="r">BoG selling</th><th>Rate date</th><th>Automatic</th><th></th></tr></thead>
      <tbody>{data.list.map(c => { const b = latest.find(x => x.code === c.code); return <tr key={c.code}>
        <td><b className="num">{c.code}</b> <span className="muted">{c.name}</span></td>
        <td className="r num">{b?.buying ? Number(b.buying).toFixed(4) : ''}</td>
        <td className="r">{c.auto_rate !== false ? <b className="num">{Number(c.rate).toFixed(4)}</b>
          : <input aria-label={`Rate for ${c.code}`} type="number" step="0.000001" min="0.000001" defaultValue={c.rate} style={{ width: 120, textAlign: 'right' }}
            onBlur={e => { if (Number(e.target.value) > 0 && Number(e.target.value) !== Number(c.rate)) act.run(async () => { await q(supabase.from('currencies').update({ rate: Number(e.target.value), rate_source: 'typed in', rate_date: today(), updated_at: new Date().toISOString() }).eq('company_id', cid).eq('code', c.code) as any); reload(); }, `${c.code} rate saved`); }} />}</td>
        <td className="r num">{b?.selling ? Number(b.selling).toFixed(4) : ''}</td>
        <td className="num" style={{ fontSize: 13 }}>{c.rate_date || c.updated_at?.slice(0, 10)}<br /><span className="muted">{c.rate_source || 'typed in'}</span></td>
        <td>{can('accountant') && <input type="checkbox" aria-label={`Fetch ${c.code} automatically`} checked={c.auto_rate !== false} onChange={e => act.run(async () => { await q(supabase.from('currencies').update({ auto_rate: e.target.checked }).eq('company_id', cid).eq('code', c.code) as any); reload(); })} />}</td>
        <td className="r">{can('accountant') && <ConfirmButton className="btn small ghost" label="Remove" confirm="Remove?" onConfirm={() => act.run(async () => { await q(supabase.from('currencies').delete().eq('company_id', cid).eq('code', c.code) as any); reload(); })} />}</td></tr>; })}</tbody>
    </table></div>}
    {can('accountant') && <form className="body grid-form" style={{ borderTop: '1px solid var(--line)' }} onSubmit={e => { e.preventDefault(); act.run(async () => {
      const code = add.code.trim().toUpperCase(); const b = latest.find(x => x.code === code);
      await q(supabase.from('currencies').insert({ company_id: cid, code, name: add.name.trim(), rate: b?.mid || 1, rate_date: b?.rate_date || null, rate_source: b ? b.source : 'not yet fetched' }) as any);
      setAdd({ code: '', name: '' }); reload(); }, 'Currency added'); }}>
      <Field label="Code" id="fx-code" value={add.code} onChange={v => setAdd({ ...add, code: v })} placeholder="USD" required />
      <Field label="Name" id="fx-name" value={add.name} onChange={v => setAdd({ ...add, name: v })} placeholder="US dollar" required />
      <div className="field" style={{ alignSelf: 'end' }}><button className="btn primary" type="submit" disabled={act.busy}>Add currency</button></div>
    </form>}
    {st && can('accountant') && <div className="body actions" style={{ borderTop: '1px solid var(--line)', flexWrap: 'wrap' }}>
      <button className="btn" type="button" disabled={act.busy} onClick={() => act.run(async () => { await rpc('fx_fetch_now', { cid }); setTimeout(reload, 12000); }, 'Fetching BoG rates — they show here in a few seconds')}>Fetch BoG rates now</button>
      {can() && !st.function_url_set && <>
        <Field label="asnys-m365 function address" id="fx-url" value={fn} onChange={setUrl} />
        <button className="btn small" type="button" disabled={act.busy} onClick={() => act.run(async () => { await rpc('fx_configure', { cid, p_function_url: fn, p_enabled: true }); reload(); }, 'Saved')}>Save address</button></>}
    </div>}
  </Panel>;
}

/** Month-end: restate unpaid foreign-currency invoices and bills at the BoG rate; reversed the next day. */
export function FxRevaluationPanel() {
  const { cid, can } = useSession();
  const act = useAction();
  const lastMonthEnd = (() => { const d = new Date(today() + 'T00:00:00Z'); d.setUTCDate(0); return d.toISOString().slice(0, 10); })();
  const [date, setDate] = useState(lastMonthEnd);
  const [prev, setPrev] = useState<any[] | null>(null);
  const { data: hist, reload } = useLoad(() => q<any[]>(supabase.from('fx_revaluations').select('*').eq('company_id', cid).order('reval_date', { ascending: false }).limit(12) as any).catch(() => null), [cid]);
  if (!can('accountant') || hist === null) return null;
  const ar = (prev || []).filter(x => x.kind === 'invoice').reduce((s, x) => s + Number(x.change), 0);
  const ap = (prev || []).filter(x => x.kind === 'bill').reduce((s, x) => s + Number(x.change), 0);
  return <Panel title="Month-end exchange revaluation" pad>
    <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>Restates unpaid USD, EUR… invoices and bills in cedis at the Bank of Ghana mid-rate of the date you choose. The unrealised gain or loss goes to 4800 Foreign exchange gains and losses, and is reversed on the next day, so payments still clear at each document's own rate. Do it before locking the month.</p>
    <div className="filters">
      <Field label="Revalue at" id="rv-date" type="date" value={date} onChange={v => { setDate(v); setPrev(null); }} />
      <button className="btn" type="button" style={{ marginBottom: 2 }} disabled={act.busy} onClick={() => act.run(async () => setPrev(await rpc<any[]>('fx_revalue_preview', { cid, p_date: date })))}>Preview</button>
      {prev && prev.length > 0 && <button className="btn primary" type="button" style={{ marginBottom: 2 }} disabled={act.busy} onClick={() => act.run(async () => { await rpc('fx_revalue', { cid, p_date: date }); setPrev(null); reload(); }, 'Revaluation posted')}>Post revaluation</button>}
    </div>
    {prev && (prev.length ? <div className="scroll" style={{ marginTop: 10 }}><table>
      <thead><tr><th>Document</th><th>Customer / supplier</th><th className="r">Unpaid</th><th className="r">Booked rate</th><th className="r">BoG rate</th><th className="r">Change (GH₵)</th></tr></thead>
      <tbody>{prev.map(x => <tr key={x.doc_id}><td className="num">{x.kind === 'invoice' ? 'Invoice' : 'Bill'} {x.number}</td><td>{x.party}</td><td className="r num">{x.currency} {money(x.open_amount)}</td>
        <td className="r num">{Number(x.booked_rate).toFixed(4)}</td><td className="r num">{Number(x.new_rate).toFixed(4)}</td><td className="r num">{money(x.change)}</td></tr>)}</tbody>
      <tfoot><tr><td colSpan={5}>Receivables {ar >= 0 ? 'up' : 'down'} {money(Math.abs(ar))} · payables {ap >= 0 ? 'up' : 'down'} {money(Math.abs(ap))} · net {ar - ap >= 0 ? 'gain' : 'loss'}</td><td className="r num">{money(ar - ap)}</td></tr></tfoot>
    </table></div> : <Empty>Nothing to revalue at this date.</Empty>)}
    {hist.length > 0 && <div className="scroll" style={{ marginTop: 12 }}><table>
      <thead><tr><th>Date</th><th className="r">Receivables</th><th className="r">Payables</th><th>Status</th><th></th></tr></thead>
      <tbody>{hist.map(h => <tr key={h.id} style={h.status === 'undone' ? { opacity: .55 } : undefined}><td className="num">{h.reval_date}</td><td className="r num">{money(h.ar_change)}</td><td className="r num">{money(h.ap_change)}</td>
        <td>{h.status === 'posted' ? <span className="pill good">Posted, reversed next day</span> : <span className="pill">Undone</span>}</td>
        <td className="r">{h.status === 'posted' && <ConfirmButton className="btn small ghost" label="Undo" confirm="Undo this revaluation? Mirror entries are posted." onConfirm={() => act.run(async () => { await rpc('fx_revalue_undo', { p_id: h.id }); reload(); }, 'Undone')} />}</td></tr>)}</tbody>
    </table></div>}
  </Panel>;
}
