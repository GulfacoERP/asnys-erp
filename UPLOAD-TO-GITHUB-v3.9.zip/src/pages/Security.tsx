import { ReactNode, useEffect, useState } from 'react';
import { q, rpc, supabase, supabaseUrl } from '../lib/supabase';
import { useSession } from '../lib/session';
import { Empty, Field, Loading, PageHead, Panel, Select, useAction, useLoad } from '../components/ui';

const ROLE_NAMES: [string, string][] = [['owner', 'Owners'], ['admin', 'Admins'], ['accountant', 'Accountants'], ['hr', 'HR'], ['project_manager', 'Project managers'], ['sales', 'Sales'], ['store', 'Storekeepers'], ['staff', 'Staff']];

// ---------------------------------------------------------------- 2-step sign-in (authenticator app codes)
/** Before the app opens: people who must use 2-step sign-in (or have set it up) enter a code from their phone. */
export function MfaGate({ children }: { children: ReactNode }) {
  const [state, setState] = useState<'checking' | 'ok' | 'challenge' | 'enrol'>('checking');
  const check = async () => {
    try {
      const { data } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
      if (!data || data.currentLevel === 'aal2') return setState('ok');
      if (data.nextLevel === 'aal2') return setState('challenge');
      const required = await rpc<boolean>('my_mfa_required', {}).catch(() => false);
      setState(required ? 'enrol' : 'ok');
    } catch { setState('ok'); }
  };
  useEffect(() => { check(); }, []);
  if (state === 'checking') return <div className="center-page"><p className="muted">Checking sign-in…</p></div>;
  if (state === 'ok') return <>{children}</>;
  return <div className="center-page" style={{ maxWidth: 460, margin: '8vh auto', padding: 16 }}>
    <Panel title={state === 'challenge' ? 'Enter your sign-in code' : 'Set up 2-step sign-in'} pad>
      {state === 'challenge' ? <Challenge onDone={check} /> : <>
        <p className="muted" style={{ marginTop: 0 }}>Your company requires a code from your phone each time you sign in. It takes one minute.</p>
        <Enrol onDone={check} /></>}
      <button className="btn ghost small" type="button" style={{ marginTop: 12 }} onClick={() => supabase.auth.signOut()}>Sign out</button>
    </Panel>
  </div>;
}

function Challenge({ onDone }: { onDone: () => void }) {
  const act = useAction();
  const [code, setCode] = useState('');
  return <form onSubmit={e => { e.preventDefault(); act.run(async () => {
    const { data: f, error } = await supabase.auth.mfa.listFactors(); if (error) throw error;
    const totp = f.totp.find(x => x.status === 'verified'); if (!totp) throw new Error('No authenticator is set up.');
    const r = await supabase.auth.mfa.challengeAndVerify({ factorId: totp.id, code: code.trim() }); if (r.error) throw new Error('That code is not right. Use the newest one.');
    onDone();
  }); }} style={{ display: 'grid', gap: 10 }}>
    <p className="muted" style={{ margin: 0 }}>Open your authenticator app (Microsoft Authenticator, Google Authenticator…) and type the 6-digit code for Asnys ERP.</p>
    <Field label="6-digit code" id="mfa-code" value={code} onChange={v => setCode(v.replace(/\D/g, '').slice(0, 6))} required inputMode="numeric" />
    <button className="btn primary" type="submit" disabled={act.busy || code.length !== 6}>Continue</button>
  </form>;
}

function Enrol({ onDone }: { onDone: () => void }) {
  const act = useAction();
  const [f, setF] = useState<{ id: string; qr: string; secret: string } | null>(null);
  const [code, setCode] = useState('');
  const start = () => act.run(async () => {
    const { data: old } = await supabase.auth.mfa.listFactors();
    for (const x of old?.all || []) if (x.status !== 'verified') await supabase.auth.mfa.unenroll({ factorId: x.id });
    const { data, error } = await supabase.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'Phone ' + new Date().toISOString().slice(0, 10) });
    if (error) throw new Error(error.message.includes('disabled') ? 'Turn on TOTP in Supabase (Authentication → Sign In / Providers → Multi-factor) first.' : error.message);
    const t = (data as any).totp; setF({ id: data.id, qr: t.qr_code, secret: t.secret });
  });
  if (!f) return <button className="btn primary" type="button" disabled={act.busy} onClick={start}>Start</button>;
  return <form onSubmit={e => { e.preventDefault(); act.run(async () => {
    const r = await supabase.auth.mfa.challengeAndVerify({ factorId: f.id, code: code.trim() }); if (r.error) throw new Error('That code is not right. Check the phone\'s time and use the newest code.');
    onDone();
  }, '2-step sign-in is on'); }} style={{ display: 'grid', gap: 10 }}>
    <ol style={{ margin: 0, paddingLeft: 18, fontSize: 14 }}>
      <li>Install <b>Microsoft Authenticator</b> or <b>Google Authenticator</b> on your phone.</li>
      <li>In the app, add an account and scan this code:</li></ol>
    <img src={f.qr} alt="QR code for the authenticator app" style={{ width: 180, height: 180, background: '#fff', borderRadius: 8, justifySelf: 'center' }} />
    <p className="muted" style={{ margin: 0, fontSize: 12 }}>Can't scan? Enter this key: <code style={{ wordBreak: 'break-all' }}>{f.secret}</code></p>
    <Field label="3. Type the 6-digit code it shows" id="mfa-new" value={code} onChange={v => setCode(v.replace(/\D/g, '').slice(0, 6))} required inputMode="numeric" />
    <button className="btn primary" type="submit" disabled={act.busy || code.length !== 6}>Turn on</button>
  </form>;
}

function MyTwoStep() {
  const act = useAction();
  const { data, reload } = useLoad(async () => (await supabase.auth.mfa.listFactors()).data?.totp.filter(x => x.status === 'verified') || [], []);
  const [enrol, setEnrol] = useState(false);
  if (!data) return null;
  return <Panel title="My 2-step sign-in" pad>
    {data.length ? <><p style={{ marginTop: 0 }}><span className="pill good">On</span> You enter a code from your phone when you sign in.</p>
      <button className="btn ghost small" type="button" disabled={act.busy} onClick={() => act.run(async () => { for (const x of data) await supabase.auth.mfa.unenroll({ factorId: x.id }); reload(); }, '2-step sign-in turned off')}>Turn off (e.g. new phone)</button></>
      : enrol ? <Enrol onDone={() => { setEnrol(false); reload(); }} />
      : <><p className="muted" style={{ marginTop: 0 }}>Protect your account with a code from your phone as well as your password. Strongly recommended for owners, admins and Finance.</p>
        <button className="btn primary" type="button" onClick={() => setEnrol(true)}>Set up</button></>}
  </Panel>;
}

// ---------------------------------------------------------------- Page
export function SecurityPage() {
  const { cid, company, can } = useSession();
  const act = useAction();
  const { data, error, loading, reload } = useLoad(() => rpc<any>('security_overview', { cid }), [cid]);
  const [bk, setBk] = useState<any | null>(null);
  useEffect(() => {
    if (data) setBk({ enabled: false, onedrive_user: '', folder: 'Asnys ERP backups', keep_days: 90, ...(data.backup || {}), function_url: '' });
  }, [data]);
  if (!can('owner')) return <><PageHead title="Security & backup" /><MyTwoStep /></>;
  if (!data || !bk) return <><PageHead title="Security & backup" /><MyTwoStep /><Loading error={error && 'Run the v3.4 database update first. ' + error} loading={loading} /></>;
  const mfaRoles: string[] = data.mfa_roles || [];
  const people: any[] = data.people || [];
  const without = people.filter(p => mfaRoles.includes(p.role) && !p.mfa);
  const saveBackup = () => act.run(async () => {
    const row = { enabled: !!bk.enabled, onedrive_user: bk.onedrive_user.trim() || null, folder: bk.folder.trim() || 'Asnys ERP backups', keep_days: Number(bk.keep_days) || 90,
      function_url: `${supabaseUrl}/functions/v1/asnys-m365`, updated_at: new Date().toISOString() };
    if (row.enabled && !row.onedrive_user) throw new Error('Enter the Microsoft 365 account whose OneDrive keeps the backups.');
    await q(supabase.from('company_backup').upsert({ company_id: cid, ...row }) as any); reload();
  }, 'Backup settings saved');
  const download = () => act.run(async () => {
    const tables = await rpc<string[]>('my_backup_tables', { cid });
    const out: Record<string, any[]> = {};
    for (const t of tables) {
      const rows: any[] = [];
      for (let from = 0; ; from += 1000) {
        const { data: page, error: e } = await supabase.from(t).select('*').eq('company_id', cid).range(from, from + 999);
        if (e) { rows.push({ _error: e.message }); break; }
        rows.push(...(page || [])); if (!page || page.length < 1000) break;
      }
      out[t] = rows;
    }
    const json = JSON.stringify({ app: 'Asnys ERP', company: company?.name, taken_at: new Date().toISOString(), tables: out });
    let blob: Blob = new Blob([json], { type: 'application/json' }), ext = 'json';
    if ('CompressionStream' in window) { blob = await new Response(new Blob([json]).stream().pipeThrough(new (window as any).CompressionStream('gzip'))).blob(); ext = 'json.gz'; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `asnys-backup-${(company?.name || 'company').replace(/\W+/g, '-')}-${new Date().toISOString().slice(0, 10)}.${ext}`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }, 'Backup downloaded — keep it somewhere safe');
  const b = data.backup;

  return <>
    <PageHead title="Security & backup" sub="2-step sign-in, who has it, daily backups to OneDrive and the Microsoft 365 key." />
    <div className="tiles">
      <div className="tile"><span>People with 2-step sign-in</span><b>{people.filter(p => p.mfa).length} of {people.length}</b></div>
      <div className="tile"><span>Required for</span><b style={{ fontSize: 15 }}>{mfaRoles.length ? ROLE_NAMES.filter(r => mfaRoles.includes(r[0])).map(r => r[1]).join(', ') : 'Nobody yet'}</b></div>
      <div className="tile"><span>Last OneDrive backup</span><b style={{ fontSize: 15, color: b?.last_status && b.last_status !== 'ok' ? 'var(--bad)' : undefined }}>{b?.last_run_at ? `${b.last_run_at.slice(0, 16).replace('T', ' ')} · ${b.last_status === 'ok' ? 'OK' : b.last_status}` : 'Never'}</b></div>
      <div className="tile"><span>Microsoft 365 key expires</span><b style={{ fontSize: 15 }}>{data.cert_expires || data.secret_expires || 'Not recorded'}</b></div>
    </div>
    <MyTwoStep />
    <Panel title="Require 2-step sign-in" pad>
      <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>Tick who must use a code from their phone. The next time they open Asnys, they are walked through setting it up. First turn on <b>TOTP</b> in Supabase: Authentication → Sign In / Providers → Multi-Factor.</p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14 }}>{ROLE_NAMES.map(([r, l]) => <label key={r} className="check"><input type="checkbox" checked={mfaRoles.includes(r)} disabled={act.busy}
        onChange={e => act.run(async () => { await rpc('set_mfa_roles', { cid, p_roles: e.target.checked ? [...mfaRoles, r] : mfaRoles.filter(x => x !== r) }); reload(); }, 'Saved')} /> {l}</label>)}</div>
      {without.length > 0 && <p style={{ marginBottom: 0, fontSize: 13 }}><span className="pill warn">{without.length}</span> still to set it up: {without.map(p => p.email).join(', ')}</p>}
    </Panel>
    <Panel title="People and sign-in">
      {people.length ? <div className="scroll"><table>
        <thead><tr><th>Person</th><th>Role</th><th>2-step</th><th>Last sign-in</th></tr></thead>
        <tbody>{people.map(p => <tr key={p.email}><td>{p.email}</td><td>{p.role.replace('_', ' ')}</td><td>{p.mfa ? <span className="pill good">On</span> : mfaRoles.includes(p.role) ? <span className="pill warn">Required, not set up</span> : <span className="muted">Off</span>}</td>
          <td className="num">{p.last_sign_in_at ? p.last_sign_in_at.slice(0, 16).replace('T', ' ') : <span className="muted">Never</span>}</td></tr>)}</tbody>
      </table></div> : <Empty>No people.</Empty>}
    </Panel>
    <Panel title="Daily backup to OneDrive (Microsoft 365)" pad>
      <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>Every night at about 06:10 a compressed copy of all of {company?.name}'s data is saved to a OneDrive folder, and old copies are deleted after the days you set. This uses the same Microsoft 365 app as email, with the extra permission <b>Files.ReadWrite.All</b>. Supabase also keeps its own daily database backups.</p>
      <label className="check"><input type="checkbox" checked={!!bk.enabled} onChange={e => setBk({ ...bk, enabled: e.target.checked })} /> Back up to OneDrive every day</label>
      <div className="grid-form" style={{ marginTop: 10 }}>
        <Field label="OneDrive of (Microsoft 365 account)" id="bk-user" type="email" value={bk.onedrive_user || ''} onChange={v => setBk({ ...bk, onedrive_user: v })} placeholder="it@gulfaco.com" />
        <Field label="Folder" id="bk-folder" value={bk.folder} onChange={v => setBk({ ...bk, folder: v })} />
        <Select label="Keep backups for" id="bk-keep" value={String(bk.keep_days)} onChange={v => setBk({ ...bk, keep_days: v })} options={[['30', '30 days'], ['90', '90 days'], ['180', '6 months'], ['365', '1 year'], ['730', '2 years'], ['2555', '7 years']]} />
      </div>
      {b?.last_file && <p className="muted" style={{ fontSize: 13 }}>Last file: {b.last_file}{b.last_size ? ` (${(b.last_size / 1048576).toFixed(1)} MB)` : ''}</p>}
      <div className="actions" style={{ marginTop: 10 }}>
        <button className="btn primary" type="button" disabled={act.busy} onClick={saveBackup}>Save</button>
        <button className="btn" type="button" disabled={act.busy || !b?.enabled} onClick={() => act.run(async () => { await rpc('backup_now', { cid }); setTimeout(reload, 15000); }, 'Backup started — the result shows here in a minute')}>Back up now</button>
        <button className="btn" type="button" disabled={act.busy} onClick={download}>{act.busy ? 'Working…' : 'Download a backup to this computer'}</button>
      </div>
    </Panel>
    <Panel title="Security checklist" pad>
      <ul style={{ margin: 0, paddingLeft: 18, display: 'grid', gap: 6, fontSize: 14 }}>
        <li>Every person signs in with their own work email; nobody shares a login. Remove people the day they leave (Settings &amp; team).</li>
        <li>Give each person the narrowest role that does the job — use custom <b>Roles</b> for mixed jobs instead of making people admins.</li>
        <li>Require 2-step sign-in for owners, admins and Finance (above).</li>
        <li>The Supabase <b>service_role</b> key, the Telegram bot token and the Microsoft 365 private key live only in Supabase secrets — never in the app, email or chat.</li>
        <li>Every change is recorded in the Activity log, and entries made in error are voided, never deleted.</li>
        <li>Lock the books after each VAT return (Settings &amp; team → Lock the books).</li>
        <li>Check this page monthly: last backup OK, everyone required has 2-step on, and the Microsoft 365 key is not near expiry (you are reminded 30 days before).</li>
      </ul>
    </Panel>
  </>;
}
