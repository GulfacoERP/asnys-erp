// Makes a self-signed certificate (RSA 2048, SHA-256) in the browser, for signing in to Microsoft 365 as an app.
// The public certificate is uploaded to the Azure app registration; the private key goes only into Supabase's secrets.

const enc = (tag: number, body: Uint8Array): Uint8Array => {
  const n = body.length;
  const len = n < 128 ? [n] : n < 256 ? [0x81, n] : n < 65536 ? [0x82, n >> 8, n & 255] : [0x83, n >> 16, (n >> 8) & 255, n & 255];
  const out = new Uint8Array(1 + len.length + n);
  out[0] = tag; out.set(len, 1); out.set(body, 1 + len.length);
  return out;
};
const cat = (...parts: Uint8Array[]) => { const out = new Uint8Array(parts.reduce((s, p) => s + p.length, 0)); let i = 0; for (const p of parts) { out.set(p, i); i += p.length; } return out; };
const seq = (...p: Uint8Array[]) => enc(0x30, cat(...p));
const set = (...p: Uint8Array[]) => enc(0x31, cat(...p));
const int = (bytes: Uint8Array) => enc(0x02, bytes[0] & 0x80 ? cat(new Uint8Array([0]), bytes) : bytes);
const oid = (s: string) => {
  const p = s.split('.').map(Number);
  const out: number[] = [p[0] * 40 + p[1]];
  for (const v of p.slice(2)) { const b: number[] = [v & 127]; let x = v >> 7; while (x) { b.unshift((x & 127) | 128); x >>= 7; } out.push(...b); }
  return enc(0x06, new Uint8Array(out));
};
const utf8 = (s: string) => enc(0x0c, new TextEncoder().encode(s));
const time = (d: Date) => {
  const y = d.getUTCFullYear(), pad = (n: number) => String(n).padStart(2, '0');
  const t = `${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
  return y < 2050 ? enc(0x17, new TextEncoder().encode(String(y).slice(2) + t)) : enc(0x18, new TextEncoder().encode(String(y) + t));
};
const pem = (label: string, der: Uint8Array) => `-----BEGIN ${label}-----\n${btoa(String.fromCharCode(...der)).match(/.{1,64}/g)!.join('\n')}\n-----END ${label}-----\n`;
const hex = (b: ArrayBuffer) => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('').toUpperCase();

export async function makeCertificate(commonName: string, years = 10) {
  const algo = { name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' };
  const kp = await crypto.subtle.generateKey(algo, true, ['sign', 'verify']) as CryptoKeyPair;
  const spki = new Uint8Array(await crypto.subtle.exportKey('spki', kp.publicKey));
  const pkcs8 = new Uint8Array(await crypto.subtle.exportKey('pkcs8', kp.privateKey));
  const serial = crypto.getRandomValues(new Uint8Array(16)); serial[0] &= 0x7f;
  const sigAlg = seq(oid('1.2.840.113549.1.1.11'), new Uint8Array([0x05, 0x00]));
  const name = seq(set(seq(oid('2.5.4.3'), utf8(commonName))));
  const from = new Date(Date.now() - 5 * 60_000); const to = new Date(from); to.setUTCFullYear(to.getUTCFullYear() + years);
  const tbs = seq(enc(0xa0, int(new Uint8Array([2]))), int(serial), sigAlg, name, seq(time(from), time(to)), name, spki);
  const sig = new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', kp.privateKey, tbs));
  const der = seq(tbs, sigAlg, enc(0x03, cat(new Uint8Array([0]), sig)));
  return {
    certificatePem: pem('CERTIFICATE', der),
    certificateDer: der,
    privateKeyPem: pem('PRIVATE KEY', pkcs8),
    thumbprint: hex(await crypto.subtle.digest('SHA-1', der)),
    expires: to.toISOString().slice(0, 10),
  };
}
