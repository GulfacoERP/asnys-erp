-- Asnys ERP v3.8 — Gulfaco's notes of 24 Nov 2026
--   1. "Who does what": each duty also says what NOT to do.
--   2. Your own contract types and client sectors (added from the drop-down), on top of the standard ones.
--   3. Supplier documents: "BoG exemption letter" (label only; uses the existing document type).
-- Run after 0025. Safe to run twice.

alter table public.cycle_responsibilities add column if not exists dont text;   -- what not to do

-- Lists the company extends itself: contract types and client sectors.
create table if not exists public.lookup_values (
  company_id uuid not null references public.companies(id) on delete cascade,
  list text not null check (list in ('contract_type','sector')),
  code text not null check (code ~ '^[a-z0-9_]{2,40}$'),
  label text not null check (length(trim(label)) between 2 and 60),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  primary key (company_id, list, code)
);
alter table public.lookup_values enable row level security;
drop policy if exists "members read lookups" on public.lookup_values;
create policy "members read lookups" on public.lookup_values for select using (is_member(company_id));
drop policy if exists "staff add lookups" on public.lookup_values;
create policy "staff add lookups" on public.lookup_values for insert with check (has_role(company_id, array['owner','admin','accountant','sales','project_manager']));
drop policy if exists "admins remove lookups" on public.lookup_values;
create policy "admins remove lookups" on public.lookup_values for delete using (has_role(company_id, array['owner','admin']));

-- Contract types and sectors are no longer limited to the fixed list.
alter table public.contracts drop constraint if exists contracts_contract_type_check;
alter table public.contracts drop constraint if exists contracts_sector_check;

-- Policies: a reference number as well as the document number.
alter table public.hse_policies add column if not exists reference_no text;

-- HR & Admin policy areas: "HR and administration" and "Compliance" replace labour/HR, administration,
-- legal and corporate, data protection and anti-bribery (existing policies move across; nothing is lost).
update public.hse_policies set area = 'hr' where scope = 'hr_admin' and area in ('labour','admin');
update public.hse_policies set area = 'compliance' where scope = 'hr_admin' and area in ('legal','data_protection','anti_bribery');
