-- Asnys ERP v3.7 — Gulfaco's notes of 18 Nov 2026
--   1. Supplier / subcontractor onboarding: type, Ghana Card, full bank and MoMo details, what they supply, documents
--      (business registration, incorporation, VAT, ISO, HSE and quality policies, tax exemption, BoG / foreign exchange,
--      others) with expiry, a requirements list per type, and approval by Finance.
--   2. Contracts: type (goods, works, services…), client sector, currency from the list; a draft contract can be started
--      from a tender before award; contract drafts kept as numbered versions; one contract or tender with several projects.
--   3. A purchase order's project can be changed (before goods are received or billed).
--   4. Policies: document / reference number generated from the company's numbering procedure; HSE policies and HR & Admin
--      compliance policies kept apart; "Other" with what it is.
-- Run after 0024. Safe to run twice.

-- ---------------------------------------------------------------- 1. Supplier onboarding
alter table public.suppliers add column if not exists supplier_type text not null default 'vendor';
alter table public.suppliers drop constraint if exists suppliers_supplier_type_check;
alter table public.suppliers add constraint suppliers_supplier_type_check check (supplier_type in ('vendor','subcontractor','both'));
alter table public.suppliers add column if not exists ghana_card text;
alter table public.suppliers add column if not exists products_services text;          -- what they supply or do
alter table public.suppliers add column if not exists bank_branch text;
alter table public.suppliers add column if not exists bank_account_name text;
alter table public.suppliers add column if not exists bank_swift text;
alter table public.suppliers add column if not exists bank_address text;
alter table public.suppliers add column if not exists momo_name text;
alter table public.suppliers add column if not exists momo_network text;
alter table public.suppliers drop constraint if exists suppliers_momo_network_check;
alter table public.suppliers add constraint suppliers_momo_network_check check (momo_network is null or momo_network in ('mtn','telecel','airteltigo','other'));
-- Suppliers already in use before onboarding existed count as approved (only the first time this runs).
do $$ begin
  if not exists (select 1 from information_schema.columns where table_schema = 'public' and table_name = 'suppliers' and column_name = 'onboarding_status') then
    alter table public.suppliers add column onboarding_status text not null default 'pending';
    update public.suppliers set onboarding_status = 'approved';
  end if;
end $$;
alter table public.suppliers drop constraint if exists suppliers_onboarding_status_check;
alter table public.suppliers add constraint suppliers_onboarding_status_check check (onboarding_status in ('pending','approved','rejected','suspended'));
alter table public.suppliers add column if not exists onboarded_at timestamptz;
alter table public.suppliers add column if not exists onboarded_by uuid;
alter table public.suppliers add column if not exists onboarding_note text;

create table if not exists public.supplier_documents (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_id uuid not null references public.suppliers(id) on delete cascade,
  doc_type text not null check (doc_type in ('business_registration','incorporation','vat_certificate','tax_clearance','iso_certificate','hse_policy',
                                             'quality_policy','tax_exemption','bog_fx','ssnit','insurance','other')),
  doc_label text,                    -- for "other": what it is
  ref_no text,
  issued_on date,
  expires_on date,
  name text,
  storage_path text,
  status text not null default 'submitted' check (status in ('submitted','verified','rejected')),
  verified_by uuid,
  verified_at timestamptz,
  note text,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists supplier_documents_supplier on public.supplier_documents (supplier_id);
alter table public.supplier_documents enable row level security;
drop policy if exists "members read supplier docs" on public.supplier_documents;
create policy "members read supplier docs" on public.supplier_documents for select using (is_member(company_id));
drop policy if exists "buyers add supplier docs" on public.supplier_documents;
create policy "buyers add supplier docs" on public.supplier_documents for insert with check (has_role(company_id, array['owner','admin','accountant','store','project_manager']));
drop policy if exists "finance edits supplier docs" on public.supplier_documents;
create policy "finance edits supplier docs" on public.supplier_documents for update using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));
drop policy if exists "finance removes supplier docs" on public.supplier_documents;
create policy "finance removes supplier docs" on public.supplier_documents for delete using (has_role(company_id, array['owner','admin','accountant']) or (uploaded_by = auth.uid() and status = 'submitted'));

-- Which documents each kind of supplier must give (Settings → Supplier onboarding).
create table if not exists public.onboarding_requirements (
  company_id uuid not null references public.companies(id) on delete cascade,
  supplier_type text not null check (supplier_type in ('vendor','subcontractor')),
  doc_type text not null,
  required boolean not null default true,
  primary key (company_id, supplier_type, doc_type)
);
alter table public.onboarding_requirements enable row level security;
drop policy if exists "members read requirements" on public.onboarding_requirements;
create policy "members read requirements" on public.onboarding_requirements for select using (is_member(company_id));
drop policy if exists "finance sets requirements" on public.onboarding_requirements;
create policy "finance sets requirements" on public.onboarding_requirements for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

create or replace function public.seed_onboarding(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into onboarding_requirements (company_id, supplier_type, doc_type, required)
  select cid, t, d, r from (values
    ('vendor','business_registration',true),('vendor','incorporation',true),('vendor','vat_certificate',true),('vendor','iso_certificate',false),
    ('vendor','hse_policy',false),('vendor','quality_policy',false),('vendor','tax_exemption',false),('vendor','bog_fx',false),
    ('subcontractor','business_registration',true),('subcontractor','incorporation',true),('subcontractor','vat_certificate',false),('subcontractor','iso_certificate',false),
    ('subcontractor','hse_policy',true),('subcontractor','quality_policy',true),('subcontractor','tax_exemption',false),('subcontractor','bog_fx',false)) v(t, d, r)
  on conflict do nothing;
$$;
select public.seed_onboarding(id) from public.companies;

-- What is still missing for a supplier (required documents not uploaded, or rejected or expired).
create or replace function public.supplier_missing_docs(p_supplier uuid) returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(r.doc_type order by r.doc_type), '{}')
    from suppliers s join onboarding_requirements r on r.company_id = s.company_id and r.required
         and (r.supplier_type = s.supplier_type or (s.supplier_type = 'both'))
   where s.id = p_supplier
     and not exists (select 1 from supplier_documents d where d.supplier_id = s.id and d.doc_type = r.doc_type
                      and d.status <> 'rejected' and (d.expires_on is null or d.expires_on >= current_date));
$$;

create or replace function public.decide_supplier(p_supplier uuid, p_status text, p_note text default null, p_override boolean default false) returns void
language plpgsql security definer set search_path = public as $$
declare s suppliers; v_missing text[];
begin
  select * into s from suppliers where id = p_supplier for update;
  if not found then raise exception 'Supplier not found'; end if;
  if not has_role(s.company_id, array['owner','admin','accountant']) then raise exception 'Only Finance or an admin approves suppliers'; end if;
  if p_status not in ('approved','rejected','suspended','pending') then raise exception 'Unknown status'; end if;
  if p_status = 'approved' then
    v_missing := supplier_missing_docs(p_supplier);
    if cardinality(v_missing) > 0 and not p_override then
      raise exception 'Still missing: %. Upload them, or approve anyway with a note.', replace(array_to_string(v_missing, ', '), '_', ' ');
    end if;
    if cardinality(v_missing) > 0 and coalesce(trim(p_note), '') = '' then raise exception 'Say why it is approved without every document'; end if;
  end if;
  if p_status in ('rejected','suspended') and coalesce(trim(p_note), '') = '' then raise exception 'Give the reason'; end if;
  update suppliers set onboarding_status = p_status, onboarded_at = now(), onboarded_by = auth.uid(), onboarding_note = p_note where id = p_supplier;
  update supplier_documents set status = 'verified', verified_by = auth.uid(), verified_at = now() where supplier_id = p_supplier and status = 'submitted' and p_status = 'approved';
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (s.company_id, 'supplier.' || p_status, 'suppliers', s.id, jsonb_build_object('supplier', s.name, 'note', p_note, 'missing', v_missing));
end $$;

-- Reminders: supplier documents that expire within 30 days (once a week per document).
alter table public.supplier_documents add column if not exists reminded_on date;
create or replace function public.run_supplier_doc_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare d record; n int := 0;
begin
  for d in select sd.*, s.name supplier from supplier_documents sd join suppliers s on s.id = sd.supplier_id
            where sd.expires_on is not null and sd.expires_on <= current_date + 30 and sd.status <> 'rejected' and s.onboarding_status = 'approved'
              and (sd.reminded_on is null or sd.reminded_on < current_date - 7) loop
    perform notify(d.company_id, array['accountant','store'], null, 'supplier_doc_expiry',
      d.supplier || ': ' || replace(d.doc_type, '_', ' ') || case when d.expires_on < current_date then ' has expired' else ' expires ' || to_char(d.expires_on, 'DD Mon YYYY') end,
      'Ask the supplier for the renewed document and upload it on their page.', '/suppliers/' || d.supplier_id, true);
    update supplier_documents set reminded_on = current_date where id = d.id;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke execute on function public.run_supplier_doc_reminders() from public, anon, authenticated;
create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_integration_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_supplier_doc_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 2. Contracts: type, sector, drafts, several projects
alter table public.contracts add column if not exists contract_type text;
alter table public.contracts drop constraint if exists contracts_contract_type_check;
alter table public.contracts add constraint contracts_contract_type_check check (contract_type is null or contract_type in ('goods','works','services','goods_works','consultancy','other'));
alter table public.contracts add column if not exists sector text;
alter table public.contracts drop constraint if exists contracts_sector_check;
alter table public.contracts add constraint contracts_sector_check check (sector is null or sector in ('oil_gas','power_energy','mining','manufacturing','construction','government','telecom','other'));
alter table public.tenders add column if not exists contract_type text;
alter table public.tenders add column if not exists sector text;
alter table public.customers add column if not exists sector text;

alter table public.contract_files drop constraint if exists contract_files_kind_check;
alter table public.contract_files add constraint contract_files_kind_check check (kind in ('draft','signed_contract','variation','security','correspondence','other'));
alter table public.contract_files add column if not exists version int;
alter table public.contract_files add column if not exists note text;
-- Drafts are numbered Draft 1, 2, 3… per contract.
create or replace function public.contract_file_version() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.kind = 'draft' and new.version is null then
    select coalesce(max(version), 0) + 1 into new.version from contract_files where contract_id = new.contract_id and kind = 'draft';
  end if;
  return new;
end $$;
drop trigger if exists contract_files_version on public.contract_files;
create trigger contract_files_version before insert on public.contract_files for each row execute function public.contract_file_version();

-- A tender's contract can be started as a draft before award; on award the draft becomes the active contract.
create or replace function public.contract_from_tender(p_tender uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders; v uuid; pj uuid; c contracts;
begin
  select * into t from tenders where id = p_tender;
  if not found then raise exception 'Tender not found'; end if;
  pj := coalesce(t.project_id, (select id from projects where tender_id = t.id order by created_at limit 1));
  select * into c from contracts where tender_id = p_tender;
  if found then
    if t.status = 'awarded' and c.status = 'draft' then
      update contracts set status = 'active', value = coalesce(t.awarded_value, value), their_ref = coalesce(t.contract_ref, their_ref),
             signed_on = coalesce(t.contract_signed_on, signed_on), project_id = coalesce(project_id, pj),
             payment_terms_days = coalesce((to_jsonb(t)->>'payment_terms_days')::int, payment_terms_days),
             advance_pct = coalesce((to_jsonb(t)->>'advance_pct')::numeric, advance_pct), retention_pct = coalesce((to_jsonb(t)->>'retention_pct')::numeric, retention_pct)
       where id = c.id;
    end if;
    return c.id;
  end if;
  insert into contracts (company_id, title, kind, customer_id, counterparty, their_ref, project_id, tender_id, value, currency, signed_on, start_date, status,
                         payment_terms_days, advance_pct, retention_pct, owner_id, description, contract_type, sector)
  values (t.company_id, t.title, 'client', t.customer_id, t.client_name, t.contract_ref, pj, t.id,
          coalesce(t.awarded_value, t.submitted_value, t.est_value, 0), t.currency, t.contract_signed_on,
          coalesce((select start_date from projects where id = pj), t.contract_signed_on),
          case when t.status = 'awarded' then 'active' else 'draft' end,
          (to_jsonb(t)->>'payment_terms_days')::int, (to_jsonb(t)->>'advance_pct')::numeric, (to_jsonb(t)->>'retention_pct')::numeric,
          coalesce(t.bd_owner_id, auth.uid()),
          case when t.status = 'awarded' then 'Awarded on ' || t.number || coalesce(' (' || replace(t.award_type, '_', ' ') || ')', '') else 'Draft from ' || t.number end,
          t.contract_type, t.sector)
  returning id into v;
  return v;
end $$;

-- From the tender page: start (or open) the contract.
create or replace function public.start_contract_from_tender(p_tender uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders;
begin
  select * into t from tenders where id = p_tender;
  if not found then raise exception 'Tender not found'; end if;
  if not has_role(t.company_id, array['owner','admin','accountant','sales','project_manager']) then raise exception 'Your role cannot start contracts'; end if;
  if t.status in ('lost','no_bid','cancelled','voided') then raise exception 'This tender is %; it cannot have a contract', t.status; end if;
  return contract_from_tender(p_tender);
end $$;

-- Several projects under one contract or tender.
alter table public.projects add column if not exists contract_id uuid references public.contracts(id) on delete set null;
update public.projects p set contract_id = c.id from public.contracts c where c.project_id = p.id and p.contract_id is null;
update public.projects p set contract_id = c.id from public.contracts c where c.tender_id is not null and p.tender_id = c.tender_id and p.contract_id is null;

drop function if exists public.register_project_from_tender(uuid, text, uuid, uuid, date, date, text, uuid);
create or replace function public.register_project_from_tender(p_tender uuid, p_name text, p_cost_centre uuid, p_manager uuid, p_start date, p_end date,
  p_billing text default 'fixed_price', p_branch uuid default null, p_value numeric default null) returns uuid
language plpgsql security definer set search_path = public as $$
declare t tenders; v uuid; v_value numeric; v_contract uuid;
begin
  select * into t from tenders where id = p_tender for update;
  if not found then raise exception 'Tender not found'; end if;
  if not has_role(t.company_id, array['owner','admin','accountant']) then raise exception 'Only Finance registers projects'; end if;
  if t.status <> 'awarded' then raise exception 'Only an awarded tender becomes a project'; end if;
  -- The first project takes the whole award unless a share is given; further projects take the share given.
  v_value := coalesce(p_value, case when t.project_id is null then t.awarded_value else 0 end);
  v_contract := (select id from contracts where tender_id = t.id);
  insert into projects (company_id, name, customer_id, status, start_date, end_date, manager_id, billing_type, contract_value, currency, location, description, hourly_rate, tender_id, contract_ref, contract_id)
  values (t.company_id, coalesce(nullif(trim(p_name), ''), t.title), t.customer_id, 'planned', p_start, p_end, p_manager, p_billing, v_value, 'GHS', t.location,
          'From ' || t.number || ' (' || replace(coalesce(t.award_type, 'award'), '_', ' ') || ' ' || coalesce(t.contract_ref, '') || ')', 0, t.id, t.contract_ref, v_contract)
  returning id into v;
  if t.project_id is null then
    perform set_config('sika.cycle','on', true);
    update tenders set project_id = v where id = p_tender;
    perform set_config('sika.cycle','off', true);
  end if;
  perform register_project(v, p_cost_centre, p_branch, t.contract_ref, v_value);
  return v;
end $$;

create or replace function public.link_project_contract(p_project uuid, p_contract uuid) returns void
language plpgsql security definer set search_path = public as $$
declare p projects; c contracts;
begin
  select * into p from projects where id = p_project;
  if not found then raise exception 'Project not found'; end if;
  if not has_role(p.company_id, array['owner','admin','accountant','project_manager']) then raise exception 'Your role cannot link projects to contracts'; end if;
  if p_contract is not null then
    select * into c from contracts where id = p_contract and company_id = p.company_id;
    if not found then raise exception 'Contract not found'; end if;
  end if;
  update projects set contract_id = p_contract where id = p_project;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (p.company_id, 'project.contract', 'projects', p.id, jsonb_build_object('contract', c.number));
end $$;

-- ---------------------------------------------------------------- 3. Move a purchase order to another project
create or replace function public.set_po_project(p_po uuid, p_project uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare po purchase_orders; v_old uuid;
begin
  select * into po from purchase_orders where id = p_po for update;
  if not found then raise exception 'Purchase order not found'; end if;
  if not has_role(po.company_id, array['owner','admin','accountant','store']) then raise exception 'Only Finance or the storekeeper can change the project of an order'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why the project is changing'; end if;
  if po.status in ('cancelled','closed') then raise exception 'This order is %', po.status; end if;
  if exists (select 1 from po_lines where po_id = p_po and (received_qty > 0 or billed_qty > 0)) then
    raise exception 'Goods have been received or billed on this order; their cost is already on the old project. Raise a new order for the other project instead.';
  end if;
  if p_project is not null and not exists (select 1 from projects where id = p_project and company_id = po.company_id and not is_template) then raise exception 'Project not found'; end if;
  v_old := po.project_id;
  perform set_config('sika.po', 'on', true);
  update purchase_orders set project_id = p_project where id = p_po;
  update po_lines set project_id = p_project where po_id = p_po and (project_id is not distinct from v_old or project_id is null);
  perform set_config('sika.po', 'off', true);
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (po.company_id, 'po.project_changed', 'purchase_orders', po.id, jsonb_build_object('number', po.number, 'from', (select number from projects where id = v_old),
          'to', (select number from projects where id = p_project), 'reason', trim(p_reason)));
end $$;

-- ---------------------------------------------------------------- 4. Policies: numbers from the numbering procedure; HSE vs HR & Admin
alter table public.hse_policies add column if not exists doc_number text;
alter table public.hse_policies add column if not exists area_other text;          -- when the area is "other": what it is
alter table public.hse_policies add column if not exists scope text not null default 'hse';
alter table public.hse_policies drop constraint if exists hse_policies_scope_check;
alter table public.hse_policies add constraint hse_policies_scope_check check (scope in ('hse','hr_admin'));
update public.hse_policies set scope = 'hr_admin' where scope = 'hse' and area in ('legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it');
alter table public.hse_policies drop constraint if exists hse_policies_area_check;
alter table public.hse_policies add constraint hse_policies_area_check
  check (area in ('safety','environment','quality','security','emergency','legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it','compliance','other'));

-- The numbering procedure: e.g. "{CO}-{AREA}-POL-{SEQ}" → GUF-HSE-POL-001. Tokens: {CO} company code, {AREA} area code,
-- {YYYY} year, {SEQ} running number (3 digits).
alter table public.companies add column if not exists policy_numbering text not null default '{CO}-{AREA}-POL-{SEQ}';
alter table public.companies add column if not exists policy_numbering_note text;

create or replace function public.policy_area_code(p_area text) returns text
language sql immutable as $$
  select case p_area when 'safety' then 'HSE' when 'environment' then 'ENV' when 'quality' then 'QA' when 'security' then 'SEC' when 'emergency' then 'ERP'
    when 'legal' then 'LEG' when 'tax_finance' then 'FIN' when 'labour' then 'HRA' when 'hr' then 'HR' when 'admin' then 'ADM' when 'it' then 'IT'
    when 'data_protection' then 'DPP' when 'anti_bribery' then 'ABC' when 'compliance' then 'CMP' else 'GEN' end;
$$;

create or replace function public.next_policy_number(cid uuid, p_area text) returns text
language plpgsql security definer set search_path = public as $$
declare f text; v int; code text := policy_area_code(p_area);
begin
  if not (is_hse(cid) or has_role(cid, array['owner','admin','hr'])) then raise exception 'Only HSE, HR or an admin numbers policies'; end if;
  select policy_numbering into f from companies where id = cid;
  insert into number_sequences (company_id, key, next_value) values (cid, 'POL-' || code, 2)
  on conflict (company_id, key) do update set next_value = number_sequences.next_value + 1
  returning next_value - 1 into v;
  return replace(replace(replace(replace(coalesce(f, '{CO}-{AREA}-POL-{SEQ}'),
    '{CO}', coalesce((select doc_prefix from companies where id = cid), 'CO')), '{AREA}', code), '{YYYY}', to_char(current_date, 'YYYY')), '{SEQ}', lpad(v::text, 3, '0'));
end $$;

create or replace function public.set_policy_numbering(cid uuid, p_format text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not (is_hse(cid) or has_role(cid, array['owner','admin','hr'])) then raise exception 'Only HSE, HR or an admin can change this'; end if;
  if position('{SEQ}' in coalesce(p_format, '')) = 0 then raise exception 'The format must contain {SEQ} (the running number)'; end if;
  update companies set policy_numbering = trim(p_format), policy_numbering_note = nullif(trim(p_note), '') where id = cid;
end $$;

-- ---------------------------------------------------------------- 5. New companies and audit
create or replace function public.company_seed_v37() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform seed_onboarding(new.id); return null; end $$;
drop trigger if exists companies_seed_v37 on public.companies;
create trigger companies_seed_v37 after insert on public.companies for each row execute function public.company_seed_v37();

do $$ declare t text; begin
  foreach t in array array['supplier_documents'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;
