-- Asnys ERP v3.9 — Gulfaco's notes of 25 Nov 2026
--   1. Policy areas: "Health, safety and environment" (one area), "HR and Administration", Compliance;
--      Legal and corporate, Data protection, Anti-bribery, Labour and Administration are folded in.
--   2. USD and EUR are set up for every company, so every currency drop-down offers them.
--   3. Suppliers: "accepts MoMo", branch sort code, the currency they invoice in.
--   4. Purchase orders need an approved (onboarded) supplier before they can be approved (company setting, on by default).
--   5. Scope 3 emission factors (travel, hired transport, freight, water, waste).
--   6. Reports fetch today's Bank of Ghana rates first when the last fetch is old.
--   7. "What this page is for" guides, editable per company.
-- Run after 0026. Safe to run twice.

-- ---------------------------------------------------------------- 1. Policy and compliance areas
update public.hse_policies set area = 'safety' where area = 'environment';
update public.hse_policies set area = 'hr' where area in ('labour','admin');
update public.hse_policies set area = 'compliance' where area in ('legal','data_protection','anti_bribery');
update public.hse_policies set scope = 'hr_admin' where scope = 'hse' and area in ('hr','compliance','it','tax_finance');

alter table public.compliance_obligations drop constraint if exists compliance_obligations_area_check;
update public.compliance_obligations set area = 'safety' where area = 'environment';
update public.compliance_obligations set area = 'hr' where area in ('labour','admin');
update public.compliance_obligations set area = 'compliance' where area in ('legal','data_protection','anti_bribery');
alter table public.compliance_obligations add constraint compliance_obligations_area_check
  check (area in ('safety','environment','quality','security','emergency','legal','tax_finance','labour','data_protection','anti_bribery','hr','admin','it','compliance','other'));

-- ---------------------------------------------------------------- 2. USD and EUR for every company
create or replace function public.seed_main_currencies(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  insert into currencies (company_id, code, name, rate, rate_date, rate_source, auto_rate)
  select cid, x.code, x.name, r.mid, r.rate_date, r.source, true
    from (values ('USD', 'US dollar'), ('EUR', 'Euro')) x(code, name)
    cross join lateral (select mid, rate_date, source from fx_rates where code = x.code and mid > 0 order by rate_date desc limit 1) r
  on conflict (company_id, code) do nothing;
end $$;
-- Only with a real Bank of Ghana rate: a made-up rate must never be used. Until the first fetch the app still offers
-- USD and EUR in every drop-down and asks for the rate to be typed in.

-- When BoG rates arrive, every company gets USD and EUR.
create or replace function public.fx_rates_main_currencies() returns trigger
language plpgsql security definer set search_path = public as $$
declare c record;
begin
  if new.code in ('USD','EUR') then
    for c in select id from companies loop perform seed_main_currencies(c.id); end loop;
  end if;
  return new;
end $$;
drop trigger if exists fx_rates_main_currencies on public.fx_rates;
create trigger fx_rates_main_currencies after insert on public.fx_rates for each row execute function public.fx_rates_main_currencies();
revoke execute on function public.seed_main_currencies(uuid) from public, anon, authenticated;

create or replace function public.company_main_currencies() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform seed_main_currencies(new.id); return new; end $$;
drop trigger if exists companies_main_currencies on public.companies;
create trigger companies_main_currencies after insert on public.companies for each row execute function public.company_main_currencies();
do $$ declare c record; begin for c in select id from public.companies loop perform public.seed_main_currencies(c.id); end loop; end $$;

-- ---------------------------------------------------------------- 3. Supplier payment details
alter table public.suppliers add column if not exists accepts_momo boolean not null default false;
alter table public.suppliers add column if not exists bank_sort_code text;
alter table public.suppliers add column if not exists currency text not null default 'GHS';
update public.suppliers set accepts_momo = true where momo_number is not null and not accepts_momo;

-- ---------------------------------------------------------------- 4. Buy only from onboarded suppliers
alter table public.companies add column if not exists po_needs_approved_supplier boolean not null default true;

create or replace function public.po_supplier_onboarded() returns trigger
language plpgsql security definer set search_path = public as $$
declare st text; nm text;
begin
  if new.status = 'approved' and old.status is distinct from 'approved'
     and (select po_needs_approved_supplier from companies where id = new.company_id) then
    select onboarding_status, name into st, nm from suppliers where id = new.supplier_id;
    if st is not null and st <> 'approved' then
      raise exception '% is not an approved supplier yet (onboarding %). Finish onboarding on the supplier''s page, then approve the order.', nm, st;
    end if;
  end if;
  return new;
end $$;
drop trigger if exists purchase_orders_supplier_onboarded on public.purchase_orders;
create trigger purchase_orders_supplier_onboarded before update of status on public.purchase_orders for each row execute function public.po_supplier_onboarded();

-- Only Finance (owner, admin, accountant) can mark a supplier approved, rejected or suspended.
create or replace function public.supplier_onboarding_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (tg_op = 'INSERT' and new.onboarding_status <> 'pending') or (tg_op = 'UPDATE' and new.onboarding_status is distinct from old.onboarding_status) then
    if not has_role(new.company_id, array['owner','admin','accountant']) then
      raise exception 'Only Finance can approve, reject or suspend a supplier';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists suppliers_onboarding_guard on public.suppliers;
create trigger suppliers_onboarding_guard before insert or update of onboarding_status on public.suppliers for each row execute function public.supplier_onboarding_guard();

-- Vendor onboarding list: every supplier with its status and what is still missing.
create or replace function public.vendor_onboarding_list(cid uuid) returns table (
  id uuid, name text, supplier_type text, onboarding_status text, tin text, contact_name text, contact_phone text,
  products_services text, created_at timestamptz, onboarded_at timestamptz, docs int, missing text[], open_pos int)
language sql stable security definer set search_path = public as $$
  select s.id, s.name, s.supplier_type, s.onboarding_status, s.tin, s.contact_name, s.contact_phone, s.products_services, s.created_at, s.onboarded_at,
         (select count(*)::int from supplier_documents d where d.supplier_id = s.id and d.status <> 'rejected'),
         supplier_missing_docs(s.id),
         (select count(*)::int from purchase_orders o where o.supplier_id = s.id and o.status in ('draft','approved','sent','partial'))
    from suppliers s
   where s.company_id = cid and is_member(cid)
   order by case s.onboarding_status when 'pending' then 0 when 'suspended' then 1 when 'rejected' then 2 else 3 end, s.created_at desc;
$$;

-- ---------------------------------------------------------------- 5. Scope 3 (value chain) factors
-- Approximate UK DESNZ/DEFRA conversion factors; Finance or HSE can change them under Emission factors.
create or replace function public.seed_scope3_factors(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
declare was text := coalesce(current_setting('sika.seed', true), '');
begin
  perform set_config('sika.seed', 'on', true);
  insert into esg_factors (company_id, key, name, category, scope, unit, kg_co2e, source) values
    (cid, 'flight_domestic_pkm', 'Flights, domestic (e.g. Accra–Kumasi)', 'travel', 3, 'passenger-km', 0.27258, 'UK DESNZ/DEFRA, domestic flight with radiative forcing (approximate)'),
    (cid, 'flight_short_pkm', 'Flights, regional (up to 3,700 km)', 'travel', 3, 'passenger-km', 0.18592, 'UK DESNZ/DEFRA, short-haul average passenger with RF (approximate)'),
    (cid, 'flight_long_pkm', 'Flights, international long-haul', 'travel', 3, 'passenger-km', 0.26128, 'UK DESNZ/DEFRA, long-haul average passenger with RF (approximate)'),
    (cid, 'taxi_km', 'Taxi, hired car or ride-hailing', 'travel', 3, 'km', 0.14861, 'UK DESNZ/DEFRA, regular taxi (approximate)'),
    (cid, 'bus_pkm', 'Bus or staff shuttle', 'travel', 3, 'passenger-km', 0.10227, 'UK DESNZ/DEFRA, average local bus (approximate)'),
    (cid, 'freight_road_tkm', 'Hired trucks: goods delivered by road', 'other', 3, 'tonne-km', 0.10650, 'UK DESNZ/DEFRA, HGV all diesel, average laden (approximate)'),
    (cid, 'freight_sea_tkm', 'Sea freight (imports)', 'other', 3, 'tonne-km', 0.01614, 'UK DESNZ/DEFRA, container ship average (approximate)')
  on conflict (company_id, key) do nothing;
  -- Water and waste were quantity-only; give them their Scope 3 factor unless someone already set one.
  update esg_factors set scope = 3, kg_co2e = 0.17700, source = 'UK DESNZ/DEFRA, water supply (approximate)'
   where company_id = cid and key = 'water_m3' and scope is null and kg_co2e = 0;
  update esg_factors set scope = 3, kg_co2e = 0.46700, source = 'UK DESNZ/DEFRA, commercial and industrial waste to landfill (approximate)'
   where company_id = cid and key = 'waste_landfill_kg' and scope is null and kg_co2e = 0;
  update esg_factors set scope = 3, kg_co2e = 0.02130, source = 'UK DESNZ/DEFRA, recycling (approximate)'
   where company_id = cid and key = 'waste_recycled_kg' and scope is null and kg_co2e = 0;
  perform set_config('sika.seed', case when was = 'on' then 'on' else 'off' end, true);
end $$;
revoke execute on function public.seed_scope3_factors(uuid) from public, anon, authenticated;

-- New companies: seeded right after the standard factors are.
create or replace function public.esg_scope3_after_seed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.key = 'waste_hazardous_kg' then perform seed_scope3_factors(new.company_id); end if;
  return new;
end $$;
drop trigger if exists esg_factors_scope3 on public.esg_factors;
create trigger esg_factors_scope3 after insert on public.esg_factors for each row execute function public.esg_scope3_after_seed();
do $$ declare c record; begin
  for c in select distinct company_id from public.esg_factors where key = 'diesel_l' loop perform public.seed_scope3_factors(c.company_id); end loop;
end $$;

-- ---------------------------------------------------------------- 6. Today's BoG rates before a report
create or replace function public.fx_refresh_if_stale(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare s fx_settings;
begin
  perform require_member(cid);
  select * into s from fx_settings where id = 1;
  if not found or not s.enabled or to_regnamespace('net') is null then return 'off'; end if;
  if s.last_run_at is not null and s.last_run_at > now() - interval '3 hours' then return 'fresh'; end if;
  if extract(isodow from now()) > 5 and s.last_rate_date is not null and s.last_rate_date >= current_date - 3 then return 'fresh'; end if;
  begin
    if start_fx_fetch() is null then return 'off'; end if;
  exception when others then return 'off';
  end;
  return 'started';
end $$;

-- ---------------------------------------------------------------- 7. Page guides
create table if not exists public.page_guides (
  company_id uuid not null references public.companies(id) on delete cascade,
  path text not null check (path ~ '^/[a-z0-9/_-]*$'),
  what text,
  who text,
  dos text,
  donts text,
  updated_by uuid default auth.uid(),
  updated_at timestamptz not null default now(),
  primary key (company_id, path)
);
alter table public.page_guides enable row level security;
drop policy if exists "members read guides" on public.page_guides;
create policy "members read guides" on public.page_guides for select using (is_member(company_id));
drop policy if exists "admins write guides" on public.page_guides;
create policy "admins write guides" on public.page_guides for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));

do $$ begin
  if not exists (select 1 from pg_trigger where tgname = 'page_guides_audit') and exists (select 1 from pg_proc where proname = 'audit_row') then
    create trigger page_guides_audit after insert or update or delete on public.page_guides for each row execute function public.audit_row();
  end if;
end $$;
