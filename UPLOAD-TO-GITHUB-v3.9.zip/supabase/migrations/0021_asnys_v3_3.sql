-- Asnys ERP v3.3 — Send email through the company's own Microsoft 365 (no Brevo)
-- Emails go out from a real mailbox (e.g. notifications@gulfaco.com) through Microsoft Graph, using an app
-- registered in the company's Microsoft 365 (Azure). The Microsoft keys stay in Supabase's secret store and the
-- send-mail function; the database only knows the function's address and a shared secret.
-- Brevo stays available as an alternative. Run after 0020. Safe to run twice.

alter table public.company_email drop constraint if exists company_email_provider_check;
alter table public.company_email add constraint company_email_provider_check check (provider in ('brevo','microsoft'));
alter table public.company_email add column if not exists function_url text;     -- https://<project>.supabase.co/functions/v1/send-mail
-- The shared secret lives in its own table that nobody can read from the app (RLS on, no policies).
create table if not exists public.company_email_secret (
  company_id uuid primary key references public.companies(id) on delete cascade,
  secret text not null default (md5(gen_random_uuid()::text || clock_timestamp()::text) || md5(gen_random_uuid()::text))
);
alter table public.company_email_secret enable row level security;
create or replace function public.company_email_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into company_email_secret (company_id) values (new.company_id) on conflict do nothing;
  return null;
end $$;
drop trigger if exists company_email_defaults on public.company_email;
create trigger company_email_defaults after insert or update on public.company_email for each row execute function public.company_email_defaults();
insert into public.company_email_secret (company_id) select company_id from public.company_email on conflict do nothing;

-- One email, by whichever service the company chose.
create or replace function public.send_company_email(cid uuid, p_to text, p_subject text, p_html text, p_text text) returns bigint
language plpgsql security definer set search_path = public as $$
declare e company_email;
begin
  select * into e from company_email where company_id = cid;
  if not found or not e.enabled or e.from_email is null or p_to is null then return null; end if;
  if e.provider = 'microsoft' then
    if e.function_url is null then return null; end if;
    return http_post_safe(e.function_url,
      jsonb_build_object('company_id', cid, 'to', p_to, 'subject', left(p_subject, 250), 'html', p_html, 'text', p_text),
      jsonb_build_object('Content-Type', 'application/json', 'x-asnys-secret', (select secret from company_email_secret where company_id = cid)));
  end if;
  if e.api_key is null then return null; end if;
  return http_post_safe('https://api.brevo.com/v3/smtp/email',
    jsonb_build_object('sender', jsonb_build_object('email', e.from_email, 'name', coalesce(e.from_name, (select name from companies where id = cid))),
      'to', jsonb_build_array(jsonb_build_object('email', p_to)), 'subject', left(p_subject, 200), 'htmlContent', p_html, 'textContent', p_text),
    jsonb_build_object('api-key', e.api_key, 'Content-Type', 'application/json', 'accept', 'application/json'));
end $$;
revoke execute on function public.send_company_email(uuid, text, text, text, text) from public, anon, authenticated;

-- Delivery now uses either service.
create or replace function public.deliver_notification() returns trigger
language plpgsql security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email; v_appr boolean; v_url text; v_email text; v_req bigint; v_text text; v_ready boolean;
begin
  begin
    select * into t from company_telegram where company_id = new.company_id;
    select * into e from company_email where company_id = new.company_id;
    if t.company_id is null and e.company_id is null then return null; end if;
    select * into uc from user_channels where company_id = new.company_id and user_id = new.user_id;
    v_appr := is_approval_kind(new.kind);
    v_url := rtrim(coalesce(t.app_url, 'https://asnys-erp.pages.dev'), '/') || coalesce(new.path, '/notifications');

    if t.bot_token is not null and t.personal and uc.telegram_chat_id is not null
       and (uc.telegram_level = 'all' or (uc.telegram_level = 'approvals' and v_appr)) then
      v_text := case when v_appr then '🔔 ' else '' end || '<b>' || tg_escape(new.title) || '</b>'
             || coalesce(E'\n' || tg_escape(new.body), '') || E'\n\n<a href="' || tg_escape(v_url) || '">' || case when v_appr then 'Open and decide' else 'Open in Asnys' end || '</a>';
      v_req := http_post_safe('https://api.telegram.org/bot' || t.bot_token || '/sendMessage',
        jsonb_build_object('chat_id', uc.telegram_chat_id, 'text', left(v_text, 4000), 'parse_mode', 'HTML', 'disable_web_page_preview', true));
      insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
      values (new.company_id, new.user_id, 'telegram', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' end);
    end if;

    v_ready := coalesce(e.enabled, false) and e.from_email is not null and ((e.provider = 'microsoft' and e.function_url is not null) or (e.provider = 'brevo' and e.api_key is not null));
    if v_ready and (coalesce(uc.email_level, 'approvals') = 'all' or (coalesce(uc.email_level, 'approvals') = 'approvals' and v_appr)) then
      select coalesce(m.email, u.email) into v_email from memberships m left join auth.users u on u.id = m.user_id where m.company_id = new.company_id and m.user_id = new.user_id;
      if v_email is not null then
        v_req := send_company_email(new.company_id, v_email, case when v_appr then '[Action] ' else '' end || new.title,
          '<div style="font-family:Arial,sans-serif;font-size:15px;color:#17231e">'
            || '<p style="margin:0 0 8px"><b>' || tg_escape(new.title) || '</b></p>'
            || coalesce('<p style="margin:0 0 16px;white-space:pre-wrap">' || tg_escape(new.body) || '</p>', '')
            || '<p><a href="' || tg_escape(v_url) || '" style="background:#1d6b55;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;display:inline-block">'
            || case when v_appr then 'Open and decide' else 'Open in Asnys ERP' end || '</a></p>'
            || '<p style="color:#5b6b63;font-size:12px">Sent by Asnys ERP for ' || tg_escape((select name from companies where id = new.company_id))
            || '. Change what you receive under Notifications → How you are notified.</p></div>',
          new.title || coalesce(E'\n' || new.body, '') || E'\n\n' || v_url);
        insert into message_log (company_id, user_id, channel, notification_id, title, request_id, status, note)
        values (new.company_id, new.user_id, 'email', new.id, new.title, v_req, case when v_req is null then 'skipped' else 'queued' end, case when v_req is null then 'pg_net is off' else v_email end);
      end if;
    end if;
  exception when others then
    null;
  end;
  return null;
end $$;

-- Used only by the send-mail function (with the service key) to check a request really came from this database.
create or replace function public.email_hook_config(cid uuid, p_secret text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('from_email', e.from_email, 'from_name', coalesce(e.from_name, c.name))
    from company_email e join companies c on c.id = e.company_id join company_email_secret x on x.company_id = e.company_id
   where e.company_id = cid and e.provider = 'microsoft' and e.enabled and x.secret = p_secret;
$$;
revoke execute on function public.email_hook_config(uuid, text) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then grant execute on function public.email_hook_config(uuid, text) to service_role; end if;
end $$;

-- Owners: send a test email to themselves now, and see how recent emails went.
create or replace function public.test_company_email(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_to text; v bigint; e company_email;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can test email'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  select * into e from company_email where company_id = cid;
  if not found or not e.enabled then raise exception 'Tick Send emails and save first'; end if;
  select coalesce(m.email, u.email) into v_to from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid();
  v := send_company_email(cid, v_to, 'Asnys ERP test email', '<p>This is a test from Asnys ERP. Email is working for ' || tg_escape((select name from companies where id = cid)) || '.</p>', 'This is a test from Asnys ERP.');
  if v is null then raise exception 'Not sent: check the settings above'; end if;
  insert into message_log (company_id, user_id, channel, title, request_id, status, note) values (cid, auth.uid(), 'email', 'Test email', v, 'queued', v_to);
  return v_to;
end $$;

create or replace function public.recent_email_results(cid uuid) returns table (sent_at timestamptz, to_email text, title text, status_code int, error text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  if to_regnamespace('net') is null then return; end if;
  return query execute
    'select l.created_at, l.note, l.title, r.status_code, left(coalesce(r.error_msg, case when r.status_code >= 300 then r.content end), 300)
       from message_log l left join net._http_response r on r.id = l.request_id
      where l.company_id = $1 and l.channel = ''email'' order by l.id desc limit 15' using cid;
end $$;

-- Each person's settings page counts Microsoft 365 as set up too.
create or replace function public.my_channels(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare uc user_channels; t company_telegram; e company_email;
begin
  perform require_member(cid);
  select * into uc from user_channels where company_id = cid and user_id = auth.uid();
  select * into t from company_telegram where company_id = cid;
  select * into e from company_email where company_id = cid;
  return jsonb_build_object(
    'telegram_ready', t.bot_token is not null and t.personal and t.bot_username is not null,
    'bot_username', t.bot_username,
    'email_ready', coalesce(e.enabled, false) and e.from_email is not null and ((e.provider = 'microsoft' and e.function_url is not null) or (e.provider = 'brevo' and e.api_key is not null)),
    'pg_net', to_regnamespace('net') is not null,
    'telegram_linked', uc.telegram_chat_id is not null,
    'telegram_username', uc.telegram_username,
    'telegram_linked_at', uc.telegram_linked_at,
    'telegram_level', coalesce(uc.telegram_level, 'all'),
    'email_level', coalesce(uc.email_level, 'approvals'),
    'email', (select coalesce(m.email, u.email) from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid and m.user_id = auth.uid()));
end $$;
