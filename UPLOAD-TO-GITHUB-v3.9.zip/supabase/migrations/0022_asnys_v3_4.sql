-- Asnys ERP v3.4 — Gulfaco's requests: numbering, customers and tax, stricter invoices, payment milestones,
-- SR/ADR/MRO requests with several items and attachments, stock for sale or for use, subcontractors,
-- company logo, backups to OneDrive, Microsoft 365 certificate, password reset by email, 2-step sign-in.
-- Run after 0021. Safe to run twice.

-- ---------------------------------------------------------------- 1. Document numbering: a company code in front (GUF-INV-00001), and set your own
alter table public.companies add column if not exists doc_prefix text check (doc_prefix ~ '^[A-Z0-9]{1,6}$');
create table if not exists public.number_formats (
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  prefix text not null check (prefix ~ '^[A-Z0-9/-]{1,12}$'),
  primary key (company_id, key)
);
alter table public.number_formats enable row level security;
drop policy if exists "members read formats" on public.number_formats;
create policy "members read formats" on public.number_formats for select using (is_member(company_id));

create or replace function public.next_number(cid uuid, p_key text, p_prefix text)
returns text language plpgsql security definer set search_path = public as $$
declare v int; v_code text; v_pre text;
begin
  insert into number_sequences (company_id, key, next_value) values (cid, p_key, 2)
  on conflict (company_id, key) do update set next_value = number_sequences.next_value + 1
  returning next_value - 1 into v;
  select doc_prefix into v_code from companies where id = cid;
  select prefix into v_pre from number_formats where company_id = cid and key = p_key;
  v_pre := coalesce(v_pre || '-', p_prefix);
  return case when v_code is not null then v_code || '-' else '' end || v_pre || lpad(v::text, 5, '0');
end $$;
revoke execute on function public.next_number(uuid, text, text) from public, anon, authenticated;

-- Settings: every sequence, its prefix and the next number; owners and Finance can change them.
create or replace function public.number_settings(cid uuid) returns table (key text, prefix text, next_value int, example text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare v_code text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  select doc_prefix into v_code from companies where id = cid;
  return query
    select s.key, coalesce(f.prefix, s.key), s.next_value,
           case when v_code is not null then v_code || '-' else '' end || coalesce(f.prefix, s.key) || '-' || lpad(s.next_value::text, 5, '0')
      from number_sequences s left join number_formats f on f.company_id = s.company_id and f.key = s.key
     where s.company_id = cid order by s.key;
end $$;

create or replace function public.set_numbering(cid uuid, p_code text, p_key text default null, p_prefix text default null, p_next int default null) returns void
language plpgsql security definer set search_path = public as $$
declare v_used int;
begin
  if not has_role(cid, array['owner','admin','accountant']) then raise exception 'Only an owner, admin or Finance can change numbering'; end if;
  update companies set doc_prefix = nullif(upper(trim(p_code)), '') where id = cid;
  if p_key is not null then
    if nullif(trim(p_prefix), '') is not null then
      insert into number_formats (company_id, key, prefix) values (cid, p_key, upper(trim(p_prefix)))
      on conflict (company_id, key) do update set prefix = excluded.prefix;
    end if;
    if p_next is not null then
      select next_value into v_used from number_sequences where company_id = cid and key = p_key;
      if p_next < 1 then raise exception 'The next number must be 1 or more'; end if;
      insert into number_sequences (company_id, key, next_value) values (cid, p_key, p_next)
      on conflict (company_id, key) do update set next_value = excluded.next_value;
    end if;
  end if;
  insert into audit_log (company_id, action, table_name, detail) values (cid, 'numbering.changed', 'number_sequences', jsonb_build_object('code', p_code, 'key', p_key, 'prefix', p_prefix, 'next', p_next));
end $$;

-- Gulfaco's request codes: SR service request, ADR procurement request, MRO material request.
insert into public.number_formats (company_id, key, prefix)
select id, k, p from public.companies, (values ('ADR','ADR'),('SR','SR'),('MRO','MRO')) v(k, p) on conflict do nothing;

-- ---------------------------------------------------------------- 2. Customers and suppliers: contacts, TIN, tax position
alter table public.customers add column if not exists contact_name text;
alter table public.customers add column if not exists contact_phone text;
alter table public.customers add column if not exists contact_email text;
alter table public.customers add column if not exists tax_status text not null default 'standard'
  check (tax_status in ('standard','exempt','zero_rated','diplomatic','free_zone'));
alter table public.customers add column if not exists exemption_ref text;
alter table public.customers add column if not exists exemption_expiry date;
alter table public.customers add column if not exists wht_agent boolean not null default false;
alter table public.customers add column if not exists wht_rate numeric(5,2) check (wht_rate between 0 and 30);
alter table public.customers add column if not exists vat_wht_agent boolean not null default false;
alter table public.customers add column if not exists tax_note text;

alter table public.suppliers add column if not exists contact_phone text;
alter table public.suppliers add column if not exists contact_email text;
alter table public.suppliers add column if not exists vat_registered boolean not null default true;
alter table public.suppliers add column if not exists wht_rate numeric(5,2) check (wht_rate between 0 and 30);
alter table public.suppliers add column if not exists tax_note text;

alter table public.companies add column if not exists strict_invoices boolean not null default false;
alter table public.companies add column if not exists wht_default_rate numeric(5,2) not null default 7.5;
update public.companies set strict_invoices = true where not strict_invoices and created_at < now() - interval '1 minute';

-- Withholding tax credit (what customers deduct and pay to GRA on Gulfaco's behalf).
create or replace function public.seed_accounts_v34(cid uuid) returns void
language sql security definer set search_path = public as $$
  insert into accounts (company_id, code, name, type, system_key) values
  (cid, '1285', 'Withholding tax credit (deducted by customers)', 'asset', 'wht_receivable')
  on conflict do nothing;
$$;
select public.seed_accounts_v34(id) from public.companies;
revoke execute on function public.seed_accounts_v34(uuid) from public, anon, authenticated;

-- ---------------------------------------------------------------- 3. Invoices tied to something, with a reference, VAT on or off
alter table public.invoices add column if not exists quote_id uuid references public.sales_quotes(id) on delete set null;
alter table public.invoices add column if not exists contract_id uuid references public.contracts(id) on delete set null;
alter table public.invoices add column if not exists milestone_id uuid references public.project_milestones(id) on delete set null;
alter table public.invoices add column if not exists customer_po text;
alter table public.invoices add column if not exists reference text;
alter table public.invoices add column if not exists charge_vat boolean not null default true;
alter table public.invoices add column if not exists wht_rate numeric(5,2);
alter table public.invoices add column if not exists wht_amount numeric(14,2) not null default 0;

-- VAT off: every line is untaxed.
create or replace function public.invoice_vat_lines() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_table_name = 'invoices' then
    if new.charge_vat is distinct from old.charge_vat and new.status = 'draft' then
      update invoice_lines l set taxable = case when new.charge_vat then coalesce((select taxable from products p where p.id = l.product_id), true) else false end where l.invoice_id = new.id;
    end if;
    return new;
  end if;
  if not coalesce((select charge_vat from invoices where id = new.invoice_id), true) then new.taxable := false; end if;
  return new;
end $$;
drop trigger if exists invoices_vat_lines on public.invoices;
create trigger invoices_vat_lines after update of charge_vat on public.invoices for each row execute function public.invoice_vat_lines();
drop trigger if exists invoice_lines_vat on public.invoice_lines;
create trigger invoice_lines_vat before insert or update on public.invoice_lines for each row execute function public.invoice_vat_lines();

-- New invoices take the customer's tax position: exempt or zero-rated → no VAT; withholding agent → expected WHT.
create or replace function public.invoice_customer_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers;
begin
  select * into c from customers where id = new.customer_id;
  if found then
    if c.tax_status in ('exempt','zero_rated','diplomatic','free_zone') and (c.exemption_expiry is null or c.exemption_expiry >= coalesce(new.invoice_date, current_date)) then new.charge_vat := false; end if;
    if c.wht_agent and new.wht_rate is null then new.wht_rate := coalesce(c.wht_rate, (select wht_default_rate from companies where id = new.company_id)); end if;
  end if;
  return new;
end $$;
drop trigger if exists invoices_customer_defaults on public.invoices;
create trigger invoices_customer_defaults before insert on public.invoices for each row execute function public.invoice_customer_defaults();

-- With strict invoices on (Settings), an invoice can only be posted when it is tied to a quote, contract, project or the
-- customer's PO, has a reference, and the customer has a TIN.
create or replace function public.invoice_post_rules() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers; v_strict boolean;
begin
  if old.status = 'draft' and new.status <> 'draft' then
    select strict_invoices into v_strict from companies where id = new.company_id;
    if v_strict then
      select * into c from customers where id = new.customer_id;
      if coalesce(trim(c.tin), '') = '' then raise exception 'Add % TIN to the customer record before posting (Sales → Customers)', c.name || '''s'; end if;
      if coalesce(trim(new.reference), '') = '' then raise exception 'Enter the invoice reference before posting'; end if;
      if new.quote_id is null and new.contract_id is null and new.project_id is null and coalesce(trim(new.customer_po), '') = '' then
        raise exception 'Tie the invoice to a quotation, contract, project or the customer''s PO number before posting';
      end if;
    end if;
    if new.wht_rate is not null then new.wht_amount := round(new.subtotal * new.wht_rate / 100, 2); end if;
  end if;
  return new;
end $$;
drop trigger if exists invoices_post_rules on public.invoices;
create trigger invoices_post_rules before update of status on public.invoices for each row execute function public.invoice_post_rules();

-- A quote converted to an invoice stays linked, with its number as the reference.
do $$ begin
  if to_regprocedure('public.convert_quote_v22(uuid)') is null then alter function public.convert_quote(uuid) rename to convert_quote_v22; end if;
end $$;
create or replace function public.convert_quote(p_quote uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid; q sales_quotes;
begin
  v := convert_quote_v22(p_quote);
  select * into q from sales_quotes where id = p_quote;
  update invoices set quote_id = p_quote, reference = coalesce(reference, q.number) where id = v;
  return v;
end $$;
revoke execute on function public.convert_quote_v22(uuid) from public, anon, authenticated;

-- Receiving a payment when the customer withheld tax: the cash is what reached the bank; the withheld part becomes a tax credit.
create or replace function public.record_payment_wht(p_invoice uuid, p_cash numeric, p_wht numeric, p_date date, p_method text,
  p_reference text default null, p_rate numeric default null, p_certificate text default null) returns void
language plpgsql security definer set search_path = public as $$
declare inv invoices; v_rate numeric; g numeric; v_je uuid;
begin
  select * into inv from invoices where id = p_invoice;
  if not found then raise exception 'Invoice not found'; end if;
  if coalesce(p_wht, 0) < 0 then raise exception 'Withholding tax cannot be negative'; end if;
  perform record_payment(p_invoice, round(coalesce(p_cash, 0) + coalesce(p_wht, 0), 2), p_date, p_method, p_reference, p_rate);
  if coalesce(p_wht, 0) > 0 then
    v_rate := case when inv.currency = 'GHS' then 1 else coalesce(nullif(p_rate, 0), inv.exchange_rate) end;
    g := round(p_wht * v_rate, 2);
    v_je := post_journal(inv.company_id, p_date, 'Withholding tax deducted by customer on ' || inv.number || coalesce(' (certificate ' || p_certificate || ')', ''),
      jsonb_build_array(jl(acct(inv.company_id, 'wht_receivable'), g, 0), jl(acct(inv.company_id, p_method), 0, g)), 'wht', inv.id);
  end if;
end $$;

-- ---------------------------------------------------------------- 4. Payment milestones as a percentage of the contract, due when work reaches a stage
alter table public.project_milestones add column if not exists kind text not null default 'progress'
  check (kind in ('advance','progress','completion','retention','other'));
alter table public.project_milestones add column if not exists pct numeric(6,2) check (pct > 0 and pct <= 100);
alter table public.project_milestones add column if not exists trigger_pct int check (trigger_pct between 0 and 100);
alter table public.project_milestones add column if not exists terms_days int check (terms_days between 0 and 365);

create or replace function public.milestone_amount() returns trigger
language plpgsql security definer set search_path = public as $$
declare v numeric;
begin
  if new.pct is not null and new.status <> 'invoiced' then
    select contract_value into v from projects where id = new.project_id;
    if coalesce(v, 0) > 0 then new.amount := round(v * new.pct / 100, 2); end if;
  end if;
  if new.status = 'planned' and new.trigger_pct = 0 then new.status := 'ready'; end if;
  return new;
end $$;
drop trigger if exists project_milestones_amount on public.project_milestones;
create trigger project_milestones_amount before insert or update on public.project_milestones for each row execute function public.milestone_amount();

-- A change of contract value re-prices the milestones not yet invoiced.
create or replace function public.project_value_milestones() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.contract_value is distinct from old.contract_value then
    update project_milestones set pct = pct where project_id = new.id and pct is not null and status <> 'invoiced';
  end if;
  return null;
end $$;
drop trigger if exists projects_value_milestones on public.projects;
create trigger projects_value_milestones after update of contract_value on public.projects for each row execute function public.project_value_milestones();

-- How far the work is: the manager's figure, else the tasks (weighted by estimated hours).
create or replace function public.project_pct(p_project uuid) returns int
language sql stable security definer set search_path = public as $$
  select coalesce(p.percent_complete_override,
    (select case when sum(coalesce(estimated_hours,0)) > 0
                 then round(sum(coalesce(estimated_hours,0) * coalesce(percent_complete, case status when 'done' then 100 when 'doing' then 50 else 0 end) / 100.0) / sum(coalesce(estimated_hours,0)) * 100)::int
                 when count(*) > 0 then round(count(*) filter (where status = 'done')::numeric / count(*) * 100)::int else 0 end
       from tasks where project_id = p.id))
  from projects p where p.id = p_project;
$$;

-- Milestones whose stage of work has been reached become ready to invoice, and the project manager and Finance are told.
create or replace function public.check_milestones(p_project uuid default null) returns int
language plpgsql security definer set search_path = public as $$
declare r record; v_pct int; n int := 0;
begin
  if p_project is not null and auth.uid() is not null and not is_member((select company_id from projects where id = p_project)) then raise exception 'Not your project'; end if;
  for r in select m.*, p.company_id cid, p.number pnum, p.name pname, p.manager_id from project_milestones m join projects p on p.id = m.project_id
            where m.status = 'planned' and m.trigger_pct is not null and (p_project is null or m.project_id = p_project) loop
    v_pct := project_pct(r.project_id);
    if coalesce(v_pct, 0) >= r.trigger_pct then
      update project_milestones set status = 'ready' where id = r.id;
      perform notify(r.cid, array['accountant'], array[r.manager_id], 'milestone.ready',
        'Ready to invoice: ' || r.name || ' (' || coalesce(r.pct || '% of contract', 'GH₵ ' || r.amount) || ')',
        coalesce(r.pnum || ' ', '') || r.pname || ' is ' || v_pct || '% complete', '/projects/' || r.project_id, true);
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

-- Invoicing a milestone: due date from its payment terms; linked and referenced.
do $$ begin
  if to_regprocedure('public.invoice_milestone_v22(uuid)') is null then alter function public.invoice_milestone(uuid) rename to invoice_milestone_v22; end if;
end $$;
create or replace function public.invoice_milestone(p_milestone uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare v uuid; m project_milestones; p projects;
begin
  select * into m from project_milestones where id = p_milestone;
  select * into p from projects where id = m.project_id;
  v := invoice_milestone_v22(p_milestone);
  update invoices set milestone_id = m.id, reference = coalesce(reference, coalesce(p.number || ' ', '') || m.name),
    due_date = case when m.terms_days is not null then invoice_date + m.terms_days else coalesce(m.due_date, due_date) end,
    customer_po = coalesce(customer_po, p.client_po)
   where id = v;
  update invoice_lines set description = 'Milestone: ' || m.name || coalesce(' (' || m.pct || '% of contract sum)', '') where invoice_id = v;
  return v;
end $$;
revoke execute on function public.invoice_milestone_v22(uuid) from public, anon, authenticated;
alter table public.projects add column if not exists client_po text;

-- ---------------------------------------------------------------- 5. Stock for sale, for use in the work, or both; each item's home store
alter table public.products add column if not exists use_for text not null default 'both' check (use_for in ('sale','internal','both'));
alter table public.products add column if not exists home_warehouse_id uuid references public.warehouses(id) on delete set null;

-- ---------------------------------------------------------------- 6. Requests: SR (services), ADR (purchases), MRO (materials from store); several items; attachments
alter table public.project_requests drop constraint if exists project_requests_kind_check;
alter table public.project_requests add constraint project_requests_kind_check check (kind in ('material','subcontract','equipment','other','service'));
alter table public.project_requests add column if not exists group_no text;
alter table public.project_requests add column if not exists line_no int;
create index if not exists project_requests_group on public.project_requests (company_id, group_no);

create or replace function public.project_request_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.company_id := (select company_id from projects where id = new.project_id);
    if new.number is null then
      new.number := case when new.kind in ('service','subcontract') then next_number(new.company_id, 'SR', 'SR-') else next_number(new.company_id, 'ADR', 'ADR-') end;
    end if;
    new.requested_by := coalesce(auth.uid(), new.requested_by);
    new.requested_email := (select email from auth.users where id = new.requested_by);
    if new.status not in ('draft','submitted') then raise exception 'New requests start as draft or submitted'; end if;
  elsif new.status is distinct from old.status and new.status in ('approved','rejected','billed','ordered')
        and coalesce(current_setting('sika.requests', true), '') <> 'on' then
    raise exception 'Use Approve or Reject to decide a request';
  end if;
  if tg_op = 'UPDATE' and old.status in ('approved','billed','ordered') and coalesce(current_setting('sika.requests', true), '') <> 'on'
     and (new.qty, new.est_unit_cost, new.project_id) is distinct from (old.qty, old.est_unit_cost, old.project_id) then
    raise exception 'An approved request cannot be changed. Cancel it and raise a new one.';
  end if;
  return new;
end $$;

-- One request with several items: one number (ADR-00012 or SR-00004) and a line for each item (ADR-00012/1, /2…).
-- p_lines: [{"description","qty","unit","est_unit_cost","product_id","supplier_id","notes"}]
create or replace function public.raise_project_request(p_project uuid, p_kind text, p_lines jsonb, p_needed_by date default null,
  p_notes text default null, p_submit boolean default true) returns text
language plpgsql security definer set search_path = public as $$
declare cid uuid; v_no text; l jsonb; i int := 0; n int;
begin
  select company_id into cid from projects where id = p_project;
  if cid is null then raise exception 'Choose the project'; end if;
  perform require_member(cid);
  n := jsonb_array_length(coalesce(p_lines, '[]'::jsonb));
  if n = 0 then raise exception 'Add at least one item'; end if;
  v_no := case when p_kind in ('service','subcontract') then next_number(cid, 'SR', 'SR-') else next_number(cid, 'ADR', 'ADR-') end;
  for l in select * from jsonb_array_elements(p_lines) loop
    i := i + 1;
    if coalesce(trim(l->>'description'), '') = '' then raise exception 'Item % has no description', i; end if;
    if coalesce((l->>'qty')::numeric, 0) <= 0 then raise exception 'Item % needs a quantity', i; end if;
    insert into project_requests (company_id, project_id, kind, description, product_id, account_id, task_id, qty, unit, est_unit_cost, supplier_id, needed_by, status, notes, number, group_no, line_no)
    values (cid, p_project, p_kind, trim(l->>'description'), nullif(l->>'product_id', '')::uuid, nullif(l->>'account_id', '')::uuid, nullif(l->>'task_id', '')::uuid, (l->>'qty')::numeric, nullif(l->>'unit', ''),
            coalesce(nullif(l->>'est_unit_cost', '')::numeric, 0), nullif(l->>'supplier_id', '')::uuid, p_needed_by,
            case when p_submit then 'submitted' else 'draft' end, concat_ws(E'\n', p_notes, nullif(l->>'notes', '')),
            case when n > 1 then v_no || '/' || i else v_no end, v_no, i);
  end loop;
  return v_no;
end $$;

-- Material requests from the store are numbered MRO.
create or replace function public.stock_request_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.company_id := (select company_id from projects where id = new.project_id);
    new.number := coalesce(new.number, next_number(new.company_id, 'MRO', 'MRO-'));
    new.requested_by := coalesce(auth.uid(), new.requested_by);
    new.requested_email := (select email from auth.users where id = new.requested_by);
    if new.status not in ('draft','submitted') then raise exception 'A new stock request starts as a draft'; end if;
    if (select project_id from warehouses where id = new.to_warehouse_id) is distinct from new.project_id then
      raise exception 'Deliver the request to this project''s site store';
    end if;
  elsif new.status is distinct from old.status and coalesce(current_setting('sika.posting', true), '') <> 'on'
        and not (old.status = 'draft' and new.status in ('submitted','cancelled')) and not (old.status = 'submitted' and new.status = 'cancelled') then
    raise exception 'Use Send or Receive to move a stock request on';
  end if;
  return new;
end $$;

-- Attachments (PDF, Excel, photos) for requests and other records.
create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  parent_type text not null,          -- 'request' (by request number), 'invoice', 'customer', ...
  parent_key text not null,
  name text not null,
  storage_path text not null,
  size_bytes bigint,
  uploaded_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists attachments_parent on public.attachments (company_id, parent_type, parent_key);
alter table public.attachments enable row level security;
drop policy if exists "members read attachments" on public.attachments;
create policy "members read attachments" on public.attachments for select using (is_member(company_id));
drop policy if exists "members add attachments" on public.attachments;
create policy "members add attachments" on public.attachments for insert with check (is_member(company_id) and uploaded_by = auth.uid());
drop policy if exists "remove own attachments" on public.attachments;
create policy "remove own attachments" on public.attachments for delete using (uploaded_by = auth.uid() or has_role(company_id, array['owner','admin']));

-- ---------------------------------------------------------------- 7. Subcontractors in HR (site records, inductions, timesheets; not on payroll)
alter table public.employees drop constraint if exists employees_employment_type_check;
alter table public.employees add constraint employees_employment_type_check
  check (employment_type in ('permanent','fixed_term','casual','contract','intern','national_service','consultant','subcontractor'));
alter table public.employees add column if not exists subcontractor_supplier_id uuid references public.suppliers(id) on delete set null;
alter table public.employees add column if not exists subcontractor_company text;
alter table public.employees add column if not exists id_type text;
alter table public.employees add column if not exists id_number text;
alter table public.employees add column if not exists trade text;

do $$ begin
  if to_regprocedure('public.calc_run_v30(uuid)') is null then alter function public.calc_run(uuid) rename to calc_run_v30; end if;
end $$;
create or replace function public.calc_run(p_run uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform calc_run_v30(p_run);
  -- Subcontractors are paid through their company's bills, never through payroll.
  delete from payslips where run_id = p_run and employee_id in (select id from employees where employment_type = 'subcontractor');
end $$;
revoke execute on function public.calc_run_v30(uuid) from public, anon, authenticated;
revoke execute on function public.calc_run(uuid) from public, anon, authenticated;

-- ---------------------------------------------------------------- 8. Company logo on documents and in the app
alter table public.companies add column if not exists logo_data text check (logo_data is null or (logo_data like 'data:image/%' and length(logo_data) < 400000));

-- ---------------------------------------------------------------- 9. Backups to the company's OneDrive (Microsoft 365), daily
create table if not exists public.company_backup (
  company_id uuid primary key references public.companies(id) on delete cascade,
  enabled boolean not null default false,
  onedrive_user text,                 -- the Microsoft 365 account whose OneDrive holds the backups
  folder text not null default 'Asnys ERP backups',
  keep_days int not null default 90 check (keep_days between 7 and 3650),
  function_url text,
  last_run_at timestamptz,
  last_status text,
  last_file text,
  last_size bigint,
  updated_at timestamptz not null default now()
);
alter table public.company_backup enable row level security;
drop policy if exists "owners manage backup" on public.company_backup;
create policy "owners manage backup" on public.company_backup for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));
insert into public.company_email_secret (company_id) select company_id from public.company_backup on conflict do nothing;
create or replace function public.company_backup_secret() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into company_email_secret (company_id) values (new.company_id) on conflict do nothing;
  return null;
end $$;
drop trigger if exists company_backup_secret on public.company_backup;
create trigger company_backup_secret after insert or update on public.company_backup for each row execute function public.company_backup_secret();

-- The tables that belong to a company (everything with a company_id), for the backup function.
create or replace function public.backup_tables() returns text[]
language sql stable security definer set search_path = public as $$
  select array_agg(c.table_name::text order by c.table_name) from information_schema.columns c join information_schema.tables t on t.table_schema = c.table_schema and t.table_name = c.table_name
   where c.table_schema = 'public' and c.column_name = 'company_id' and t.table_type = 'BASE TABLE'
     and c.table_name not in ('company_email','company_email_secret','company_telegram','message_log','notifications','user_channels');
$$;
create or replace function public.backup_hook_config(cid uuid, p_secret text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('onedrive_user', b.onedrive_user, 'folder', b.folder, 'keep_days', b.keep_days, 'company', c.name, 'code', coalesce(c.doc_prefix, ''), 'tables', backup_tables())
    from company_backup b join companies c on c.id = b.company_id join company_email_secret x on x.company_id = b.company_id
   where b.company_id = cid and b.enabled and x.secret = p_secret;
$$;
create or replace function public.backup_done(cid uuid, p_secret text, p_status text, p_file text, p_size bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from company_email_secret where company_id = cid and secret = p_secret) then raise exception 'Not allowed'; end if;
  update company_backup set last_run_at = now(), last_status = left(p_status, 500), last_file = p_file, last_size = p_size where company_id = cid;
  if p_status <> 'ok' then
    perform notify(cid, array[]::text[], null, 'backup_failed', 'Backup to OneDrive failed', left(p_status, 300), '/settings/security', true);
  end if;
end $$;
do $$ begin
  revoke execute on function public.backup_hook_config(uuid, text) from public, anon, authenticated;
  revoke execute on function public.backup_done(uuid, text, text, text, bigint) from public, anon, authenticated;
  revoke execute on function public.backup_tables() from public, anon, authenticated;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.backup_hook_config(uuid, text) to service_role;
    grant execute on function public.backup_done(uuid, text, text, text, bigint) to service_role;
    grant execute on function public.backup_tables() to service_role;
  end if;
end $$;

create or replace function public.start_backup(cid uuid) returns bigint
language plpgsql security definer set search_path = public as $$
declare b company_backup;
begin
  select * into b from company_backup where company_id = cid;
  if not found or not b.enabled or b.function_url is null or b.onedrive_user is null then return null; end if;
  return http_post_safe(b.function_url, jsonb_build_object('action', 'backup', 'company_id', cid),
    jsonb_build_object('Content-Type', 'application/json', 'x-asnys-secret', (select secret from company_email_secret where company_id = cid)));
end $$;
revoke execute on function public.start_backup(uuid) from public, anon, authenticated;

-- Owners can also download a backup to their own computer from the app (the same tables).
create or replace function public.my_backup_tables(cid uuid) returns text[]
language plpgsql stable security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can download a backup'; end if;
  return backup_tables();
end $$;

create or replace function public.backup_now(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can start a backup'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  v := start_backup(cid);
  if v is null then raise exception 'Tick Back up to OneDrive, enter the OneDrive account and save first'; end if;
  return 'started';
end $$;

-- ---------------------------------------------------------------- 10. Microsoft 365 sign-in by certificate (10 years) and its expiry reminder
alter table public.company_email add column if not exists cert_thumbprint text;
alter table public.company_email add column if not exists cert_expires date;
alter table public.company_email add column if not exists secret_expires date;
alter table public.company_email add column if not exists reminded_on date;
-- The v3.3 send-mail function is replaced by asnys-m365 (email, backups and password reset in one).
update public.company_email set function_url = replace(function_url, '/functions/v1/send-mail', '/functions/v1/asnys-m365') where function_url like '%/functions/v1/send-mail';

create or replace function public.run_integration_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare r record; n int := 0; v_date date; v_what text;
begin
  for r in select * from company_email where provider = 'microsoft' and enabled loop
    v_date := least(coalesce(r.cert_expires, '9999-12-31'), coalesce(r.secret_expires, '9999-12-31'));
    v_what := case when v_date = r.cert_expires then 'certificate' else 'client secret' end;
    if v_date <= current_date + 30 and (r.reminded_on is null or r.reminded_on < current_date - 7) then
      perform notify(r.company_id, array[]::text[], null, 'integration_expiry', 'Microsoft 365 ' || v_what || case when v_date < current_date then ' has EXPIRED' else ' expires ' || to_char(v_date, 'DD Mon YYYY') end,
        'Emails, invitations and OneDrive backups stop when it expires. Renew it under Settings → Telegram & email.', '/settings/messaging', true);
      update company_email set reminded_on = current_date where company_id = r.company_id; n := n + 1;
    end if;
  end loop;
  -- Daily backups to OneDrive
  for r in select company_id from company_backup where enabled and (last_run_at is null or last_run_at < now() - interval '20 hours') loop
    perform start_backup(r.company_id); n := n + 1;
  end loop;
  -- Payment milestones whose stage of work has been reached
  n := n + coalesce(check_milestones(null), 0);
  return n;
end $$;
revoke execute on function public.run_integration_reminders() from public, anon, authenticated;

create or replace function public.run_all_cash_reminders() returns int
language plpgsql security definer set search_path = public as $$
declare c record; n int := 0;
begin
  for c in select id from companies loop
    begin n := n + coalesce(run_cash_reminders_internal(c.id), 0); exception when others then null; end;
  end loop;
  begin n := n + coalesce(run_project_hold_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hse_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_hr_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_fleet_reminders(), 0); exception when others then null; end;
  begin n := n + coalesce(run_integration_reminders(), 0); exception when others then null; end;
  return n;
end $$;
revoke execute on function public.run_all_cash_reminders() from public, anon, authenticated;

-- ---------------------------------------------------------------- 11. "Forgot password" by the company's Microsoft 365 email
create table if not exists public.password_reset_log (
  id bigserial primary key,
  email text not null,
  requested_at timestamptz not null default now(),
  sent boolean not null default false
);
alter table public.password_reset_log enable row level security;
-- Called by the asnys-m365 function (service key): may this email have a reset link now, and from which company's mailbox?
create or replace function public.reset_target(p_email text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_user uuid; v_cid uuid; v_recent int;
begin
  select count(*) into v_recent from password_reset_log where lower(email) = lower(p_email) and requested_at > now() - interval '1 hour';
  insert into password_reset_log (email) values (lower(p_email));
  if v_recent >= 3 then return null; end if;
  select id into v_user from auth.users where lower(email) = lower(p_email);
  if v_user is null then return null; end if;
  select m.company_id into v_cid from memberships m join company_email e on e.company_id = m.company_id
   where m.user_id = v_user and e.provider = 'microsoft' and e.enabled order by m.created_at limit 1;
  if v_cid is null then return null; end if;
  update password_reset_log set sent = true where id = currval(pg_get_serial_sequence('public.password_reset_log', 'id'));
  return jsonb_build_object('company_id', v_cid, 'company', (select name from companies where id = v_cid),
    'from_email', (select from_email from company_email where company_id = v_cid), 'from_name', (select coalesce(from_name, (select name from companies where id = v_cid)) from company_email where company_id = v_cid),
    'app_url', coalesce((select app_url from company_telegram where company_id = v_cid), 'https://asnys-erp.pages.dev'));
end $$;
-- For invitations sent by invite-member: the company's Microsoft 365 sender, if it has one.
create or replace function public.m365_sender(cid uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('from_email', e.from_email, 'from_name', coalesce(e.from_name, c.name), 'company', c.name)
    from company_email e join companies c on c.id = e.company_id where e.company_id = cid and e.provider = 'microsoft' and e.enabled and e.from_email is not null;
$$;
do $$ begin
  revoke execute on function public.reset_target(text) from public, anon, authenticated;
  revoke execute on function public.m365_sender(uuid) from public, anon, authenticated;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.reset_target(text) to service_role;
    grant execute on function public.m365_sender(uuid) to service_role;
  end if;
end $$;

-- ---------------------------------------------------------------- 12. 2-step sign-in (authenticator app): who must use it, and who has it
alter table public.companies add column if not exists mfa_roles text[] not null default '{}';
create or replace function public.my_mfa_required() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships m join companies c on c.id = m.company_id where m.user_id = auth.uid() and m.role = any(c.mfa_roles));
$$;
create or replace function public.security_overview(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_mfa boolean := to_regclass('auth.mfa_factors') is not null; v jsonb;
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can see this'; end if;
  if v_mfa then
    execute 'select coalesce(jsonb_agg(jsonb_build_object(''email'', coalesce(m.email, u.email), ''role'', m.role, ''last_sign_in_at'', u.last_sign_in_at,
               ''mfa'', exists (select 1 from auth.mfa_factors f where f.user_id = m.user_id and f.status = ''verified'')) order by m.role, coalesce(m.email, u.email)), ''[]'')
               from memberships m left join auth.users u on u.id = m.user_id where m.company_id = $1' into v using cid;
  else
    select coalesce(jsonb_agg(jsonb_build_object('email', coalesce(m.email, u.email), 'role', m.role, 'last_sign_in_at', u.last_sign_in_at, 'mfa', false)), '[]')
      into v from memberships m left join auth.users u on u.id = m.user_id where m.company_id = cid;
  end if;
  return jsonb_build_object('people', v, 'mfa_roles', (select mfa_roles from companies where id = cid),
    'backup', (select to_jsonb(b) - 'function_url' from company_backup b where company_id = cid),
    'cert_expires', (select cert_expires from company_email where company_id = cid),
    'secret_expires', (select secret_expires from company_email where company_id = cid),
    'failed_resets_24h', (select count(*) from password_reset_log where requested_at > now() - interval '1 day' and not sent));
end $$;
create or replace function public.set_mfa_roles(cid uuid, p_roles text[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  update companies set mfa_roles = coalesce(p_roles, '{}') where id = cid;
  insert into audit_log (company_id, action, table_name, detail) values (cid, 'security.mfa_roles', 'companies', jsonb_build_object('roles', p_roles));
end $$;

-- ---------------------------------------------------------------- 12b. Custom roles: tick the modules and pages, and whether they may approve and void
-- A person keeps one main role and can hold any number of custom roles; they get everything those roles allow combined.
-- What a custom role may do in the database is expressed as the built-in roles it "acts as" (worked out by the app from
-- the pages ticked); owner and admin can never be granted this way.
create table if not exists public.custom_roles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null check (length(trim(name)) between 2 and 60),
  description text,
  pages text[] not null default '{}',           -- app pages (paths) this role can open
  grants text[] not null default '{}' check (grants <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  approve text[] not null default '{}' check (approve <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  void_grants text[] not null default '{}' check (void_grants <@ array['accountant','sales','hr','project_manager','store','transport','hse']),
  created_at timestamptz not null default now(),
  unique (company_id, name)
);
alter table public.custom_roles enable row level security;
drop policy if exists "members read custom roles" on public.custom_roles;
create policy "members read custom roles" on public.custom_roles for select using (is_member(company_id));
drop policy if exists "admins manage custom roles" on public.custom_roles;
create policy "admins manage custom roles" on public.custom_roles for all using (has_role(company_id, array['owner','admin'])) with check (has_role(company_id, array['owner','admin']));

alter table public.memberships add column if not exists custom_role_ids uuid[] not null default '{}';
alter table public.memberships add column if not exists extra_roles text[] not null default '{}';
alter table public.memberships add column if not exists approve_roles text[] not null default '{}';
alter table public.memberships add column if not exists void_roles text[] not null default '{}';
alter table public.memberships add column if not exists allowed_pages text[];      -- null: the main role decides

-- The combined rights are always worked out here from the roles held, so nobody can write them directly.
create or replace function public.membership_custom_sync() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.extra_roles
    from custom_roles r left join lateral unnest(r.grants) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.approve_roles
    from custom_roles r left join lateral unnest(r.approve) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  select coalesce(array_agg(distinct g) filter (where g is not null), '{}') into new.void_roles
    from custom_roles r left join lateral unnest(r.void_grants) g on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  if cardinality(new.custom_role_ids) = 0 then new.allowed_pages := null;
  else select coalesce(array_agg(distinct pg) filter (where pg is not null), '{}') into new.allowed_pages
         from custom_roles r left join lateral unnest(r.pages) pg on true where r.id = any(new.custom_role_ids) and r.company_id = new.company_id;
  end if;
  return new;
end $$;
drop trigger if exists memberships_custom_sync on public.memberships;
create trigger memberships_custom_sync before insert or update on public.memberships for each row execute function public.membership_custom_sync();

create or replace function public.custom_role_changed() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update memberships set custom_role_ids = case when tg_op = 'DELETE' then array_remove(custom_role_ids, old.id) else custom_role_ids end
   where company_id = coalesce(new.company_id, old.company_id) and coalesce(new.id, old.id) = any(custom_role_ids);
  return null;
end $$;
drop trigger if exists custom_roles_changed on public.custom_roles;
create trigger custom_roles_changed after update or delete on public.custom_roles for each row execute function public.custom_role_changed();

-- A role check now also counts the custom roles a person holds.
create or replace function public.has_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or extra_roles && roles));
$$;
-- Approving a step of an approval chain needs the main role, or a custom role with "Can approve" ticked.
create or replace function public.has_approve_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or approve_roles && roles));
$$;
-- Voiding needs the main role, or a custom role with "Can void" ticked.
create or replace function public.has_void_role(cid uuid, roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships
                 where company_id = cid and user_id = auth.uid() and (role = any(roles) or void_roles && roles));
$$;

create or replace function public.can_approve_step(s approval_steps) returns boolean
language sql stable security definer set search_path = public as $$
  select s.status = 'pending'
     and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'pending' and o.step_no < s.step_no)
     and (has_role(s.company_id, array['owner'])
          or ((s.approver_user = auth.uid() or (s.approver_role is not null and has_approve_role(s.company_id, array[s.approver_role])))
              and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = auth.uid())));
$$;

create or replace function public.step_approvers(s approval_steps) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(distinct u), '{}') from (
    select s.approver_user u where s.approver_user is not null
    union select m.user_id from memberships m where m.company_id = s.company_id and s.approver_role is not null and (m.role = s.approver_role or s.approver_role = any(m.approve_roles))
    union select m.user_id from memberships m where m.company_id = s.company_id and m.role = 'owner'
      and not exists (select 1 from memberships x where x.company_id = s.company_id and ((s.approver_role is not null and (x.role = s.approver_role or s.approver_role = any(x.approve_roles))) or x.user_id = s.approver_user))
  ) x where u is not null and not exists (select 1 from approval_steps o where o.doc_type = s.doc_type and o.doc_id = s.doc_id and o.status = 'approved' and o.decided_by = u);
$$;

create or replace function public.can_void(p_table text, p_id uuid) returns boolean
language plpgsql stable security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid;
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then return false; end if;
  execute format('select company_id, status from public.%I where id = $1', p_table) into v_cid, v_status using p_id;
  if v_cid is null or not (v_status = any(vr.from_status)) then return false; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  return has_role(v_cid, array['owner','admin']) or has_void_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid());
end $$;

-- Notices sent "to Finance", "to HR" etc. also reach people holding that right through a custom role.
create or replace function public.notify(cid uuid, p_roles text[], p_users uuid[], p_kind text, p_title text, p_body text default null, p_path text default null, p_include_self boolean default false)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into notifications (company_id, user_id, kind, title, body, path)
  select distinct cid, u, p_kind, p_title, p_body, p_path from (
    select m.user_id u from memberships m where m.company_id = cid and (m.role = any(p_roles) or m.extra_roles && p_roles or m.role in ('owner','admin'))
    union select unnest(coalesce(p_users, '{}'::uuid[]))) x
  where u is not null and (p_include_self or u is distinct from auth.uid());
  get diagnostics n = row_count;
  return n;
end $$;

-- Transport officers and HSE officers can also come from a custom role.
create or replace function public.is_hse(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (hse or 'hse' = any(extra_roles) or role in ('owner','admin')));
$$;
create or replace function public.hse_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (hse or 'hse' = any(extra_roles));
$$;
create or replace function public.is_transport(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from memberships where company_id = cid and user_id = auth.uid() and (transport or 'transport' = any(extra_roles) or role in ('owner','admin','accountant','store')));
$$;
create or replace function public.transport_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or 'transport' = any(extra_roles) or role = 'store');
$$;
create or replace function public.fleet_alert_users(cid uuid) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(user_id), '{}') from memberships where company_id = cid and (transport or 'transport' = any(extra_roles) or role in ('store','owner','admin'));
$$;
revoke execute on function public.fleet_alert_users(uuid) from public, anon, authenticated;

-- Owners and admins give or take away custom roles.
create or replace function public.set_member_custom_roles(cid uuid, p_user uuid, p_roles uuid[]) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can give custom roles'; end if;
  if exists (select 1 from unnest(coalesce(p_roles, '{}')) r where not exists (select 1 from custom_roles c where c.id = r and c.company_id = cid)) then
    raise exception 'Unknown role';
  end if;
  update memberships set custom_role_ids = coalesce(p_roles, '{}') where company_id = cid and user_id = p_user;
  if not found then raise exception 'That person is not in this company'; end if;
  insert into audit_log (company_id, action, table_name, row_id, detail)
  values (cid, 'member.custom_roles', 'memberships', p_user, jsonb_build_object('roles', (select coalesce(jsonb_agg(name), '[]') from custom_roles where id = any(p_roles))));
end $$;

-- ---------------------------------------------------------------- 12c. Several bank accounts; each invoice says which one to pay into
create table if not exists public.company_banks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  bank_name text not null,
  branch text,
  account_name text,
  account_no text not null,
  swift text,
  currency text not null default 'GHS',
  is_default boolean not null default false,
  active boolean not null default true,
  sort int not null default 0,
  created_at timestamptz not null default now()
);
create unique index if not exists company_banks_one_default on public.company_banks (company_id) where is_default;
alter table public.company_banks enable row level security;
drop policy if exists "members read banks" on public.company_banks;
create policy "members read banks" on public.company_banks for select using (is_member(company_id));
drop policy if exists "finance manages banks" on public.company_banks;
create policy "finance manages banks" on public.company_banks for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));
alter table public.invoices add column if not exists bank_id uuid references public.company_banks(id) on delete set null;
alter table public.sales_quotes add column if not exists bank_id uuid references public.company_banks(id) on delete set null;

-- A new invoice pays into the account in its currency, else the default account.
create or replace function public.invoice_bank_default() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.bank_id is null then
    select id into new.bank_id from company_banks where company_id = new.company_id and active
     order by (currency = coalesce(new.currency, 'GHS')) desc, is_default desc, sort limit 1;
  end if;
  return new;
end $$;
drop trigger if exists invoices_bank_default on public.invoices;
create trigger invoices_bank_default before insert on public.invoices for each row execute function public.invoice_bank_default();

-- ---------------------------------------------------------------- 13. Voiding: also lets material requests through their store guard
create or replace function public.void_entry(p_table text, p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_creator uuid; f text;
  flags text[] := array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle','sika.posting'];
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be voided here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  v_creator := entry_owner(vr.creator_col, p_table, p_id);
  if not (has_role(v_cid, array['owner','admin']) or has_void_role(v_cid, vr.roles) or (v_creator is not null and v_creator = auth.uid())) then
    raise exception 'You cannot void this %. Ask an admin.', lower(vr.label);
  end if;
  if v_status = 'voided' then raise exception 'Already voided'; end if;
  if not (v_status = any(vr.from_status)) then
    raise exception 'A % that is % cannot be voided. %', lower(vr.label), replace(v_status, '_', ' '),
      case when p_table = 'purchase_orders' then 'Goods have been received against it; close it instead.'
           when p_table = 'expense_claims' then 'It has been posted; reverse it with a journal.'
           when p_table = 'tenders' then 'An awarded tender has a project; cancel the project instead.'
           else 'It has already gone through.' end;
  end if;
  if p_table = 'timesheets' and exists (select 1 from timesheets where id = p_id and invoice_id is not null) then raise exception 'This time has been invoiced'; end if;
  foreach f in array flags loop perform set_config(f, 'on', true); end loop;
  execute format('update public.%I set status = ''voided'', void_reason = $2, voided_at = now(), voided_by = auth.uid() where id = $1', p_table) using p_id, trim(p_reason);
  foreach f in array flags loop perform set_config(f, 'off', true); end loop;
  update approval_steps set status = 'skipped' where doc_id = p_id and status = 'pending';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.voided', p_table, p_id, jsonb_build_object('what', vr.label, 'was', v_status, 'reason', trim(p_reason)));
end $$;

-- ---------------------------------------------------------------- 13a. Restore (un-void): owners and admins, with a reason; back to the status it had
create or replace function public.unvoid_entry(p_table text, p_id uuid, p_reason text) returns text
language plpgsql security definer set search_path = public as $$
declare vr void_rules; v_cid uuid; v_status text; v_was text; f text;
  flags text[] := array['sika.cycle','sika.docs','sika.fleet','sika.hr','sika.hse','sika.po','sika.requests','sika.spend','sika.training','sika.petty','sika.contracts','sika.lifecycle','sika.posting'];
begin
  select * into vr from void_rules where table_name = p_table;
  if not found then raise exception 'This kind of entry cannot be restored here'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being restored'; end if;
  execute format('select company_id, status from public.%I where id = $1 for update', p_table) into v_cid, v_status using p_id;
  if v_cid is null then raise exception '% not found', vr.label; end if;
  if not has_role(v_cid, array['owner','admin']) then raise exception 'Only an owner or admin can restore a voided entry'; end if;
  if v_status <> 'voided' then raise exception 'This % is not voided', lower(vr.label); end if;
  select detail->>'was' into v_was from audit_log where company_id = v_cid and action = 'entry.voided' and table_name = p_table and row_id = p_id order by id desc limit 1;
  if v_was is null then raise exception 'The status before voiding is not on record, so it cannot be restored'; end if;
  foreach f in array flags loop perform set_config(f, 'on', true); end loop;
  execute format('update public.%I set status = $2, void_reason = null, voided_at = null, voided_by = null where id = $1', p_table) using p_id, v_was;
  foreach f in array flags loop perform set_config(f, 'off', true); end loop;
  update approval_steps set status = 'pending' where doc_id = p_id and status = 'skipped';
  insert into audit_log (company_id, action, table_name, row_id, detail) values (v_cid, 'entry.restored', p_table, p_id, jsonb_build_object('what', vr.label, 'back_to', v_was, 'reason', trim(p_reason)));
  return v_was;
end $$;

-- ---------------------------------------------------------------- 13b. Numbered entries are never deleted: void them instead
-- Once a document has a number it stays in the system for the audit trail. Drafts without a number can still be deleted,
-- and deleting a whole company (cascade) is not blocked.
create or replace function public.keep_numbered() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if pg_trigger_depth() = 1 and coalesce(to_jsonb(old)->>'number', '') <> '' and coalesce(current_setting('asnys.purge', true), '') <> 'on' then
    raise exception '% is numbered, so it cannot be deleted. Use Void instead: it stays in the records marked voided, with the reason.', to_jsonb(old)->>'number';
  end if;
  return old;
end $$;
do $$ declare t text; begin
  for t in select v.table_name from void_rules v
             where exists (select 1 from information_schema.columns c where c.table_schema = 'public' and c.table_name = v.table_name and c.column_name = 'number') loop
    execute format('drop trigger if exists %I on public.%I', t || '_keep_numbered', t);
    execute format('create trigger %I before delete on public.%I for each row execute function public.keep_numbered()', t || '_keep_numbered', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- 14. New companies
create or replace function public.company_seed_v34() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform seed_accounts_v34(new.id);
  insert into number_formats (company_id, key, prefix) values (new.id, 'ADR', 'ADR'), (new.id, 'SR', 'SR'), (new.id, 'MRO', 'MRO') on conflict do nothing;
  return null;
end $$;
drop trigger if exists companies_seed_v34 on public.companies;
create trigger companies_seed_v34 after insert on public.companies for each row execute function public.company_seed_v34();

-- Audit the new settings tables too.
do $$ declare t text; begin
  foreach t in array array['number_formats','attachments','company_backup','custom_roles','company_banks'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;

-- Progress changes make milestones ready straight away.
create or replace function public.progress_milestones() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform check_milestones(case when tg_table_name = 'tasks' then (to_jsonb(new)->>'project_id')::uuid else new.id end);
  return null;
end $$;
drop trigger if exists tasks_progress_milestones on public.tasks;
create trigger tasks_progress_milestones after update of status, percent_complete on public.tasks for each row execute function public.progress_milestones();
drop trigger if exists projects_progress_milestones on public.projects;
create trigger projects_progress_milestones after update of percent_complete_override on public.projects for each row execute function public.progress_milestones();
