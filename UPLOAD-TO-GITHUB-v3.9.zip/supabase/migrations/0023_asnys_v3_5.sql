-- Asnys ERP v3.5 — QuickBooks-style sales and accounting
--   1. Receive payment: one receipt split over several invoices, into the bank account you choose; anything extra is kept
--      as the customer's credit (customer deposits) and applied to later invoices.
--   2. Sales receipt: a cash sale in one step (invoice + payment), without the strict-invoice checks.
--   3. Pay bills: several supplier bills paid together from one account, with withholding tax deducted.
--   4. Bank feed: statement lines imported from the bank's CSV, rules that suggest the account, matched or posted.
--   5. Reports: cash flow, sales by customer, sales by product, profit by project and by customer.
-- Run after 0022. Safe to run twice.

-- ---------------------------------------------------------------- 0. Accounts
create or replace function public.seed_accounts_v35(cid uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  -- 2500 has existed since v1.1 without a key; give it one so receipts can use it.
  if not exists (select 1 from accounts where company_id = cid and system_key = 'customer_deposits') then
    if exists (select 1 from accounts where company_id = cid and code = '2500' and system_key is null) then
      update accounts set system_key = 'customer_deposits' where company_id = cid and code = '2500';
    else
      insert into accounts (company_id, code, name, type, system_key)
      values (cid, case when exists (select 1 from accounts where company_id = cid and code = '2500') then '2510' else '2500' end, 'Customer deposits and credits', 'liability', 'customer_deposits')
      on conflict do nothing;
    end if;
  end if;
  if not exists (select 1 from accounts where company_id = cid and system_key = 'wht_payable') then
    insert into accounts (company_id, code, name, type, system_key)
    values (cid, case when exists (select 1 from accounts where company_id = cid and code = '2270') then '2275' else '2270' end, 'Withholding tax payable (deducted from suppliers)', 'liability', 'wht_payable')
    on conflict do nothing;
  end if;
end $$;
select public.seed_accounts_v35(id) from public.companies;

-- Which payment method a cash, MoMo or bank account counts as.
create or replace function public.method_of(p_account uuid) returns text
language sql stable security definer set search_path = public as $$
  select case when system_key = 'cash' or name ilike '%cash%' then 'cash' when system_key = 'momo' or name ilike '%momo%' or name ilike '%mobile money%' then 'momo' else 'bank' end
    from accounts where id = p_account;
$$;

alter table public.payments add column if not exists account_id uuid references public.accounts(id);
alter table public.payments add column if not exists receipt_id uuid;
alter table public.bill_payments add column if not exists account_id uuid references public.accounts(id);
alter table public.bill_payments add column if not exists batch_id uuid;
alter table public.bill_payments add column if not exists wht_amount numeric(14,2) not null default 0;

-- ---------------------------------------------------------------- 1. Receive payment over several invoices, with customer credit
create table if not exists public.customer_receipts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  customer_id uuid not null references public.customers(id),
  receipt_date date not null,
  account_id uuid not null references public.accounts(id),
  currency text not null default 'GHS',
  exchange_rate numeric(14,6) not null default 1,
  amount numeric(14,2) not null check (amount > 0),
  unapplied numeric(14,2) not null default 0 check (unapplied >= 0),
  reference text,
  memo text,
  status text not null default 'posted' check (status in ('posted','voided')),
  journal_entry_id uuid references public.journal_entries(id),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists customer_receipts_customer on public.customer_receipts (company_id, customer_id);
alter table public.customer_receipts enable row level security;
drop policy if exists "finance and sales read receipts" on public.customer_receipts;
create policy "finance and sales read receipts" on public.customer_receipts for select using (has_role(company_id, array['owner','admin','accountant','sales']));

-- p_allocs: [{"invoice_id": "...", "amount": 1000}] in the receipt's currency. Every invoice must be this customer's and in that currency.
create or replace function public.receive_payment(cid uuid, p_customer uuid, p_date date, p_account uuid, p_amount numeric,
  p_allocs jsonb default '[]', p_reference text default null, p_memo text default null, p_currency text default 'GHS', p_rate numeric default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_no text; a jsonb; inv invoices; v_alloc numeric; v_wht numeric; v_total numeric := 0; v_rate numeric; v_lines jsonb := '[]'; v_je uuid;
  g_bank numeric; g_ar numeric; g_wht numeric; g_sum_ar numeric := 0; g_sum_wht numeric := 0; v_left numeric; v_method text; v_cust customers;
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  select * into v_cust from customers where id = p_customer and company_id = cid;
  if not found then raise exception 'Choose the customer'; end if;
  perform paying_account(cid, p_account);
  if round(coalesce(p_amount, 0), 2) <= 0 then raise exception 'Enter the amount received'; end if;
  v_rate := case when coalesce(p_currency, 'GHS') = 'GHS' then 1 else nullif(p_rate, 0) end;
  if v_rate is null then raise exception 'Type in the exchange rate for %', p_currency; end if;
  v_method := method_of(p_account);
  select coalesce(sum(round((x->>'amount')::numeric, 2)), 0) into v_total from jsonb_array_elements(coalesce(p_allocs, '[]')) x where coalesce((x->>'amount')::numeric, 0) > 0;
  if v_total > round(p_amount, 2) then raise exception 'You applied % to invoices but received only %', v_total, round(p_amount, 2); end if;

  v_no := next_number(cid, 'RCP', 'RCP-');
  insert into customer_receipts (company_id, number, customer_id, receipt_date, account_id, currency, exchange_rate, amount, unapplied, reference, memo)
  values (cid, v_no, p_customer, p_date, p_account, coalesce(p_currency, 'GHS'), v_rate, round(p_amount, 2), round(p_amount, 2) - v_total, p_reference, p_memo)
  returning id into v_id;

  g_bank := round(p_amount * v_rate, 2);
  for a in select * from jsonb_array_elements(coalesce(p_allocs, '[]')) loop
    v_alloc := round(coalesce((a->>'amount')::numeric, 0), 2);
    v_wht := round(coalesce((a->>'wht')::numeric, 0), 2);     -- withholding tax the customer deducted (paid to GRA for us)
    continue when v_alloc + v_wht <= 0;
    if v_alloc < 0 or v_wht < 0 then raise exception 'Amounts cannot be negative'; end if;
    select * into inv from invoices where id = (a->>'invoice_id')::uuid and company_id = cid for update;
    if not found or inv.customer_id <> p_customer then raise exception 'An invoice is not this customer''s'; end if;
    if inv.status not in ('posted') then raise exception '% is not open for payment', coalesce(inv.number, 'A draft invoice'); end if;
    if inv.currency <> coalesce(p_currency, 'GHS') then raise exception '% is in %; receive it in that currency', inv.number, inv.currency; end if;
    v_left := inv.total - inv.amount_paid - inv.amount_credited;
    if v_alloc + v_wht > v_left then raise exception '% has only % left to pay', inv.number, v_left; end if;
    g_ar := round((v_alloc + v_wht) * inv.exchange_rate, 2);
    g_wht := round(v_wht * v_rate, 2);
    g_sum_ar := g_sum_ar + g_ar; g_sum_wht := g_sum_wht + g_wht;
    insert into payments (company_id, invoice_id, payment_date, amount, method, reference, exchange_rate, account_id, receipt_id)
    values (cid, inv.id, p_date, v_alloc + v_wht, v_method, coalesce(p_reference, v_no) || case when v_wht > 0 then ' (incl. WHT ' || v_wht || ')' else '' end, v_rate, p_account, v_id);
    update invoices set amount_paid = amount_paid + v_alloc + v_wht,
      status = case when amount_paid + amount_credited + v_alloc + v_wht >= total then 'paid' else 'posted' end where id = inv.id;
    v_lines := v_lines || jl(acct(cid, 'ar'), 0, g_ar);
    if g_wht > 0 then v_lines := v_lines || jl(acct(cid, 'wht_receivable'), g_wht, 0); end if;
  end loop;
  -- Bank in full; receivables at each invoice's own rate; the extra waits as the customer's credit; rounding/rate difference to FX.
  v_lines := v_lines || jl(p_account, g_bank, 0);
  if round(p_amount, 2) - v_total > 0 then v_lines := v_lines || jl(acct(cid, 'customer_deposits'), 0, round((round(p_amount, 2) - v_total) * v_rate, 2)); end if;
  declare d numeric;
  begin
    d := g_bank + g_sum_wht - g_sum_ar - case when round(p_amount, 2) - v_total > 0 then round((round(p_amount, 2) - v_total) * v_rate, 2) else 0 end;
    if d <> 0 then v_lines := v_lines || jl(acct(cid, 'fx'), greatest(-d, 0), greatest(d, 0)); end if;
  end;
  v_je := post_journal(cid, p_date, 'Payment received from ' || v_cust.name || ' (' || v_no || ')' || coalesce(' — ' || p_reference, ''), v_lines, 'receipt', v_id);
  update customer_receipts set journal_entry_id = v_je where id = v_id;
  return v_id;
end $$;

-- Use a customer's unapplied credit against an invoice (same currency).
create or replace function public.apply_customer_credit(p_receipt uuid, p_invoice uuid, p_amount numeric, p_date date default current_date)
returns void language plpgsql security definer set search_path = public as $$
declare r customer_receipts; inv invoices; v numeric; g_dep numeric; g_ar numeric; v_je uuid;
begin
  select * into r from customer_receipts where id = p_receipt for update;
  if not found or r.status <> 'posted' then raise exception 'Receipt not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant','sales']);
  select * into inv from invoices where id = p_invoice for update;
  if not found or inv.customer_id <> r.customer_id or inv.status <> 'posted' then raise exception 'Choose an open invoice of the same customer'; end if;
  if inv.currency <> r.currency then raise exception 'The credit is in % but the invoice is in %', r.currency, inv.currency; end if;
  v := round(least(coalesce(p_amount, 0), r.unapplied, inv.total - inv.amount_paid - inv.amount_credited), 2);
  if v <= 0 then raise exception 'Nothing to apply'; end if;
  g_dep := round(v * r.exchange_rate, 2); g_ar := round(v * inv.exchange_rate, 2);
  v_je := post_journal(r.company_id, greatest(p_date, r.receipt_date), 'Customer credit ' || r.number || ' applied to ' || inv.number,
    jsonb_build_array(jl(acct(r.company_id, 'customer_deposits'), g_dep, 0), jl(acct(r.company_id, 'ar'), 0, g_ar),
      jl(acct(r.company_id, 'fx'), greatest(g_ar - g_dep, 0), greatest(g_dep - g_ar, 0))), 'receipt', r.id);
  insert into payments (company_id, invoice_id, payment_date, amount, method, reference, exchange_rate, account_id, receipt_id, journal_entry_id)
  values (r.company_id, inv.id, greatest(p_date, r.receipt_date), v, method_of(r.account_id), 'Credit ' || r.number, r.exchange_rate, r.account_id, r.id, v_je);
  update invoices set amount_paid = amount_paid + v, status = case when amount_paid + amount_credited + v >= total then 'paid' else 'posted' end where id = inv.id;
  update customer_receipts set unapplied = unapplied - v where id = r.id;
end $$;

-- A receipt entered in error: reverse its journal, take the amounts off the invoices; it stays on record as voided.
create or replace function public.void_customer_receipt(p_receipt uuid, p_reason text, p_date date default current_date)
returns void language plpgsql security definer set search_path = public as $$
declare r customer_receipts; p record; v_lines jsonb;
begin
  select * into r from customer_receipts where id = p_receipt for update;
  if not found then raise exception 'Receipt not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant']);
  if r.status = 'voided' then raise exception 'Already voided'; end if;
  if coalesce(trim(p_reason), '') = '' then raise exception 'Say why it is being voided'; end if;
  if exists (select 1 from payments where receipt_id = r.id and reference like 'Credit %') then raise exception 'Part of this credit has been applied to invoices. Reverse those first with a credit note or journal.'; end if;
  for p in select * from payments where receipt_id = r.id loop
    update invoices set amount_paid = amount_paid - p.amount, status = 'posted' where id = p.invoice_id;
  end loop;
  delete from payments where receipt_id = r.id;
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit, 'project_id', l.project_id)) into v_lines
    from journal_lines l where l.entry_id = r.journal_entry_id;
  perform post_journal(r.company_id, greatest(p_date, r.receipt_date), 'Void of receipt ' || r.number || ': ' || trim(p_reason), v_lines, 'receipt', r.id);
  update customer_receipts set status = 'voided', unapplied = 0 where id = r.id;
  insert into audit_log (company_id, action, table_name, row_id, detail) values (r.company_id, 'entry.voided', 'customer_receipts', r.id, jsonb_build_object('what', 'Receipt', 'number', r.number, 'reason', trim(p_reason)));
end $$;

-- Open items for the Receive payment screen.
create or replace function public.customer_open_items(cid uuid, p_customer uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  return jsonb_build_object(
    'invoices', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'number', i.number, 'invoice_date', i.invoice_date, 'due_date', i.due_date, 'currency', i.currency,
        'total', i.total, 'open', i.total - i.amount_paid - i.amount_credited, 'reference', i.reference, 'customer_po', i.customer_po, 'wht_amount', i.wht_amount) order by i.due_date nulls last, i.invoice_date)
      from invoices i where i.company_id = cid and i.customer_id = p_customer and i.status = 'posted' and i.total - i.amount_paid - i.amount_credited > 0), '[]'),
    'credits', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'number', r.number, 'receipt_date', r.receipt_date, 'currency', r.currency, 'unapplied', r.unapplied) order by r.receipt_date)
      from customer_receipts r where r.company_id = cid and r.customer_id = p_customer and r.status = 'posted' and r.unapplied > 0), '[]'));
end $$;

-- ---------------------------------------------------------------- 2. Sales receipt (cash sale): invoice and payment in one step
alter table public.invoices add column if not exists cash_sale boolean not null default false;
create or replace function public.invoice_post_rules() returns trigger
language plpgsql security definer set search_path = public as $$
declare c customers; v_strict boolean;
begin
  if old.status = 'draft' and new.status <> 'draft' then
    select strict_invoices into v_strict from companies where id = new.company_id;
    if v_strict and not new.cash_sale then
      select * into c from customers where id = new.customer_id;
      if coalesce(trim(c.tin), '') = '' then raise exception 'Add % TIN to the customer record before posting (Sales → Customers)', c.name || '''s'; end if;
      if coalesce(trim(new.reference), '') = '' then raise exception 'Enter the invoice reference before posting'; end if;
      if new.quote_id is null and new.contract_id is null and new.project_id is null and coalesce(trim(new.customer_po), '') = '' then
        raise exception 'Tie the invoice to a quotation, contract, project or the customer''s PO number before posting';
      end if;
    end if;
    if new.wht_rate is not null then new.wht_amount := round(new.subtotal * new.wht_rate / 100, 2); end if;
  end if;
  return new;
end $$;

create or replace function public.complete_sales_receipt(p_invoice uuid, p_account uuid, p_reference text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare inv invoices; v uuid;
begin
  select * into inv from invoices where id = p_invoice;
  if not found then raise exception 'Invoice not found'; end if;
  perform require_member(inv.company_id, array['owner','admin','accountant','sales']);
  update invoices set cash_sale = true, due_date = coalesce(due_date, invoice_date) where id = p_invoice and status = 'draft';
  if inv.status = 'draft' then perform post_invoice(p_invoice); end if;
  select * into inv from invoices where id = p_invoice;
  v := receive_payment(inv.company_id, inv.customer_id, inv.invoice_date, p_account, inv.total - inv.amount_paid - inv.amount_credited,
    jsonb_build_array(jsonb_build_object('invoice_id', inv.id, 'amount', inv.total - inv.amount_paid - inv.amount_credited)), p_reference, 'Sales receipt ' || inv.number, inv.currency, inv.exchange_rate);
  return v;
end $$;

-- ---------------------------------------------------------------- 3. Pay several bills at once, from the account you choose, with WHT deducted
create table if not exists public.bill_payment_batches (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  number text,
  pay_date date not null,
  account_id uuid not null references public.accounts(id),
  reference text,
  total_paid numeric(14,2) not null default 0,
  total_wht numeric(14,2) not null default 0,
  bills int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
alter table public.bill_payment_batches enable row level security;
drop policy if exists "finance reads bill batches" on public.bill_payment_batches;
create policy "finance reads bill batches" on public.bill_payment_batches for select using (has_role(company_id, array['owner','admin','accountant']));

-- p_items: [{"bill_id": "...", "amount": 1000, "wht": 75, "rate": 15.2}] in each bill's currency; amount is what is paid out,
-- wht what is kept back for GRA. Both together come off the bill.
create or replace function public.pay_bills(cid uuid, p_date date, p_account uuid, p_items jsonb, p_reference text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_batch uuid; v_no text; x jsonb; b bills; v_pay numeric; v_wht numeric; v_rate numeric; g_bank numeric; g_ap numeric; g_wht numeric;
  v_je uuid; v_id uuid; n int := 0; t_pay numeric := 0; t_wht numeric := 0; v_method text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  perform paying_account(cid, p_account);
  v_method := method_of(p_account);
  v_no := next_number(cid, 'BPB', 'BPB-');
  insert into bill_payment_batches (company_id, number, pay_date, account_id, reference) values (cid, v_no, p_date, p_account, p_reference) returning id into v_batch;
  for x in select * from jsonb_array_elements(coalesce(p_items, '[]')) loop
    v_pay := round(coalesce((x->>'amount')::numeric, 0), 2); v_wht := round(coalesce((x->>'wht')::numeric, 0), 2);
    continue when v_pay + v_wht <= 0;
    if v_pay < 0 or v_wht < 0 then raise exception 'Amounts cannot be negative'; end if;
    select * into b from bills where id = (x->>'bill_id')::uuid and company_id = cid for update;
    if not found then raise exception 'Bill not found'; end if;
    if b.status <> 'posted' then raise exception '% is not open for payment', coalesce(b.number, 'A draft bill'); end if;
    if v_pay + v_wht > b.total - b.amount_paid then raise exception '% has only % left to pay', b.number, b.total - b.amount_paid; end if;
    v_rate := case when b.currency = 'GHS' then 1 else coalesce(nullif((x->>'rate')::numeric, 0), b.exchange_rate) end;
    g_bank := round(v_pay * v_rate, 2); g_wht := round(v_wht * v_rate, 2); g_ap := round((v_pay + v_wht) * b.exchange_rate, 2);
    insert into bill_payments (company_id, bill_id, payment_date, amount, method, reference, exchange_rate, account_id, batch_id, wht_amount)
    values (cid, b.id, p_date, v_pay + v_wht, v_method, coalesce(p_reference, v_no), v_rate, p_account, v_batch, v_wht) returning id into v_id;
    v_je := post_journal(cid, p_date, 'Payment to supplier for ' || b.number || ' (' || v_no || ')' || case when v_wht > 0 then ', WHT withheld' else '' end,
      jsonb_build_array(jl(acct(cid, 'ap'), g_ap, 0), jl(p_account, 0, g_bank),
        case when g_wht > 0 then jl(acct(cid, 'wht_payable'), 0, g_wht) else jl(p_account, 0, 0) end,
        jl(acct(cid, 'fx'), greatest(g_bank + g_wht - g_ap, 0), greatest(g_ap - g_bank - g_wht, 0))), 'bill_payment', v_id);
    update bill_payments set journal_entry_id = v_je where id = v_id;
    update bills set amount_paid = amount_paid + v_pay + v_wht, status = case when amount_paid + v_pay + v_wht >= total then 'paid' else 'posted' end where id = b.id;
    n := n + 1; t_pay := t_pay + g_bank; t_wht := t_wht + g_wht;
  end loop;
  if n = 0 then raise exception 'Tick at least one bill and enter what to pay'; end if;
  update bill_payment_batches set total_paid = t_pay, total_wht = t_wht, bills = n where id = v_batch;
  return v_batch;
end $$;

-- ---------------------------------------------------------------- 4. Bank feed: imported statement lines and rules
create table if not exists public.bank_rules (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  contains text not null,                      -- words in the bank's description, e.g. "ECG" or "SALARY"
  direction text not null default 'any' check (direction in ('in','out','any')),
  counter_account_id uuid not null references public.accounts(id),
  payee text,
  project_id uuid references public.projects(id) on delete set null,
  priority int not null default 100,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.bank_rules enable row level security;
drop policy if exists "finance manages rules" on public.bank_rules;
create policy "finance manages rules" on public.bank_rules for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

create table if not exists public.bank_feed_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id),
  txn_date date not null,
  description text not null,
  reference text,
  amount numeric(14,2) not null check (amount <> 0),   -- positive = money in, negative = money out
  fingerprint text not null,
  status text not null default 'new' check (status in ('new','done','ignored')),
  done_as text,                                        -- what it became: payment, bill payment, money in/out, matched
  done_ref text,
  batch text,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  unique (company_id, account_id, fingerprint)
);
create index if not exists bank_feed_open on public.bank_feed_lines (company_id, account_id, status, txn_date);
alter table public.bank_feed_lines enable row level security;
drop policy if exists "finance manages feed" on public.bank_feed_lines;
create policy "finance manages feed" on public.bank_feed_lines for all using (has_role(company_id, array['owner','admin','accountant'])) with check (has_role(company_id, array['owner','admin','accountant']));

-- Upload: lines already imported (same date, amount, description and reference) are skipped.
create or replace function public.import_bank_lines(cid uuid, p_account uuid, p_lines jsonb, p_batch text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare x jsonb; n_new int := 0; n_dup int := 0; v_fp text;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  perform paying_account(cid, p_account);
  for x in select * from jsonb_array_elements(coalesce(p_lines, '[]')) loop
    continue when coalesce((x->>'amount')::numeric, 0) = 0 or nullif(x->>'date', '') is null;
    v_fp := md5((x->>'date') || '|' || round((x->>'amount')::numeric, 2)::text || '|' || lower(trim(coalesce(x->>'description', ''))) || '|' || lower(trim(coalesce(x->>'reference', ''))));
    insert into bank_feed_lines (company_id, account_id, txn_date, description, reference, amount, fingerprint, batch)
    values (cid, p_account, (x->>'date')::date, left(coalesce(nullif(trim(x->>'description'), ''), '(no description)'), 400), nullif(trim(x->>'reference'), ''),
            round((x->>'amount')::numeric, 2), v_fp, p_batch)
    on conflict (company_id, account_id, fingerprint) do nothing;
    if found then n_new := n_new + 1; else n_dup := n_dup + 1; end if;
  end loop;
  return jsonb_build_object('added', n_new, 'skipped', n_dup);
end $$;

-- What each open line could be: an existing entry in the books with the same amount within 5 days, an open invoice or
-- bill of that amount (or whose number is in the description), or a rule.
create or replace function public.bank_feed_suggestions(cid uuid, p_account uuid)
returns table (line_id uuid, kind text, target_id uuid, label text, amount numeric, counter_account_id uuid, payee text, project_id uuid)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with open as (select * from bank_feed_lines f where f.company_id = cid and f.account_id = p_account and f.status = 'new'),
  booked as (   -- entries already in the books on this account and not yet matched to a line
    select je.id, je.entry_date, je.memo, sum(l.debit - l.credit) amt
      from journal_entries je join journal_lines l on l.entry_id = je.id
     where je.company_id = cid and l.account_id = p_account and l.reconciliation_id is null
       and not exists (select 1 from bank_feed_lines f where f.company_id = cid and f.done_ref = je.id::text)
     group by je.id, je.entry_date, je.memo)
  select o.id, 'match', b.id, 'Already in the books: ' || b.memo, b.amt, null::uuid, null::text, null::uuid
    from open o join booked b on b.amt = o.amount and abs(b.entry_date - o.txn_date) <= 5
  union all
  select o.id, 'invoice', i.id, 'Payment of ' || i.number || ' — ' || c.name, i.total - i.amount_paid - i.amount_credited, null, c.name, i.project_id
    from open o join invoices i on i.company_id = cid and i.status = 'posted' and i.currency = 'GHS'
    join customers c on c.id = i.customer_id
   where o.amount > 0 and (i.total - i.amount_paid - i.amount_credited = o.amount or (i.number is not null and o.description || ' ' || coalesce(o.reference, '') ilike '%' || i.number || '%')
        or (i.total - i.amount_paid - i.amount_credited - coalesce(i.wht_amount, 0) = o.amount and coalesce(i.wht_amount, 0) > 0))
  union all
  select o.id, 'bill', b.id, 'Pay ' || b.number || ' — ' || s.name, b.total - b.amount_paid, null, s.name, null
    from open o join bills b on b.company_id = cid and b.status = 'posted' and b.currency = 'GHS'
    join suppliers s on s.id = b.supplier_id
   where o.amount < 0 and (b.total - b.amount_paid = -o.amount or (b.number is not null and o.description ilike '%' || b.number || '%')
        or (b.supplier_ref is not null and length(b.supplier_ref) >= 3 and o.description || ' ' || coalesce(o.reference, '') ilike '%' || b.supplier_ref || '%'))
  union all
  select distinct on (o.id) o.id, 'rule', r.id, r.name || ' → ' || a.code || ' ' || a.name, abs(o.amount), r.counter_account_id, r.payee, r.project_id
    from open o join bank_rules r on r.company_id = cid and r.active and o.description || ' ' || coalesce(o.reference, '') ilike '%' || r.contains || '%'
         and (r.direction = 'any' or (r.direction = 'in' and o.amount > 0) or (r.direction = 'out' and o.amount < 0))
    join accounts a on a.id = r.counter_account_id
   order by 1, 2;
end $$;

-- Close a line: matched to an entry already in the books, or after the app posted it (payment, bill payment, money in/out).
create or replace function public.bank_line_done(p_line uuid, p_as text, p_ref text default null) returns void
language plpgsql security definer set search_path = public as $$
declare f bank_feed_lines;
begin
  select * into f from bank_feed_lines where id = p_line for update;
  if not found then raise exception 'Line not found'; end if;
  perform require_member(f.company_id, array['owner','admin','accountant']);
  update bank_feed_lines set status = case when p_as = 'ignored' then 'ignored' when p_as = 'reopen' then 'new' else 'done' end,
    done_as = case when p_as in ('ignored','reopen') then null else p_as end, done_ref = case when p_as in ('ignored','reopen') then null else p_ref end where id = p_line;
end $$;

-- ---------------------------------------------------------------- 5. Reports
-- Cash flow (direct): every movement on cash, MoMo and bank accounts, sorted by what was on the other side.
create or replace function public.cash_flow(cid uuid, p_from date, p_to date)
returns table (section text, line text, amount numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with banks as (select id from accounts where company_id = cid and is_bank),
  ent as (select distinct l.entry_id from journal_lines l join journal_entries e on e.id = l.entry_id
           where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date between p_from and p_to),
  other as (select a.*, l.credit - l.debit amt from journal_lines l join accounts a on a.id = l.account_id
             where l.entry_id in (select entry_id from ent) and l.account_id not in (select id from banks)),
  classed as (
    select case
             when o.system_key in ('fa_cost','fa_accdep','disposal') or (o.type = 'asset' and o.system_key is null and o.code between '1500' and '1999') then '2 Investing'
             when o.type = 'equity' or o.code = '2400' or (o.type = 'liability' and o.system_key is null and o.name ilike '%loan%') then '3 Financing'
             else '1 Operating' end sec,
           case
             when o.system_key = 'ar' then 'Received from customers'
             when o.system_key = 'customer_deposits' then 'Customer deposits'
             when o.system_key in ('ap','grni') then 'Paid to suppliers'
             when o.system_key in ('net_pay','salaries','paye','ssnit1','tier2','payroll_deductions','employer_ssnit') then 'Salaries, PAYE and pensions'
             when o.system_key in ('vat_out','nhil_out','getf_out','vat_in','nhil_in','getf_in','wht_payable','wht_receivable') then 'VAT, levies and withholding tax'
             when o.system_key in ('staff_advances','staff_loans','reimburse') then 'Staff advances, loans and claims'
             when o.type = 'income' then 'Other income received'
             when o.type = 'expense' then o.code || ' ' || o.name
             else o.code || ' ' || o.name end ln,
           o.amt from other o)
  select c.sec, c.ln, round(sum(c.amt), 2) from classed c group by c.sec, c.ln having round(sum(c.amt), 2) <> 0
  union all
  select '0 Opening', 'Cash and bank at ' || to_char(p_from, 'DD Mon YYYY'), round(coalesce(sum(l.debit - l.credit), 0), 2)
    from journal_lines l join journal_entries e on e.id = l.entry_id where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date < p_from
  union all
  select '9 Closing', 'Cash and bank at ' || to_char(p_to, 'DD Mon YYYY'), round(coalesce(sum(l.debit - l.credit), 0), 2)
    from journal_lines l join journal_entries e on e.id = l.entry_id where l.company_id = cid and l.account_id in (select id from banks) and e.entry_date <= p_to
  order by 1, 3;
end $$;

-- Sales by customer or by product/service, in GH₵, net of credit notes.
create or replace function public.sales_by(cid uuid, p_from date, p_to date, p_by text default 'customer')
returns table (name text, docs bigint, qty numeric, net numeric, tax numeric, total numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant','sales']);
  if p_by = 'product' then
    return query
    select coalesce(p.name, '(services and other lines)'), count(distinct i.id), sum(l.qty), round(sum(l.qty * l.unit_price * i.exchange_rate), 2), 0::numeric, round(sum(l.qty * l.unit_price * i.exchange_rate), 2)
      from invoices i join invoice_lines l on l.invoice_id = i.id left join products p on p.id = l.product_id
     where i.company_id = cid and i.status in ('posted','paid') and i.invoice_date between p_from and p_to
     group by coalesce(p.name, '(services and other lines)') order by 4 desc;
  else
    return query
    with s as (
      select i.customer_id, count(*) n, sum(i.subtotal * i.exchange_rate) sub, sum((i.total - i.subtotal) * i.exchange_rate) tx
        from invoices i where i.company_id = cid and i.status in ('posted','paid') and i.invoice_date between p_from and p_to group by i.customer_id),
    cr as (
      select n.customer_id, sum(n.subtotal * coalesce(n.exchange_rate, 1)) sub, sum((n.total - n.subtotal) * coalesce(n.exchange_rate, 1)) tx
        from credit_notes n where n.company_id = cid and n.status = 'posted' and n.credit_date between p_from and p_to group by n.customer_id)
    select c.name, coalesce(s.n, 0), null::numeric, round(coalesce(s.sub, 0) - coalesce(cr.sub, 0), 2), round(coalesce(s.tx, 0) - coalesce(cr.tx, 0), 2),
           round(coalesce(s.sub, 0) + coalesce(s.tx, 0) - coalesce(cr.sub, 0) - coalesce(cr.tx, 0), 2)
      from customers c left join s on s.customer_id = c.id left join cr on cr.customer_id = c.id
     where c.company_id = cid and (s.customer_id is not null or cr.customer_id is not null)
     order by 4 desc;
  end if;
end $$;

-- Profit by project (from the ledger lines tagged to each project) or by customer (their projects plus invoices without a project).
create or replace function public.profit_by(cid uuid, p_from date, p_to date, p_by text default 'project')
returns table (name text, detail text, income numeric, costs numeric, profit numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  if p_by = 'customer' then
    return query
    with pl as (
      select pr.customer_id, sum(case when a.type = 'income' then l.credit - l.debit else 0 end) inc, sum(case when a.type = 'expense' then l.debit - l.credit else 0 end) cst
        from journal_lines l join journal_entries e on e.id = l.entry_id join accounts a on a.id = l.account_id join projects pr on pr.id = l.project_id
       where l.company_id = cid and e.entry_date between p_from and p_to group by pr.customer_id),
    loose as (   -- invoices with no project: their income only
      select i.customer_id, sum(i.subtotal * i.exchange_rate) inc from invoices i
       where i.company_id = cid and i.project_id is null and i.status in ('posted','paid') and i.invoice_date between p_from and p_to group by i.customer_id)
    select coalesce(c.name, '(no customer)'), (select count(*) from projects x where x.customer_id = c.id and not x.is_template)::text || ' project(s)',
           round(coalesce(pl.inc, 0) + coalesce(loose.inc, 0), 2), round(coalesce(pl.cst, 0), 2), round(coalesce(pl.inc, 0) + coalesce(loose.inc, 0) - coalesce(pl.cst, 0), 2)
      from pl full join loose on loose.customer_id = pl.customer_id left join customers c on c.id = coalesce(pl.customer_id, loose.customer_id)
     order by 5 desc;
  else
    return query
    select coalesce(p.number || ' ', '') || p.name, coalesce(c.name, 'Internal'),
           round(sum(case when a.type = 'income' then l.credit - l.debit else 0 end), 2), round(sum(case when a.type = 'expense' then l.debit - l.credit else 0 end), 2),
           round(sum(case when a.type = 'income' then l.credit - l.debit when a.type = 'expense' then l.credit - l.debit else 0 end), 2)
      from journal_lines l join journal_entries e on e.id = l.entry_id join accounts a on a.id = l.account_id join projects p on p.id = l.project_id
      left join customers c on c.id = p.customer_id
     where l.company_id = cid and e.entry_date between p_from and p_to and a.type in ('income','expense')
     group by p.id, p.number, p.name, c.name order by 5 desc;
  end if;
end $$;

-- ---------------------------------------------------------------- 6. New companies, numbering names, audit, voiding rules
create or replace function public.company_seed_v35() returns trigger
language plpgsql security definer set search_path = public as $$
begin perform seed_accounts_v35(new.id); return null; end $$;
drop trigger if exists companies_seed_v35 on public.companies;
create trigger companies_seed_v35 after insert on public.companies for each row execute function public.company_seed_v35();

do $$ declare t text; begin
  foreach t in array array['customer_receipts','bill_payment_batches','bank_rules'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;
