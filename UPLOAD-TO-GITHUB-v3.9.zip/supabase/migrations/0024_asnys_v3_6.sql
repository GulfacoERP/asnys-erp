-- Asnys ERP v3.6 — Bank of Ghana exchange rates, filled in automatically, and month-end revaluation
--   1. Every working day the BoG interbank rates (buying, mid, selling) are fetched by the asnys-m365 edge function
--      (from a rates service that republishes the BoG table, with the BoG web page as the backup) and kept as history.
--   2. Each company's currency list takes the BoG mid-rate; new documents and payments fill in the BoG mid-rate for
--      their date (staff can still change it).
--   3. Month-end revaluation restates unpaid foreign-currency invoices and bills at the month-end BoG rate; the
--      unrealised gain or loss is posted and reversed on the first day of the next month.
-- The books stay in cedis. Run after 0023. Safe to run twice.

-- ---------------------------------------------------------------- 1. Rate history (the same BoG rates for every company)
create table if not exists public.fx_rates (
  rate_date date not null,
  code text not null check (code ~ '^[A-Z]{3}$'),
  buying numeric(14,6),
  mid numeric(14,6) not null check (mid > 0),
  selling numeric(14,6),
  source text not null default 'BoG',
  fetched_at timestamptz not null default now(),
  primary key (rate_date, code)
);
alter table public.fx_rates enable row level security;
drop policy if exists "signed in read rates" on public.fx_rates;
create policy "signed in read rates" on public.fx_rates for select using (auth.uid() is not null);

-- One row of settings for the daily fetch. The shared secret is only readable by the database and the edge function.
create table if not exists public.fx_settings (
  id int primary key default 1 check (id = 1),
  enabled boolean not null default true,
  function_url text,
  secret text not null default (md5(gen_random_uuid()::text || clock_timestamp()::text) || md5(gen_random_uuid()::text)),
  last_run_at timestamptz,
  last_status text,
  last_rate_date date,
  last_alert date
);
insert into public.fx_settings (id) values (1) on conflict do nothing;
alter table public.fx_settings enable row level security;   -- no policies: reached only through the functions below

alter table public.currencies add column if not exists rate_date date;
alter table public.currencies add column if not exists rate_source text;
alter table public.currencies add column if not exists auto_rate boolean not null default true;

-- The rate for a currency on a day: the latest BoG mid-rate on or before that day (weekends and holidays use Friday's).
create or replace function public.fx_rate(cid uuid, p_code text, p_date date default current_date)
returns jsonb language sql stable security definer set search_path = public as $$
  select case when p_code = 'GHS' then jsonb_build_object('rate', 1, 'rate_date', p_date, 'source', 'GHS')
         else (select jsonb_build_object('rate', r.mid, 'buying', r.buying, 'selling', r.selling, 'rate_date', r.rate_date, 'source', r.source)
                 from fx_rates r where r.code = upper(p_code) and r.rate_date <= coalesce(p_date, current_date)
                order by r.rate_date desc limit 1) end
   where is_member(cid);
$$;

-- Settings screen: the last fetch and today's table.
create or replace function public.fx_status(cid uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s fx_settings;
begin
  perform require_member(cid);
  select * into s from fx_settings where id = 1;
  return jsonb_build_object('enabled', s.enabled, 'function_url_set', s.function_url is not null, 'last_run_at', s.last_run_at, 'last_status', s.last_status,
    'last_rate_date', s.last_rate_date, 'pg_net', to_regnamespace('net') is not null,
    'latest', coalesce((select jsonb_agg(jsonb_build_object('code', r.code, 'buying', r.buying, 'mid', r.mid, 'selling', r.selling, 'rate_date', r.rate_date, 'source', r.source) order by r.code)
                 from fx_rates r where r.rate_date = (select max(rate_date) from fx_rates)), '[]'));
end $$;

-- Owners point the daily fetch at their asnys-m365 function (any company owner of this installation may set it).
create or replace function public.fx_configure(cid uuid, p_function_url text, p_enabled boolean default true) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not has_role(cid, array['owner','admin']) then raise exception 'Only an owner or admin can change this'; end if;
  if p_function_url !~ '^https://.+/functions/v1/asnys-m365$' then raise exception 'The address should end in /functions/v1/asnys-m365'; end if;
  update fx_settings set function_url = p_function_url, enabled = p_enabled where id = 1;
end $$;

-- Ask the edge function to fetch today's table.
create or replace function public.start_fx_fetch() returns bigint
language plpgsql security definer set search_path = public as $$
declare s fx_settings; v_url text;
begin
  select * into s from fx_settings where id = 1;
  if not s.enabled then return null; end if;
  v_url := coalesce(s.function_url, (select function_url from company_email where function_url like '%/functions/v1/asnys-m365' limit 1));
  if v_url is null then return null; end if;
  update fx_settings set last_run_at = now(), last_status = 'started' where id = 1;
  return http_post_safe(v_url, jsonb_build_object('action', 'fx'), jsonb_build_object('Content-Type', 'application/json', 'x-asnys-fx', s.secret));
end $$;
revoke execute on function public.start_fx_fetch() from public, anon, authenticated;

create or replace function public.fx_fetch_now(cid uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
  if not has_role(cid, array['owner','admin','accountant']) then raise exception 'Only Finance can fetch rates'; end if;
  if to_regnamespace('net') is null then raise exception 'Turn on the pg_net extension in Supabase (Database → Extensions → pg_net) first'; end if;
  v := start_fx_fetch();
  if v is null then raise exception 'Set the asnys-m365 function address under Foreign currencies first'; end if;
  return 'started';
end $$;

-- Used only by the edge function (service key + the shared secret): save the table and update every company's rates.
create or replace function public.fx_save(p_secret text, p_rows jsonb, p_source text, p_status text default 'ok') returns int
language plpgsql security definer set search_path = public as $$
declare x jsonb; n int := 0; v_date date; c record;
begin
  if not exists (select 1 from fx_settings where id = 1 and secret = p_secret) then raise exception 'Not allowed'; end if;
  for x in select * from jsonb_array_elements(coalesce(p_rows, '[]')) loop
    continue when coalesce((x->>'mid')::numeric, 0) <= 0 or coalesce(x->>'code', '') !~ '^[A-Z]{3}$' or (x->>'code') = 'GHS';
    insert into fx_rates (rate_date, code, buying, mid, selling, source)
    values ((x->>'date')::date, x->>'code', nullif(x->>'buying', '')::numeric, (x->>'mid')::numeric, nullif(x->>'selling', '')::numeric, coalesce(p_source, 'BoG'))
    on conflict (rate_date, code) do update set buying = excluded.buying, mid = excluded.mid, selling = excluded.selling, source = excluded.source, fetched_at = now();
    n := n + 1; v_date := greatest(v_date, (x->>'date')::date);
  end loop;
  update fx_settings set last_status = case when n > 0 then 'ok' else coalesce(p_status, 'no rates found') end,
    last_rate_date = coalesce(v_date, last_rate_date), last_run_at = now() where id = 1;
  if n > 0 then
    update currencies cu set rate = r.mid, rate_date = r.rate_date, rate_source = r.source, updated_at = now()
      from (select distinct on (code) code, mid, rate_date, source from fx_rates order by code, rate_date desc) r
     where cu.code = r.code and cu.auto_rate;
  elsif (select coalesce(last_alert, '1900-01-01') < current_date from fx_settings where id = 1) then
    -- Tell Finance once a day that the rates could not be fetched; the last rates stay in use.
    update fx_settings set last_alert = current_date where id = 1;
    for c in select distinct company_id from currencies loop
      perform notify(c.company_id, array['accountant'], null, 'fx_failed', 'Bank of Ghana rates could not be fetched today',
        'The last rates stay in use. Check the rate on each foreign-currency document, or type it in. ' || coalesce(p_status, ''), '/settings', true);
    end loop;
  end if;
  return n;
end $$;
revoke execute on function public.fx_save(text, jsonb, text, text) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then grant execute on function public.fx_save(text, jsonb, text, text) to service_role; end if;
end $$;

-- Daily at 15:00 and 17:00 Ghana time (UTC) on working days, if pg_cron is on.
do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    begin perform cron.unschedule('asnys-bog-rates'); exception when others then null; end;
    perform cron.schedule('asnys-bog-rates', '0 15,17 * * 1-5', 'select public.start_fx_fetch()');
  end if;
exception when others then null;
end $$;

-- ---------------------------------------------------------------- 2. Month-end revaluation of unpaid foreign-currency invoices and bills
create table if not exists public.fx_revaluations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  reval_date date not null,
  ar_change numeric(14,2) not null default 0,     -- + = receivables worth more in cedis (gain)
  ap_change numeric(14,2) not null default 0,     -- + = payables cost more in cedis (loss)
  detail jsonb not null default '[]',
  journal_entry_id uuid references public.journal_entries(id),
  reversal_entry_id uuid references public.journal_entries(id),
  status text not null default 'posted' check (status in ('posted','undone')),
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create unique index if not exists fx_revaluations_one_per_date on public.fx_revaluations (company_id, reval_date) where status = 'posted';
alter table public.fx_revaluations enable row level security;
drop policy if exists "finance reads revaluations" on public.fx_revaluations;
create policy "finance reads revaluations" on public.fx_revaluations for select using (has_role(company_id, array['owner','admin','accountant']));

-- What revaluing at a date would do (nothing is posted).
create or replace function public.fx_revalue_preview(cid uuid, p_date date)
returns table (kind text, doc_id uuid, number text, party text, currency text, open_amount numeric, booked_rate numeric, new_rate numeric, change numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  perform require_member(cid, array['owner','admin','accountant']);
  return query
  with r as (select distinct on (code) code, mid from fx_rates where rate_date <= p_date order by code, rate_date desc)
  select 'invoice', i.id, i.number, c.name, i.currency, round(i.total - i.amount_paid - i.amount_credited, 2), i.exchange_rate, r.mid,
         round((i.total - i.amount_paid - i.amount_credited) * (r.mid - i.exchange_rate), 2)
    from invoices i join customers c on c.id = i.customer_id join r on r.code = i.currency
   where i.company_id = cid and i.currency <> 'GHS' and i.status = 'posted' and i.invoice_date <= p_date and i.total - i.amount_paid - i.amount_credited > 0
  union all
  select 'bill', b.id, b.number, s.name, b.currency, round(b.total - b.amount_paid, 2), b.exchange_rate, r.mid,
         round((b.total - b.amount_paid) * (r.mid - b.exchange_rate), 2)
    from bills b join suppliers s on s.id = b.supplier_id join r on r.code = b.currency
   where b.company_id = cid and b.currency <> 'GHS' and b.status = 'posted' and b.bill_date <= p_date and b.total - b.amount_paid > 0
  order by 1, 3;
end $$;

-- Post it: one entry at the date, reversed the next day, so payments later still clear at each document's own rate.
create or replace function public.fx_revalue(cid uuid, p_date date) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_ar numeric; v_ap numeric; v_det jsonb; v_lines jsonb := '[]'; v_je uuid; v_rev uuid; v_id uuid; v_net numeric;
begin
  perform require_member(cid, array['owner','admin','accountant']);
  if exists (select 1 from fx_revaluations where company_id = cid and reval_date = p_date and status = 'posted') then raise exception 'Already revalued at %. Undo that one first.', p_date; end if;
  select coalesce(sum(change) filter (where kind = 'invoice'), 0), coalesce(sum(change) filter (where kind = 'bill'), 0), coalesce(jsonb_agg(to_jsonb(p)), '[]')
    into v_ar, v_ap, v_det from fx_revalue_preview(cid, p_date) p;
  if v_ar = 0 and v_ap = 0 then raise exception 'Nothing to revalue: no unpaid foreign-currency invoices or bills, or no BoG rate on or before %', p_date; end if;
  -- Receivables up = gain; payables up = loss.
  if v_ar <> 0 then v_lines := v_lines || jl(acct(cid, 'ar'), greatest(v_ar, 0), greatest(-v_ar, 0)); end if;
  if v_ap <> 0 then v_lines := v_lines || jl(acct(cid, 'ap'), greatest(-v_ap, 0), greatest(v_ap, 0)); end if;
  v_net := v_ar - v_ap;
  if v_net <> 0 then v_lines := v_lines || jl(acct(cid, 'fx'), greatest(-v_net, 0), greatest(v_net, 0)); end if;
  insert into fx_revaluations (company_id, reval_date, ar_change, ap_change, detail) values (cid, p_date, v_ar, v_ap, v_det) returning id into v_id;
  v_je := post_journal(cid, p_date, 'Unrealised exchange gain/loss: foreign-currency invoices and bills restated at the BoG rate of ' || to_char(p_date, 'DD Mon YYYY'), v_lines, 'fx_reval', v_id);
  select jsonb_agg(jsonb_build_object('account_id', l->>'account_id', 'debit', l->>'credit', 'credit', l->>'debit')) into v_lines from jsonb_array_elements(v_lines) l;
  v_rev := post_journal(cid, p_date + 1, 'Reversal of the ' || to_char(p_date, 'DD Mon YYYY') || ' exchange revaluation', v_lines, 'fx_reval', v_id);
  update fx_revaluations set journal_entry_id = v_je, reversal_entry_id = v_rev where id = v_id;
  return v_id;
end $$;

create or replace function public.fx_revalue_undo(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare r fx_revaluations; v_lines jsonb;
begin
  select * into r from fx_revaluations where id = p_id for update;
  if not found or r.status <> 'posted' then raise exception 'Revaluation not found'; end if;
  perform require_member(r.company_id, array['owner','admin','accountant']);
  -- Cancel both entries with mirror entries (dated as the originals; the books must not be locked over those dates).
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit)) into v_lines from journal_lines l where l.entry_id = r.journal_entry_id;
  perform post_journal(r.company_id, r.reval_date, 'Undo exchange revaluation of ' || to_char(r.reval_date, 'DD Mon YYYY'), v_lines, 'fx_reval', r.id);
  select jsonb_agg(jsonb_build_object('account_id', l.account_id, 'debit', l.credit, 'credit', l.debit)) into v_lines from journal_lines l where l.entry_id = r.reversal_entry_id;
  perform post_journal(r.company_id, r.reval_date + 1, 'Undo reversal of exchange revaluation of ' || to_char(r.reval_date, 'DD Mon YYYY'), v_lines, 'fx_reval', r.id);
  update fx_revaluations set status = 'undone' where id = r.id;
end $$;

do $$ declare t text; begin
  foreach t in array array['fx_revaluations'] loop
    if not exists (select 1 from pg_trigger g join pg_proc p on p.oid = g.tgfoid where g.tgrelid = ('public.' || t)::regclass and p.proname = 'audit_row') then
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end if;
  end loop;
end $$;
