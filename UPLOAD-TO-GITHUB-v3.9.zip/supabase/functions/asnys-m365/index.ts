// Asnys ERP: Gulfaco's Microsoft 365 link. One function, four jobs:
//   • send    — approval and notification emails from your mailbox (called by the Asnys database)
//   • backup  — daily backup of the company's data to OneDrive (called by the Asnys database)
//   • reset   — "Forgot password" emails (called from the sign-in page)
//   • fx      — Bank of Ghana exchange rates, every working day (called by the Asnys database)
// Deploy:  Supabase → Edge Functions → Deploy a new function → Via editor → name it asnys-m365 → paste → Deploy.
//          Then in the function's settings switch OFF "Verify JWT" (the database proves itself with a secret instead).
// Secrets (Edge Functions → Secrets):
//   MS_TENANT_ID, MS_CLIENT_ID                         from the Azure app registration
//   MS_CERT_KEY, MS_CERT_THUMBPRINT                    from Asnys → Settings → Telegram & email → Create certificate (recommended, 10 years)
//   or MS_CLIENT_SECRET                                a client secret instead of the certificate (24 months)
//   ALLRATESTODAY_KEY                                  free key from allratestoday.com (BoG rates); without it the BoG page is read
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase automatically.
import { createClient } from 'npm:@supabase/supabase-js@2.45.4';
// ---- Microsoft 365 (Graph) sign-in: certificate (MS_CERT_KEY + MS_CERT_THUMBPRINT) or client secret (MS_CLIENT_SECRET)
const b64url = (b: ArrayBuffer | Uint8Array) => btoa(String.fromCharCode(...new Uint8Array(b instanceof Uint8Array ? b : new Uint8Array(b)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64urlStr = (s: string) => b64url(new TextEncoder().encode(s));
let graphCache: { token: string; until: number } | null = null;
async function graphToken(): Promise<string> {
  if (graphCache && graphCache.until > Date.now() + 60_000) return graphCache.token;
  const tenant = Deno.env.get('MS_TENANT_ID'), id = Deno.env.get('MS_CLIENT_ID');
  if (!tenant || !id) throw new Error('Add MS_TENANT_ID and MS_CLIENT_ID under Edge Functions → Secrets');
  const url = `https://login.microsoftonline.com/${encodeURIComponent(tenant)}/oauth2/v2.0/token`;
  const form: Record<string, string> = { client_id: id, scope: 'https://graph.microsoft.com/.default', grant_type: 'client_credentials' };
  const pem = Deno.env.get('MS_CERT_KEY'), thumb = Deno.env.get('MS_CERT_THUMBPRINT');
  if (pem && thumb) {
    const der = Uint8Array.from(atob(pem.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '')), c => c.charCodeAt(0));
    const key = await crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
    const x5t = b64url(Uint8Array.from(thumb.replace(/[^0-9a-f]/gi, '').match(/.{2}/g)!.map(h => parseInt(h, 16))));
    const now = Math.floor(Date.now() / 1000);
    const head = b64urlStr(JSON.stringify({ alg: 'RS256', typ: 'JWT', x5t }));
    const body = b64urlStr(JSON.stringify({ aud: url, iss: id, sub: id, jti: crypto.randomUUID(), nbf: now - 60, exp: now + 600 }));
    const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(`${head}.${body}`));
    form.client_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer';
    form.client_assertion = `${head}.${body}.${b64url(sig)}`;
  } else {
    const secret = Deno.env.get('MS_CLIENT_SECRET');
    if (!secret) throw new Error('Add the certificate (MS_CERT_KEY and MS_CERT_THUMBPRINT) or MS_CLIENT_SECRET under Edge Functions → Secrets');
    form.client_secret = secret;
  }
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(form) });
  const j = await res.json();
  if (!res.ok) throw new Error('Microsoft sign-in failed: ' + (j.error_description || j.error || res.status));
  graphCache = { token: j.access_token, until: Date.now() + (Number(j.expires_in) || 3000) * 1000 };
  return graphCache.token;
}
async function graph(path: string, init: RequestInit = {}): Promise<Response> {
  const token = await graphToken();
  return fetch('https://graph.microsoft.com/v1.0' + path, { ...init, headers: { Authorization: `Bearer ${token}`, ...(init.headers || {}) } });
}
async function sendMail(from: { email: string; name?: string }, to: string, subject: string, html: string) {
  const res = await graph(`/users/${encodeURIComponent(from.email)}/sendMail`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: { subject, body: { contentType: 'HTML', content: html }, from: { emailAddress: { address: from.email, name: from.name } }, toRecipients: [{ emailAddress: { address: to } }] }, saveToSentItems: true }),
  });
  if (res.status === 202) return;
  const t = await res.text(); let msg = t;
  try { msg = JSON.parse(t)?.error?.message || t; } catch { /* not JSON */ }
  if (res.status === 403) msg = 'Microsoft refused: give the app the Mail.Send application permission and grant admin consent (and check the mailbox is allowed). ' + msg;
  if (res.status === 404) msg = `Mailbox ${from.email} not found in Microsoft 365. ` + msg;
  throw new Error(msg);
}
const esc = (t: string) => String(t ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' } as Record<string, string>)[c]);
const button = (href: string, label: string) => `<p><a href="${esc(href)}" style="background:#1d6b55;color:#fff;padding:11px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:bold">${esc(label)}</a></p>`;
const mailBody = (inner: string, company: string) => `<div style="font-family:Arial,sans-serif;font-size:15px;color:#17231e;max-width:560px">${inner}<p style="color:#5b6b63;font-size:12px;margin-top:24px">Sent by Asnys ERP for ${esc(company)}.</p></div>`;
// ---- end of Microsoft 365 part

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' } });
const admin = () => createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false, autoRefreshToken: false } });

// ---------------------------------------------------------------- send: one notification email (from the database)
async function doSend(b: any, secret: string) {
  const db = admin();
  const { data: cfg, error } = await db.rpc('email_hook_config', { cid: b.company_id, p_secret: secret });
  if (error) return json({ error: error.message }, 500);
  if (!cfg) return json({ error: 'Not allowed' }, 403);
  await sendMail({ email: cfg.from_email, name: cfg.from_name }, b.to, b.subject, b.html || esc(b.text || ''));
  return json({ ok: true });
}

// ---------------------------------------------------------------- backup: every company table to OneDrive, gzipped JSON
async function doBackup(b: any, secret: string) {
  const db = admin();
  const { data: cfg, error } = await db.rpc('backup_hook_config', { cid: b.company_id, p_secret: secret });
  if (error) return json({ error: error.message }, 500);
  if (!cfg) return json({ error: 'Not allowed' }, 403);
  const report = async (status: string, file: string | null, size: number | null) => { await db.rpc('backup_done', { cid: b.company_id, p_secret: secret, p_status: status, p_file: file, p_size: size }); };
  try {
    const out: Record<string, unknown[]> = {};
    for (const t of cfg.tables as string[]) {
      const rows: unknown[] = [];
      for (let from = 0; ; from += 1000) {
        const { data, error: e } = await db.from(t).select('*').eq('company_id', b.company_id).range(from, from + 999);
        if (e) throw new Error(`${t}: ${e.message}`);
        rows.push(...(data || []));
        if (!data || data.length < 1000) break;
      }
      out[t] = rows;
    }
    const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 16);
    const raw = new TextEncoder().encode(JSON.stringify({ app: 'Asnys ERP', company: cfg.company, company_id: b.company_id, made_at: new Date().toISOString(), tables: out }));
    const gz = new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
    const folder = String(cfg.folder || 'Asnys ERP backups').replace(/[\\:*?"<>|]/g, '');
    const name = `${(cfg.code || 'company').toString()}-asnys-backup-${stamp}.json.gz`;
    const base = `/users/${encodeURIComponent(cfg.onedrive_user)}/drive/root:/${encodeURIComponent(folder)}/${encodeURIComponent(name)}`;
    const ses = await graph(base + ':/createUploadSession', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ item: { '@microsoft.graph.conflictBehavior': 'rename' } }) });
    if (!ses.ok) throw new Error('OneDrive refused the upload (' + ses.status + '): ' + (await ses.text()).slice(0, 300) + ' — give the app the Files.ReadWrite.All application permission and check the OneDrive account exists.');
    const { uploadUrl } = await ses.json();
    const CH = 320 * 1024 * 16;
    for (let i = 0; i < gz.length; i += CH) {
      const part = gz.slice(i, Math.min(i + CH, gz.length));
      const r = await fetch(uploadUrl, { method: 'PUT', headers: { 'Content-Length': String(part.length), 'Content-Range': `bytes ${i}-${i + part.length - 1}/${gz.length}` }, body: part });
      if (![200, 201, 202].includes(r.status)) throw new Error('Upload stopped (' + r.status + '): ' + (await r.text()).slice(0, 200));
    }
    // Remove backups older than the keep period.
    const list = await graph(`/users/${encodeURIComponent(cfg.onedrive_user)}/drive/root:/${encodeURIComponent(folder)}:/children?$select=id,name,createdDateTime&$top=500`);
    if (list.ok) {
      const cut = Date.now() - Number(cfg.keep_days || 90) * 864e5;
      for (const it of ((await list.json()).value || []) as any[]) {
        if (/asnys-backup-.*\.json\.gz$/.test(it.name) && Date.parse(it.createdDateTime) < cut) await graph(`/users/${encodeURIComponent(cfg.onedrive_user)}/drive/items/${it.id}`, { method: 'DELETE' });
      }
    }
    await report('ok', `${folder}/${name}`, gz.length);
    return json({ ok: true, file: `${folder}/${name}`, size: gz.length });
  } catch (e) {
    await report((e as Error).message, null, null);
    return json({ error: (e as Error).message }, 500);
  }
}

// ---------------------------------------------------------------- reset: "Forgot password" link by email (public; same answer either way)
async function doReset(b: any) {
  const email = String(b.email || '').trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(email)) return json({ error: 'Enter your email address' }, 400);
  const db = admin();
  const { data: t } = await db.rpc('reset_target', { p_email: email });
  if (t) {
    const app = String(t.app_url || '').replace(/\/$/, '');
    const { data: link, error } = await db.auth.admin.generateLink({ type: 'recovery', email, options: { redirectTo: app + '/' } });
    if (!error && link?.properties?.action_link) {
      try {
        await sendMail({ email: t.from_email, name: t.from_name }, email, `Reset your ${t.company} Asnys ERP password`,
          mailBody(`<p>Someone (we hope you) asked to reset the password for <b>${esc(email)}</b> on Asnys ERP.</p>${button(link.properties.action_link, 'Choose a new password')}<p>The link works once and expires soon. If you did not ask, ignore this email; your password stays the same.</p>`, t.company));
      } catch { /* the answer below stays the same */ }
    }
  } else {
    // Not a Microsoft 365 company (or sent too often): fall back to Supabase's own reset email, which has its own limits.
    const back = /^https:\/\/[\w.-]+(:\d+)?\/?$/.test(String(b.redirect || '')) ? String(b.redirect) : undefined;
    try { await db.auth.resetPasswordForEmail(email, back ? { redirectTo: back } : undefined); } catch { /* same answer */ }
  }
  return json({ ok: true, message: 'If that email has an Asnys login, a reset link is on its way.' });
}


// ---------------------------------------------------------------- fx: Bank of Ghana interbank rates (buying, mid, selling) for today
type FxRow = { date: string; code: string; buying: number | null; mid: number; selling: number | null };
const NAMES: Record<string, string> = { 'US DOLLAR': 'USD', 'POUND STERLING': 'GBP', 'BRITISH POUND': 'GBP', 'EURO': 'EUR', 'SWISS FRANC': 'CHF', 'JAPANESE YEN': 'JPY', 'CHINESE YUAN': 'CNY', 'CHINESE RENMINBI': 'CNY',
  'CANADIAN DOLLAR': 'CAD', 'AUSTRALIAN DOLLAR': 'AUD', 'DANISH KRONE': 'DKK', 'SWEDISH KRONA': 'SEK', 'NORWEGIAN KRONE': 'NOK', 'SOUTH AFRICAN RAND': 'ZAR', 'CFA FRANC': 'XOF', 'NIGERIAN NAIRA': 'NGN', 'NEW ZEALAND DOLLAR': 'NZD', 'GAMBIAN DALASI': 'GMD' };
const isoDate = (s: string) => { const d = new Date(s); return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10); };

async function fromService(key: string): Promise<FxRow[]> {
  const r = await fetch('https://allratestoday.com/api/v1/central-bank/bog/latest', { headers: { Authorization: 'Bearer ' + key, Accept: 'application/json' } });
  if (!r.ok) throw new Error(`Rates service ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const j = await r.json();
  const date = isoDate(j.rate_date || j.date || '') || new Date().toISOString().slice(0, 10);
  const by: Record<string, FxRow> = {};
  for (const x of j.rates || []) {
    let code = String(x.base || '').toUpperCase(), v = Number(x.value);
    if (code === 'GHS') { code = String(x.quote || '').toUpperCase(); v = v ? 1 / v : 0; }   // GHS-based quote: turn into GH₵ per unit
    else if (String(x.quote || 'GHS').toUpperCase() !== 'GHS') continue;
    if (!/^[A-Z]{3}$/.test(code) || !(v > 0)) continue;
    const row = by[code] ||= { date, code, buying: null, mid: 0, selling: null };
    const t = String(x.type || 'middle').toLowerCase();
    if (t.startsWith('buy')) row.buying = v; else if (t.startsWith('sell')) row.selling = v; else row.mid = v;
  }
  return Object.values(by).map(r => ({ ...r, mid: r.mid || (r.buying && r.selling ? (r.buying + r.selling) / 2 : r.buying || r.selling || 0) })).filter(r => r.mid > 0);
}

// Backup: read the table on the Bank of Ghana page (best effort; the page layout can change).
async function fromBogPage(): Promise<FxRow[]> {
  const r = await fetch('https://www.bog.gov.gh/treasury-and-the-markets/daily-interbank-fx-rates/', { headers: { 'User-Agent': 'Mozilla/5.0 (Asnys ERP rates)', Accept: 'text/html' } });
  if (!r.ok) throw new Error('BoG page ' + r.status);
  const html = await r.text();
  const rows = [...html.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)].map(m => [...m[1].matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(c => c[1].replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim()));
  const out: Record<string, FxRow> = {};
  for (const cells of rows) {
    const text = cells.join(' | ').toUpperCase();
    let code = (text.match(/\b(USD|GBP|EUR|CHF|JPY|CNY|CAD|AUD|DKK|SEK|NOK|ZAR|XOF|NGN|NZD|GMD)\b/) || [])[1];
    if (!code) for (const [n, c] of Object.entries(NAMES)) if (text.includes(n)) { code = c; break; }
    if (!code || out[code]) continue;   // the first (newest) row per currency
    const nums = cells.map(c => Number(c.replace(/,/g, ''))).filter(n => isFinite(n) && n > 0 && n < 100000);
    const dateCell = cells.map(c => isoDate(c)).find(Boolean);
    if (!nums.length) continue;
    const [a, b2, c3] = nums.slice(-3);
    const row: FxRow = nums.length >= 3 ? { date: dateCell || '', code, buying: Math.min(a, b2, c3), mid: [a, b2, c3].sort((x, y) => x - y)[1], selling: Math.max(a, b2, c3) }
      : nums.length === 2 ? { date: dateCell || '', code, buying: Math.min(a, b2), mid: (a + b2) / 2, selling: Math.max(a, b2) } : { date: dateCell || '', code, buying: null, mid: a, selling: null };
    row.date = row.date || new Date().toISOString().slice(0, 10);
    out[code] = row;
  }
  return Object.values(out);
}

async function doFx(secret: string) {
  const db = admin();
  let rows: FxRow[] = [], source = '', problems: string[] = [];
  const key = Deno.env.get('ALLRATESTODAY_KEY');
  if (key) { try { rows = await fromService(key); source = 'BoG (via AllRatesToday)'; } catch (e) { problems.push((e as Error).message); } }
  if (!rows.length) { try { rows = await fromBogPage(); source = 'BoG website'; } catch (e) { problems.push((e as Error).message); } }
  const { data, error } = await db.rpc('fx_save', { p_secret: secret, p_rows: rows, p_source: source || 'BoG', p_status: problems.join('; ').slice(0, 300) || 'no rates found' });
  if (error) return json({ error: error.message }, 403);
  return json({ ok: true, saved: data, source, problems });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return json({ ok: true });
  if (req.method !== 'POST') return json({ error: 'Use POST' }, 405);
  let b: any;
  try { b = await req.json(); } catch { return json({ error: 'Send JSON' }, 400); }
  const secret = req.headers.get('x-asnys-secret') || '';
  try {
    if (b.action === 'reset') return await doReset(b);
    if (b.action === 'fx') return await doFx(req.headers.get('x-asnys-fx') || '');
    if (!b.company_id || !secret) return json({ error: 'Not allowed' }, 403);
    if (b.action === 'backup') return await doBackup(b, secret);
    return await doSend(b, secret);   // default: send one email (called by the database)
  } catch (e) {
    return json({ error: (e as Error).message }, 500);
  }
});
