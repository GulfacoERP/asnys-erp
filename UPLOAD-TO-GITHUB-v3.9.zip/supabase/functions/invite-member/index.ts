// Asnys ERP: staff logins.
//   action "invite" (default): emails invitations.
//   action "create_login":     creates logins with a temporary password (no email needed) and returns the passwords.
//   action "set_password":     gives an existing member a new temporary password.
// People with a temporary password must choose their own at their next sign-in.
// Deploy:  Supabase → Edge Functions → invite-member → Code → paste → Deploy updates (Verify JWT stays on).
// Secrets: SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY are provided by Supabase automatically.
//          Optionally set SITE_URL (e.g. https://asnys-erp.pages.dev) so email links open your app.
//          When the company sends email through Microsoft 365 (Settings → Telegram & email), invitations go out from that
//          mailbox using the same MS_* secrets as the asnys-m365 function; otherwise Supabase's own email is used.
// The service role key stays here on the server; the browser never sees it. Every action is checked by the
// database as the signed-in person first (owners and admins; HR for staff only).
import { createClient } from 'npm:@supabase/supabase-js@2.45.4';
// ---- Microsoft 365 (Graph) sign-in: certificate (MS_CERT_KEY + MS_CERT_THUMBPRINT) or client secret (MS_CLIENT_SECRET)
const b64url = (b: ArrayBuffer | Uint8Array) => btoa(String.fromCharCode(...new Uint8Array(b instanceof Uint8Array ? b : new Uint8Array(b)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const b64urlStr = (s: string) => b64url(new TextEncoder().encode(s));
let graphCache: { token: string; until: number } | null = null;
async function graphToken(): Promise<string> {
  if (graphCache && graphCache.until > Date.now() + 60_000) return graphCache.token;
  const tenant = Deno.env.get('MS_TENANT_ID'), id = Deno.env.get('MS_CLIENT_ID');
  if (!tenant || !id) throw new Error('Add MS_TENANT_ID and MS_CLIENT_ID under Edge Functions → Secrets');
  const url = `https://login.microsoftonline.com/${encodeURIComponent(tenant)}/oauth2/v2.0/token`;
  const form: Record<string, string> = { client_id: id, scope: 'https://graph.microsoft.com/.default', grant_type: 'client_credentials' };
  const pem = Deno.env.get('MS_CERT_KEY'), thumb = Deno.env.get('MS_CERT_THUMBPRINT');
  if (pem && thumb) {
    const der = Uint8Array.from(atob(pem.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '')), c => c.charCodeAt(0));
    const key = await crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
    const x5t = b64url(Uint8Array.from(thumb.replace(/[^0-9a-f]/gi, '').match(/.{2}/g)!.map(h => parseInt(h, 16))));
    const now = Math.floor(Date.now() / 1000);
    const head = b64urlStr(JSON.stringify({ alg: 'RS256', typ: 'JWT', x5t }));
    const body = b64urlStr(JSON.stringify({ aud: url, iss: id, sub: id, jti: crypto.randomUUID(), nbf: now - 60, exp: now + 600 }));
    const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(`${head}.${body}`));
    form.client_assertion_type = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer';
    form.client_assertion = `${head}.${body}.${b64url(sig)}`;
  } else {
    const secret = Deno.env.get('MS_CLIENT_SECRET');
    if (!secret) throw new Error('Add the certificate (MS_CERT_KEY and MS_CERT_THUMBPRINT) or MS_CLIENT_SECRET under Edge Functions → Secrets');
    form.client_secret = secret;
  }
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(form) });
  const j = await res.json();
  if (!res.ok) throw new Error('Microsoft sign-in failed: ' + (j.error_description || j.error || res.status));
  graphCache = { token: j.access_token, until: Date.now() + (Number(j.expires_in) || 3000) * 1000 };
  return graphCache.token;
}
async function graph(path: string, init: RequestInit = {}): Promise<Response> {
  const token = await graphToken();
  return fetch('https://graph.microsoft.com/v1.0' + path, { ...init, headers: { Authorization: `Bearer ${token}`, ...(init.headers || {}) } });
}
async function sendMail(from: { email: string; name?: string }, to: string, subject: string, html: string) {
  const res = await graph(`/users/${encodeURIComponent(from.email)}/sendMail`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: { subject, body: { contentType: 'HTML', content: html }, from: { emailAddress: { address: from.email, name: from.name } }, toRecipients: [{ emailAddress: { address: to } }] }, saveToSentItems: true }),
  });
  if (res.status === 202) return;
  const t = await res.text(); let msg = t;
  try { msg = JSON.parse(t)?.error?.message || t; } catch { /* not JSON */ }
  if (res.status === 403) msg = 'Microsoft refused: give the app the Mail.Send application permission and grant admin consent (and check the mailbox is allowed). ' + msg;
  if (res.status === 404) msg = `Mailbox ${from.email} not found in Microsoft 365. ` + msg;
  throw new Error(msg);
}
const esc = (t: string) => String(t ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' } as Record<string, string>)[c]);
const button = (href: string, label: string) => `<p><a href="${esc(href)}" style="background:#1d6b55;color:#fff;padding:11px 18px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:bold">${esc(label)}</a></p>`;
const mailBody = (inner: string, company: string) => `<div style="font-family:Arial,sans-serif;font-size:15px;color:#17231e;max-width:560px">${inner}<p style="color:#5b6b63;font-size:12px;margin-top:24px">Sent by Asnys ERP for ${esc(company)}.</p></div>`;
// ---- end of Microsoft 365 part


const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

// Easy to read out or type from a phone: Word-1234-word, about 40 bits of randomness.
const WORDS = ['Tema', 'Volta', 'Kumasi', 'Accra', 'Takoradi', 'Ho', 'Tamale', 'Sunyani', 'Koforidua', 'Cape', 'Ada', 'Keta', 'Aburi', 'Elmina', 'Bole', 'Wa',
  'Cocoa', 'Kente', 'Baobab', 'Shea', 'Mango', 'Palm', 'River', 'Harbour', 'Savanna', 'Forest', 'Falcon', 'Eagle', 'Lion', 'Gazelle', 'Hornbill', 'Pepper'];
const LOWER = 'abcdefghjkmnpqrstuvwxyz';
function tempPassword() {
  const r = new Uint32Array(5);
  crypto.getRandomValues(r);
  const digits = String(1000 + (r[1] % 9000));
  return `${WORDS[r[0] % WORDS.length]}-${digits}-${LOWER[r[2] % LOWER.length]}${LOWER[r[3] % LOWER.length]}${LOWER[r[4] % LOWER.length]}`;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Use POST' }, 405);

  const url = Deno.env.get('SUPABASE_URL')!;
  const anon = Deno.env.get('SUPABASE_ANON_KEY')!;
  const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const auth = req.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return json({ error: 'Sign in first' }, 401);

  let body: { action?: string; company_id?: string; invite_ids?: string[]; user_id?: string; redirect_to?: string };
  try { body = await req.json(); } catch { return json({ error: 'Send JSON' }, 400); }
  const action = body.action || 'invite';
  if (!body.company_id) return json({ error: 'company_id is required' }, 400);

  // Acts as the signed-in person, so the database checks what they may do.
  const asUser = createClient(url, anon, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
  const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } });

  // ---------------------------------------------------------------- New password for an existing member
  if (action === 'set_password') {
    if (!body.user_id) return json({ error: 'user_id is required' }, 400);
    const { data: email, error } = await asUser.rpc('password_reset_target', { cid: body.company_id, p_user: body.user_id });
    if (error) return json({ error: error.message }, 403);
    const password = tempPassword();
    const { error: e } = await admin.auth.admin.updateUserById(body.user_id, { password, user_metadata: { must_change_password: true } });
    if (e) return json({ error: e.message }, 400);
    return json({ results: [{ email, ok: true, password }] });
  }

  if (!Array.isArray(body.invite_ids) || !body.invite_ids.length) return json({ error: 'invite_ids are required' }, 400);
  if (body.invite_ids.length > 200) return json({ error: 'At most 200 at a time' }, 400);

  // ---------------------------------------------------------------- Logins with a temporary password
  if (action === 'create_login') {
    const { data: invites, error } = await asUser.rpc('invites_for_password', { cid: body.company_id, p_ids: body.invite_ids });
    if (error) return json({ error: error.message }, 403);
    const results: { id: string; email: string; ok: boolean; password?: string; note?: string; error?: string }[] = [];
    for (const inv of (invites || []) as { id: string; email: string; role: string; company_name: string; user_id: string | null; signed_in: boolean }[]) {
      const password = tempPassword();
      let err: string | undefined; let note: string | undefined; let pw: string | undefined = password;
      if (!inv.user_id) {
        const { error: e } = await admin.auth.admin.createUser({
          email: inv.email, password, email_confirm: true,
          user_metadata: { must_change_password: true, invited_to: inv.company_name, invited_role: inv.role },
        });
        if (e) err = e.message;
      } else if (!inv.signed_in) {
        // Invited by email before but never signed in: give them a password instead.
        const { error: e } = await admin.auth.admin.updateUserById(inv.user_id, { password, email_confirm: true, user_metadata: { must_change_password: true, invited_to: inv.company_name } });
        if (e) err = e.message;
      } else {
        // Already uses Asnys (perhaps for another company): keep their password; they are added at their next sign-in.
        pw = undefined; note = 'Already has a login. They sign in with their existing password and are added to this company.';
      }
      await asUser.rpc('mark_invite_sent', { p_id: inv.id, p_ok: !err, p_error: err ?? null, p_method: 'password' });
      results.push({ id: inv.id, email: inv.email, ok: !err, password: err ? undefined : pw, note, error: err });
    }
    return json({ sent: results.filter(r => r.ok).length, failed: results.filter(r => !r.ok).length, results });
  }

  // ---------------------------------------------------------------- Email invitations (as before)
  const { data: invites, error } = await asUser.rpc('invites_to_send', { cid: body.company_id, p_ids: body.invite_ids });
  if (error) return json({ error: error.message }, 403);

  // Links go back to the app. SITE_URL wins; otherwise the app's own address, which must be in Supabase's redirect URLs.
  const site = (Deno.env.get('SITE_URL') || body.redirect_to || '').replace(/\/$/, '');
  const redirectTo = site ? `${site}/` : undefined;

  const plain = createClient(url, anon, { auth: { persistSession: false } });
  const results: { id: string; email: string; ok: boolean; method?: string; error?: string }[] = [];
  const { data: m365 } = await admin.rpc('m365_sender', { cid: body.company_id });

  // Through the company's Microsoft 365 mailbox: Supabase makes the link, Asnys emails it.
  if (m365) {
    for (const inv of (invites || []) as { id: string; email: string; role: string; company_name: string; has_login: boolean }[]) {
      let err: string | undefined; const method = inv.has_login ? 'magic_link' : 'invite';
      try {
        const { data: link, error: e } = await admin.auth.admin.generateLink(inv.has_login
          ? { type: 'magiclink', email: inv.email, options: { redirectTo } }
          : { type: 'invite', email: inv.email, options: { redirectTo, data: { invited_to: inv.company_name, invited_role: inv.role } } });
        if (e || !link?.properties?.action_link) throw new Error(e?.message || 'Could not make the link');
        await sendMail({ email: m365.from_email, name: m365.from_name }, inv.email,
          inv.has_login ? `You now have access to ${inv.company_name} on Asnys ERP` : `You're invited to ${inv.company_name} on Asnys ERP`,
          mailBody(inv.has_login
            ? `<p>You have been added to <b>${esc(inv.company_name)}</b> on Asnys ERP.</p>${button(link.properties.action_link, 'Open Asnys ERP')}<p>Sign in as usual with ${esc(inv.email)} and your password.</p>`
            : `<h2 style="margin:0 0 12px">Welcome to ${esc(inv.company_name)}</h2><p>You have been invited to use Asnys ERP, our system for projects, timesheets, expenses, leave and stores.</p>${button(link.properties.action_link, 'Accept and choose your password')}<p>From then on, sign in with this email address (${esc(inv.email)}) and your password. If the link has expired, ask HR to resend your invitation.</p>`,
            m365.company));
      } catch (e) { err = (e as Error).message; }
      await asUser.rpc('mark_invite_sent', { p_id: inv.id, p_ok: !err, p_error: err ?? null, p_method: method });
      results.push({ id: inv.id, email: inv.email, ok: !err, method, error: err });
    }
    return json({ sent: results.filter(r => r.ok).length, failed: results.filter(r => !r.ok).length, results });
  }

  for (const inv of (invites || []) as { id: string; email: string; role: string; company_name: string; has_login: boolean }[]) {
    let method = inv.has_login ? 'magic_link' : 'invite';
    let err: string | undefined;
    if (!inv.has_login) {
      const { error: e } = await admin.auth.admin.inviteUserByEmail(inv.email, {
        redirectTo, data: { invited_to: inv.company_name, invited_role: inv.role },
      });
      if (e && /already|registered|exists/i.test(e.message)) method = 'magic_link';
      else if (e) err = e.message;
    }
    if (method === 'magic_link') {
      // Already has an Asnys login (perhaps for another company): a sign-in link adds them on arrival.
      const { error: e } = await plain.auth.signInWithOtp({ email: inv.email, options: { shouldCreateUser: false, emailRedirectTo: redirectTo } });
      if (e) err = e.message;
    }
    await asUser.rpc('mark_invite_sent', { p_id: inv.id, p_ok: !err, p_error: err ?? null, p_method: method });
    results.push({ id: inv.id, email: inv.email, ok: !err, method, error: err });
  }
  return json({ sent: results.filter(r => r.ok).length, failed: results.filter(r => !r.ok).length, results });
});
